TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB) /home/runner/work/vibescript/vibescript/base/vibes/value/value_methods.go
  value_methods.go:605		0x5aed00		4c8da42488feffff	LEAQ 0xfffffe88(SP), R12									
  value_methods.go:605		0x5aed08		4d3b6610		CMPQ R12, 0x10(R14)										
  value_methods.go:605		0x5aed0c		0f86c9060000		JBE 0x5af3db											
  value_methods.go:605		0x5aed12		55			PUSHQ BP											
  value_methods.go:605		0x5aed13		4889e5			MOVQ SP, BP											
  value_methods.go:605		0x5aed16		4881ecf0010000		SUBQ $0x1f0, SP											
  value_methods.go:605		0x5aed1d		48899c2408020000	MOVQ BX, 0x208(SP)										
  value_methods.go:605		0x5aed25		48898c2410020000	MOVQ CX, 0x210(SP)										
  value_methods.go:607		0x5aed2d		4889b42420020000	MOVQ SI, 0x220(SP)										
  value_methods.go:605		0x5aed35		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  value_methods.go:605		0x5aed3e		6690			NOPW												
  value_methods.go:607		0x5aed40		4883f805		CMPQ AX, $0x5											
  value_methods.go:607		0x5aed44		0f8493020000		JE 0x5aefdd											
  value_methods.go:627		0x5aed4a		4883f806		CMPQ AX, $0x6											
  value_methods.go:627		0x5aed4e		0f84d5000000		JE 0x5aee29											
  value_methods.go:647		0x5aed54		4883f814		CMPQ AX, $0x14											
  value_methods.go:647		0x5aed58		0f8488000000		JE 0x5aede6											
  value_methods.go:652		0x5aed5e		488b151b055b00		MOVQ github.com/mgomes/vibescript/vibes/value.RuntimeStringRuneLen(SB), DX			
  value_methods.go:652		0x5aed65		4885d2			TESTQ DX, DX											
  value_methods.go:652		0x5aed68		7449			JE 0x5aedb3											
  value_methods.go:607		0x5aed6a		4889bc2418010000	MOVQ DI, 0x118(SP)										
  value_methods.go:607		0x5aed72		48898c24e8010000	MOVQ CX, 0x1e8(SP)										
  value_methods.go:607		0x5aed7a		48899c2410010000	MOVQ BX, 0x110(SP)										
  value_methods.go:607		0x5aed82		4889842408010000	MOVQ AX, 0x108(SP)										
  value_methods.go:653		0x5aed8a		488b32			MOVQ 0(DX), SI											
  value_methods.go:653		0x5aed8d		ffd6			CALL SI												
  value_methods.go:653		0x5aed8f		84db			TESTL BL, BL											
  value_methods.go:653		0x5aed91		753b			JNE 0x5aedce											
  value_methods.go:657		0x5aed93		488b842408010000	MOVQ 0x108(SP), AX										
  value_methods.go:657		0x5aed9b		488b8c24e8010000	MOVQ 0x1e8(SP), CX										
  value_methods.go:657		0x5aeda3		488b9c2410010000	MOVQ 0x110(SP), BX										
  value_methods.go:657		0x5aedab		488bbc2418010000	MOVQ 0x118(SP), DI										
  value_methods.go:657		0x5aedb3		e868d5ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  value_methods.go:657		0x5aedb8		4889842428010000	MOVQ AX, 0x128(SP)										
  value_methods.go:657		0x5aedc0		48895c2458		MOVQ BX, 0x58(SP)										
  utf8.go:448			0x5aedc5		31d2			XORL DX, DX											
  utf8.go:448			0x5aedc7		31f6			XORL SI, SI											
  utf8.go:448			0x5aedc9		e9bd050000		JMP 0x5af38b											
  value_methods.go:654		0x5aedce		4889442440		MOVQ AX, 0x40(SP)										
  value_methods.go:659		0x5aedd3		e848d0e9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:654		0x5aedd8		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aeddd		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aede4		5d			POPQ BP												
  value_methods.go:659		0x5aede5		c3			RET												
  value_methods.go:650		0x5aede6		488d158b7b5500		LEAQ 0x557b8b(IP), DX										
  value_methods.go:650		0x5aeded		4839d3			CMPQ BX, DX											
  value_methods.go:650		0x5aedf0		0f857b050000		JNE 0x5af371											
  value_methods.go:650		0x5aedf6		488b01			MOVQ 0(CX), AX											
  value_methods.go:650		0x5aedf9		488b5908		MOVQ 0x8(CX), BX										
  value_methods.go:650		0x5aedfd		488b5110		MOVQ 0x10(CX), DX										
  value_methods.go:650		0x5aee01		488b7918		MOVQ 0x18(CX), DI										
  value_methods.go:650		0x5aee05		488b7120		MOVQ 0x20(CX), SI										
  value_methods.go:650		0x5aee09		4889d1			MOVQ DX, CX											
  value_methods.go:650		0x5aee0c		e86f69ffff		CALL github.com/mgomes/vibescript/vibes/value.Regex.StringRuneLen(SB)				
  value_methods.go:650		0x5aee11		4889442440		MOVQ AX, 0x40(SP)										
  value_methods.go:659		0x5aee16		e805d0e9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:650		0x5aee1b		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aee20		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aee27		5d			POPQ BP												
  value_methods.go:659		0x5aee28		c3			RET												
  value_methods.go:628		0x5aee29		90			NOPL												
  value_accessors.go:113	0x5aee2a		488d15efc55000		LEAQ 0x50c5ef(IP), DX										
  value_accessors.go:113	0x5aee31		4839d3			CMPQ BX, DX											
  value_accessors.go:113	0x5aee34		0f8525050000		JNE 0x5af35f											
  value_accessors.go:113	0x5aee3a		488b19			MOVQ 0(CX), BX											
  value_accessors.go:113	0x5aee3d		0f1f00			NOPL 0(AX)											
  value_methods.go:629		0x5aee40		4885db			TESTQ BX, BX											
  value_methods.go:629		0x5aee43		7405			JE 0x5aee4a											
  value_methods.go:629		0x5aee45		488b13			MOVQ 0(BX), DX											
  value_methods.go:629		0x5aee48		eb02			JMP 0x5aee4c											
  value_methods.go:629		0x5aee4a		31d2			XORL DX, DX											
  value_methods.go:629		0x5aee4c		4885d2			TESTQ DX, DX											
  value_methods.go:629		0x5aee4f		0f846c010000		JE 0x5aefc1											
  value_accessors.go:113	0x5aee55		48899c24e0010000	MOVQ BX, 0x1e0(SP)										
  type.go:208			0x5aee5d		0fb615607a5100		MOVZX 0x517a60(IP), DX										
  value.go:165			0x5aee64		90			NOPL												
  type.go:208			0x5aee65		f6c220			TESTL $0x20, DL											
  value.go:3164			0x5aee68		b995000000		MOVL $0x95, CX											
  value.go:3164			0x5aee6d		ba15000000		MOVL $0x15, DX											
  value.go:3164			0x5aee72		480f45ca		CMOVNE DX, CX											
  value_methods.go:632		0x5aee76		488d05337a5100		LEAQ 0x517a33(IP), AX										
  value_methods.go:632		0x5aee7d		0f1f00			NOPL 0(AX)											
  value_methods.go:632		0x5aee80		e8fb7ff1ff		CALL reflect.Value.Pointer(SB)									
  value_methods.go:633		0x5aee85		4885c0			TESTQ AX, AX											
  value_methods.go:633		0x5aee88		7510			JNE 0x5aee9a											
  value_methods.go:629		0x5aee8a		488b9c24e0010000	MOVQ 0x1e0(SP), BX										
  value_methods.go:629		0x5aee92		4885db			TESTQ BX, BX											
  value_methods.go:633		0x5aee95		e9a9000000		JMP 0x5aef43											
  value_methods.go:632		0x5aee9a		4889442460		MOVQ AX, 0x60(SP)										
  value_methods.go:634		0x5aee9f		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:634		0x5aeea7		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:634		0x5aeeab		4889c1			MOVQ AX, CX											
  value_methods.go:634		0x5aeeae		488d053b7e5100		LEAQ 0x517e3b(IP), AX										
  value_methods.go:634		0x5aeeb5		e806fce5ff		CALL runtime.mapaccess2_fast64(SB)								
  value_methods.go:634		0x5aeeba		660f1f440000		NOPW 0(AX)(AX*1)										
  value_methods.go:634		0x5aeec0		84db			TESTL BL, BL											
  value_methods.go:634		0x5aeec2		0f85dd000000		JNE 0x5aefa5											
  value_methods.go:637		0x5aeec8		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:637		0x5aeed0		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:637		0x5aeed4		488d05157e5100		LEAQ 0x517e15(IP), AX										
  value_methods.go:637		0x5aeedb		488b4c2460		MOVQ 0x60(SP), CX										
  value_methods.go:637		0x5aeee0		e85bfee5ff		CALL runtime.mapassign_fast64(SB)								
  value_methods.go:637		0x5aeee5		8400			TESTB AL, 0(AX)											
  value_methods.go:638		0x5aeee7		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:638		0x5aeeef		488b5208		MOVQ 0x8(DX), DX										
  value_methods.go:638		0x5aeef3		488d35065c0000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB), SI	
  value_methods.go:638		0x5aeefa		4889b42438010000	MOVQ SI, 0x138(SP)										
  value_methods.go:638		0x5aef02		4889942440010000	MOVQ DX, 0x140(SP)										
  value_methods.go:638		0x5aef0a		488b542460		MOVQ 0x60(SP), DX										
  value_methods.go:638		0x5aef0f		4889942448010000	MOVQ DX, 0x148(SP)										
  value_methods.go:638		0x5aef17		488d942438010000	LEAQ 0x138(SP), DX										
  value_methods.go:638		0x5aef1f		48899424a0000000	MOVQ DX, 0xa0(SP)										
  value_methods.go:638		0x5aef27		488d842488000000	LEAQ 0x88(SP), AX										
  value_methods.go:638		0x5aef2f		e8ccc9e9ff		CALL runtime.deferprocStack(SB)									
  value_methods.go:629		0x5aef34		488b9c24e0010000	MOVQ 0x1e0(SP), BX										
  value_methods.go:629		0x5aef3c		0f1f4000		NOPL 0(AX)											
  value_methods.go:629		0x5aef40		4885db			TESTQ BX, BX											
  value_methods.go:641		0x5aef43		7405			JE 0x5aef4a											
  value_methods.go:641		0x5aef45		488b13			MOVQ 0(BX), DX											
  value_methods.go:641		0x5aef48		eb02			JMP 0x5aef4c											
  value_methods.go:641		0x5aef4a		31d2			XORL DX, DX											
  value_methods.go:1031		0x5aef4c		4883fa02		CMPQ DX, $0x2											
  value_methods.go:1031		0x5aef50		7d04			JGE 0x5aef56											
  value_methods.go:1031		0x5aef52		31d2			XORL DX, DX											
  value_methods.go:641		0x5aef54		eb08			JMP 0x5aef5e											
  value_methods.go:1034		0x5aef56		488d1412		LEAQ 0(DX)(DX*1), DX										
  value_methods.go:1034		0x5aef5a		488d52fe		LEAQ -0x2(DX), DX										
  value_methods.go:641		0x5aef5e		4889542438		MOVQ DX, 0x38(SP)										
  value_methods.go:642		0x5aef63		488d8c2478010000	LEAQ 0x178(SP), CX										
  value_methods.go:642		0x5aef6b		440f1139		MOVUPS X15, 0(CX)										
  value_methods.go:642		0x5aef6f		440f117910		MOVUPS X15, 0x10(CX)										
  value_methods.go:642		0x5aef74		440f117920		MOVUPS X15, 0x20(CX)										
  value_methods.go:642		0x5aef79		440f117930		MOVUPS X15, 0x30(CX)										
  value_methods.go:642		0x5aef7e		440f117940		MOVUPS X15, 0x40(CX)										
  value_methods.go:642		0x5aef83		440f117950		MOVUPS X15, 0x50(CX)										
  value_methods.go:642		0x5aef88		488d0521795100		LEAQ 0x517921(IP), AX										
  value_methods.go:642		0x5aef8f		e86c59e7ff		CALL runtime.mapIterStart(SB)									
  value_methods.go:641		0x5aef94		488b542438		MOVQ 0x38(SP), DX										
  value_methods.go:641		0x5aef99		4883c202		ADDQ $0x2, DX											
  value_methods.go:641		0x5aef9d		0f1f00			NOPL 0(AX)											
  value_methods.go:642		0x5aefa0		e9d4020000		JMP 0x5af279											
  value_methods.go:635		0x5aefa5		48c744244007000000	MOVQ $0x7, 0x40(SP)										
  value_methods.go:659		0x5aefae		e86dcee9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:635		0x5aefb3		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aefb8		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aefbf		5d			POPQ BP												
  value_methods.go:659		0x5aefc0		c3			RET												
  value_methods.go:630		0x5aefc1		48c744244002000000	MOVQ $0x2, 0x40(SP)										
  value_methods.go:659		0x5aefca		e851cee9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:630		0x5aefcf		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aefd4		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aefdb		5d			POPQ BP												
  value_methods.go:659		0x5aefdc		c3			RET												
  value_methods.go:608		0x5aefdd		90			NOPL												
  value_accessors.go:86		0x5aefde		488d1593c35000		LEAQ 0x50c393(IP), DX										
  value_accessors.go:86		0x5aefe5		4839d3			CMPQ BX, DX											
  value_accessors.go:86		0x5aefe8		0f8534020000		JNE 0x5af222											
  value_accessors.go:86		0x5aefee		488b5908		MOVQ 0x8(CX), BX										
  value_accessors.go:86		0x5aeff2		48895c2428		MOVQ BX, 0x28(SP)										
  value_accessors.go:86		0x5aeff7		488b5110		MOVQ 0x10(CX), DX										
  value_accessors.go:86		0x5aeffb		4889542430		MOVQ DX, 0x30(SP)										
  value_accessors.go:86		0x5af000		488b01			MOVQ 0(CX), AX											
  value_accessors.go:86		0x5af003		4889842420010000	MOVQ AX, 0x120(SP)										
  value_methods.go:610		0x5af00b		4889d1			MOVQ DX, CX											
  value_methods.go:610		0x5af00e		e84d6bedff		CALL runtime.convTslice(SB)									
  type.go:208			0x5af013		0fb615421b5100		MOVZX 0x511b42(IP), DX										
  value.go:165			0x5af01a		90			NOPL												
  type.go:208			0x5af01b		f6c220			TESTL $0x20, DL											
  value.go:3164			0x5af01e		b997000000		MOVL $0x97, CX											
  value.go:3164			0x5af023		ba17000000		MOVL $0x17, DX											
  value.go:3164			0x5af028		480f45ca		CMOVNE DX, CX											
  value_methods.go:610		0x5af02c		4889c3			MOVQ AX, BX											
  value_methods.go:610		0x5af02f		488d05121b5100		LEAQ 0x511b12(IP), AX										
  value_methods.go:610		0x5af036		e8457ef1ff		CALL reflect.Value.Pointer(SB)									
  value_methods.go:610		0x5af03b		0f1f440000		NOPL 0(AX)(AX*1)										
  value_methods.go:614		0x5af040		4885c0			TESTQ AX, AX											
  value_methods.go:614		0x5af043		0f8407010000		JE 0x5af150											
  value_methods.go:610		0x5af049		4889842480000000	MOVQ AX, 0x80(SP)										
  value_methods.go:615		0x5af051		48898424e8000000	MOVQ AX, 0xe8(SP)										
  value_methods.go:615		0x5af059		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:615		0x5af05e		48899424f0000000	MOVQ DX, 0xf0(SP)										
  value_methods.go:615		0x5af066		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:615		0x5af06b		48899424f8000000	MOVQ DX, 0xf8(SP)										
  value_methods.go:615		0x5af073		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:615		0x5af07b		488b1a			MOVQ 0(DX), BX											
  value_methods.go:615		0x5af07e		488d058b7e5100		LEAQ 0x517e8b(IP), AX										
  value_methods.go:615		0x5af085		488d8c24e8000000	LEAQ 0xe8(SP), CX										
  value_methods.go:615		0x5af08d		e88eeae5ff		CALL runtime.mapaccess2(SB)									
  value_methods.go:615		0x5af092		84db			TESTL BL, BL											
  value_methods.go:615		0x5af094		0f85f9000000		JNE 0x5af193											
  value_methods.go:618		0x5af09a		488b942480000000	MOVQ 0x80(SP), DX										
  value_methods.go:618		0x5af0a2		48899424e8000000	MOVQ DX, 0xe8(SP)										
  value_methods.go:618		0x5af0aa		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:618		0x5af0af		48899424f0000000	MOVQ DX, 0xf0(SP)										
  value_methods.go:618		0x5af0b7		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:618		0x5af0bc		48899424f8000000	MOVQ DX, 0xf8(SP)										
  value_methods.go:618		0x5af0c4		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:618		0x5af0cc		488b1a			MOVQ 0(DX), BX											
  value_methods.go:618		0x5af0cf		488d053a7e5100		LEAQ 0x517e3a(IP), AX										
  value_methods.go:618		0x5af0d6		488d8c24e8000000	LEAQ 0xe8(SP), CX										
  value_methods.go:618		0x5af0de		6690			NOPW												
  value_methods.go:618		0x5af0e0		e81bede5ff		CALL runtime.mapassign(SB)									
  value_methods.go:618		0x5af0e5		8400			TESTB AL, 0(AX)											
  value_methods.go:619		0x5af0e7		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:619		0x5af0ef		488b12			MOVQ 0(DX), DX											
  value_methods.go:619		0x5af0f2		488d35475a0000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB), SI	
  value_methods.go:619		0x5af0f9		4889b42450010000	MOVQ SI, 0x150(SP)										
  value_methods.go:619		0x5af101		4889942458010000	MOVQ DX, 0x158(SP)										
  value_methods.go:619		0x5af109		488b942480000000	MOVQ 0x80(SP), DX										
  value_methods.go:619		0x5af111		4889942460010000	MOVQ DX, 0x160(SP)										
  value_methods.go:619		0x5af119		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:619		0x5af11e		4889942468010000	MOVQ DX, 0x168(SP)										
  value_methods.go:619		0x5af126		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:619		0x5af12b		4889942470010000	MOVQ DX, 0x170(SP)										
  value_methods.go:619		0x5af133		488d942450010000	LEAQ 0x150(SP), DX										
  value_methods.go:619		0x5af13b		48899424d0000000	MOVQ DX, 0xd0(SP)										
  value_methods.go:619		0x5af143		488d8424b8000000	LEAQ 0xb8(SP), AX										
  value_methods.go:619		0x5af14b		e8b0c7e9ff		CALL runtime.deferprocStack(SB)									
  value_methods.go:1031		0x5af150		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:1031		0x5af155		4883fa02		CMPQ DX, $0x2											
  value_methods.go:1031		0x5af159		7d07			JGE 0x5af162											
  value_methods.go:1031		0x5af15b		4531c0			XORL R8, R8											
  value_methods.go:1031		0x5af15e		6690			NOPW												
  value_methods.go:622		0x5af160		eb08			JMP 0x5af16a											
  value_methods.go:1034		0x5af162		4c8d0412		LEAQ 0(DX)(DX*1), R8										
  value_methods.go:1034		0x5af166		4d8d40fe		LEAQ -0x2(R8), R8										
  value_methods.go:622		0x5af16a		4983c002		ADDQ $0x2, R8											
  value_methods.go:623		0x5af16e		4c8b8c2420010000	MOVQ 0x120(SP), R9										
  value_methods.go:623		0x5af176		e98a000000		JMP 0x5af205											
  value_methods.go:659		0x5af17b		0f1f440000		NOPL 0(AX)(AX*1)										
  value_methods.go:659		0x5af180		e89bcce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:619		0x5af185		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af18a		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af191		5d			POPQ BP												
  value_methods.go:659		0x5af192		c3			RET												
  value_methods.go:616		0x5af193		48c744244007000000	MOVQ $0x7, 0x40(SP)										
  value_methods.go:616		0x5af19c		0f1f4000		NOPL 0(AX)											
  value_methods.go:659		0x5af1a0		e87bcce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:616		0x5af1a5		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af1aa		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af1b1		5d			POPQ BP												
  value_methods.go:659		0x5af1b2		c3			RET												
  value_methods.go:623		0x5af1b3		4889942400010000	MOVQ DX, 0x100(SP)										
  value_methods.go:623		0x5af1bb		4c89442450		MOVQ R8, 0x50(SP)										
  value_methods.go:623		0x5af1c0		4c898c24d8010000	MOVQ R9, 0x1d8(SP)										
  value_methods.go:623		0x5af1c8		498b01			MOVQ 0(R9), AX											
  value_methods.go:623		0x5af1cb		498b4910		MOVQ 0x10(R9), CX										
  value_methods.go:623		0x5af1cf		498b7918		MOVQ 0x18(R9), DI										
  value_methods.go:623		0x5af1d3		498b5908		MOVQ 0x8(R9), BX										
  value_methods.go:624		0x5af1d7		488bb42420020000	MOVQ 0x220(SP), SI										
  value_methods.go:624		0x5af1df		90			NOPL												
  value_methods.go:624		0x5af1e0		e81bfbffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			
  value_methods.go:623		0x5af1e5		4c8b8c24d8010000	MOVQ 0x1d8(SP), R9										
  value_methods.go:623		0x5af1ed		4983c120		ADDQ $0x20, R9											
  value_methods.go:624		0x5af1f1		488b542450		MOVQ 0x50(SP), DX										
  value_methods.go:624		0x5af1f6		4c8d0402		LEAQ 0(DX)(AX*1), R8										
  value_methods.go:623		0x5af1fa		488b942400010000	MOVQ 0x100(SP), DX										
  value_methods.go:623		0x5af202		48ffca			DECQ DX												
  value_methods.go:623		0x5af205		4885d2			TESTQ DX, DX											
  value_methods.go:623		0x5af208		7fa9			JG 0x5af1b3											
  value_methods.go:626		0x5af20a		4c89442440		MOVQ R8, 0x40(SP)										
  value_methods.go:659		0x5af20f		e80ccce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:626		0x5af214		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af219		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af220		5d			POPQ BP												
  value_methods.go:659		0x5af221		c3			RET												
  value_accessors.go:86		0x5af222		4889d8			MOVQ BX, AX											
  value_accessors.go:86		0x5af225		4889d3			MOVQ DX, BX											
  value_accessors.go:86		0x5af228		488d0d01735300		LEAQ 0x537301(IP), CX										
  value_accessors.go:86		0x5af22f		e80cdce6ff		CALL runtime.panicdottypeE(SB)									
  value_methods.go:644		0x5af234		4c89c0			MOVQ R8, AX											
  value_methods.go:644		0x5af237		4c89d3			MOVQ R10, BX											
  value_methods.go:644		0x5af23a		488bb42420020000	MOVQ 0x220(SP), SI										
  value_methods.go:644		0x5af242		e8b9faffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			
  value_methods.go:644		0x5af247		4889842400010000	MOVQ AX, 0x100(SP)										
  value_methods.go:642		0x5af24f		488d842478010000	LEAQ 0x178(SP), AX										
  value_methods.go:642		0x5af257		e80457e7ff		CALL runtime.mapIterNext(SB)									
  value_methods.go:643		0x5af25c		488b542470		MOVQ 0x70(SP), DX										
  value_methods.go:643		0x5af261		4c8b442448		MOVQ 0x48(SP), R8										
  value_methods.go:643		0x5af266		4c01c2			ADDQ R8, DX											
  value_methods.go:644		0x5af269		4c8b842400010000	MOVQ 0x100(SP), R8										
  value_methods.go:644		0x5af271		4a8d1402		LEAQ 0(DX)(R8*1), DX										
  value_methods.go:644		0x5af275		488d5202		LEAQ 0x2(DX), DX										
  value_methods.go:642		0x5af279		4c8b842478010000	MOVQ 0x178(SP), R8										
  value_methods.go:642		0x5af281		4d85c0			TESTQ R8, R8											
  value_methods.go:642		0x5af284		0f84bd000000		JE 0x5af347											
  value_methods.go:642		0x5af28a		4889542448		MOVQ DX, 0x48(SP)										
  value_methods.go:642		0x5af28f		4c8b8c2480010000	MOVQ 0x180(SP), R9										
  value_methods.go:642		0x5af297		498b00			MOVQ 0(R8), AX											
  value_methods.go:642		0x5af29a		4889842430010000	MOVQ AX, 0x130(SP)										
  value_methods.go:642		0x5af2a2		498b5808		MOVQ 0x8(R8), BX										
  value_methods.go:642		0x5af2a6		48895c2478		MOVQ BX, 0x78(SP)										
  value_methods.go:642		0x5af2ab		4d8b01			MOVQ 0(R9), R8											
  value_methods.go:642		0x5af2ae		4c89842408010000	MOVQ R8, 0x108(SP)										
  value_methods.go:642		0x5af2b6		4d8b5108		MOVQ 0x8(R9), R10										
  value_methods.go:642		0x5af2ba		4c89942410010000	MOVQ R10, 0x110(SP)										
  value_methods.go:642		0x5af2c2		498b4910		MOVQ 0x10(R9), CX										
  value_methods.go:642		0x5af2c6		48898c24e8010000	MOVQ CX, 0x1e8(SP)										
  value_methods.go:642		0x5af2ce		498b7918		MOVQ 0x18(R9), DI										
  value_methods.go:642		0x5af2d2		4889bc2418010000	MOVQ DI, 0x118(SP)										
  utf8.go:448			0x5af2da		4531c9			XORL R9, R9											
  utf8.go:448			0x5af2dd		4531db			XORL R11, R11											
  utf8.go:448			0x5af2e0		eb03			JMP 0x5af2e5											
  utf8.go:449			0x5af2e2		49ffc1			INCQ R9												
  utf8.go:448			0x5af2e5		4c894c2470		MOVQ R9, 0x70(SP)										
  utf8.go:448			0x5af2ea		4939db			CMPQ R11, BX											
  utf8.go:448			0x5af2ed		0f8d41ffffff		JGE 0x5af234											
  utf8.go:448			0x5af2f3		450fb62403		MOVZX 0(R11)(AX*1), R12										
  utf8.go:448			0x5af2f8		4183fc7f		CMPL R12, $0x7f											
  utf8.go:448			0x5af2fc		7f05			JG 0x5af303											
  utf8.go:448			0x5af2fe		49ffc3			INCQ R11											
  utf8.go:448			0x5af301		ebdf			JMP 0x5af2e2											
  utf8.go:448			0x5af303		4c89d9			MOVQ R11, CX											
  utf8.go:448			0x5af306		e8f5deecff		CALL runtime.decoderune(SB)									
  utf8.go:448			0x5af30b		488b842430010000	MOVQ 0x130(SP), AX										
  value_methods.go:644		0x5af313		488b8c24e8010000	MOVQ 0x1e8(SP), CX										
  value_methods.go:643		0x5af31b		488b542448		MOVQ 0x48(SP), DX										
  value_methods.go:644		0x5af320		488bbc2418010000	MOVQ 0x118(SP), DI										
  value_methods.go:644		0x5af328		4c8b842408010000	MOVQ 0x108(SP), R8										
  utf8.go:449			0x5af330		4c8b4c2470		MOVQ 0x70(SP), R9										
  value_methods.go:644		0x5af335		4c8b942410010000	MOVQ 0x110(SP), R10										
  utf8.go:449			0x5af33d		4989db			MOVQ BX, R11											
  utf8.go:448			0x5af340		488b5c2478		MOVQ 0x78(SP), BX										
  utf8.go:448			0x5af345		eb9b			JMP 0x5af2e2											
  value_methods.go:646		0x5af347		4889542440		MOVQ DX, 0x40(SP)										
  value_methods.go:659		0x5af34c		e8cfcae9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:646		0x5af351		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af356		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af35d		5d			POPQ BP												
  value_methods.go:659		0x5af35e		c3			RET												
  value_accessors.go:113	0x5af35f		4889d8			MOVQ BX, AX											
  value_accessors.go:113	0x5af362		4889d3			MOVQ DX, BX											
  value_accessors.go:113	0x5af365		488d0dc4715300		LEAQ 0x5371c4(IP), CX										
  value_accessors.go:113	0x5af36c		e8cfdae6ff		CALL runtime.panicdottypeE(SB)									
  value_methods.go:650		0x5af371		4889d8			MOVQ BX, AX											
  value_methods.go:650		0x5af374		4889d3			MOVQ DX, BX											
  value_methods.go:650		0x5af377		488d0db2715300		LEAQ 0x5371b2(IP), CX										
  value_methods.go:650		0x5af37e		6690			NOPW												
  value_methods.go:650		0x5af380		e8bbdae6ff		CALL runtime.panicdottypeE(SB)									
  utf8.go:449			0x5af385		48ffc6			INCQ SI												
  utf8.go:448			0x5af388		4889ca			MOVQ CX, DX											
  utf8.go:448			0x5af38b		4839d3			CMPQ BX, DX											
  utf8.go:448			0x5af38e		7e33			JLE 0x5af3c3											
  utf8.go:448			0x5af390		0fb63c10		MOVZX 0(AX)(DX*1), DI										
  utf8.go:448			0x5af394		83ff7f			CMPL DI, $0x7f											
  utf8.go:448			0x5af397		7f06			JG 0x5af39f											
  utf8.go:448			0x5af399		488d4a01		LEAQ 0x1(DX), CX										
  utf8.go:448			0x5af39d		ebe6			JMP 0x5af385											
  utf8.go:448			0x5af39f		4889742468		MOVQ SI, 0x68(SP)										
  utf8.go:448			0x5af3a4		4889d1			MOVQ DX, CX											
  utf8.go:448			0x5af3a7		e854deecff		CALL runtime.decoderune(SB)									
  utf8.go:448			0x5af3ac		488b842428010000	MOVQ 0x128(SP), AX										
  utf8.go:449			0x5af3b4		488b742468		MOVQ 0x68(SP), SI										
  utf8.go:449			0x5af3b9		4889d9			MOVQ BX, CX											
  utf8.go:448			0x5af3bc		488b5c2458		MOVQ 0x58(SP), BX										
  utf8.go:448			0x5af3c1		ebc2			JMP 0x5af385											
  value_methods.go:657		0x5af3c3		4889742440		MOVQ SI, 0x40(SP)										
  value_methods.go:659		0x5af3c8		e853cae9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:657		0x5af3cd		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af3d2		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af3d9		5d			POPQ BP												
  value_methods.go:659		0x5af3da		c3			RET												
  value_methods.go:605		0x5af3db		4889442408		MOVQ AX, 0x8(SP)										
  value_methods.go:605		0x5af3e0		48895c2410		MOVQ BX, 0x10(SP)										
  value_methods.go:605		0x5af3e5		48894c2418		MOVQ CX, 0x18(SP)										
  value_methods.go:605		0x5af3ea		48897c2420		MOVQ DI, 0x20(SP)										
  value_methods.go:605		0x5af3ef		4889742428		MOVQ SI, 0x28(SP)										
  value_methods.go:605		0x5af3f4		e847d2edff		CALL runtime.morestack_noctxt.abi0(SB)								
  value_methods.go:605		0x5af3f9		488b442408		MOVQ 0x8(SP), AX										
  value_methods.go:605		0x5af3fe		488b5c2410		MOVQ 0x10(SP), BX										
  value_methods.go:605		0x5af403		488b4c2418		MOVQ 0x18(SP), CX										
  value_methods.go:605		0x5af408		488b7c2420		MOVQ 0x20(SP), DI										
  value_methods.go:605		0x5af40d		488b742428		MOVQ 0x28(SP), SI										
  value_methods.go:605		0x5af412		e9e9f8ffff		JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB) /home/runner/work/vibescript/vibescript/base/vibes/value/value_methods.go
  value_methods.go:844		0x5b0780		4c8da42468feffff	LEAQ 0xfffffe68(SP), R12										
  value_methods.go:844		0x5b0788		4d3b6610		CMPQ R12, 0x10(R14)											
  value_methods.go:844		0x5b078c		0f86210a0000		JBE 0x5b11b3												
  value_methods.go:844		0x5b0792		55			PUSHQ BP												
  value_methods.go:844		0x5b0793		4889e5			MOVQ SP, BP												
  value_methods.go:844		0x5b0796		4881ec10020000		SUBQ $0x210, SP												
  value_methods.go:844		0x5b079d		48899c2428020000	MOVQ BX, 0x228(SP)											
  value_methods.go:844		0x5b07a5		48898c2430020000	MOVQ CX, 0x230(SP)											
  value_methods.go:845		0x5b07ad		4889b42440020000	MOVQ SI, 0x240(SP)											
  value_methods.go:845		0x5b07b5		4c89842448020000	MOVQ R8, 0x248(SP)											
  value_methods.go:845		0x5b07bd		48898c24f0010000	MOVQ CX, 0x1f0(SP)											
  value_methods.go:845		0x5b07c5		48899c24c8000000	MOVQ BX, 0xc8(SP)											
  value_methods.go:845		0x5b07cd		48898424c0000000	MOVQ AX, 0xc0(SP)											
  value_methods.go:845		0x5b07d5		4889bc24b8000000	MOVQ DI, 0xb8(SP)											
  value_methods.go:844		0x5b07dd		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:844		0x5b07e6		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:845		0x5b07ef		498b00			MOVQ 0(R8), AX												
  value_methods.go:845		0x5b07f2		4c89c2			MOVQ R8, DX												
  value_methods.go:845		0x5b07f5		ffd0			CALL AX													
  value_methods.go:845		0x5b07f7		660f1f840000000000	NOPW 0(AX)(AX*1)											
  value_methods.go:845		0x5b0800		4885c0			TESTQ AX, AX												
  value_methods.go:845		0x5b0803		0f854d050000		JNE 0x5b0d56												
  value_methods.go:849		0x5b0809		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:849		0x5b0811		4883f805		CMPQ AX, $0x5												
  value_methods.go:849		0x5b0815		0f85e5010000		JNE 0x5b0a00												
  value_methods.go:850		0x5b081b		90			NOPL													
  value_accessors.go:86		0x5b081c		488b8424c8000000	MOVQ 0xc8(SP), AX											
  value_accessors.go:86		0x5b0824		488d1d4dab5000		LEAQ 0x50ab4d(IP), BX											
  value_accessors.go:86		0x5b082b		4839d8			CMPQ AX, BX												
  value_accessors.go:86		0x5b082e		0f8572090000		JNE 0x5b11a6												
  value_accessors.go:86		0x5b0834		488b9424f0010000	MOVQ 0x1f0(SP), DX											
  value_accessors.go:86		0x5b083c		488b5a08		MOVQ 0x8(DX), BX											
  value_accessors.go:86		0x5b0840		48895c2430		MOVQ BX, 0x30(SP)											
  value_accessors.go:86		0x5b0845		488b4a10		MOVQ 0x10(DX), CX											
  value_accessors.go:86		0x5b0849		48894c2438		MOVQ CX, 0x38(SP)											
  value_accessors.go:86		0x5b084e		488b02			MOVQ 0(DX), AX												
  value_accessors.go:86		0x5b0851		4889842440010000	MOVQ AX, 0x140(SP)											
  value_methods.go:852		0x5b0859		e80253edff		CALL runtime.convTslice(SB)										
  type.go:208			0x5b085e		0fb615f7025100		MOVZX 0x5102f7(IP), DX											
  value.go:165			0x5b0865		90			NOPL													
  type.go:208			0x5b0866		f6c220			TESTL $0x20, DL												
  value.go:3164			0x5b0869		b997000000		MOVL $0x97, CX												
  value.go:3164			0x5b086e		ba17000000		MOVL $0x17, DX												
  value.go:3164			0x5b0873		480f45ca		CMOVNE DX, CX												
  value_methods.go:852		0x5b0877		4889c3			MOVQ AX, BX												
  value_methods.go:852		0x5b087a		488d05c7025100		LEAQ 0x5102c7(IP), AX											
  value_methods.go:852		0x5b0881		e8fa65f1ff		CALL reflect.Value.Pointer(SB)										
  value_methods.go:856		0x5b0886		4885c0			TESTQ AX, AX												
  value_methods.go:856		0x5b0889		0f840d010000		JE 0x5b099c												
  value_methods.go:852		0x5b088f		4889842490000000	MOVQ AX, 0x90(SP)											
  value_methods.go:857		0x5b0897		4889842498000000	MOVQ AX, 0x98(SP)											
  value_methods.go:857		0x5b089f		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:857		0x5b08a4		48899424a0000000	MOVQ DX, 0xa0(SP)											
  value_methods.go:857		0x5b08ac		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:857		0x5b08b1		48899424a8000000	MOVQ DX, 0xa8(SP)											
  value_methods.go:857		0x5b08b9		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:857		0x5b08c1		488b1a			MOVQ 0(DX), BX												
  value_methods.go:857		0x5b08c4		488d0545665100		LEAQ 0x516645(IP), AX											
  value_methods.go:857		0x5b08cb		488d8c2498000000	LEAQ 0x98(SP), CX											
  value_methods.go:857		0x5b08d3		e848d2e5ff		CALL runtime.mapaccess2(SB)										
  value_methods.go:857		0x5b08d8		0f1f840000000000	NOPL 0(AX)(AX*1)											
  value_methods.go:857		0x5b08e0		84db			TESTL BL, BL												
  value_methods.go:857		0x5b08e2		0f85dd000000		JNE 0x5b09c5												
  value_methods.go:860		0x5b08e8		488b942490000000	MOVQ 0x90(SP), DX											
  value_methods.go:860		0x5b08f0		4889942498000000	MOVQ DX, 0x98(SP)											
  value_methods.go:860		0x5b08f8		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:860		0x5b08fd		48899424a0000000	MOVQ DX, 0xa0(SP)											
  value_methods.go:860		0x5b0905		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:860		0x5b090a		48899424a8000000	MOVQ DX, 0xa8(SP)											
  value_methods.go:860		0x5b0912		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:860		0x5b091a		488b1a			MOVQ 0(DX), BX												
  value_methods.go:860		0x5b091d		488d05ec655100		LEAQ 0x5165ec(IP), AX											
  value_methods.go:860		0x5b0924		488d8c2498000000	LEAQ 0x98(SP), CX											
  value_methods.go:860		0x5b092c		e8cfd4e5ff		CALL runtime.mapassign(SB)										
  value_methods.go:860		0x5b0931		8400			TESTB AL, 0(AX)												
  value_methods.go:861		0x5b0933		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:861		0x5b093b		488b12			MOVQ 0(DX), DX												
  value_methods.go:861		0x5b093e		488d35fb420000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB), SI	
  value_methods.go:861		0x5b0945		4889b42460010000	MOVQ SI, 0x160(SP)											
  value_methods.go:861		0x5b094d		4889942468010000	MOVQ DX, 0x168(SP)											
  value_methods.go:861		0x5b0955		488b942490000000	MOVQ 0x90(SP), DX											
  value_methods.go:861		0x5b095d		4889942470010000	MOVQ DX, 0x170(SP)											
  value_methods.go:861		0x5b0965		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:861		0x5b096a		4889942478010000	MOVQ DX, 0x178(SP)											
  value_methods.go:861		0x5b0972		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:861		0x5b0977		4889942480010000	MOVQ DX, 0x180(SP)											
  value_methods.go:861		0x5b097f		488d942460010000	LEAQ 0x160(SP), DX											
  value_methods.go:861		0x5b0987		4889942418010000	MOVQ DX, 0x118(SP)											
  value_methods.go:861		0x5b098f		488d842400010000	LEAQ 0x100(SP), AX											
  value_methods.go:861		0x5b0997		e864afe9ff		CALL runtime.deferprocStack(SB)										
  value_methods.go:1031		0x5b099c		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:1031		0x5b09a1		4883fa02		CMPQ DX, $0x2												
  value_methods.go:1031		0x5b09a5		7d05			JGE 0x5b09ac												
  value_methods.go:1031		0x5b09a7		4531c9			XORL R9, R9												
  value_methods.go:864		0x5b09aa		eb08			JMP 0x5b09b4												
  value_methods.go:1034		0x5b09ac		4c8d0c12		LEAQ 0(DX)(DX*1), R9											
  value_methods.go:1034		0x5b09b0		4d8d49fe		LEAQ -0x2(R9), R9											
  value_methods.go:864		0x5b09b4		4983c102		ADDQ $0x2, R9												
  value_methods.go:865		0x5b09b8		4c8b942440010000	MOVQ 0x140(SP), R10											
  value_methods.go:865		0x5b09c0		e931070000		JMP 0x5b10f6												
  value_methods.go:858		0x5b09c5		48c744244807000000	MOVQ $0x7, 0x48(SP)											
  value_methods.go:858		0x5b09ce		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b09d7		e844b4e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:858		0x5b09dc		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:858		0x5b09e4		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:858		0x5b09ec		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b09f1		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b09f8		5d			POPQ BP													
  value_methods.go:918		0x5b09f9		c3			RET													
  value_methods.go:918		0x5b09fa		660f1f440000		NOPW 0(AX)(AX*1)											
  value_methods.go:873		0x5b0a00		4883f806		CMPQ AX, $0x6												
  value_methods.go:873		0x5b0a04		0f850e020000		JNE 0x5b0c18												
  value_methods.go:874		0x5b0a0a		90			NOPL													
  value_accessors.go:113	0x5b0a0b		488b8424c8000000	MOVQ 0xc8(SP), AX											
  value_accessors.go:113	0x5b0a13		488d1d06aa5000		LEAQ 0x50aa06(IP), BX											
  value_accessors.go:113	0x5b0a1a		660f1f440000		NOPW 0(AX)(AX*1)											
  value_accessors.go:113	0x5b0a20		4839d8			CMPQ AX, BX												
  value_accessors.go:113	0x5b0a23		0f85a1060000		JNE 0x5b10ca												
  value_accessors.go:113	0x5b0a29		488b9424f0010000	MOVQ 0x1f0(SP), DX											
  value_accessors.go:113	0x5b0a31		488b1a			MOVQ 0(DX), BX												
  value_methods.go:875		0x5b0a34		4885db			TESTQ BX, BX												
  value_methods.go:875		0x5b0a37		7405			JE 0x5b0a3e												
  value_methods.go:875		0x5b0a39		488b13			MOVQ 0(BX), DX												
  value_methods.go:875		0x5b0a3c		eb02			JMP 0x5b0a40												
  value_methods.go:875		0x5b0a3e		31d2			XORL DX, DX												
  value_methods.go:875		0x5b0a40		4885d2			TESTQ DX, DX												
  value_methods.go:875		0x5b0a43		0f849a010000		JE 0x5b0be3												
  value_accessors.go:113	0x5b0a49		48899c2448010000	MOVQ BX, 0x148(SP)											
  type.go:208			0x5b0a51		0fb6156c5e5100		MOVZX 0x515e6c(IP), DX											
  value.go:165			0x5b0a58		90			NOPL													
  type.go:208			0x5b0a59		f6c220			TESTL $0x20, DL												
  value.go:3164			0x5b0a5c		b995000000		MOVL $0x95, CX												
  value.go:3164			0x5b0a61		ba15000000		MOVL $0x15, DX												
  value.go:3164			0x5b0a66		480f45ca		CMOVNE DX, CX												
  value_methods.go:878		0x5b0a6a		488d053f5e5100		LEAQ 0x515e3f(IP), AX											
  value_methods.go:878		0x5b0a71		e80a64f1ff		CALL reflect.Value.Pointer(SB)										
  value_methods.go:879		0x5b0a76		4885c0			TESTQ AX, AX												
  value_methods.go:879		0x5b0a79		7510			JNE 0x5b0a8b												
  value_methods.go:875		0x5b0a7b		488b9c2448010000	MOVQ 0x148(SP), BX											
  value_methods.go:875		0x5b0a83		4885db			TESTQ BX, BX												
  value_methods.go:879		0x5b0a86		e99f000000		JMP 0x5b0b2a												
  value_methods.go:878		0x5b0a8b		4889442468		MOVQ AX, 0x68(SP)											
  value_methods.go:880		0x5b0a90		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:880		0x5b0a98		488b5a08		MOVQ 0x8(DX), BX											
  value_methods.go:880		0x5b0a9c		4889c1			MOVQ AX, CX												
  value_methods.go:880		0x5b0a9f		488d054a625100		LEAQ 0x51624a(IP), AX											
  value_methods.go:880		0x5b0aa6		e815e0e5ff		CALL runtime.mapaccess2_fast64(SB)									
  value_methods.go:880		0x5b0aab		84db			TESTL BL, BL												
  value_methods.go:880		0x5b0aad		0f85f9000000		JNE 0x5b0bac												
  value_methods.go:883		0x5b0ab3		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:883		0x5b0abb		488b5a08		MOVQ 0x8(DX), BX											
  value_methods.go:883		0x5b0abf		488d052a625100		LEAQ 0x51622a(IP), AX											
  value_methods.go:883		0x5b0ac6		488b4c2468		MOVQ 0x68(SP), CX											
  value_methods.go:883		0x5b0acb		e870e2e5ff		CALL runtime.mapassign_fast64(SB)									
  value_methods.go:883		0x5b0ad0		8400			TESTB AL, 0(AX)												
  value_methods.go:884		0x5b0ad2		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:884		0x5b0ada		488b5208		MOVQ 0x8(DX), DX											
  value_methods.go:884		0x5b0ade		488d351b410000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB), SI	
  value_methods.go:884		0x5b0ae5		4889b424f8010000	MOVQ SI, 0x1f8(SP)											
  value_methods.go:884		0x5b0aed		4889942400020000	MOVQ DX, 0x200(SP)											
  value_methods.go:884		0x5b0af5		488b542468		MOVQ 0x68(SP), DX											
  value_methods.go:884		0x5b0afa		4889942408020000	MOVQ DX, 0x208(SP)											
  value_methods.go:884		0x5b0b02		488d9424f8010000	LEAQ 0x1f8(SP), DX											
  value_methods.go:884		0x5b0b0a		48899424e8000000	MOVQ DX, 0xe8(SP)											
  value_methods.go:884		0x5b0b12		488d8424d0000000	LEAQ 0xd0(SP), AX											
  value_methods.go:884		0x5b0b1a		e8e1ade9ff		CALL runtime.deferprocStack(SB)										
  value_methods.go:875		0x5b0b1f		488b9c2448010000	MOVQ 0x148(SP), BX											
  value_methods.go:875		0x5b0b27		4885db			TESTQ BX, BX												
  value_methods.go:887		0x5b0b2a		7405			JE 0x5b0b31												
  value_methods.go:887		0x5b0b2c		488b13			MOVQ 0(BX), DX												
  value_methods.go:887		0x5b0b2f		eb02			JMP 0x5b0b33												
  value_methods.go:887		0x5b0b31		31d2			XORL DX, DX												
  value_methods.go:1031		0x5b0b33		4883fa02		CMPQ DX, $0x2												
  value_methods.go:1031		0x5b0b37		7d04			JGE 0x5b0b3d												
  value_methods.go:1031		0x5b0b39		31d2			XORL DX, DX												
  value_methods.go:887		0x5b0b3b		eb08			JMP 0x5b0b45												
  value_methods.go:1034		0x5b0b3d		488d1412		LEAQ 0(DX)(DX*1), DX											
  value_methods.go:1034		0x5b0b41		488d52fe		LEAQ -0x2(DX), DX											
  value_methods.go:887		0x5b0b45		4889542440		MOVQ DX, 0x40(SP)											
  value_methods.go:888		0x5b0b4a		488d8c2488010000	LEAQ 0x188(SP), CX											
  value_methods.go:888		0x5b0b52		440f1139		MOVUPS X15, 0(CX)											
  value_methods.go:888		0x5b0b56		440f117910		MOVUPS X15, 0x10(CX)											
  value_methods.go:888		0x5b0b5b		440f117920		MOVUPS X15, 0x20(CX)											
  value_methods.go:888		0x5b0b60		440f117930		MOVUPS X15, 0x30(CX)											
  value_methods.go:888		0x5b0b65		440f117940		MOVUPS X15, 0x40(CX)											
  value_methods.go:888		0x5b0b6a		440f117950		MOVUPS X15, 0x50(CX)											
  value_methods.go:888		0x5b0b6f		488d053a5d5100		LEAQ 0x515d3a(IP), AX											
  value_methods.go:888		0x5b0b76		e8853de7ff		CALL runtime.mapIterStart(SB)										
  value_methods.go:887		0x5b0b7b		488b542440		MOVQ 0x40(SP), DX											
  value_methods.go:887		0x5b0b80		4883c202		ADDQ $0x2, DX												
  value_methods.go:888		0x5b0b84		e9c7030000		JMP 0x5b0f50												
  value_methods.go:918		0x5b0b89		e892b2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:861		0x5b0b8e		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:861		0x5b0b96		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:861		0x5b0b9e		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0ba3		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0baa		5d			POPQ BP													
  value_methods.go:918		0x5b0bab		c3			RET													
  value_methods.go:881		0x5b0bac		48c744244807000000	MOVQ $0x7, 0x48(SP)											
  value_methods.go:881		0x5b0bb5		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:881		0x5b0bbe		6690			NOPW													
  value_methods.go:918		0x5b0bc0		e85bb2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:881		0x5b0bc5		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:881		0x5b0bcd		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:881		0x5b0bd5		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0bda		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0be1		5d			POPQ BP													
  value_methods.go:918		0x5b0be2		c3			RET													
  value_methods.go:876		0x5b0be3		48c744244802000000	MOVQ $0x2, 0x48(SP)											
  value_methods.go:876		0x5b0bec		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0bf5		e826b2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:876		0x5b0bfa		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:876		0x5b0c02		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:876		0x5b0c0a		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0c0f		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0c16		5d			POPQ BP													
  value_methods.go:918		0x5b0c17		c3			RET													
  value_methods.go:897		0x5b0c18		4883f814		CMPQ AX, $0x14												
  value_methods.go:897		0x5b0c1c		752d			JNE 0x5b0c4b												
  regex.go:180			0x5b0c1e		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0c26		488d1d4b5d5500		LEAQ 0x555d4b(IP), BX											
  regex.go:180			0x5b0c2d		4839d8			CMPQ AX, BX												
  regex.go:180			0x5b0c30		0f85d9020000		JNE 0x5b0f0f												
  regex.go:180			0x5b0c36		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  regex.go:180			0x5b0c3e		4d8b4808		MOVQ 0x8(R8), R9											
  regex.go:180			0x5b0c42		49c1e906		SHRQ $0x6, R9												
  regex.go:180			0x5b0c46		e9da010000		JMP 0x5b0e25												
  value_methods.go:908		0x5b0c4b		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:908		0x5b0c53		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:908		0x5b0c5b		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:908		0x5b0c63		488bb42448020000	MOVQ 0x248(SP), SI											
  value_methods.go:908		0x5b0c6b		e850ebfeff		CALL github.com/mgomes/vibescript/vibes/value.chargeBigIntRenderSteps(SB)				
  value_methods.go:908		0x5b0c70		4885c0			TESTQ AX, AX												
  value_methods.go:908		0x5b0c73		0f85a1000000		JNE 0x5b0d1a												
  value_methods.go:911		0x5b0c79		488b1500e65a00		MOVQ github.com/mgomes/vibescript/vibes/value.RuntimeStringRuneLen(SB), DX				
  value_methods.go:911		0x5b0c80		4885d2			TESTQ DX, DX												
  value_methods.go:911		0x5b0c83		7429			JE 0x5b0cae												
  value_methods.go:912		0x5b0c85		488b32			MOVQ 0(DX), SI												
  value_methods.go:912		0x5b0c88		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:912		0x5b0c90		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:912		0x5b0c98		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:912		0x5b0ca0		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:912		0x5b0ca8		ffd6			CALL SI													
  value_methods.go:912		0x5b0caa		84db			TESTL BL, BL												
  value_methods.go:912		0x5b0cac		753b			JNE 0x5b0ce9												
  value_methods.go:916		0x5b0cae		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:916		0x5b0cb6		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:916		0x5b0cbe		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:916		0x5b0cc6		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:916		0x5b0cce		e84db6ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)						
  value_methods.go:916		0x5b0cd3		4889842450010000	MOVQ AX, 0x150(SP)											
  value_methods.go:916		0x5b0cdb		48895c2460		MOVQ BX, 0x60(SP)											
  utf8.go:448			0x5b0ce0		31d2			XORL DX, DX												
  utf8.go:448			0x5b0ce2		31f6			XORL SI, SI												
  utf8.go:448			0x5b0ce4		e9af000000		JMP 0x5b0d98												
  value_methods.go:913		0x5b0ce9		4889442448		MOVQ AX, 0x48(SP)											
  value_methods.go:913		0x5b0cee		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0cf7		e824b1e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:913		0x5b0cfc		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:913		0x5b0d04		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:913		0x5b0d0c		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0d11		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0d18		5d			POPQ BP													
  value_methods.go:918		0x5b0d19		c3			RET													
  value_methods.go:909		0x5b0d1a		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:909		0x5b0d23		4889842430010000	MOVQ AX, 0x130(SP)											
  value_methods.go:909		0x5b0d2b		48899c2438010000	MOVQ BX, 0x138(SP)											
  value_methods.go:918		0x5b0d33		e8e8b0e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:909		0x5b0d38		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:909		0x5b0d40		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:909		0x5b0d48		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0d4d		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0d54		5d			POPQ BP													
  value_methods.go:918		0x5b0d55		c3			RET													
  value_methods.go:846		0x5b0d56		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:846		0x5b0d5f		4889842430010000	MOVQ AX, 0x130(SP)											
  value_methods.go:846		0x5b0d67		48899c2438010000	MOVQ BX, 0x138(SP)											
  value_methods.go:918		0x5b0d6f		e8acb0e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:846		0x5b0d74		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:846		0x5b0d7c		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:846		0x5b0d84		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0d89		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0d90		5d			POPQ BP													
  value_methods.go:918		0x5b0d91		c3			RET													
  utf8.go:449			0x5b0d92		48ffc6			INCQ SI													
  utf8.go:448			0x5b0d95		4889ca			MOVQ CX, DX												
  utf8.go:448			0x5b0d98		4839d3			CMPQ BX, DX												
  utf8.go:448			0x5b0d9b		7e33			JLE 0x5b0dd0												
  utf8.go:448			0x5b0d9d		0fb63c02		MOVZX 0(DX)(AX*1), DI											
  utf8.go:448			0x5b0da1		83ff7f			CMPL DI, $0x7f												
  utf8.go:448			0x5b0da4		7f06			JG 0x5b0dac												
  utf8.go:448			0x5b0da6		488d4a01		LEAQ 0x1(DX), CX											
  utf8.go:448			0x5b0daa		ebe6			JMP 0x5b0d92												
  utf8.go:448			0x5b0dac		4889742470		MOVQ SI, 0x70(SP)											
  utf8.go:448			0x5b0db1		4889d1			MOVQ DX, CX												
  utf8.go:448			0x5b0db4		e847c4ecff		CALL runtime.decoderune(SB)										
  utf8.go:448			0x5b0db9		488b842450010000	MOVQ 0x150(SP), AX											
  utf8.go:449			0x5b0dc1		488b742470		MOVQ 0x70(SP), SI											
  utf8.go:449			0x5b0dc6		4889d9			MOVQ BX, CX												
  utf8.go:448			0x5b0dc9		488b5c2460		MOVQ 0x60(SP), BX											
  utf8.go:448			0x5b0dce		ebc2			JMP 0x5b0d92												
  value_methods.go:916		0x5b0dd0		4889742448		MOVQ SI, 0x48(SP)											
  value_methods.go:916		0x5b0dd5		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0dde		6690			NOPW													
  value_methods.go:918		0x5b0de0		e83bb0e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:916		0x5b0de5		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:916		0x5b0ded		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:916		0x5b0df5		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0dfa		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0e01		5d			POPQ BP													
  value_methods.go:918		0x5b0e02		c3			RET													
  regex.go:180			0x5b0e03		4c8b8c24b0000000	MOVQ 0xb0(SP), R9											
  regex.go:180			0x5b0e0b		49ffc9			DECQ R9													
  regex.go:180			0x5b0e0e		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0e16		488d1d5b5b5500		LEAQ 0x555b5b(IP), BX											
  value_methods.go:906		0x5b0e1d		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  regex.go:180			0x5b0e25		4d85c9			TESTQ R9, R9												
  regex.go:180			0x5b0e28		7e3a			JLE 0x5b0e64												
  regex.go:180			0x5b0e2a		4c898c24b0000000	MOVQ R9, 0xb0(SP)											
  regex.go:181			0x5b0e32		488b942448020000	MOVQ 0x248(SP), DX											
  regex.go:181			0x5b0e3a		488b02			MOVQ 0(DX), AX												
  regex.go:181			0x5b0e3d		ffd0			CALL AX													
  regex.go:181			0x5b0e3f		90			NOPL													
  regex.go:181			0x5b0e40		4885c0			TESTQ AX, AX												
  regex.go:181			0x5b0e43		74be			JE 0x5b0e03												
  value_methods.go:906		0x5b0e45		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  value_methods.go:903		0x5b0e4d		4889c1			MOVQ AX, CX												
  value_methods.go:903		0x5b0e50		4889da			MOVQ BX, DX												
  regex.go:180			0x5b0e53		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0e5b		488d1d165b5500		LEAQ 0x555b16(IP), BX											
  value_methods.go:903		0x5b0e62		eb04			JMP 0x5b0e68												
  value_methods.go:903		0x5b0e64		31c9			XORL CX, CX												
  value_methods.go:903		0x5b0e66		31d2			XORL DX, DX												
  value_methods.go:903		0x5b0e68		4885c9			TESTQ CX, CX												
  value_methods.go:903		0x5b0e6b		7556			JNE 0x5b0ec3												
  regex.go:180			0x5b0e6d		4839d8			CMPQ AX, BX												
  value_methods.go:906		0x5b0e70		0f858d000000		JNE 0x5b0f03												
  value_methods.go:906		0x5b0e76		498b00			MOVQ 0(R8), AX												
  value_methods.go:906		0x5b0e79		498b5808		MOVQ 0x8(R8), BX											
  value_methods.go:906		0x5b0e7d		498b4810		MOVQ 0x10(R8), CX											
  value_methods.go:906		0x5b0e81		498b7818		MOVQ 0x18(R8), DI											
  value_methods.go:906		0x5b0e85		498b7020		MOVQ 0x20(R8), SI											
  value_methods.go:906		0x5b0e89		e8f248ffff		CALL github.com/mgomes/vibescript/vibes/value.Regex.StringRuneLen(SB)					
  value_methods.go:906		0x5b0e8e		4889442448		MOVQ AX, 0x48(SP)											
  value_methods.go:906		0x5b0e93		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:906		0x5b0e9c		0f1f4000		NOPL 0(AX)												
  value_methods.go:918		0x5b0ea0		e87bafe9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:906		0x5b0ea5		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:906		0x5b0ead		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:906		0x5b0eb5		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0eba		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0ec1		5d			POPQ BP													
  value_methods.go:918		0x5b0ec2		c3			RET													
  value_methods.go:904		0x5b0ec3		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:904		0x5b0ecc		48898c2430010000	MOVQ CX, 0x130(SP)											
  value_methods.go:904		0x5b0ed4		4889942438010000	MOVQ DX, 0x138(SP)											
  value_methods.go:904		0x5b0edc		0f1f4000		NOPL 0(AX)												
  value_methods.go:918		0x5b0ee0		e83bafe9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:904		0x5b0ee5		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:904		0x5b0eed		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:904		0x5b0ef5		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0efa		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0f01		5d			POPQ BP													
  value_methods.go:918		0x5b0f02		c3			RET													
  value_methods.go:906		0x5b0f03		488d0d26565300		LEAQ 0x535626(IP), CX											
  value_methods.go:906		0x5b0f0a		e831bfe6ff		CALL runtime.panicdottypeE(SB)										
  regex.go:180			0x5b0f0f		488d0d1a565300		LEAQ 0x53561a(IP), CX											
  regex.go:180			0x5b0f16		e825bfe6ff		CALL runtime.panicdottypeE(SB)										
  value_methods.go:890		0x5b0f1b		4889842480000000	MOVQ AX, 0x80(SP)											
  value_methods.go:889		0x5b0f23		48899424b0000000	MOVQ DX, 0xb0(SP)											
  value_methods.go:888		0x5b0f2b		488d842488010000	LEAQ 0x188(SP), AX											
  value_methods.go:888		0x5b0f33		e8283ae7ff		CALL runtime.mapIterNext(SB)										
  value_methods.go:894		0x5b0f38		488b8c2480000000	MOVQ 0x80(SP), CX											
  value_methods.go:894		0x5b0f40		488b9424b0000000	MOVQ 0xb0(SP), DX											
  value_methods.go:894		0x5b0f48		488d140a		LEAQ 0(DX)(CX*1), DX											
  value_methods.go:894		0x5b0f4c		488d5202		LEAQ 0x2(DX), DX											
  value_methods.go:888		0x5b0f50		4c8b8c2488010000	MOVQ 0x188(SP), R9											
  value_methods.go:888		0x5b0f58		0f1f840000000000	NOPL 0(AX)(AX*1)											
  value_methods.go:888		0x5b0f60		4d85c9			TESTQ R9, R9												
  value_methods.go:888		0x5b0f63		0f84f4000000		JE 0x5b105d												
  value_methods.go:888		0x5b0f69		4889542450		MOVQ DX, 0x50(SP)											
  value_methods.go:888		0x5b0f6e		4c8b942490010000	MOVQ 0x190(SP), R10											
  value_methods.go:888		0x5b0f76		498b01			MOVQ 0(R9), AX												
  value_methods.go:888		0x5b0f79		4889842458010000	MOVQ AX, 0x158(SP)											
  value_methods.go:888		0x5b0f81		498b5908		MOVQ 0x8(R9), BX											
  value_methods.go:888		0x5b0f85		48899c2488000000	MOVQ BX, 0x88(SP)											
  value_methods.go:888		0x5b0f8d		4d8b0a			MOVQ 0(R10), R9												
  value_methods.go:888		0x5b0f90		4c898c24c0000000	MOVQ R9, 0xc0(SP)											
  value_methods.go:888		0x5b0f98		4d8b5a08		MOVQ 0x8(R10), R11											
  value_methods.go:888		0x5b0f9c		4c899c24c8000000	MOVQ R11, 0xc8(SP)											
  value_methods.go:888		0x5b0fa4		498b4a10		MOVQ 0x10(R10), CX											
  value_methods.go:888		0x5b0fa8		48898c24f0010000	MOVQ CX, 0x1f0(SP)											
  value_methods.go:888		0x5b0fb0		498b7a18		MOVQ 0x18(R10), DI											
  value_methods.go:888		0x5b0fb4		4889bc24b8000000	MOVQ DI, 0xb8(SP)											
  utf8.go:448			0x5b0fbc		4531d2			XORL R10, R10												
  utf8.go:448			0x5b0fbf		4531e4			XORL R12, R12												
  utf8.go:448			0x5b0fc2		eb03			JMP 0x5b0fc7												
  utf8.go:449			0x5b0fc4		49ffc2			INCQ R10												
  utf8.go:448			0x5b0fc7		4c89542478		MOVQ R10, 0x78(SP)											
  utf8.go:448			0x5b0fcc		4939dc			CMPQ R12, BX												
  utf8.go:448			0x5b0fcf		7d58			JGE 0x5b1029												
  utf8.go:448			0x5b0fd1		450fb62c04		MOVZX 0(R12)(AX*1), R13											
  utf8.go:448			0x5b0fd6		4183fd7f		CMPL R13, $0x7f												
  utf8.go:448			0x5b0fda		7f06			JG 0x5b0fe2												
  utf8.go:448			0x5b0fdc		49ffc4			INCQ R12												
  utf8.go:448			0x5b0fdf		90			NOPL													
  utf8.go:448			0x5b0fe0		ebe2			JMP 0x5b0fc4												
  utf8.go:448			0x5b0fe2		4c89e1			MOVQ R12, CX												
  utf8.go:448			0x5b0fe5		e816c2ecff		CALL runtime.decoderune(SB)										
  utf8.go:448			0x5b0fea		488b842458010000	MOVQ 0x158(SP), AX											
  value_methods.go:890		0x5b0ff2		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:889		0x5b0ffa		488b542450		MOVQ 0x50(SP), DX											
  value_methods.go:890		0x5b0fff		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:890		0x5b1007		4c8b8c24c0000000	MOVQ 0xc0(SP), R9											
  utf8.go:449			0x5b100f		4c8b542478		MOVQ 0x78(SP), R10											
  value_methods.go:890		0x5b1014		4c8b9c24c8000000	MOVQ 0xc8(SP), R11											
  utf8.go:449			0x5b101c		4989dc			MOVQ BX, R12												
  utf8.go:448			0x5b101f		488b9c2488000000	MOVQ 0x88(SP), BX											
  utf8.go:448			0x5b1027		eb9b			JMP 0x5b0fc4												
  value_methods.go:890		0x5b1029		4c89c8			MOVQ R9, AX												
  value_methods.go:890		0x5b102c		4c89db			MOVQ R11, BX												
  value_methods.go:890		0x5b102f		488bb42440020000	MOVQ 0x240(SP), SI											
  value_methods.go:890		0x5b1037		4c8b842448020000	MOVQ 0x248(SP), R8											
  value_methods.go:890		0x5b103f		90			NOPL													
  value_methods.go:890		0x5b1040		e83bf7ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			
  value_methods.go:889		0x5b1045		488b542478		MOVQ 0x78(SP), DX											
  value_methods.go:889		0x5b104a		4c8b4c2450		MOVQ 0x50(SP), R9											
  value_methods.go:889		0x5b104f		4c01ca			ADDQ R9, DX												
  value_methods.go:891		0x5b1052		4885db			TESTQ BX, BX												
  value_methods.go:891		0x5b1055		0f84c0feffff		JE 0x5b0f1b												
  value_methods.go:891		0x5b105b		eb31			JMP 0x5b108e												
  value_methods.go:896		0x5b105d		4889542448		MOVQ DX, 0x48(SP)											
  value_methods.go:896		0x5b1062		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b106b		e8b0ade9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:896		0x5b1070		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:896		0x5b1078		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:896		0x5b1080		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b1085		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b108c		5d			POPQ BP													
  value_methods.go:918		0x5b108d		c3			RET													
  value_methods.go:892		0x5b108e		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:892		0x5b1097		48899c2430010000	MOVQ BX, 0x130(SP)											
  value_methods.go:892		0x5b109f		48898c2438010000	MOVQ CX, 0x138(SP)											
  value_methods.go:918		0x5b10a7		e874ade9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:892		0x5b10ac		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:892		0x5b10b4		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:892		0x5b10bc		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b10c1		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b10c8		5d			POPQ BP													
  value_methods.go:918		0x5b10c9		c3			RET													
  value_accessors.go:113	0x5b10ca		488d0d5f545300		LEAQ 0x53545f(IP), CX											
  value_accessors.go:113	0x5b10d1		e86abde6ff		CALL runtime.panicdottypeE(SB)										
  value_methods.go:865		0x5b10d6		4c8b9424e8010000	MOVQ 0x1e8(SP), R10											
  value_methods.go:865		0x5b10de		4983c220		ADDQ $0x20, R10												
  value_methods.go:870		0x5b10e2		4c8b5c2458		MOVQ 0x58(SP), R11											
  value_methods.go:870		0x5b10e7		4d8d0c03		LEAQ 0(R11)(AX*1), R9											
  value_methods.go:865		0x5b10eb		488b9424b0000000	MOVQ 0xb0(SP), DX											
  value_methods.go:865		0x5b10f3		48ffca			DECQ DX													
  value_methods.go:865		0x5b10f6		4885d2			TESTQ DX, DX												
  value_methods.go:865		0x5b10f9		7e7a			JLE 0x5b1175												
  value_methods.go:865		0x5b10fb		48899424b0000000	MOVQ DX, 0xb0(SP)											
  value_methods.go:865		0x5b1103		4c894c2458		MOVQ R9, 0x58(SP)											
  value_methods.go:865		0x5b1108		4c899424e8010000	MOVQ R10, 0x1e8(SP)											
  value_methods.go:865		0x5b1110		498b02			MOVQ 0(R10), AX												
  value_methods.go:865		0x5b1113		498b5a08		MOVQ 0x8(R10), BX											
  value_methods.go:865		0x5b1117		498b4a10		MOVQ 0x10(R10), CX											
  value_methods.go:865		0x5b111b		498b7a18		MOVQ 0x18(R10), DI											
  value_methods.go:866		0x5b111f		488bb42440020000	MOVQ 0x240(SP), SI											
  value_methods.go:866		0x5b1127		4c8b842448020000	MOVQ 0x248(SP), R8											
  value_methods.go:866		0x5b112f		e84cf6ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			
  value_methods.go:867		0x5b1134		4885db			TESTQ BX, BX												
  value_methods.go:867		0x5b1137		749d			JE 0x5b10d6												
  value_methods.go:868		0x5b1139		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:868		0x5b1142		48899c2430010000	MOVQ BX, 0x130(SP)											
  value_methods.go:868		0x5b114a		48898c2438010000	MOVQ CX, 0x138(SP)											
  value_methods.go:918		0x5b1152		e8c9ace9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:868		0x5b1157		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:868		0x5b115f		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:868		0x5b1167		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b116c		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b1173		5d			POPQ BP													
  value_methods.go:918		0x5b1174		c3			RET													
  value_methods.go:872		0x5b1175		4c894c2448		MOVQ R9, 0x48(SP)											
  value_methods.go:872		0x5b117a		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b1183		e898ace9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:872		0x5b1188		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:872		0x5b1190		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:872		0x5b1198		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b119d		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b11a4		5d			POPQ BP													
  value_methods.go:918		0x5b11a5		c3			RET													
  value_accessors.go:86		0x5b11a6		488d0d83535300		LEAQ 0x535383(IP), CX											
  value_accessors.go:86		0x5b11ad		e88ebce6ff		CALL runtime.panicdottypeE(SB)										
  value_accessors.go:86		0x5b11b2		90			NOPL													
  value_methods.go:844		0x5b11b3		4889442408		MOVQ AX, 0x8(SP)											
  value_methods.go:844		0x5b11b8		48895c2410		MOVQ BX, 0x10(SP)											
  value_methods.go:844		0x5b11bd		48894c2418		MOVQ CX, 0x18(SP)											
  value_methods.go:844		0x5b11c2		48897c2420		MOVQ DI, 0x20(SP)											
  value_methods.go:844		0x5b11c7		4889742428		MOVQ SI, 0x28(SP)											
  value_methods.go:844		0x5b11cc		4c89442430		MOVQ R8, 0x30(SP)											
  value_methods.go:844		0x5b11d1		e86ab4edff		CALL runtime.morestack_noctxt.abi0(SB)									
  value_methods.go:844		0x5b11d6		488b442408		MOVQ 0x8(SP), AX											
  value_methods.go:844		0x5b11db		488b5c2410		MOVQ 0x10(SP), BX											
  value_methods.go:844		0x5b11e0		488b4c2418		MOVQ 0x18(SP), CX											
  value_methods.go:844		0x5b11e5		488b7c2420		MOVQ 0x20(SP), DI											
  value_methods.go:844		0x5b11ea		488b742428		MOVQ 0x28(SP), SI											
  value_methods.go:844		0x5b11ef		4c8b442430		MOVQ 0x30(SP), R8											
  value_methods.go:844		0x5b11f4		e987f5ffff		JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB) /home/runner/work/vibescript/vibescript/base/vibes/value/value_methods.go
  value_methods.go:638	0x5b4b00		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:638	0x5b4b04		7625			JBE 0x5b4b2b											
  value_methods.go:638	0x5b4b06		55			PUSHQ BP											
  value_methods.go:638	0x5b4b07		4889e5			MOVQ SP, BP											
  value_methods.go:638	0x5b4b0a		4883ec18		SUBQ $0x18, SP											
  value_methods.go:638	0x5b4b0e		488b4a10		MOVQ 0x10(DX), CX										
  value_methods.go:638	0x5b4b12		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:638	0x5b4b16		488d05d3215100		LEAQ 0x5121d3(IP), AX										
  value_methods.go:638	0x5b4b1d		0f1f00			NOPL 0(AX)											
  value_methods.go:638	0x5b4b20		e83baae5ff		CALL runtime.mapdelete_fast64(SB)								
  value_methods.go:638	0x5b4b25		4883c418		ADDQ $0x18, SP											
  value_methods.go:638	0x5b4b29		5d			POPQ BP												
  value_methods.go:638	0x5b4b2a		c3			RET												
  value_methods.go:638	0x5b4b2b		e8707aedff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:638	0x5b4b30		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB) /home/runner/work/vibescript/vibescript/base/vibes/value/value_methods.go
  value_methods.go:619	0x5b4b40		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:619	0x5b4b44		7625			JBE 0x5b4b6b											
  value_methods.go:619	0x5b4b46		55			PUSHQ BP											
  value_methods.go:619	0x5b4b47		4889e5			MOVQ SP, BP											
  value_methods.go:619	0x5b4b4a		4883ec18		SUBQ $0x18, SP											
  value_methods.go:619	0x5b4b4e		488d4a10		LEAQ 0x10(DX), CX										
  value_methods.go:619	0x5b4b52		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:619	0x5b4b56		488d05b3235100		LEAQ 0x5123b3(IP), AX										
  value_methods.go:619	0x5b4b5d		0f1f00			NOPL 0(AX)											
  value_methods.go:619	0x5b4b60		e83b17edff		CALL runtime.mapdelete(SB)									
  value_methods.go:619	0x5b4b65		4883c418		ADDQ $0x18, SP											
  value_methods.go:619	0x5b4b69		5d			POPQ BP												
  value_methods.go:619	0x5b4b6a		c3			RET												
  value_methods.go:619	0x5b4b6b		e8307aedff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:619	0x5b4b70		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB) /home/runner/work/vibescript/vibescript/base/vibes/value/value_methods.go
  value_methods.go:884	0x5b4c00		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:884	0x5b4c04		7625			JBE 0x5b4c2b											
  value_methods.go:884	0x5b4c06		55			PUSHQ BP											
  value_methods.go:884	0x5b4c07		4889e5			MOVQ SP, BP											
  value_methods.go:884	0x5b4c0a		4883ec18		SUBQ $0x18, SP											
  value_methods.go:884	0x5b4c0e		488b4a10		MOVQ 0x10(DX), CX										
  value_methods.go:884	0x5b4c12		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:884	0x5b4c16		488d05d3205100		LEAQ 0x5120d3(IP), AX										
  value_methods.go:884	0x5b4c1d		0f1f00			NOPL 0(AX)											
  value_methods.go:884	0x5b4c20		e83ba9e5ff		CALL runtime.mapdelete_fast64(SB)								
  value_methods.go:884	0x5b4c25		4883c418		ADDQ $0x18, SP											
  value_methods.go:884	0x5b4c29		5d			POPQ BP												
  value_methods.go:884	0x5b4c2a		c3			RET												
  value_methods.go:884	0x5b4c2b		e87079edff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:884	0x5b4c30		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB) /home/runner/work/vibescript/vibescript/base/vibes/value/value_methods.go
  value_methods.go:861	0x5b4c40		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:861	0x5b4c44		7625			JBE 0x5b4c6b											
  value_methods.go:861	0x5b4c46		55			PUSHQ BP											
  value_methods.go:861	0x5b4c47		4889e5			MOVQ SP, BP											
  value_methods.go:861	0x5b4c4a		4883ec18		SUBQ $0x18, SP											
  value_methods.go:861	0x5b4c4e		488d4a10		LEAQ 0x10(DX), CX										
  value_methods.go:861	0x5b4c52		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:861	0x5b4c56		488d05b3225100		LEAQ 0x5122b3(IP), AX										
  value_methods.go:861	0x5b4c5d		0f1f00			NOPL 0(AX)											
  value_methods.go:861	0x5b4c60		e83b16edff		CALL runtime.mapdelete(SB)									
  value_methods.go:861	0x5b4c65		4883c418		ADDQ $0x18, SP											
  value_methods.go:861	0x5b4c69		5d			POPQ BP												
  value_methods.go:861	0x5b4c6a		c3			RET												
  value_methods.go:861	0x5b4c6b		e83079edff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:861	0x5b4c70		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneIndex(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:1223	0x6cdfa0		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:1223	0x6cdfa4		0f86bc030000		JBE 0x6ce366									
  members_string.go:1223	0x6cdfaa		55			PUSHQ BP									
  members_string.go:1223	0x6cdfab		4889e5			MOVQ SP, BP									
  members_string.go:1223	0x6cdfae		4883ec60		SUBQ $0x60, SP									
  members_string.go:1223	0x6cdfb2		48895c2478		MOVQ BX, 0x78(SP)								
  members_string.go:1223	0x6cdfb7		4889bc2488000000	MOVQ DI, 0x88(SP)								
  members_string.go:1223	0x6cdfbf		90			NOPL										
  members_string.go:1224	0x6cdfc0		4d85c0			TESTQ R8, R8									
  members_string.go:1224	0x6cdfc3		7c7e			JL 0x6ce043									
  members_string.go:5204	0x6cdfc5		4885c9			TESTQ CX, CX									
  members_string.go:5204	0x6cdfc8		7504			JNE 0x6cdfce									
  members_string.go:5204	0x6cdfca		31d2			XORL DX, DX									
  members_string.go:1240	0x6cdfcc		eb3d			JMP 0x6ce00b									
  members_string.go:1224	0x6cdfce		4889c2			MOVQ AX, DX									
  members_string.go:5207	0x6cdfd1		48b8ffffffffffffff7f	MOVQ $0x7fffffffffffffff, AX							
  members_string.go:1224	0x6cdfdb		4989d1			MOVQ DX, R9									
  members_string.go:5207	0x6cdfde		31d2			XORL DX, DX									
  members_string.go:5207	0x6cdfe0		48f7f1			DIVQ CX										
  members_string.go:5207	0x6cdfe3		4883f804		CMPQ AX, $0x4									
  members_string.go:5207	0x6cdfe7		7d0f			JGE 0x6cdff8									
  members_string.go:1257	0x6cdfe9		4c89c8			MOVQ R9, AX									
  members_string.go:1257	0x6cdfec		48baffffffffffffff7f	MOVQ $0x7fffffffffffffff, DX							
  members_string.go:1240	0x6cdff6		eb13			JMP 0x6ce00b									
  members_string.go:5210	0x6cdff8		4889ca			MOVQ CX, DX									
  members_string.go:5210	0x6cdffb		48c1e102		SHLQ $0x2, CX									
  members_string.go:1257	0x6cdfff		4c89c8			MOVQ R9, AX									
  members_string.go:1100	0x6ce002		4989ca			MOVQ CX, R10									
  members_string.go:1100	0x6ce005		4889d1			MOVQ DX, CX									
  members_string.go:1240	0x6ce008		4c89d2			MOVQ R10, DX									
  members_string.go:1240	0x6ce00b		4839d6			CMPQ SI, DX									
  members_string.go:1240	0x6ce00e		7f22			JG 0x6ce032									
  members_string.go:1224	0x6ce010		4889442470		MOVQ AX, 0x70(SP)								
  members_string.go:1224	0x6ce015		4c89842498000000	MOVQ R8, 0x98(SP)								
  members_string.go:1224	0x6ce01d		4889b42490000000	MOVQ SI, 0x90(SP)								
  members_string.go:1224	0x6ce025		4889bc2488000000	MOVQ DI, 0x88(SP)								
  members_string.go:1243	0x6ce02d		90			NOPL										
  members_string.go:1100	0x6ce02e		31d2			XORL DX, DX									
  members_string.go:1100	0x6ce030		eb25			JMP 0x6ce057									
  members_string.go:1241	0x6ce032		48c7c0ffffffff		MOVQ $-0x1, AX									
  members_string.go:1241	0x6ce039		31db			XORL BX, BX									
  members_string.go:1241	0x6ce03b		31c9			XORL CX, CX									
  members_string.go:1241	0x6ce03d		4883c460		ADDQ $0x60, SP									
  members_string.go:1241	0x6ce041		5d			POPQ BP										
  members_string.go:1241	0x6ce042		c3			RET										
  members_string.go:1225	0x6ce043		48c7c0ffffffff		MOVQ $-0x1, AX									
  members_string.go:1225	0x6ce04a		31db			XORL BX, BX									
  members_string.go:1225	0x6ce04c		31c9			XORL CX, CX									
  members_string.go:1225	0x6ce04e		4883c460		ADDQ $0x60, SP									
  members_string.go:1225	0x6ce052		5d			POPQ BP										
  members_string.go:1225	0x6ce053		c3			RET										
  members_string.go:1100	0x6ce054		48ffc2			INCQ DX										
  members_string.go:1100	0x6ce057		4839d1			CMPQ CX, DX									
  members_string.go:1100	0x6ce05a		7e0d			JLE 0x6ce069									
  members_string.go:1101	0x6ce05c		440fb60c1a		MOVZX 0(DX)(BX*1), R9								
  members_string.go:1101	0x6ce061		4180f980		CMPL R9, $0x80									
  members_string.go:1101	0x6ce065		72ed			JB 0x6ce054									
  members_string.go:1101	0x6ce067		eb1d			JMP 0x6ce086									
  members_string.go:1243	0x6ce069		90			NOPL										
  members_string.go:1100	0x6ce06a		31d2			XORL DX, DX									
  members_string.go:1100	0x6ce06c		eb03			JMP 0x6ce071									
  members_string.go:1100	0x6ce06e		48ffc2			INCQ DX										
  members_string.go:1100	0x6ce071		4839d6			CMPQ SI, DX									
  members_string.go:1100	0x6ce074		0f8e91000000		JLE 0x6ce10b									
  members_string.go:1101	0x6ce07a		440fb60c17		MOVZX 0(DI)(DX*1), R9								
  members_string.go:1101	0x6ce07f		90			NOPL										
  members_string.go:1101	0x6ce080		4180f980		CMPL R9, $0x80									
  members_string.go:1101	0x6ce084		72e8			JB 0x6ce06e									
  members_string.go:1224	0x6ce086		48895c2478		MOVQ BX, 0x78(SP)								
  members_string.go:1224	0x6ce08b		48898c2480000000	MOVQ CX, 0x80(SP)								
  members_string.go:1256	0x6ce093		4889d8			MOVQ BX, AX									
  members_string.go:1256	0x6ce096		4889cb			MOVQ CX, BX									
  members_string.go:1256	0x6ce099		e8c20edeff		CALL unicode/utf8.ValidString(SB)						
  members_string.go:1256	0x6ce09e		6690			NOPW										
  members_string.go:1256	0x6ce0a0		84c0			TESTL AL, AL									
  members_string.go:1256	0x6ce0a2		742e			JE 0x6ce0d2									
  members_string.go:1256	0x6ce0a4		488b842488000000	MOVQ 0x88(SP), AX								
  members_string.go:1256	0x6ce0ac		488b9c2490000000	MOVQ 0x90(SP), BX								
  members_string.go:1256	0x6ce0b4		e8a70edeff		CALL unicode/utf8.ValidString(SB)						
  members_string.go:1256	0x6ce0b9		84c0			TESTL AL, AL									
  members_string.go:1256	0x6ce0bb		7415			JE 0x6ce0d2									
  members_string.go:1188	0x6ce0bd		90			NOPL										
  members_string.go:1100	0x6ce0be		31d2			XORL DX, DX									
  members_string.go:1100	0x6ce0c0		488b9c2480000000	MOVQ 0x80(SP), BX								
  members_string.go:1100	0x6ce0c8		488b442478		MOVQ 0x78(SP), AX								
  members_string.go:1100	0x6ce0cd		e9b2000000		JMP 0x6ce184									
  members_string.go:1257	0x6ce0d2		488b442470		MOVQ 0x70(SP), AX								
  members_string.go:1257	0x6ce0d7		488b5c2478		MOVQ 0x78(SP), BX								
  members_string.go:1257	0x6ce0dc		488b8c2480000000	MOVQ 0x80(SP), CX								
  members_string.go:1257	0x6ce0e4		488bbc2488000000	MOVQ 0x88(SP), DI								
  members_string.go:1257	0x6ce0ec		488bb42490000000	MOVQ 0x90(SP), SI								
  members_string.go:1257	0x6ce0f4		4c8b842498000000	MOVQ 0x98(SP), R8								
  members_string.go:1257	0x6ce0fc		0f1f4000		NOPL 0(AX)									
  members_string.go:1257	0x6ce100		e8fb030000		CALL github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB)	
  members_string.go:1257	0x6ce105		4883c460		ADDQ $0x60, SP									
  members_string.go:1257	0x6ce109		5d			POPQ BP										
  members_string.go:1257	0x6ce10a		c3			RET										
  members_string.go:1244	0x6ce10b		4c39c1			CMPQ CX, R8									
  members_string.go:1244	0x6ce10e		7c5f			JL 0x6ce16f									
  members_string.go:1247	0x6ce110		4885f6			TESTQ SI, SI									
  members_string.go:1247	0x6ce113		744d			JE 0x6ce162									
  members_string.go:1250	0x6ce115		4c29c1			SUBQ R8, CX									
  members_string.go:1250	0x6ce118		4889ca			MOVQ CX, DX									
  members_string.go:1250	0x6ce11b		48f7d9			NEGQ CX										
  members_string.go:1250	0x6ce11e		48c1f93f		SARQ $0x3f, CX									
  members_string.go:1250	0x6ce122		4c21c1			ANDQ R8, CX									
  members_string.go:1250	0x6ce125		488d0419		LEAQ 0(CX)(BX*1), AX								
  strings.go:1264		0x6ce129		4889d3			MOVQ DX, BX									
  strings.go:1264		0x6ce12c		4889f9			MOVQ DI, CX									
  strings.go:1264		0x6ce12f		4889f7			MOVQ SI, DI									
  strings.go:1264		0x6ce132		e8696fd4ff		CALL internal/stringslite.Index(SB)						
  members_string.go:1251	0x6ce137		4885c0			TESTQ AX, AX									
  members_string.go:1251	0x6ce13a		7d11			JGE 0x6ce14d									
  members_string.go:1252	0x6ce13c		48c7c0ffffffff		MOVQ $-0x1, AX									
  members_string.go:1252	0x6ce143		31db			XORL BX, BX									
  members_string.go:1252	0x6ce145		31c9			XORL CX, CX									
  members_string.go:1252	0x6ce147		4883c460		ADDQ $0x60, SP									
  members_string.go:1252	0x6ce14b		5d			POPQ BP										
  members_string.go:1252	0x6ce14c		c3			RET										
  members_string.go:1254	0x6ce14d		488b942498000000	MOVQ 0x98(SP), DX								
  members_string.go:1254	0x6ce155		4801d0			ADDQ DX, AX									
  members_string.go:1254	0x6ce158		31db			XORL BX, BX									
  members_string.go:1254	0x6ce15a		31c9			XORL CX, CX									
  members_string.go:1254	0x6ce15c		4883c460		ADDQ $0x60, SP									
  members_string.go:1254	0x6ce160		5d			POPQ BP										
  members_string.go:1254	0x6ce161		c3			RET										
  members_string.go:1248	0x6ce162		4c89c0			MOVQ R8, AX									
  members_string.go:1248	0x6ce165		31db			XORL BX, BX									
  members_string.go:1248	0x6ce167		31c9			XORL CX, CX									
  members_string.go:1248	0x6ce169		4883c460		ADDQ $0x60, SP									
  members_string.go:1248	0x6ce16d		5d			POPQ BP										
  members_string.go:1248	0x6ce16e		c3			RET										
  members_string.go:1245	0x6ce16f		48c7c0ffffffff		MOVQ $-0x1, AX									
  members_string.go:1245	0x6ce176		31db			XORL BX, BX									
  members_string.go:1245	0x6ce178		31c9			XORL CX, CX									
  members_string.go:1245	0x6ce17a		4883c460		ADDQ $0x60, SP									
  members_string.go:1245	0x6ce17e		5d			POPQ BP										
  members_string.go:1245	0x6ce17f		90			NOPL										
  members_string.go:1245	0x6ce180		c3			RET										
  members_string.go:1100	0x6ce181		48ffc2			INCQ DX										
  members_string.go:1100	0x6ce184		4839d3			CMPQ BX, DX									
  members_string.go:1100	0x6ce187		7e1c			JLE 0x6ce1a5									
  members_string.go:1101	0x6ce189		0fb63402		MOVZX 0(DX)(AX*1), SI								
  members_string.go:1101	0x6ce18d		4080fe80		CMPL SI, $0x80									
  members_string.go:1101	0x6ce191		72ee			JB 0x6ce181									
  members_string.go:1195	0x6ce193		31d2			XORL DX, DX									
  members_string.go:1195	0x6ce195		31f6			XORL SI, SI									
  members_string.go:1195	0x6ce197		4c8b842498000000	MOVQ 0x98(SP), R8								
  members_string.go:1195	0x6ce19f		90			NOPL										
  members_string.go:1195	0x6ce1a0		e93c010000		JMP 0x6ce2e1									
  members_string.go:1189	0x6ce1a5		488b942498000000	MOVQ 0x98(SP), DX								
  members_string.go:1189	0x6ce1ad		4839d3			CMPQ BX, DX									
  members_string.go:1189	0x6ce1b0		7d06			JGE 0x6ce1b8									
  members_string.go:1189	0x6ce1b2		31c9			XORL CX, CX									
  members_string.go:1189	0x6ce1b4		31f6			XORL SI, SI									
  members_string.go:1259	0x6ce1b6		eb08			JMP 0x6ce1c0									
  members_string.go:1259	0x6ce1b8		b901000000		MOVL $0x1, CX									
  members_string.go:1259	0x6ce1bd		4889d6			MOVQ DX, SI									
  members_string.go:1259	0x6ce1c0		84c9			TESTL CL, CL									
  members_string.go:1260	0x6ce1c2		0f84ab000000		JE 0x6ce273									
  members_string.go:1263	0x6ce1c8		488bbc2490000000	MOVQ 0x90(SP), DI								
  members_string.go:1263	0x6ce1d0		4885ff			TESTQ DI, DI									
  members_string.go:1263	0x6ce1d3		0f848d000000		JE 0x6ce266									
  members_string.go:1263	0x6ce1d9		0f1f8000000000		NOPL 0(AX)									
  members_string.go:1266	0x6ce1e0		4839f3			CMPQ BX, SI									
  members_string.go:1266	0x6ce1e3		0f82ed000000		JB 0x6ce2d6									
  members_string.go:1259	0x6ce1e9		4889742430		MOVQ SI, 0x30(SP)								
  members_string.go:1266	0x6ce1ee		4889da			MOVQ BX, DX									
  members_string.go:1266	0x6ce1f1		4829f2			SUBQ SI, DX									
  members_string.go:1266	0x6ce1f4		4889d3			MOVQ DX, BX									
  members_string.go:1266	0x6ce1f7		48f7da			NEGQ DX										
  members_string.go:1266	0x6ce1fa		48c1fa3f		SARQ $0x3f, DX									
  members_string.go:1266	0x6ce1fe		4821f2			ANDQ SI, DX									
  members_string.go:1266	0x6ce201		4801d0			ADDQ DX, AX									
  strings.go:1264		0x6ce204		488b8c2488000000	MOVQ 0x88(SP), CX								
  strings.go:1264		0x6ce20c		e88f6ed4ff		CALL internal/stringslite.Index(SB)						
  members_string.go:1267	0x6ce211		4885c0			TESTQ AX, AX									
  members_string.go:1267	0x6ce214		7c3f			JL 0x6ce255									
  members_string.go:1270	0x6ce216		488b542430		MOVQ 0x30(SP), DX								
  members_string.go:1270	0x6ce21b		488d3402		LEAQ 0(DX)(AX*1), SI								
  members_string.go:1270	0x6ce21f		488bbc2480000000	MOVQ 0x80(SP), DI								
  members_string.go:1270	0x6ce227		4839f7			CMPQ DI, SI									
  members_string.go:1270	0x6ce22a		0f82a1000000		JB 0x6ce2d1									
  strings.go:1264		0x6ce230		4889442448		MOVQ AX, 0x48(SP)								
  members_string.go:1270	0x6ce235		4889c3			MOVQ AX, BX									
  members_string.go:1270	0x6ce238		48f7d8			NEGQ AX										
  members_string.go:1270	0x6ce23b		48c1f83f		SARQ $0x3f, AX									
  members_string.go:1270	0x6ce23f		4821d0			ANDQ DX, AX									
  members_string.go:1270	0x6ce242		488b542478		MOVQ 0x78(SP), DX								
  members_string.go:1270	0x6ce247		4801d0			ADDQ DX, AX									
  members_string.go:1270	0x6ce24a		4889442458		MOVQ AX, 0x58(SP)								
  utf8.go:448			0x6ce24f		31d2			XORL DX, DX									
  utf8.go:448			0x6ce251		31f6			XORL SI, SI									
  utf8.go:448			0x6ce253		eb32			JMP 0x6ce287									
  members_string.go:1268	0x6ce255		48c7c0ffffffff		MOVQ $-0x1, AX									
  members_string.go:1268	0x6ce25c		31db			XORL BX, BX									
  members_string.go:1268	0x6ce25e		31c9			XORL CX, CX									
  members_string.go:1268	0x6ce260		4883c460		ADDQ $0x60, SP									
  members_string.go:1268	0x6ce264		5d			POPQ BP										
  members_string.go:1268	0x6ce265		c3			RET										
  members_string.go:1264	0x6ce266		4889d0			MOVQ DX, AX									
  members_string.go:1264	0x6ce269		31db			XORL BX, BX									
  members_string.go:1264	0x6ce26b		31c9			XORL CX, CX									
  members_string.go:1264	0x6ce26d		4883c460		ADDQ $0x60, SP									
  members_string.go:1264	0x6ce271		5d			POPQ BP										
  members_string.go:1264	0x6ce272		c3			RET										
  members_string.go:1261	0x6ce273		48c7c0ffffffff		MOVQ $-0x1, AX									
  members_string.go:1261	0x6ce27a		31db			XORL BX, BX									
  members_string.go:1261	0x6ce27c		31c9			XORL CX, CX									
  members_string.go:1261	0x6ce27e		4883c460		ADDQ $0x60, SP									
  members_string.go:1261	0x6ce282		5d			POPQ BP										
  members_string.go:1261	0x6ce283		c3			RET										
  utf8.go:449			0x6ce284		48ffc6			INCQ SI										
  utf8.go:448			0x6ce287		4839d3			CMPQ BX, DX									
  utf8.go:448			0x6ce28a		7e2f			JLE 0x6ce2bb									
  utf8.go:448			0x6ce28c		0fb63c02		MOVZX 0(DX)(AX*1), DI								
  utf8.go:448			0x6ce290		83ff7f			CMPL DI, $0x7f									
  utf8.go:448			0x6ce293		7f05			JG 0x6ce29a									
  utf8.go:448			0x6ce295		48ffc2			INCQ DX										
  utf8.go:448			0x6ce298		ebea			JMP 0x6ce284									
  utf8.go:448			0x6ce29a		4889742440		MOVQ SI, 0x40(SP)								
  utf8.go:448			0x6ce29f		4889d1			MOVQ DX, CX									
  utf8.go:448			0x6ce2a2		e859efdaff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x6ce2a7		488b442458		MOVQ 0x58(SP), AX								
  utf8.go:449			0x6ce2ac		488b742440		MOVQ 0x40(SP), SI								
  utf8.go:449			0x6ce2b1		4889da			MOVQ BX, DX									
  utf8.go:448			0x6ce2b4		488b5c2448		MOVQ 0x48(SP), BX								
  utf8.go:448			0x6ce2b9		ebc9			JMP 0x6ce284									
  members_string.go:1270	0x6ce2bb		488b942498000000	MOVQ 0x98(SP), DX								
  members_string.go:1270	0x6ce2c3		488d0432		LEAQ 0(DX)(SI*1), AX								
  members_string.go:1270	0x6ce2c7		31db			XORL BX, BX									
  members_string.go:1270	0x6ce2c9		31c9			XORL CX, CX									
  members_string.go:1270	0x6ce2cb		4883c460		ADDQ $0x60, SP									
  members_string.go:1270	0x6ce2cf		5d			POPQ BP										
  members_string.go:1270	0x6ce2d0		c3			RET										
  members_string.go:1270	0x6ce2d1		e8aaffdbff		CALL runtime.panicBounds(SB)							
  members_string.go:1266	0x6ce2d6		e8a5ffdbff		CALL runtime.panicBounds(SB)							
  members_string.go:1199	0x6ce2db		48ffc6			INCQ SI										
  members_string.go:1195	0x6ce2de		4c89ca			MOVQ R9, DX									
  members_string.go:1195	0x6ce2e1		4839d3			CMPQ BX, DX									
  members_string.go:1195	0x6ce2e4		7e5f			JLE 0x6ce345									
  members_string.go:1195	0x6ce2e6		440fb60c02		MOVZX 0(DX)(AX*1), R9								
  members_string.go:1195	0x6ce2eb		4183f97f		CMPL R9, $0x7f									
  members_string.go:1195	0x6ce2ef		7f06			JG 0x6ce2f7									
  members_string.go:1195	0x6ce2f1		4c8d4a01		LEAQ 0x1(DX), R9								
  members_string.go:1195	0x6ce2f5		eb34			JMP 0x6ce32b									
  members_string.go:1195	0x6ce2f7		4889542450		MOVQ DX, 0x50(SP)								
  members_string.go:1195	0x6ce2fc		4889742438		MOVQ SI, 0x38(SP)								
  members_string.go:1195	0x6ce301		4889d1			MOVQ DX, CX									
  members_string.go:1195	0x6ce304		e8f7eedaff		CALL runtime.decoderune(SB)							
  members_string.go:1195	0x6ce309		488b442478		MOVQ 0x78(SP), AX								
  members_string.go:1259	0x6ce30e		488b542450		MOVQ 0x50(SP), DX								
  members_string.go:1196	0x6ce313		488b742438		MOVQ 0x38(SP), SI								
  members_string.go:1196	0x6ce318		4c8b842498000000	MOVQ 0x98(SP), R8								
  members_string.go:1195	0x6ce320		4989d9			MOVQ BX, R9									
  members_string.go:1195	0x6ce323		488b9c2480000000	MOVQ 0x80(SP), BX								
  members_string.go:1196	0x6ce32b		4939f0			CMPQ R8, SI									
  members_string.go:1196	0x6ce32e		75ab			JNE 0x6ce2db									
  members_string.go:1196	0x6ce330		b901000000		MOVL $0x1, CX									
  members_string.go:1259	0x6ce335		4889d6			MOVQ DX, SI									
  members_string.go:1264	0x6ce338		4c89c2			MOVQ R8, DX									
  members_string.go:1264	0x6ce33b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:1259	0x6ce340		e97bfeffff		JMP 0x6ce1c0									
  members_string.go:1201	0x6ce345		4939f0			CMPQ R8, SI									
  members_string.go:1201	0x6ce348		7510			JNE 0x6ce35a									
  members_string.go:1264	0x6ce34a		4c89c2			MOVQ R8, DX									
  members_string.go:1264	0x6ce34d		b901000000		MOVL $0x1, CX									
  members_string.go:1259	0x6ce352		4889de			MOVQ BX, SI									
  members_string.go:1259	0x6ce355		e966feffff		JMP 0x6ce1c0									
  members_string.go:1264	0x6ce35a		4c89c2			MOVQ R8, DX									
  members_string.go:1264	0x6ce35d		31c9			XORL CX, CX									
  members_string.go:1264	0x6ce35f		31f6			XORL SI, SI									
  members_string.go:1259	0x6ce361		e95afeffff		JMP 0x6ce1c0									
  members_string.go:1223	0x6ce366		4889442408		MOVQ AX, 0x8(SP)								
  members_string.go:1223	0x6ce36b		48895c2410		MOVQ BX, 0x10(SP)								
  members_string.go:1223	0x6ce370		48894c2418		MOVQ CX, 0x18(SP)								
  members_string.go:1223	0x6ce375		48897c2420		MOVQ DI, 0x20(SP)								
  members_string.go:1223	0x6ce37a		4889742428		MOVQ SI, 0x28(SP)								
  members_string.go:1223	0x6ce37f		4c89442430		MOVQ R8, 0x30(SP)								
  members_string.go:1223	0x6ce384		e8b7e2dbff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:1223	0x6ce389		488b442408		MOVQ 0x8(SP), AX								
  members_string.go:1223	0x6ce38e		488b5c2410		MOVQ 0x10(SP), BX								
  members_string.go:1223	0x6ce393		488b4c2418		MOVQ 0x18(SP), CX								
  members_string.go:1223	0x6ce398		488b7c2420		MOVQ 0x20(SP), DI								
  members_string.go:1223	0x6ce39d		488b742428		MOVQ 0x28(SP), SI								
  members_string.go:1223	0x6ce3a2		4c8b442430		MOVQ 0x30(SP), R8								
  members_string.go:1223	0x6ce3a7		e9f4fbffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneIndex(SB)		

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:1297	0x6ce500		4c8da424c0feffff	LEAQ 0xfffffec0(SP), R12								
  members_string.go:1297	0x6ce508		4d3b6610		CMPQ R12, 0x10(R14)									
  members_string.go:1297	0x6ce50c		0f865f020000		JBE 0x6ce771										
  members_string.go:1297	0x6ce512		55			PUSHQ BP										
  members_string.go:1297	0x6ce513		4889e5			MOVQ SP, BP										
  members_string.go:1297	0x6ce516		4881ecb8010000		SUBQ $0x1b8, SP										
  members_string.go:1298	0x6ce51d		4c898424f0010000	MOVQ R8, 0x1f0(SP)									
  members_string.go:1298	0x6ce525		48898c24d8010000	MOVQ CX, 0x1d8(SP)									
  members_string.go:1298	0x6ce52d		48899c24d0010000	MOVQ BX, 0x1d0(SP)									
  members_string.go:1298	0x6ce535		4889b424e8010000	MOVQ SI, 0x1e8(SP)									
  members_string.go:1298	0x6ce53d		4889bc24e0010000	MOVQ DI, 0x1e0(SP)									
  members_string.go:1298	0x6ce545		e876feffff		CALL github.com/mgomes/vibescript/internal/runtime.reserveFallbackSearchScratch(SB)	
  members_string.go:1298	0x6ce54a		4885c0			TESTQ AX, AX										
  members_string.go:1298	0x6ce54d		0f859b010000		JNE 0x6ce6ee										
  members_string.go:1301	0x6ce553		488d8424e8000000	LEAQ 0xe8(SP), AX									
  members_string.go:1301	0x6ce55b		488b9c24d0010000	MOVQ 0x1d0(SP), BX									
  members_string.go:1301	0x6ce563		488b8c24d8010000	MOVQ 0x1d8(SP), CX									
  members_string.go:1301	0x6ce56b		e810c8d9ff		CALL runtime.stringtoslicerune(SB)							
  members_string.go:1301	0x6ce570		48899c2488010000	MOVQ BX, 0x188(SP)									
  members_string.go:1301	0x6ce578		48898424a8010000	MOVQ AX, 0x1a8(SP)									
  members_string.go:1301	0x6ce580		48898c2490010000	MOVQ CX, 0x190(SP)									
  members_string.go:1302	0x6ce588		488d442468		LEAQ 0x68(SP), AX									
  members_string.go:1302	0x6ce58d		488b9c24e0010000	MOVQ 0x1e0(SP), BX									
  members_string.go:1302	0x6ce595		488b8c24e8010000	MOVQ 0x1e8(SP), CX									
  members_string.go:1302	0x6ce59d		0f1f00			NOPL 0(AX)										
  members_string.go:1302	0x6ce5a0		e8dbc7d9ff		CALL runtime.stringtoslicerune(SB)							
  members_string.go:1303	0x6ce5a5		488b942488010000	MOVQ 0x188(SP), DX									
  members_string.go:1303	0x6ce5ad		488bb424f0010000	MOVQ 0x1f0(SP), SI									
  members_string.go:1303	0x6ce5b5		4839f2			CMPQ DX, SI										
  members_string.go:1303	0x6ce5b8		0f8c1c010000		JL 0x6ce6da										
  members_string.go:1303	0x6ce5be		6690			NOPW											
  members_string.go:1306	0x6ce5c0		4885db			TESTQ BX, BX										
  members_string.go:1306	0x6ce5c3		0f8401010000		JE 0x6ce6ca										
  members_string.go:1309	0x6ce5c9		4989d0			MOVQ DX, R8										
  members_string.go:1309	0x6ce5cc		4829da			SUBQ BX, DX										
  members_string.go:1310	0x6ce5cf		4839d6			CMPQ SI, DX										
  members_string.go:1310	0x6ce5d2		0f8fde000000		JG 0x6ce6b6										
  members_string.go:1310	0x6ce5d8		0f1f840000000000	NOPL 0(AX)(AX*1)									
  members_string.go:1303	0x6ce5e0		4939f0			CMPQ R8, SI										
  members_string.go:1320	0x6ce5e3		0f8282010000		JB 0x6ce76b										
  members_string.go:1302	0x6ce5e9		48899c2470010000	MOVQ BX, 0x170(SP)									
  members_string.go:1302	0x6ce5f1		48898424a0010000	MOVQ AX, 0x1a0(SP)									
  members_string.go:1302	0x6ce5f9		48898c2478010000	MOVQ CX, 0x178(SP)									
  members_string.go:1320	0x6ce601		4929f0			SUBQ SI, R8										
  members_string.go:1320	0x6ce604		488bbc2490010000	MOVQ 0x190(SP), DI									
  members_string.go:1320	0x6ce60c		4829f7			SUBQ SI, DI										
  members_string.go:1320	0x6ce60f		488b9424a8010000	MOVQ 0x1a8(SP), DX									
  members_string.go:1320	0x6ce617		488d1cb2		LEAQ 0(DX)(SI*4), BX									
  members_string.go:1320	0x6ce61b		488d442448		LEAQ 0x48(SP), AX									
  members_string.go:1320	0x6ce620		4c89c1			MOVQ R8, CX										
  members_string.go:1320	0x6ce623		e8d8c8d9ff		CALL runtime.slicerunetostring(SB)							
  members_string.go:1320	0x6ce628		48898424b0010000	MOVQ AX, 0x1b0(SP)									
  members_string.go:1320	0x6ce630		48899c2498010000	MOVQ BX, 0x198(SP)									
  members_string.go:1321	0x6ce638		488d442428		LEAQ 0x28(SP), AX									
  members_string.go:1321	0x6ce63d		488b9c24a0010000	MOVQ 0x1a0(SP), BX									
  members_string.go:1321	0x6ce645		488b8c2470010000	MOVQ 0x170(SP), CX									
  members_string.go:1321	0x6ce64d		488bbc2478010000	MOVQ 0x178(SP), DI									
  members_string.go:1321	0x6ce655		e8a6c8d9ff		CALL runtime.slicerunetostring(SB)							
  strings.go:1264		0x6ce65a		4889c1			MOVQ AX, CX										
  strings.go:1264		0x6ce65d		4889df			MOVQ BX, DI										
  strings.go:1264		0x6ce660		488b8424b0010000	MOVQ 0x1b0(SP), AX									
  strings.go:1264		0x6ce668		488b9c2498010000	MOVQ 0x198(SP), BX									
  strings.go:1264		0x6ce670		e82b6ad4ff		CALL internal/stringslite.Index(SB)							
  members_string.go:1322	0x6ce675		4885c0			TESTQ AX, AX										
  members_string.go:1322	0x6ce678		7c28			JL 0x6ce6a2										
  members_string.go:1325	0x6ce67a		488b942498010000	MOVQ 0x198(SP), DX									
  members_string.go:1325	0x6ce682		4839d0			CMPQ AX, DX										
  members_string.go:1325	0x6ce685		0f87db000000		JA 0x6ce766										
  strings.go:1264		0x6ce68b		4889842468010000	MOVQ AX, 0x168(SP)									
  utf8.go:448			0x6ce693		31d2			XORL DX, DX										
  utf8.go:448			0x6ce695		488bb424b0010000	MOVQ 0x1b0(SP), SI									
  utf8.go:448			0x6ce69d		31c9			XORL CX, CX										
  utf8.go:448			0x6ce69f		90			NOPL											
  utf8.go:448			0x6ce6a0		eb65			JMP 0x6ce707										
  members_string.go:1323	0x6ce6a2		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1323	0x6ce6a9		31db			XORL BX, BX										
  members_string.go:1323	0x6ce6ab		31c9			XORL CX, CX										
  members_string.go:1323	0x6ce6ad		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1323	0x6ce6b4		5d			POPQ BP											
  members_string.go:1323	0x6ce6b5		c3			RET											
  members_string.go:1311	0x6ce6b6		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1311	0x6ce6bd		31db			XORL BX, BX										
  members_string.go:1311	0x6ce6bf		31c9			XORL CX, CX										
  members_string.go:1311	0x6ce6c1		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1311	0x6ce6c8		5d			POPQ BP											
  members_string.go:1311	0x6ce6c9		c3			RET											
  members_string.go:1307	0x6ce6ca		4889f0			MOVQ SI, AX										
  members_string.go:1307	0x6ce6cd		31db			XORL BX, BX										
  members_string.go:1307	0x6ce6cf		31c9			XORL CX, CX										
  members_string.go:1307	0x6ce6d1		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1307	0x6ce6d8		5d			POPQ BP											
  members_string.go:1307	0x6ce6d9		c3			RET											
  members_string.go:1304	0x6ce6da		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1304	0x6ce6e1		31db			XORL BX, BX										
  members_string.go:1304	0x6ce6e3		31c9			XORL CX, CX										
  members_string.go:1304	0x6ce6e5		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1304	0x6ce6ec		5d			POPQ BP											
  members_string.go:1304	0x6ce6ed		c3			RET											
  members_string.go:1299	0x6ce6ee		4889d9			MOVQ BX, CX										
  members_string.go:1299	0x6ce6f1		4889c3			MOVQ AX, BX										
  members_string.go:1299	0x6ce6f4		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1299	0x6ce6fb		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1299	0x6ce702		5d			POPQ BP											
  members_string.go:1299	0x6ce703		c3			RET											
  utf8.go:449			0x6ce704		48ffc1			INCQ CX											
  utf8.go:448			0x6ce707		4839d0			CMPQ AX, DX										
  utf8.go:448			0x6ce70a		7e41			JLE 0x6ce74d										
  utf8.go:448			0x6ce70c		0fb63c16		MOVZX 0(SI)(DX*1), DI									
  utf8.go:448			0x6ce710		83ff7f			CMPL DI, $0x7f										
  utf8.go:448			0x6ce713		7f05			JG 0x6ce71a										
  utf8.go:448			0x6ce715		48ffc2			INCQ DX											
  utf8.go:448			0x6ce718		ebea			JMP 0x6ce704										
  utf8.go:448			0x6ce71a		48898c2480010000	MOVQ CX, 0x180(SP)									
  utf8.go:448			0x6ce722		4889c3			MOVQ AX, BX										
  utf8.go:448			0x6ce725		4889d1			MOVQ DX, CX										
  utf8.go:448			0x6ce728		4889f0			MOVQ SI, AX										
  utf8.go:448			0x6ce72b		e8d0eadaff		CALL runtime.decoderune(SB)								
  utf8.go:448			0x6ce730		488b842468010000	MOVQ 0x168(SP), AX									
  utf8.go:449			0x6ce738		488b8c2480010000	MOVQ 0x180(SP), CX									
  utf8.go:448			0x6ce740		488bb424b0010000	MOVQ 0x1b0(SP), SI									
  utf8.go:449			0x6ce748		4889da			MOVQ BX, DX										
  utf8.go:448			0x6ce74b		ebb7			JMP 0x6ce704										
  members_string.go:1325	0x6ce74d		488b9424f0010000	MOVQ 0x1f0(SP), DX									
  members_string.go:1325	0x6ce755		488d040a		LEAQ 0(DX)(CX*1), AX									
  members_string.go:1325	0x6ce759		31db			XORL BX, BX										
  members_string.go:1325	0x6ce75b		31c9			XORL CX, CX										
  members_string.go:1325	0x6ce75d		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1325	0x6ce764		5d			POPQ BP											
  members_string.go:1325	0x6ce765		c3			RET											
  members_string.go:1325	0x6ce766		e815fbdbff		CALL runtime.panicBounds(SB)								
  members_string.go:1320	0x6ce76b		e810fbdbff		CALL runtime.panicBounds(SB)								
  members_string.go:1320	0x6ce770		90			NOPL											
  members_string.go:1297	0x6ce771		4889442408		MOVQ AX, 0x8(SP)									
  members_string.go:1297	0x6ce776		48895c2410		MOVQ BX, 0x10(SP)									
  members_string.go:1297	0x6ce77b		48894c2418		MOVQ CX, 0x18(SP)									
  members_string.go:1297	0x6ce780		48897c2420		MOVQ DI, 0x20(SP)									
  members_string.go:1297	0x6ce785		4889742428		MOVQ SI, 0x28(SP)									
  members_string.go:1297	0x6ce78a		4c89442430		MOVQ R8, 0x30(SP)									
  members_string.go:1297	0x6ce78f		e8acdedbff		CALL runtime.morestack_noctxt.abi0(SB)							
  members_string.go:1297	0x6ce794		488b442408		MOVQ 0x8(SP), AX									
  members_string.go:1297	0x6ce799		488b5c2410		MOVQ 0x10(SP), BX									
  members_string.go:1297	0x6ce79e		488b4c2418		MOVQ 0x18(SP), CX									
  members_string.go:1297	0x6ce7a3		488b7c2420		MOVQ 0x20(SP), DI									
  members_string.go:1297	0x6ce7a8		488b742428		MOVQ 0x28(SP), SI									
  members_string.go:1297	0x6ce7ad		4c8b442430		MOVQ 0x30(SP), R8									
  members_string.go:1297	0x6ce7b2		e949fdffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB)		

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneSlice(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:1446	0x6cefa0		4c8d642488		LEAQ -0x78(SP), R12							
  members_string.go:1446	0x6cefa5		4d3b6610		CMPQ R12, 0x10(R14)							
  members_string.go:1446	0x6cefa9		0f8629030000		JBE 0x6cf2d8								
  members_string.go:1446	0x6cefaf		55			PUSHQ BP								
  members_string.go:1446	0x6cefb0		4889e5			MOVQ SP, BP								
  members_string.go:1446	0x6cefb3		4881ecf0000000		SUBQ $0xf0, SP								
  members_string.go:1446	0x6cefba		4889842400010000	MOVQ AX, 0x100(SP)							
  members_string.go:1447	0x6cefc2		4885ff			TESTQ DI, DI								
  members_string.go:1447	0x6cefc5		7c26			JL 0x6cefed								
  members_string.go:1447	0x6cefc7		4889bc2418010000	MOVQ DI, 0x118(SP)							
  members_string.go:1447	0x6cefcf		48899c2408010000	MOVQ BX, 0x108(SP)							
  members_string.go:1447	0x6cefd7		4889842400010000	MOVQ AX, 0x100(SP)							
  members_string.go:1447	0x6cefdf		90			NOPL									
  members_string.go:1450	0x6cefe0		4885c9			TESTQ CX, CX								
  members_string.go:1450	0x6cefe3		7d19			JGE 0x6ceffe								
  members_string.go:1178	0x6cefe5		90			NOPL									
  members_string.go:1100	0x6cefe6		31d2			XORL DX, DX								
  members_string.go:1100	0x6cefe8		e93b020000		JMP 0x6cf228								
  members_string.go:1448	0x6cefed		31c0			XORL AX, AX								
  members_string.go:1448	0x6cefef		31db			XORL BX, BX								
  members_string.go:1448	0x6ceff1		31c9			XORL CX, CX								
  members_string.go:1448	0x6ceff3		89cf			MOVL CX, DI								
  members_string.go:1448	0x6ceff5		4881c4f0000000		ADDQ $0xf0, SP								
  members_string.go:1448	0x6ceffc		5d			POPQ BP									
  members_string.go:1448	0x6ceffd		c3			RET									
  members_string.go:1448	0x6ceffe		6690			NOPW									
  members_string.go:1185	0x6cf000		4885c9			TESTQ CX, CX								
  members_string.go:1185	0x6cf003		7d06			JGE 0x6cf00b								
  members_string.go:1185	0x6cf005		31c9			XORL CX, CX								
  members_string.go:1185	0x6cf007		31d2			XORL DX, DX								
  members_string.go:1456	0x6cf009		eb3f			JMP 0x6cf04a								
  members_string.go:1188	0x6cf00b		90			NOPL									
  members_string.go:1100	0x6cf00c		31d2			XORL DX, DX								
  members_string.go:1100	0x6cf00e		eb03			JMP 0x6cf013								
  members_string.go:1100	0x6cf010		48ffc2			INCQ DX									
  members_string.go:1100	0x6cf013		4839d3			CMPQ BX, DX								
  members_string.go:1100	0x6cf016		7e1f			JLE 0x6cf037								
  members_string.go:1101	0x6cf018		0fb63410		MOVZX 0(AX)(DX*1), SI							
  members_string.go:1101	0x6cf01c		0f1f4000		NOPL 0(AX)								
  members_string.go:1101	0x6cf020		4080fe80		CMPL SI, $0x80								
  members_string.go:1101	0x6cf024		72ea			JB 0x6cf010								
  members_string.go:1456	0x6cf026		48898c24d0000000	MOVQ CX, 0xd0(SP)							
  members_string.go:1195	0x6cf02e		31d2			XORL DX, DX								
  members_string.go:1195	0x6cf030		31f6			XORL SI, SI								
  members_string.go:1195	0x6cf032		e95e010000		JMP 0x6cf195								
  members_string.go:1189	0x6cf037		4839cb			CMPQ BX, CX								
  members_string.go:1189	0x6cf03a		7d06			JGE 0x6cf042								
  members_string.go:1189	0x6cf03c		31c9			XORL CX, CX								
  members_string.go:1189	0x6cf03e		31d2			XORL DX, DX								
  members_string.go:1456	0x6cf040		eb08			JMP 0x6cf04a								
  members_string.go:1456	0x6cf042		4889ca			MOVQ CX, DX								
  members_string.go:1456	0x6cf045		b901000000		MOVL $0x1, CX								
  members_string.go:1456	0x6cf04a		84c9			TESTL CL, CL								
  members_string.go:1457	0x6cf04c		740d			JE 0x6cf05b								
  members_string.go:1456	0x6cf04e		48899424c0000000	MOVQ DX, 0xc0(SP)							
  members_string.go:1456	0x6cf056		4889d1			MOVQ DX, CX								
  members_string.go:1461	0x6cf059		eb17			JMP 0x6cf072								
  members_string.go:1458	0x6cf05b		31c0			XORL AX, AX								
  members_string.go:1458	0x6cf05d		31db			XORL BX, BX								
  members_string.go:1458	0x6cf05f		31c9			XORL CX, CX								
  members_string.go:1458	0x6cf061		89cf			MOVL CX, DI								
  members_string.go:1458	0x6cf063		4881c4f0000000		ADDQ $0xf0, SP								
  members_string.go:1458	0x6cf06a		5d			POPQ BP									
  members_string.go:1458	0x6cf06b		c3			RET									
  members_string.go:1466	0x6cf06c		4801f2			ADDQ SI, DX								
  members_string.go:1461	0x6cf06f		48ffcf			DECQ DI									
  members_string.go:1461	0x6cf072		4885ff			TESTQ DI, DI								
  members_string.go:1461	0x6cf075		7e73			JLE 0x6cf0ea								
  members_string.go:1462	0x6cf077		4839d3			CMPQ BX, DX								
  members_string.go:1462	0x6cf07a		746e			JE 0x6cf0ea								
  members_string.go:1462	0x6cf07c		0f1f4000		NOPL 0(AX)								
  members_string.go:1465	0x6cf080		0f8204010000		JB 0x6cf18a								
  utf8.go:223			0x6cf086		0fb63402		MOVZX 0(DX)(AX*1), SI							
  members_string.go:1465	0x6cf08a		4989d8			MOVQ BX, R8								
  members_string.go:1465	0x6cf08d		4929d0			SUBQ DX, R8								
  members_string.go:1465	0x6cf090		4c8d0c02		LEAQ 0(DX)(AX*1), R9							
  utf8.go:223			0x6cf094		4080fe80		CMPL SI, $0x80								
  utf8.go:223			0x6cf098		7308			JAE 0x6cf0a2								
  utf8.go:223			0x6cf09a		be01000000		MOVL $0x1, SI								
  utf8.go:223			0x6cf09f		90			NOPL									
  members_string.go:1465	0x6cf0a0		ebca			JMP 0x6cf06c								
  members_string.go:1461	0x6cf0a2		4889bc24e0000000	MOVQ DI, 0xe0(SP)							
  members_string.go:1461	0x6cf0aa		48899424d8000000	MOVQ DX, 0xd8(SP)							
  utf8.go:226			0x6cf0b2		4c89c8			MOVQ R9, AX								
  utf8.go:226			0x6cf0b5		4c89c3			MOVQ R8, BX								
  utf8.go:226			0x6cf0b8		e843f8ddff		CALL unicode/utf8.decodeRuneInStringSlow(SB)				
  utf8.go:223			0x6cf0bd		488b842400010000	MOVQ 0x100(SP), AX							
  members_string.go:1468	0x6cf0c5		488b8c24c0000000	MOVQ 0xc0(SP), CX							
  members_string.go:1466	0x6cf0cd		488b9424d8000000	MOVQ 0xd8(SP), DX							
  members_string.go:1461	0x6cf0d5		488bbc24e0000000	MOVQ 0xe0(SP), DI							
  members_string.go:1465	0x6cf0dd		4889de			MOVQ BX, SI								
  members_string.go:1462	0x6cf0e0		488b9c2408010000	MOVQ 0x108(SP), BX							
  members_string.go:1465	0x6cf0e8		eb82			JMP 0x6cf06c								
  members_string.go:1468	0x6cf0ea		4839d3			CMPQ BX, DX								
  members_string.go:1468	0x6cf0ed		0f8292000000		JB 0x6cf185								
  members_string.go:1468	0x6cf0f3		4839ca			CMPQ DX, CX								
  members_string.go:1468	0x6cf0f6		0f8283000000		JB 0x6cf17f								
  members_string.go:1468	0x6cf0fc		4829ca			SUBQ CX, DX								
  members_string.go:1468	0x6cf0ff		48899424b8000000	MOVQ DX, 0xb8(SP)							
  members_string.go:1468	0x6cf107		4889d3			MOVQ DX, BX								
  members_string.go:1468	0x6cf10a		48f7da			NEGQ DX									
  members_string.go:1468	0x6cf10d		48c1fa3f		SARQ $0x3f, DX								
  members_string.go:1468	0x6cf111		4821d1			ANDQ DX, CX								
  members_string.go:1468	0x6cf114		4801c8			ADDQ CX, AX								
  members_string.go:1468	0x6cf117		48898424e8000000	MOVQ AX, 0xe8(SP)							
  members_string.go:1433	0x6cf11f		90			NOPL									
  members_string.go:1433	0x6cf120		e83bfeddff		CALL unicode/utf8.ValidString(SB)					
  members_string.go:1433	0x6cf125		88442427		MOVB AL, 0x27(SP)							
  members_string.go:1433	0x6cf129		84c0			TESTL AL, AL								
  members_string.go:1433	0x6cf12b		7412			JE 0x6cf13f								
  members_string.go:1468	0x6cf12d		488b9c24b8000000	MOVQ 0xb8(SP), BX							
  members_string.go:1468	0x6cf135		488b8424e8000000	MOVQ 0xe8(SP), AX							
  members_string.go:1468	0x6cf13d		eb2a			JMP 0x6cf169								
  members_string.go:1436	0x6cf13f		488d442428		LEAQ 0x28(SP), AX							
  members_string.go:1436	0x6cf144		488b9c24e8000000	MOVQ 0xe8(SP), BX							
  members_string.go:1436	0x6cf14c		488b8c24b8000000	MOVQ 0xb8(SP), CX							
  members_string.go:1436	0x6cf154		e827bcd9ff		CALL runtime.stringtoslicerune(SB)					
  members_string.go:1436	0x6cf159		4889cf			MOVQ CX, DI								
  members_string.go:1436	0x6cf15c		4889d9			MOVQ BX, CX								
  members_string.go:1436	0x6cf15f		4889c3			MOVQ AX, BX								
  members_string.go:1436	0x6cf162		31c0			XORL AX, AX								
  members_string.go:1436	0x6cf164		e897bdd9ff		CALL runtime.slicerunetostring(SB)					
  members_string.go:1468	0x6cf169		0fb64c2427		MOVZX 0x27(SP), CX							
  members_string.go:1468	0x6cf16e		83f101			XORL $0x1, CX								
  members_string.go:1468	0x6cf171		bf01000000		MOVL $0x1, DI								
  members_string.go:1468	0x6cf176		4881c4f0000000		ADDQ $0xf0, SP								
  members_string.go:1468	0x6cf17d		5d			POPQ BP									
  members_string.go:1468	0x6cf17e		c3			RET									
  members_string.go:1468	0x6cf17f		90			NOPL									
  members_string.go:1468	0x6cf180		e8fbf0dbff		CALL runtime.panicBounds(SB)						
  members_string.go:1468	0x6cf185		e8f6f0dbff		CALL runtime.panicBounds(SB)						
  members_string.go:1465	0x6cf18a		e8f1f0dbff		CALL runtime.panicBounds(SB)						
  members_string.go:1199	0x6cf18f		48ffc6			INCQ SI									
  members_string.go:1195	0x6cf192		4c89c2			MOVQ R8, DX								
  members_string.go:1195	0x6cf195		4839d3			CMPQ BX, DX								
  members_string.go:1195	0x6cf198		7e6d			JLE 0x6cf207								
  members_string.go:1195	0x6cf19a		440fb60410		MOVZX 0(AX)(DX*1), R8							
  members_string.go:1195	0x6cf19f		90			NOPL									
  members_string.go:1195	0x6cf1a0		4183f87f		CMPL R8, $0x7f								
  members_string.go:1195	0x6cf1a4		7f06			JG 0x6cf1ac								
  members_string.go:1195	0x6cf1a6		4c8d4201		LEAQ 0x1(DX), R8							
  members_string.go:1195	0x6cf1aa		eb4c			JMP 0x6cf1f8								
  members_string.go:1195	0x6cf1ac		48899424a8000000	MOVQ DX, 0xa8(SP)							
  members_string.go:1195	0x6cf1b4		4889b424c8000000	MOVQ SI, 0xc8(SP)							
  members_string.go:1195	0x6cf1bc		4889d1			MOVQ DX, CX								
  members_string.go:1195	0x6cf1bf		90			NOPL									
  members_string.go:1195	0x6cf1c0		e83be0daff		CALL runtime.decoderune(SB)						
  members_string.go:1195	0x6cf1c5		488b842400010000	MOVQ 0x100(SP), AX							
  members_string.go:1196	0x6cf1cd		488b8c24d0000000	MOVQ 0xd0(SP), CX							
  members_string.go:1456	0x6cf1d5		488b9424a8000000	MOVQ 0xa8(SP), DX							
  members_string.go:1196	0x6cf1dd		488bb424c8000000	MOVQ 0xc8(SP), SI							
  members_string.go:1461	0x6cf1e5		488bbc2418010000	MOVQ 0x118(SP), DI							
  members_string.go:1195	0x6cf1ed		4989d8			MOVQ BX, R8								
  members_string.go:1195	0x6cf1f0		488b9c2408010000	MOVQ 0x108(SP), BX							
  members_string.go:1196	0x6cf1f8		4839ce			CMPQ SI, CX								
  members_string.go:1196	0x6cf1fb		7592			JNE 0x6cf18f								
  members_string.go:1196	0x6cf1fd		b901000000		MOVL $0x1, CX								
  members_string.go:1456	0x6cf202		e943feffff		JMP 0x6cf04a								
  members_string.go:1201	0x6cf207		4839ce			CMPQ SI, CX								
  members_string.go:1201	0x6cf20a		750d			JNE 0x6cf219								
  members_string.go:1201	0x6cf20c		b901000000		MOVL $0x1, CX								
  members_string.go:1456	0x6cf211		4889da			MOVQ BX, DX								
  members_string.go:1456	0x6cf214		e931feffff		JMP 0x6cf04a								
  members_string.go:1456	0x6cf219		31c9			XORL CX, CX								
  members_string.go:1456	0x6cf21b		31d2			XORL DX, DX								
  members_string.go:1456	0x6cf21d		0f1f00			NOPL 0(AX)								
  members_string.go:1456	0x6cf220		e925feffff		JMP 0x6cf04a								
  members_string.go:1100	0x6cf225		48ffc2			INCQ DX									
  members_string.go:1100	0x6cf228		4839d3			CMPQ BX, DX								
  members_string.go:1100	0x6cf22b		7e19			JLE 0x6cf246								
  members_string.go:1101	0x6cf22d		0fb63410		MOVZX 0(AX)(DX*1), SI							
  members_string.go:1101	0x6cf231		4080fe80		CMPL SI, $0x80								
  members_string.go:1101	0x6cf235		72ee			JB 0x6cf225								
  members_string.go:1447	0x6cf237		48898c2410010000	MOVQ CX, 0x110(SP)							
  members_string.go:1181	0x6cf23f		90			NOPL									
  utf8.go:448			0x6cf240		31d2			XORL DX, DX								
  utf8.go:448			0x6cf242		31f6			XORL SI, SI								
  utf8.go:448			0x6cf244		eb2a			JMP 0x6cf270								
  members_string.go:1447	0x6cf246		4889da			MOVQ BX, DX								
  members_string.go:1451	0x6cf249		4801cb			ADDQ CX, BX								
  members_string.go:1452	0x6cf24c		4885db			TESTQ BX, BX								
  members_string.go:1452	0x6cf24f		7c0b			JL 0x6cf25c								
  members_string.go:1456	0x6cf251		4889d9			MOVQ BX, CX								
  members_string.go:1100	0x6cf254		4889d3			MOVQ DX, BX								
  members_string.go:1452	0x6cf257		e9a2fdffff		JMP 0x6ceffe								
  members_string.go:1453	0x6cf25c		31c0			XORL AX, AX								
  members_string.go:1453	0x6cf25e		31db			XORL BX, BX								
  members_string.go:1453	0x6cf260		31c9			XORL CX, CX								
  members_string.go:1453	0x6cf262		89cf			MOVL CX, DI								
  members_string.go:1453	0x6cf264		4881c4f0000000		ADDQ $0xf0, SP								
  members_string.go:1453	0x6cf26b		5d			POPQ BP									
  members_string.go:1453	0x6cf26c		c3			RET									
  utf8.go:449			0x6cf26d		48ffc2			INCQ DX									
  utf8.go:448			0x6cf270		4839f3			CMPQ BX, SI								
  utf8.go:448			0x6cf273		7e53			JLE 0x6cf2c8								
  utf8.go:448			0x6cf275		440fb60430		MOVZX 0(AX)(SI*1), R8							
  utf8.go:448			0x6cf27a		660f1f440000		NOPW 0(AX)(AX*1)							
  utf8.go:448			0x6cf280		4183f87f		CMPL R8, $0x7f								
  utf8.go:448			0x6cf284		7f05			JG 0x6cf28b								
  utf8.go:448			0x6cf286		48ffc6			INCQ SI									
  utf8.go:448			0x6cf289		ebe2			JMP 0x6cf26d								
  utf8.go:448			0x6cf28b		48899424b0000000	MOVQ DX, 0xb0(SP)							
  utf8.go:448			0x6cf293		4889f1			MOVQ SI, CX								
  utf8.go:448			0x6cf296		e865dfdaff		CALL runtime.decoderune(SB)						
  utf8.go:448			0x6cf29b		488b842400010000	MOVQ 0x100(SP), AX							
  members_string.go:1451	0x6cf2a3		488b8c2410010000	MOVQ 0x110(SP), CX							
  utf8.go:449			0x6cf2ab		488b9424b0000000	MOVQ 0xb0(SP), DX							
  members_string.go:1461	0x6cf2b3		488bbc2418010000	MOVQ 0x118(SP), DI							
  utf8.go:449			0x6cf2bb		4889de			MOVQ BX, SI								
  utf8.go:448			0x6cf2be		488b9c2408010000	MOVQ 0x108(SP), BX							
  utf8.go:448			0x6cf2c6		eba5			JMP 0x6cf26d								
  members_string.go:1451	0x6cf2c8		4889d3			MOVQ DX, BX								
  members_string.go:1100	0x6cf2cb		488b942408010000	MOVQ 0x108(SP), DX							
  members_string.go:1451	0x6cf2d3		e971ffffff		JMP 0x6cf249								
  members_string.go:1446	0x6cf2d8		4889442408		MOVQ AX, 0x8(SP)							
  members_string.go:1446	0x6cf2dd		48895c2410		MOVQ BX, 0x10(SP)							
  members_string.go:1446	0x6cf2e2		48894c2418		MOVQ CX, 0x18(SP)							
  members_string.go:1446	0x6cf2e7		48897c2420		MOVQ DI, 0x20(SP)							
  members_string.go:1446	0x6cf2ec		e84fd3dbff		CALL runtime.morestack_noctxt.abi0(SB)					
  members_string.go:1446	0x6cf2f1		488b442408		MOVQ 0x8(SP), AX							
  members_string.go:1446	0x6cf2f6		488b5c2410		MOVQ 0x10(SP), BX							
  members_string.go:1446	0x6cf2fb		488b4c2418		MOVQ 0x18(SP), CX							
  members_string.go:1446	0x6cf300		488b7c2420		MOVQ 0x20(SP), DI							
  members_string.go:1446	0x6cf305		e996fcffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneSlice(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func2(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:3804	0x758940		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:3804	0x758944		0f8626010000		JBE 0x758a70									
  members_string.go:3804	0x75894a		55			PUSHQ BP									
  members_string.go:3804	0x75894b		4889e5			MOVQ SP, BP									
  members_string.go:3804	0x75894e		4883ec40		SUBQ $0x40, SP									
  members_string.go:3804	0x758952		48898c2480000000	MOVQ CX, 0x80(SP)								
  members_string.go:3804	0x75895a		4889bc2488000000	MOVQ DI, 0x88(SP)								
  members_string.go:3804	0x758962		4c89842498000000	MOVQ R8, 0x98(SP)								
  members_string.go:3805	0x75896a		4d85c9			TESTQ R9, R9									
  members_string.go:3805	0x75896d		751b			JNE 0x75898a									
  members_string.go:3808	0x75896f		4889d8			MOVQ BX, AX									
  members_string.go:3808	0x758972		4889cb			MOVQ CX, BX									
  members_string.go:3808	0x758975		4889f9			MOVQ DI, CX									
  members_string.go:3808	0x758978		4889f7			MOVQ SI, DI									
  members_string.go:3808	0x75897b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:3808	0x758980		e89b39e5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:1178	0x758985		90			NOPL										
  members_string.go:1100	0x758986		31d2			XORL DX, DX									
  members_string.go:1100	0x758988		eb6e			JMP 0x7589f8									
  errors.go:26			0x75898a		488d0559740600		LEAQ 0x67459(IP), AX								
  errors.go:26			0x758991		bb25000000		MOVL $0x25, BX									
  errors.go:26			0x758996		31c9			XORL CX, CX									
  errors.go:26			0x758998		31ff			XORL DI, DI									
  errors.go:26			0x75899a		89fe			MOVL DI, SI									
  errors.go:26			0x75899c		0f1f4000		NOPL 0(AX)									
  errors.go:26			0x7589a0		e81b55d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x7589a5		4885c0			TESTQ AX, AX									
  errors.go:26			0x7589a8		7537			JNE 0x7589e1									
  errors.go:31			0x7589aa		90			NOPL										
  errors.go:65			0x7589ab		b810000000		MOVL $0x10, AX									
  errors.go:65			0x7589b0		488d1d691d3900		LEAQ 0x391d69(IP), BX								
  errors.go:65			0x7589b7		b901000000		MOVL $0x1, CX									
  errors.go:65			0x7589bc		0f1f4000		NOPL 0(AX)									
  errors.go:65			0x7589c0		e8db89ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x7589c5		48c7400825000000	MOVQ $0x25, 0x8(AX)								
  errors.go:65			0x7589cd		488d1516740600		LEAQ 0x67416(IP), DX								
  errors.go:65			0x7589d4		488910			MOVQ DX, 0(AX)									
  members_string.go:3806	0x7589d7		4889c3			MOVQ AX, BX									
  members_string.go:3806	0x7589da		488d05effa3b00		LEAQ 0x3bfaef(IP), AX								
  members_string.go:3806	0x7589e1		31c9			XORL CX, CX									
  members_string.go:3806	0x7589e3		31ff			XORL DI, DI									
  members_string.go:3806	0x7589e5		4889c6			MOVQ AX, SI									
  members_string.go:3806	0x7589e8		4989d8			MOVQ BX, R8									
  members_string.go:3806	0x7589eb		31c0			XORL AX, AX									
  members_string.go:3806	0x7589ed		31db			XORL BX, BX									
  members_string.go:3806	0x7589ef		4883c440		ADDQ $0x40, SP									
  members_string.go:3806	0x7589f3		5d			POPQ BP										
  members_string.go:3806	0x7589f4		c3			RET										
  members_string.go:1100	0x7589f5		48ffc2			INCQ DX										
  members_string.go:1100	0x7589f8		4839d3			CMPQ BX, DX									
  members_string.go:1100	0x7589fb		7e1d			JLE 0x758a1a									
  members_string.go:1101	0x7589fd		440fb60c10		MOVZX 0(AX)(DX*1), R9								
  members_string.go:1101	0x758a02		4180f980		CMPL R9, $0x80									
  members_string.go:1101	0x758a06		72ed			JB 0x7589f5									
  members_string.go:3808	0x758a08		48895c2428		MOVQ BX, 0x28(SP)								
  members_string.go:3808	0x758a0d		4889442438		MOVQ AX, 0x38(SP)								
  members_string.go:1181	0x758a12		90			NOPL										
  utf8.go:448			0x758a13		31d2			XORL DX, DX									
  utf8.go:448			0x758a15		4531c9			XORL R9, R9									
  utf8.go:448			0x758a18		eb1a			JMP 0x758a34									
  members_string.go:3808	0x758a1a		b802000000		MOVL $0x2, AX									
  members_string.go:3808	0x758a1f		31c9			XORL CX, CX									
  members_string.go:3808	0x758a21		4889df			MOVQ BX, DI									
  members_string.go:3808	0x758a24		31f6			XORL SI, SI									
  members_string.go:3808	0x758a26		4189c8			MOVL CX, R8									
  members_string.go:3808	0x758a29		89f3			MOVL SI, BX									
  members_string.go:3808	0x758a2b		4883c440		ADDQ $0x40, SP									
  members_string.go:3808	0x758a2f		5d			POPQ BP										
  members_string.go:3808	0x758a30		c3			RET										
  utf8.go:449			0x758a31		49ffc1			INCQ R9										
  utf8.go:448			0x758a34		4839d3			CMPQ BX, DX									
  utf8.go:448			0x758a37		7e32			JLE 0x758a6b									
  utf8.go:448			0x758a39		0fb63c10		MOVZX 0(AX)(DX*1), DI								
  utf8.go:448			0x758a3d		0f1f00			NOPL 0(AX)									
  utf8.go:448			0x758a40		83ff7f			CMPL DI, $0x7f									
  utf8.go:448			0x758a43		7f05			JG 0x758a4a									
  utf8.go:448			0x758a45		48ffc2			INCQ DX										
  utf8.go:448			0x758a48		ebe7			JMP 0x758a31									
  utf8.go:448			0x758a4a		4c894c2430		MOVQ R9, 0x30(SP)								
  utf8.go:448			0x758a4f		4889d1			MOVQ DX, CX									
  utf8.go:448			0x758a52		e8a947d2ff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x758a57		488b442438		MOVQ 0x38(SP), AX								
  utf8.go:449			0x758a5c		4c8b4c2430		MOVQ 0x30(SP), R9								
  utf8.go:449			0x758a61		4889da			MOVQ BX, DX									
  utf8.go:448			0x758a64		488b5c2428		MOVQ 0x28(SP), BX								
  utf8.go:448			0x758a69		ebc6			JMP 0x758a31									
  members_string.go:3808	0x758a6b		4c89cb			MOVQ R9, BX									
  members_string.go:3808	0x758a6e		ebaa			JMP 0x758a1a									
  members_string.go:3804	0x758a70		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:3804	0x758a75		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:3804	0x758a7a		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:3804	0x758a7f		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:3804	0x758a84		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:3804	0x758a89		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:3804	0x758a8e		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:3804	0x758a93		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:3804	0x758a98		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:3804	0x758a9d		0f1f00			NOPL 0(AX)									
  members_string.go:3804	0x758aa0		e89b3bd3ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:3804	0x758aa5		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:3804	0x758aaa		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:3804	0x758aaf		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:3804	0x758ab4		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:3804	0x758ab9		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:3804	0x758abe		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:3804	0x758ac3		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:3804	0x758ac8		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:3804	0x758acd		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:3804	0x758ad2		e969feffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func2(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func20(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4045	0x75b560		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4045	0x75b564		0f8615010000		JBE 0x75b67f									
  members_string.go:4045	0x75b56a		55			PUSHQ BP									
  members_string.go:4045	0x75b56b		4889e5			MOVQ SP, BP									
  members_string.go:4045	0x75b56e		4883ec38		SUBQ $0x38, SP									
  members_string.go:4045	0x75b572		48894c2478		MOVQ CX, 0x78(SP)								
  members_string.go:4045	0x75b577		4889bc2480000000	MOVQ DI, 0x80(SP)								
  members_string.go:4045	0x75b57f		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4046	0x75b587		4983f901		CMPQ R9, $0x1									
  members_string.go:4046	0x75b58b		0f858b000000		JNE 0x75b61c									
  members_string.go:4049	0x75b591		49833804		CMPQ 0(R8), $0x4								
  members_string.go:4049	0x75b595		7413			JE 0x75b5aa									
  members_string.go:4050	0x75b597		31c0			XORL AX, AX									
  members_string.go:4050	0x75b599		31db			XORL BX, BX									
  members_string.go:4050	0x75b59b		31c9			XORL CX, CX									
  members_string.go:4050	0x75b59d		31ff			XORL DI, DI									
  members_string.go:4050	0x75b59f		89de			MOVL BX, SI									
  members_string.go:4050	0x75b5a1		4189c8			MOVL CX, R8									
  members_string.go:4050	0x75b5a4		4883c438		ADDQ $0x38, SP									
  members_string.go:4050	0x75b5a8		5d			POPQ BP										
  members_string.go:4050	0x75b5a9		c3			RET										
  members_string.go:4046	0x75b5aa		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4052	0x75b5b2		4889d8			MOVQ BX, AX									
  members_string.go:4052	0x75b5b5		4889cb			MOVQ CX, BX									
  members_string.go:4052	0x75b5b8		4889f9			MOVQ DI, CX									
  members_string.go:4052	0x75b5bb		4889f7			MOVQ SI, DI									
  members_string.go:4052	0x75b5be		6690			NOPW										
  members_string.go:4052	0x75b5c0		e85b0de5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4052	0x75b5c5		4889442430		MOVQ AX, 0x30(SP)								
  members_string.go:4052	0x75b5ca		48895c2428		MOVQ BX, 0x28(SP)								
  members_string.go:4052	0x75b5cf		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4052	0x75b5d7		488b02			MOVQ 0(DX), AX									
  members_string.go:4052	0x75b5da		488b4a10		MOVQ 0x10(DX), CX								
  members_string.go:4052	0x75b5de		488b7a18		MOVQ 0x18(DX), DI								
  members_string.go:4052	0x75b5e2		488b5a08		MOVQ 0x8(DX), BX								
  members_string.go:4052	0x75b5e6		e8350de5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4052	0x75b5eb		4889c1			MOVQ AX, CX									
  members_string.go:4052	0x75b5ee		4889df			MOVQ BX, DI									
  members_string.go:4052	0x75b5f1		488b442430		MOVQ 0x30(SP), AX								
  members_string.go:4052	0x75b5f6		488b5c2428		MOVQ 0x28(SP), BX								
  members_string.go:4052	0x75b5fb		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4052	0x75b600		e8fb27f7ff		CALL github.com/mgomes/vibescript/internal/runtime.asciiCaseCompare(SB)		
  members_string.go:4052	0x75b605		31db			XORL BX, BX									
  members_string.go:4052	0x75b607		31c9			XORL CX, CX									
  members_string.go:4052	0x75b609		4889c7			MOVQ AX, DI									
  members_string.go:4052	0x75b60c		89de			MOVL BX, SI									
  members_string.go:4052	0x75b60e		4189c8			MOVL CX, R8									
  members_string.go:4052	0x75b611		b802000000		MOVL $0x2, AX									
  members_string.go:4052	0x75b616		4883c438		ADDQ $0x38, SP									
  members_string.go:4052	0x75b61a		5d			POPQ BP										
  members_string.go:4052	0x75b61b		c3			RET										
  errors.go:26			0x75b61c		488d054e720600		LEAQ 0x6724e(IP), AX								
  errors.go:26			0x75b623		bb29000000		MOVL $0x29, BX									
  errors.go:26			0x75b628		31c9			XORL CX, CX									
  errors.go:26			0x75b62a		31ff			XORL DI, DI									
  errors.go:26			0x75b62c		89fe			MOVL DI, SI									
  errors.go:26			0x75b62e		e88d28d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75b633		4885c0			TESTQ AX, AX									
  errors.go:26			0x75b636		7533			JNE 0x75b66b									
  errors.go:31			0x75b638		90			NOPL										
  errors.go:65			0x75b639		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75b63e		488d1ddbf03800		LEAQ 0x38f0db(IP), BX								
  errors.go:65			0x75b645		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75b64a		e8515dccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75b64f		48c7400829000000	MOVQ $0x29, 0x8(AX)								
  errors.go:65			0x75b657		488d1513720600		LEAQ 0x67213(IP), DX								
  errors.go:65			0x75b65e		488910			MOVQ DX, 0(AX)									
  members_string.go:4047	0x75b661		4889c3			MOVQ AX, BX									
  members_string.go:4047	0x75b664		488d0565ce3b00		LEAQ 0x3bce65(IP), AX								
  members_string.go:4047	0x75b66b		31c9			XORL CX, CX									
  members_string.go:4047	0x75b66d		31ff			XORL DI, DI									
  members_string.go:4047	0x75b66f		4889c6			MOVQ AX, SI									
  members_string.go:4047	0x75b672		4989d8			MOVQ BX, R8									
  members_string.go:4047	0x75b675		31c0			XORL AX, AX									
  members_string.go:4047	0x75b677		31db			XORL BX, BX									
  members_string.go:4047	0x75b679		4883c438		ADDQ $0x38, SP									
  members_string.go:4047	0x75b67d		5d			POPQ BP										
  members_string.go:4047	0x75b67e		c3			RET										
  members_string.go:4045	0x75b67f		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4045	0x75b684		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4045	0x75b689		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4045	0x75b68e		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4045	0x75b693		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4045	0x75b698		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4045	0x75b69d		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4045	0x75b6a2		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4045	0x75b6a7		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4045	0x75b6ac		e88f0fd3ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4045	0x75b6b1		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4045	0x75b6b6		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4045	0x75b6bb		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4045	0x75b6c0		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4045	0x75b6c5		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4045	0x75b6ca		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4045	0x75b6cf		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4045	0x75b6d4		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4045	0x75b6d9		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4045	0x75b6de		6690			NOPW										
  members_string.go:4045	0x75b6e0		e97bfeffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func20(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func21(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4055	0x75b700		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4055	0x75b704		0f8615010000		JBE 0x75b81f									
  members_string.go:4055	0x75b70a		55			PUSHQ BP									
  members_string.go:4055	0x75b70b		4889e5			MOVQ SP, BP									
  members_string.go:4055	0x75b70e		4883ec38		SUBQ $0x38, SP									
  members_string.go:4055	0x75b712		48894c2478		MOVQ CX, 0x78(SP)								
  members_string.go:4055	0x75b717		4889bc2480000000	MOVQ DI, 0x80(SP)								
  members_string.go:4055	0x75b71f		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4056	0x75b727		4983f901		CMPQ R9, $0x1									
  members_string.go:4056	0x75b72b		0f858b000000		JNE 0x75b7bc									
  members_string.go:4059	0x75b731		49833804		CMPQ 0(R8), $0x4								
  members_string.go:4059	0x75b735		7413			JE 0x75b74a									
  members_string.go:4060	0x75b737		31c0			XORL AX, AX									
  members_string.go:4060	0x75b739		31db			XORL BX, BX									
  members_string.go:4060	0x75b73b		31c9			XORL CX, CX									
  members_string.go:4060	0x75b73d		31ff			XORL DI, DI									
  members_string.go:4060	0x75b73f		89de			MOVL BX, SI									
  members_string.go:4060	0x75b741		4189c8			MOVL CX, R8									
  members_string.go:4060	0x75b744		4883c438		ADDQ $0x38, SP									
  members_string.go:4060	0x75b748		5d			POPQ BP										
  members_string.go:4060	0x75b749		c3			RET										
  members_string.go:4056	0x75b74a		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4062	0x75b752		4889d8			MOVQ BX, AX									
  members_string.go:4062	0x75b755		4889cb			MOVQ CX, BX									
  members_string.go:4062	0x75b758		4889f9			MOVQ DI, CX									
  members_string.go:4062	0x75b75b		4889f7			MOVQ SI, DI									
  members_string.go:4062	0x75b75e		6690			NOPW										
  members_string.go:4062	0x75b760		e8bb0be5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4062	0x75b765		4889442430		MOVQ AX, 0x30(SP)								
  members_string.go:4062	0x75b76a		48895c2428		MOVQ BX, 0x28(SP)								
  members_string.go:4062	0x75b76f		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4062	0x75b777		488b02			MOVQ 0(DX), AX									
  members_string.go:4062	0x75b77a		488b5a08		MOVQ 0x8(DX), BX								
  members_string.go:4062	0x75b77e		488b4a10		MOVQ 0x10(DX), CX								
  members_string.go:4062	0x75b782		488b7a18		MOVQ 0x18(DX), DI								
  members_string.go:4062	0x75b786		e8950be5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4062	0x75b78b		4889c1			MOVQ AX, CX									
  members_string.go:4062	0x75b78e		4889df			MOVQ BX, DI									
  members_string.go:4062	0x75b791		488b442430		MOVQ 0x30(SP), AX								
  members_string.go:4062	0x75b796		488b5c2428		MOVQ 0x28(SP), BX								
  members_string.go:4062	0x75b79b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4062	0x75b7a0		e8db26f7ff		CALL github.com/mgomes/vibescript/internal/runtime.caseInsensitiveEqual(SB)	
  members_string.go:4062	0x75b7a5		0fb6f8			MOVZX AL, DI									
  members_string.go:4062	0x75b7a8		b801000000		MOVL $0x1, AX									
  members_string.go:4062	0x75b7ad		31db			XORL BX, BX									
  members_string.go:4062	0x75b7af		31c9			XORL CX, CX									
  members_string.go:4062	0x75b7b1		89de			MOVL BX, SI									
  members_string.go:4062	0x75b7b3		4189c8			MOVL CX, R8									
  members_string.go:4062	0x75b7b6		4883c438		ADDQ $0x38, SP									
  members_string.go:4062	0x75b7ba		5d			POPQ BP										
  members_string.go:4062	0x75b7bb		c3			RET										
  errors.go:26			0x75b7bc		488d05237b0600		LEAQ 0x67b23(IP), AX								
  errors.go:26			0x75b7c3		bb2a000000		MOVL $0x2a, BX									
  errors.go:26			0x75b7c8		31c9			XORL CX, CX									
  errors.go:26			0x75b7ca		31ff			XORL DI, DI									
  errors.go:26			0x75b7cc		89fe			MOVL DI, SI									
  errors.go:26			0x75b7ce		e8ed26d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75b7d3		4885c0			TESTQ AX, AX									
  errors.go:26			0x75b7d6		7533			JNE 0x75b80b									
  errors.go:31			0x75b7d8		90			NOPL										
  errors.go:65			0x75b7d9		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75b7de		488d1d3bef3800		LEAQ 0x38ef3b(IP), BX								
  errors.go:65			0x75b7e5		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75b7ea		e8b15bccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75b7ef		48c740082a000000	MOVQ $0x2a, 0x8(AX)								
  errors.go:65			0x75b7f7		488d15e87a0600		LEAQ 0x67ae8(IP), DX								
  errors.go:65			0x75b7fe		488910			MOVQ DX, 0(AX)									
  members_string.go:4057	0x75b801		4889c3			MOVQ AX, BX									
  members_string.go:4057	0x75b804		488d05c5cc3b00		LEAQ 0x3bccc5(IP), AX								
  members_string.go:4057	0x75b80b		31c9			XORL CX, CX									
  members_string.go:4057	0x75b80d		31ff			XORL DI, DI									
  members_string.go:4057	0x75b80f		4889c6			MOVQ AX, SI									
  members_string.go:4057	0x75b812		4989d8			MOVQ BX, R8									
  members_string.go:4057	0x75b815		31c0			XORL AX, AX									
  members_string.go:4057	0x75b817		31db			XORL BX, BX									
  members_string.go:4057	0x75b819		4883c438		ADDQ $0x38, SP									
  members_string.go:4057	0x75b81d		5d			POPQ BP										
  members_string.go:4057	0x75b81e		c3			RET										
  members_string.go:4055	0x75b81f		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4055	0x75b824		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4055	0x75b829		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4055	0x75b82e		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4055	0x75b833		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4055	0x75b838		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4055	0x75b83d		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4055	0x75b842		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4055	0x75b847		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4055	0x75b84c		e8ef0dd3ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4055	0x75b851		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4055	0x75b856		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4055	0x75b85b		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4055	0x75b860		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4055	0x75b865		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4055	0x75b86a		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4055	0x75b86f		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4055	0x75b874		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4055	0x75b879		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4055	0x75b87e		6690			NOPW										
  members_string.go:4055	0x75b880		e97bfeffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func21(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func22(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4065	0x75b8a0		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4065	0x75b8a4		0f8684000000		JBE 0x75b92e									
  members_string.go:4065	0x75b8aa		55			PUSHQ BP									
  members_string.go:4065	0x75b8ab		4889e5			MOVQ SP, BP									
  members_string.go:4065	0x75b8ae		4883ec70		SUBQ $0x70, SP									
  members_string.go:4065	0x75b8b2		48898c24b0000000	MOVQ CX, 0xb0(SP)								
  members_string.go:4065	0x75b8ba		4889bc24b8000000	MOVQ DI, 0xb8(SP)								
  members_string.go:4065	0x75b8c2		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4066	0x75b8ca		4c891c24		MOVQ R11, 0(SP)									
  members_string.go:4066	0x75b8ce		488b942480000000	MOVQ 0x80(SP), DX								
  members_string.go:4066	0x75b8d6		4889542408		MOVQ DX, 0x8(SP)								
  members_string.go:4066	0x75b8db		488b942488000000	MOVQ 0x88(SP), DX								
  members_string.go:4066	0x75b8e3		4889542410		MOVQ DX, 0x10(SP)								
  members_string.go:4066	0x75b8e8		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4066	0x75b8f0		4889542418		MOVQ DX, 0x18(SP)								
  members_string.go:4066	0x75b8f5		488b942498000000	MOVQ 0x98(SP), DX								
  members_string.go:4066	0x75b8fd		4889542420		MOVQ DX, 0x20(SP)								
  members_string.go:4066	0x75b902		488d05dc850500		LEAQ 0x585dc(IP), AX								
  members_string.go:4066	0x75b909		4d89d3			MOVQ R10, R11									
  members_string.go:4066	0x75b90c		4d89ca			MOVQ R9, R10									
  members_string.go:4066	0x75b90f		4d89c1			MOVQ R8, R9									
  members_string.go:4066	0x75b912		4989f0			MOVQ SI, R8									
  members_string.go:4066	0x75b915		4889fe			MOVQ DI, SI									
  members_string.go:4066	0x75b918		4889cf			MOVQ CX, DI									
  members_string.go:4066	0x75b91b		4889d9			MOVQ BX, CX									
  members_string.go:4066	0x75b91e		bb0f000000		MOVL $0xf, BX									
  members_string.go:4066	0x75b923		e818f0fdff		CALL github.com/mgomes/vibescript/internal/runtime.comparableBetween(SB)	
  members_string.go:4066	0x75b928		4883c470		ADDQ $0x70, SP									
  members_string.go:4066	0x75b92c		5d			POPQ BP										
  members_string.go:4066	0x75b92d		c3			RET										
  members_string.go:4065	0x75b92e		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4065	0x75b933		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4065	0x75b938		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4065	0x75b93d		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4065	0x75b942		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4065	0x75b947		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4065	0x75b94c		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4065	0x75b951		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4065	0x75b956		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4065	0x75b95b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4065	0x75b960		e8db0cd3ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4065	0x75b965		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4065	0x75b96a		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4065	0x75b96f		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4065	0x75b974		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4065	0x75b979		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4065	0x75b97e		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4065	0x75b983		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4065	0x75b988		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4065	0x75b98d		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4065	0x75b992		e909ffffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func22(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func23(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4069	0x75b9a0		4c8da42400ffffff	LEAQ 0xffffff00(SP), R12									
  members_string.go:4069	0x75b9a8		4d3b6610		CMPQ R12, 0x10(R14)										
  members_string.go:4069	0x75b9ac		0f86f3080000		JBE 0x75c2a5											
  members_string.go:4069	0x75b9b2		55			PUSHQ BP											
  members_string.go:4069	0x75b9b3		4889e5			MOVQ SP, BP											
  members_string.go:4069	0x75b9b6		4881ec78010000		SUBQ $0x178, SP											
  members_string.go:4069	0x75b9bd		48898c24b8010000	MOVQ CX, 0x1b8(SP)										
  members_string.go:4069	0x75b9c5		4889bc24c0010000	MOVQ DI, 0x1c0(SP)										
  members_string.go:4069	0x75b9cd		4c898424d0010000	MOVQ R8, 0x1d0(SP)										
  members_string.go:4070	0x75b9d5		4d85db			TESTQ R11, R11											
  members_string.go:4070	0x75b9d8		7405			JE 0x75b9df											
  members_string.go:4070	0x75b9da		498b13			MOVQ 0(R11), DX											
  members_string.go:4070	0x75b9dd		eb02			JMP 0x75b9e1											
  members_string.go:4070	0x75b9df		31d2			XORL DX, DX											
  members_string.go:4070	0x75b9e1		4885d2			TESTQ DX, DX											
  members_string.go:4070	0x75b9e4		0f8f89020000		JG 0x75bc73											
  members_string.go:4073	0x75b9ea		4d85c9			TESTQ R9, R9											
  members_string.go:4073	0x75b9ed		7406			JE 0x75b9f5											
  members_string.go:4073	0x75b9ef		4983f902		CMPQ R9, $0x2											
  members_string.go:4073	0x75b9f3		7e66			JLE 0x75ba5b											
  errors.go:26			0x75b9f5		488d059bb40600		LEAQ 0x6b49b(IP), AX										
  errors.go:26			0x75b9fc		bb32000000		MOVL $0x32, BX											
  errors.go:26			0x75ba01		31c9			XORL CX, CX											
  errors.go:26			0x75ba03		31ff			XORL DI, DI											
  errors.go:26			0x75ba05		89fe			MOVL DI, SI											
  errors.go:26			0x75ba07		e8b424d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75ba0c		4885c0			TESTQ AX, AX											
  errors.go:26			0x75ba0f		7533			JNE 0x75ba44											
  errors.go:31			0x75ba11		90			NOPL												
  errors.go:65			0x75ba12		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75ba17		488d1d02ed3800		LEAQ 0x38ed02(IP), BX										
  errors.go:65			0x75ba1e		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75ba23		e87859ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75ba28		48c7400832000000	MOVQ $0x32, 0x8(AX)										
  errors.go:65			0x75ba30		488d1560b40600		LEAQ 0x6b460(IP), DX										
  errors.go:65			0x75ba37		488910			MOVQ DX, 0(AX)											
  members_string.go:4074	0x75ba3a		4889c3			MOVQ AX, BX											
  members_string.go:4074	0x75ba3d		488d058cca3b00		LEAQ 0x3bca8c(IP), AX										
  members_string.go:4074	0x75ba44		31c9			XORL CX, CX											
  members_string.go:4074	0x75ba46		31ff			XORL DI, DI											
  members_string.go:4074	0x75ba48		4889c6			MOVQ AX, SI											
  members_string.go:4074	0x75ba4b		4989d8			MOVQ BX, R8											
  members_string.go:4074	0x75ba4e		31c0			XORL AX, AX											
  members_string.go:4074	0x75ba50		31db			XORL BX, BX											
  members_string.go:4074	0x75ba52		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4074	0x75ba59		5d			POPQ BP												
  members_string.go:4074	0x75ba5a		c3			RET												
  members_string.go:4070	0x75ba5b		48898424a8010000	MOVQ AX, 0x1a8(SP)										
  members_string.go:4070	0x75ba63		4c899c24e8010000	MOVQ R11, 0x1e8(SP)										
  members_string.go:4070	0x75ba6b		48899c2418010000	MOVQ BX, 0x118(SP)										
  members_string.go:4070	0x75ba73		4c898424d0010000	MOVQ R8, 0x1d0(SP)										
  members_string.go:4070	0x75ba7b		4c898c24d8010000	MOVQ R9, 0x1d8(SP)										
  members_string.go:4070	0x75ba83		4c899424e0010000	MOVQ R10, 0x1e0(SP)										
  members_string.go:4070	0x75ba8b		4889b42410010000	MOVQ SI, 0x110(SP)										
  members_string.go:4070	0x75ba93		4889bc2440010000	MOVQ DI, 0x140(SP)										
  members_string.go:4070	0x75ba9b		48898c2408010000	MOVQ CX, 0x108(SP)										
  members_string.go:4076	0x75baa3		498b7808		MOVQ 0x8(R8), DI										
  members_string.go:4076	0x75baa7		498b7010		MOVQ 0x10(R8), SI										
  members_string.go:4076	0x75baab		498b5018		MOVQ 0x18(R8), DX										
  members_string.go:4076	0x75baaf		498b08			MOVQ 0(R8), CX											
  members_string.go:4076	0x75bab2		488d058f6f0500		LEAQ 0x56f8f(IP), AX										
  members_string.go:4076	0x75bab9		bb0c000000		MOVL $0xc, BX											
  members_string.go:4076	0x75babe		4989d0			MOVQ DX, R8											
  members_string.go:4076	0x75bac1		e81a50fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4077	0x75bac6		4885ff			TESTQ DI, DI											
  members_string.go:4077	0x75bac9		0f858d010000		JNE 0x75bc5c											
  members_string.go:4076	0x75bacf		888c24af000000		MOVB CL, 0xaf(SP)										
  members_string.go:4076	0x75bad6		48899c24e8000000	MOVQ BX, 0xe8(SP)										
  members_string.go:4076	0x75bade		4889842430010000	MOVQ AX, 0x130(SP)										
  members_string.go:4080	0x75bae6		488b842418010000	MOVQ 0x118(SP), AX										
  members_string.go:4080	0x75baee		488b9c2408010000	MOVQ 0x108(SP), BX										
  members_string.go:4080	0x75baf6		488b8c2440010000	MOVQ 0x140(SP), CX										
  members_string.go:4080	0x75bafe		488bbc2410010000	MOVQ 0x110(SP), DI										
  members_string.go:4080	0x75bb06		e81508e5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  members_string.go:4080	0x75bb0b		4889842428010000	MOVQ AX, 0x128(SP)										
  members_string.go:4080	0x75bb13		48899c24d8000000	MOVQ BX, 0xd8(SP)										
  members_string.go:4081	0x75bb1b		4889c1			MOVQ AX, CX											
  members_string.go:4081	0x75bb1e		4889df			MOVQ BX, DI											
  members_string.go:4081	0x75bb21		488bb42430010000	MOVQ 0x130(SP), SI										
  members_string.go:4081	0x75bb29		4c8b8424e8000000	MOVQ 0xe8(SP), R8										
  members_string.go:4081	0x75bb31		440fb68c24af000000	MOVZX 0xaf(SP), R9										
  members_string.go:4081	0x75bb3a		488d05076f0500		LEAQ 0x56f07(IP), AX										
  members_string.go:4081	0x75bb41		bb0c000000		MOVL $0xc, BX											
  members_string.go:4081	0x75bb46		e8f565f7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)			
  members_string.go:4081	0x75bb4b		4885c0			TESTQ AX, AX											
  members_string.go:4081	0x75bb4e		0f85f1000000		JNE 0x75bc45											
  members_string.go:4073	0x75bb54		488b9424d8010000	MOVQ 0x1d8(SP), DX										
  members_string.go:4073	0x75bb5c		0f1f4000		NOPL 0(AX)											
  members_string.go:4073	0x75bb60		4883fa02		CMPQ DX, $0x2											
  members_string.go:4096	0x75bb64		7418			JE 0x75bb7e											
  members_string.go:2136	0x75bb66		488b8424d8000000	MOVQ 0xd8(SP), AX										
  members_string.go:2136	0x75bb6e		488bbc2428010000	MOVQ 0x128(SP), DI										
  members_string.go:2136	0x75bb76		4531d2			XORL R10, R10											
  members_string.go:4096	0x75bb79		e9a5020000		JMP 0x75be23											
  members_string.go:4097	0x75bb7e		488b9424d0010000	MOVQ 0x1d0(SP), DX										
  members_string.go:4097	0x75bb86		488b4220		MOVQ 0x20(DX), AX										
  members_string.go:4097	0x75bb8a		488b5a28		MOVQ 0x28(DX), BX										
  members_string.go:4097	0x75bb8e		488b4a30		MOVQ 0x30(DX), CX										
  members_string.go:4097	0x75bb92		488b7a38		MOVQ 0x38(DX), DI										
  members_string.go:4097	0x75bb96		e86581fdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)				
  members_string.go:4097	0x75bb9b		0f1f440000		NOPL 0(AX)(AX*1)										
  members_string.go:4098	0x75bba0		4885db			TESTQ BX, BX											
  members_string.go:4098	0x75bba3		753a			JNE 0x75bbdf											
  members_string.go:1213	0x75bba5		4885c0			TESTQ AX, AX											
  members_string.go:1213	0x75bba8		7c1d			JL 0x75bbc7											
  members_string.go:1100	0x75bbaa		488b8c24d8000000	MOVQ 0xd8(SP), CX										
  members_string.go:1101	0x75bbb2		488bbc2428010000	MOVQ 0x128(SP), DI										
  members_string.go:4101	0x75bbba		4989c2			MOVQ AX, R10											
  members_string.go:4101	0x75bbbd		b801000000		MOVL $0x1, AX											
  members_string.go:4101	0x75bbc2		e959010000		JMP 0x75bd20											
  members_string.go:1178	0x75bbc7		90			NOPL												
  members_string.go:1100	0x75bbc8		31d2			XORL DX, DX											
  members_string.go:1100	0x75bbca		488bb424d8000000	MOVQ 0xd8(SP), SI										
  members_string.go:1100	0x75bbd2		488bbc2428010000	MOVQ 0x128(SP), DI										
  members_string.go:1100	0x75bbda		e901010000		JMP 0x75bce0											
  errors.go:26			0x75bbdf		488d056a280600		LEAQ 0x6286a(IP), AX										
  errors.go:26			0x75bbe6		bb23000000		MOVL $0x23, BX											
  errors.go:26			0x75bbeb		31c9			XORL CX, CX											
  errors.go:26			0x75bbed		31ff			XORL DI, DI											
  errors.go:26			0x75bbef		89fe			MOVL DI, SI											
  errors.go:26			0x75bbf1		e8ca22d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75bbf6		4885c0			TESTQ AX, AX											
  errors.go:26			0x75bbf9		7533			JNE 0x75bc2e											
  errors.go:31			0x75bbfb		90			NOPL												
  errors.go:65			0x75bbfc		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75bc01		488d1d18eb3800		LEAQ 0x38eb18(IP), BX										
  errors.go:65			0x75bc08		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75bc0d		e88e57ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75bc12		48c7400823000000	MOVQ $0x23, 0x8(AX)										
  errors.go:65			0x75bc1a		488d152f280600		LEAQ 0x6282f(IP), DX										
  errors.go:65			0x75bc21		488910			MOVQ DX, 0(AX)											
  members_string.go:4099	0x75bc24		4889c3			MOVQ AX, BX											
  members_string.go:4099	0x75bc27		488d05a2c83b00		LEAQ 0x3bc8a2(IP), AX										
  members_string.go:4099	0x75bc2e		31c9			XORL CX, CX											
  members_string.go:4099	0x75bc30		31ff			XORL DI, DI											
  members_string.go:4099	0x75bc32		4889c6			MOVQ AX, SI											
  members_string.go:4099	0x75bc35		4989d8			MOVQ BX, R8											
  members_string.go:4099	0x75bc38		31c0			XORL AX, AX											
  members_string.go:4099	0x75bc3a		31db			XORL BX, BX											
  members_string.go:4099	0x75bc3c		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4099	0x75bc43		5d			POPQ BP												
  members_string.go:4099	0x75bc44		c3			RET												
  members_string.go:4082	0x75bc45		31c9			XORL CX, CX											
  members_string.go:4082	0x75bc47		31ff			XORL DI, DI											
  members_string.go:4082	0x75bc49		4889c6			MOVQ AX, SI											
  members_string.go:4082	0x75bc4c		4989d8			MOVQ BX, R8											
  members_string.go:4082	0x75bc4f		31c0			XORL AX, AX											
  members_string.go:4082	0x75bc51		31db			XORL BX, BX											
  members_string.go:4082	0x75bc53		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4082	0x75bc5a		5d			POPQ BP												
  members_string.go:4082	0x75bc5b		c3			RET												
  members_string.go:4078	0x75bc5c		31c0			XORL AX, AX											
  members_string.go:4078	0x75bc5e		31db			XORL BX, BX											
  members_string.go:4078	0x75bc60		31c9			XORL CX, CX											
  members_string.go:4078	0x75bc62		4989f0			MOVQ SI, R8											
  members_string.go:4078	0x75bc65		4889fe			MOVQ DI, SI											
  members_string.go:4078	0x75bc68		31ff			XORL DI, DI											
  members_string.go:4078	0x75bc6a		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4078	0x75bc71		5d			POPQ BP												
  members_string.go:4078	0x75bc72		c3			RET												
  errors.go:26			0x75bc73		488d05a39b0600		LEAQ 0x69ba3(IP), AX										
  errors.go:26			0x75bc7a		bb2e000000		MOVL $0x2e, BX											
  errors.go:26			0x75bc7f		31c9			XORL CX, CX											
  errors.go:26			0x75bc81		31ff			XORL DI, DI											
  errors.go:26			0x75bc83		89fe			MOVL DI, SI											
  errors.go:26			0x75bc85		e83622d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75bc8a		4885c0			TESTQ AX, AX											
  errors.go:26			0x75bc8d		7533			JNE 0x75bcc2											
  errors.go:31			0x75bc8f		90			NOPL												
  errors.go:65			0x75bc90		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75bc95		488d1d84ea3800		LEAQ 0x38ea84(IP), BX										
  errors.go:65			0x75bc9c		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75bca1		e8fa56ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75bca6		48c740082e000000	MOVQ $0x2e, 0x8(AX)										
  errors.go:65			0x75bcae		488d15689b0600		LEAQ 0x69b68(IP), DX										
  errors.go:65			0x75bcb5		488910			MOVQ DX, 0(AX)											
  members_string.go:4071	0x75bcb8		4889c3			MOVQ AX, BX											
  members_string.go:4071	0x75bcbb		488d050ec83b00		LEAQ 0x3bc80e(IP), AX										
  members_string.go:4071	0x75bcc2		31c9			XORL CX, CX											
  members_string.go:4071	0x75bcc4		31ff			XORL DI, DI											
  members_string.go:4071	0x75bcc6		4889c6			MOVQ AX, SI											
  members_string.go:4071	0x75bcc9		4989d8			MOVQ BX, R8											
  members_string.go:4071	0x75bccc		31c0			XORL AX, AX											
  members_string.go:4071	0x75bcce		31db			XORL BX, BX											
  members_string.go:4071	0x75bcd0		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4071	0x75bcd7		5d			POPQ BP												
  members_string.go:4071	0x75bcd8		c3			RET												
  members_string.go:1100	0x75bcd9		48ffc2			INCQ DX												
  members_string.go:1100	0x75bcdc		0f1f4000		NOPL 0(AX)											
  members_string.go:1100	0x75bce0		4839d6			CMPQ SI, DX											
  members_string.go:1100	0x75bce3		7e20			JLE 0x75bd05											
  members_string.go:1101	0x75bce5		440fb61c3a		MOVZX 0(DX)(DI*1), R11										
  members_string.go:1101	0x75bcea		4180fb80		CMPL R11, $0x80											
  members_string.go:1101	0x75bcee		72e9			JB 0x75bcd9											
  members_string.go:4097	0x75bcf0		48898424e0000000	MOVQ AX, 0xe0(SP)										
  members_string.go:1181	0x75bcf8		90			NOPL												
  utf8.go:448			0x75bcf9		31d2			XORL DX, DX											
  utf8.go:448			0x75bcfb		4531db			XORL R11, R11											
  utf8.go:448			0x75bcfe		6690			NOPW												
  utf8.go:448			0x75bd00		e943050000		JMP 0x75c248											
  members_string.go:4080	0x75bd05		4889f1			MOVQ SI, CX											
  members_string.go:1216	0x75bd08		4c8d1406		LEAQ 0(SI)(AX*1), R10										
  members_string.go:1217	0x75bd0c		4d85d2			TESTQ R10, R10											
  members_string.go:1217	0x75bd0f		7d07			JGE 0x75bd18											
  members_string.go:1217	0x75bd11		31c0			XORL AX, AX											
  members_string.go:1217	0x75bd13		4531d2			XORL R10, R10											
  members_string.go:4101	0x75bd16		eb08			JMP 0x75bd20											
  members_string.go:4101	0x75bd18		b801000000		MOVL $0x1, AX											
  members_string.go:4101	0x75bd1d		0f1f00			NOPL 0(AX)											
  members_string.go:4101	0x75bd20		84c0			TESTL AL, AL											
  members_string.go:4102	0x75bd22		7408			JE 0x75bd2c											
  members_string.go:1178	0x75bd24		90			NOPL												
  members_string.go:1100	0x75bd25		31d2			XORL DX, DX											
  members_string.go:1100	0x75bd27		e9c9000000		JMP 0x75bdf5											
  members_string.go:4103	0x75bd2c		488b842430010000	MOVQ 0x130(SP), AX										
  members_string.go:4103	0x75bd34		488b9c24e8000000	MOVQ 0xe8(SP), BX										
  members_string.go:4103	0x75bd3c		0f1f4000		NOPL 0(AX)											
  members_string.go:4103	0x75bd40		e85bddfaff		CALL github.com/mgomes/vibescript/internal/runtime.compileCachedRegex(SB)			
  members_string.go:4103	0x75bd45		4885db			TESTQ BX, BX											
  members_string.go:4103	0x75bd48		0f848e000000		JE 0x75bddc											
  members_string.go:4104	0x75bd4e		440f11bc2468010000	MOVUPS X15, 0x168(SP)										
  members_string.go:4104	0x75bd57		7404			JE 0x75bd5d											
  members_string.go:4104	0x75bd59		488b5b08		MOVQ 0x8(BX), BX										
  members_string.go:4104	0x75bd5d		48899c2468010000	MOVQ BX, 0x168(SP)										
  members_string.go:4104	0x75bd65		48898c2470010000	MOVQ CX, 0x170(SP)										
  errors.go:26			0x75bd6d		488d0546f00500		LEAQ 0x5f046(IP), AX										
  errors.go:26			0x75bd74		bb1e000000		MOVL $0x1e, BX											
  errors.go:26			0x75bd79		488d8c2468010000	LEAQ 0x168(SP), CX										
  errors.go:26			0x75bd81		bf01000000		MOVL $0x1, DI											
  errors.go:26			0x75bd86		89fe			MOVL DI, SI											
  errors.go:26			0x75bd88		e83321d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75bd8d		4885c0			TESTQ AX, AX											
  errors.go:26			0x75bd90		7533			JNE 0x75bdc5											
  errors.go:31			0x75bd92		90			NOPL												
  errors.go:65			0x75bd93		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75bd98		488d1d81e93800		LEAQ 0x38e981(IP), BX										
  errors.go:65			0x75bd9f		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75bda4		e8f755ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75bda9		48c740081e000000	MOVQ $0x1e, 0x8(AX)										
  errors.go:65			0x75bdb1		488d1502f00500		LEAQ 0x5f002(IP), DX										
  errors.go:65			0x75bdb8		488910			MOVQ DX, 0(AX)											
  members_string.go:4104	0x75bdbb		4889c3			MOVQ AX, BX											
  members_string.go:4104	0x75bdbe		488d050bc73b00		LEAQ 0x3bc70b(IP), AX										
  members_string.go:4104	0x75bdc5		31c9			XORL CX, CX											
  members_string.go:4104	0x75bdc7		31ff			XORL DI, DI											
  members_string.go:4104	0x75bdc9		4889c6			MOVQ AX, SI											
  members_string.go:4104	0x75bdcc		4989d8			MOVQ BX, R8											
  members_string.go:4104	0x75bdcf		31c0			XORL AX, AX											
  members_string.go:4104	0x75bdd1		31db			XORL BX, BX											
  members_string.go:4104	0x75bdd3		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4104	0x75bdda		5d			POPQ BP												
  members_string.go:4104	0x75bddb		c3			RET												
  members_string.go:4106	0x75bddc		31c0			XORL AX, AX											
  members_string.go:4106	0x75bdde		31db			XORL BX, BX											
  members_string.go:4106	0x75bde0		31c9			XORL CX, CX											
  members_string.go:4106	0x75bde2		31ff			XORL DI, DI											
  members_string.go:4106	0x75bde4		89de			MOVL BX, SI											
  members_string.go:4106	0x75bde6		4189c8			MOVL CX, R8											
  members_string.go:4106	0x75bde9		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4106	0x75bdf0		5d			POPQ BP												
  members_string.go:4106	0x75bdf1		c3			RET												
  members_string.go:1100	0x75bdf2		48ffc2			INCQ DX												
  members_string.go:1100	0x75bdf5		4839d1			CMPQ CX, DX											
  members_string.go:1100	0x75bdf8		7e1f			JLE 0x75be19											
  members_string.go:1101	0x75bdfa		440fb61c3a		MOVZX 0(DX)(DI*1), R11										
  members_string.go:1101	0x75bdff		90			NOPL												
  members_string.go:1101	0x75be00		4180fb80		CMPL R11, $0x80											
  members_string.go:1101	0x75be04		72ec			JB 0x75bdf2											
  members_string.go:4101	0x75be06		4c899424d0000000	MOVQ R10, 0xd0(SP)										
  members_string.go:1181	0x75be0e		90			NOPL												
  utf8.go:448			0x75be0f		31d2			XORL DX, DX											
  utf8.go:448			0x75be11		4531db			XORL R11, R11											
  utf8.go:448			0x75be14		e9cf030000		JMP 0x75c1e8											
  members_string.go:4080	0x75be19		4889c8			MOVQ CX, AX											
  members_string.go:4108	0x75be1c		4c39d1			CMPQ CX, R10											
  members_string.go:4111	0x75be1f		4c0f4cd1		CMOVL CX, R10											
  members_string.go:2136	0x75be23		488b1516374000		MOVQ github.com/mgomes/vibescript/internal/runtime.compiledRegexps(SB), DX			
  members_string.go:4113	0x75be2a		90			NOPL												
  members_string.go:2136	0x75be2b		488d1d166c0500		LEAQ 0x56c16(IP), BX										
  members_string.go:2136	0x75be32		b90c000000		MOVL $0xc, CX											
  members_string.go:2136	0x75be37		4889c6			MOVQ AX, SI											
  members_string.go:2136	0x75be3a		4c8b842430010000	MOVQ 0x130(SP), R8										
  members_string.go:2136	0x75be42		4c8b8c24e8000000	MOVQ 0xe8(SP), R9										
  members_string.go:2136	0x75be4a		4889d0			MOVQ DX, AX											
  members_string.go:2136	0x75be4d		e8ce69f7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexSubmatchFromRuneOffsetWithCache(SB)	
  members_string.go:4114	0x75be52		4885ff			TESTQ DI, DI											
  members_string.go:4114	0x75be55		0f85a2010000		JNE 0x75bffd											
  members_string.go:4114	0x75be5b		0f1f440000		NOPL 0(AX)(AX*1)										
  members_string.go:4117	0x75be60		4885c0			TESTQ AX, AX											
  members_string.go:4117	0x75be63		0f847e010000		JE 0x75bfe7											
  members_string.go:2136	0x75be69		48898c24b8000000	MOVQ CX, 0xb8(SP)										
  members_string.go:2136	0x75be71		48899c24b0000000	MOVQ BX, 0xb0(SP)										
  members_string.go:2136	0x75be79		4889842420010000	MOVQ AX, 0x120(SP)										
  members_string.go:4122	0x75be81		488b842430010000	MOVQ 0x130(SP), AX										
  members_string.go:4122	0x75be89		488b9c24e8000000	MOVQ 0xe8(SP), BX										
  members_string.go:4122	0x75be91		e80a69f7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexSubexpNames(SB)				
  members_string.go:4122	0x75be96		488b942418010000	MOVQ 0x118(SP), DX										
  members_string.go:4122	0x75be9e		48891424		MOVQ DX, 0(SP)											
  members_string.go:4122	0x75bea2		488b942408010000	MOVQ 0x108(SP), DX										
  members_string.go:4122	0x75beaa		4889542408		MOVQ DX, 0x8(SP)										
  members_string.go:4122	0x75beaf		488b942440010000	MOVQ 0x140(SP), DX										
  members_string.go:4122	0x75beb7		4889542410		MOVQ DX, 0x10(SP)										
  members_string.go:4122	0x75bebc		488b942410010000	MOVQ 0x110(SP), DX										
  members_string.go:4122	0x75bec4		4889542418		MOVQ DX, 0x18(SP)										
  members_string.go:4122	0x75bec9		488b9424d0010000	MOVQ 0x1d0(SP), DX										
  members_string.go:4122	0x75bed1		4889542420		MOVQ DX, 0x20(SP)										
  members_string.go:4122	0x75bed6		488b9424d8010000	MOVQ 0x1d8(SP), DX										
  members_string.go:4122	0x75bede		4889542428		MOVQ DX, 0x28(SP)										
  members_string.go:4122	0x75bee3		488b9424e0010000	MOVQ 0x1e0(SP), DX										
  members_string.go:4122	0x75beeb		4889542430		MOVQ DX, 0x30(SP)										
  members_string.go:4122	0x75bef0		488b9424e8010000	MOVQ 0x1e8(SP), DX										
  members_string.go:4122	0x75bef8		4889542438		MOVQ DX, 0x38(SP)										
  members_string.go:4122	0x75befd		488b942488010000	MOVQ 0x188(SP), DX										
  members_string.go:4122	0x75bf05		4889542440		MOVQ DX, 0x40(SP)										
  members_string.go:4122	0x75bf0a		488b942490010000	MOVQ 0x190(SP), DX										
  members_string.go:4122	0x75bf12		4889542448		MOVQ DX, 0x48(SP)										
  members_string.go:4122	0x75bf17		488b942498010000	MOVQ 0x198(SP), DX										
  members_string.go:4122	0x75bf1f		4889542450		MOVQ DX, 0x50(SP)										
  members_string.go:4122	0x75bf24		488b9424a0010000	MOVQ 0x1a0(SP), DX										
  members_string.go:4122	0x75bf2c		4889542458		MOVQ DX, 0x58(SP)										
  members_string.go:4122	0x75bf31		488bbc2420010000	MOVQ 0x120(SP), DI										
  members_string.go:4122	0x75bf39		488bb424b0000000	MOVQ 0xb0(SP), SI										
  members_string.go:4122	0x75bf41		4c8b8424b8000000	MOVQ 0xb8(SP), R8										
  members_string.go:4122	0x75bf49		4989c1			MOVQ AX, R9											
  members_string.go:4122	0x75bf4c		4989da			MOVQ BX, R10											
  members_string.go:4122	0x75bf4f		4989cb			MOVQ CX, R11											
  members_string.go:4122	0x75bf52		488b8424a8010000	MOVQ 0x1a8(SP), AX										
  members_string.go:4122	0x75bf5a		488b9c2428010000	MOVQ 0x128(SP), BX										
  members_string.go:4122	0x75bf62		488b8c24d8000000	MOVQ 0xd8(SP), CX										
  members_string.go:4122	0x75bf6a		e83198f3ff		CALL github.com/mgomes/vibescript/internal/runtime.newMatchData(SB)				
  members_string.go:4123	0x75bf6f		4885f6			TESTQ SI, SI											
  members_string.go:4123	0x75bf72		7562			JNE 0x75bfd6											
  members_string.go:4122	0x75bf74		4889842400010000	MOVQ AX, 0x100(SP)										
  members_string.go:4122	0x75bf7c		4889bc24f8000000	MOVQ DI, 0xf8(SP)										
  members_string.go:4122	0x75bf84		48898c2438010000	MOVQ CX, 0x138(SP)										
  members_string.go:4122	0x75bf8c		48899c24f0000000	MOVQ BX, 0xf0(SP)										
  aliases.go:1400		0x75bf94		90			NOPL												
  value_accessors.go:180	0x75bf95		488b942488010000	MOVQ 0x188(SP), DX										
  value_accessors.go:180	0x75bf9d		0f1f00			NOPL 0(AX)											
  value_accessors.go:180	0x75bfa0		4883fa0f		CMPQ DX, $0xf											
  value_accessors.go:180	0x75bfa4		7529			JNE 0x75bfcf											
  value_accessors.go:183	0x75bfa6		4c8b9c2490010000	MOVQ 0x190(SP), R11										
  value_accessors.go:183	0x75bfae		4d85db			TESTQ R11, R11											
  value_accessors.go:183	0x75bfb1		7414			JE 0x75bfc7											
  value_accessors.go:183	0x75bfb3		4c8b2526263f00		MOVQ github.com/mgomes/vibescript/internal/runtime..typeAssert.357(SB), R12			
  value_accessors.go:183	0x75bfba		4d8b2c24		MOVQ 0(R12), R13										
  value_accessors.go:183	0x75bfbe		458b7b10		MOVL 0x10(R11), R15										
  value_accessors.go:183	0x75bfc2		e9a5010000		JMP 0x75c16c											
  members_string.go:4069	0x75bfc7		4c89de			MOVQ R11, SI											
  value_accessors.go:183	0x75bfca		e98d010000		JMP 0x75c15c											
  value_accessors.go:183	0x75bfcf		31f6			XORL SI, SI											
  value_accessors.go:183	0x75bfd1		4531c0			XORL R8, R8											
  aliases.go:1367		0x75bfd4		eb3e			JMP 0x75c014											
  members_string.go:4124	0x75bfd6		31c0			XORL AX, AX											
  members_string.go:4124	0x75bfd8		31db			XORL BX, BX											
  members_string.go:4124	0x75bfda		31c9			XORL CX, CX											
  members_string.go:4124	0x75bfdc		31ff			XORL DI, DI											
  members_string.go:4124	0x75bfde		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4124	0x75bfe5		5d			POPQ BP												
  members_string.go:4124	0x75bfe6		c3			RET												
  members_string.go:4120	0x75bfe7		31c0			XORL AX, AX											
  members_string.go:4120	0x75bfe9		31db			XORL BX, BX											
  members_string.go:4120	0x75bfeb		31c9			XORL CX, CX											
  members_string.go:4120	0x75bfed		31ff			XORL DI, DI											
  members_string.go:4120	0x75bfef		89de			MOVL BX, SI											
  members_string.go:4120	0x75bff1		4189c8			MOVL CX, R8											
  members_string.go:4120	0x75bff4		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4120	0x75bffb		5d			POPQ BP												
  members_string.go:4120	0x75bffc		c3			RET												
  members_string.go:4115	0x75bffd		31c0			XORL AX, AX											
  members_string.go:4115	0x75bfff		31db			XORL BX, BX											
  members_string.go:4115	0x75c001		31c9			XORL CX, CX											
  members_string.go:4115	0x75c003		4989f0			MOVQ SI, R8											
  members_string.go:4115	0x75c006		4889fe			MOVQ DI, SI											
  members_string.go:4115	0x75c009		31ff			XORL DI, DI											
  members_string.go:4115	0x75c00b		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4115	0x75c012		5d			POPQ BP												
  members_string.go:4115	0x75c013		c3			RET												
  aliases.go:1367		0x75c014		4c8d1d15cd3b00		LEAQ 0x3bcd15(IP), R11										
  aliases.go:1367		0x75c01b		0f1f440000		NOPL 0(AX)(AX*1)										
  aliases.go:1367		0x75c020		4c39de			CMPQ SI, R11											
  aliases.go:1367		0x75c023		7403			JE 0x75c028											
  aliases.go:1367		0x75c025		4531c0			XORL R8, R8											
  members_string.go:4126	0x75c028		4d85c0			TESTQ R8, R8											
  members_string.go:4126	0x75c02b		0f841d010000		JE 0x75c14e											
  members_string.go:4130	0x75c031		4c8b9c2418010000	MOVQ 0x118(SP), R11										
  members_string.go:4130	0x75c039		4c891c24		MOVQ R11, 0(SP)											
  members_string.go:4130	0x75c03d		4c8b9c2408010000	MOVQ 0x108(SP), R11										
  members_string.go:4130	0x75c045		4c895c2408		MOVQ R11, 0x8(SP)										
  members_string.go:4130	0x75c04a		4c8b9c2440010000	MOVQ 0x140(SP), R11										
  members_string.go:4130	0x75c052		4c895c2410		MOVQ R11, 0x10(SP)										
  members_string.go:4130	0x75c057		4c8b9c2410010000	MOVQ 0x110(SP), R11										
  members_string.go:4130	0x75c05f		4c895c2418		MOVQ R11, 0x18(SP)										
  members_string.go:4130	0x75c064		4c8b9c24d0010000	MOVQ 0x1d0(SP), R11										
  members_string.go:4130	0x75c06c		4c895c2420		MOVQ R11, 0x20(SP)										
  members_string.go:4130	0x75c071		4c8b9c24d8010000	MOVQ 0x1d8(SP), R11										
  members_string.go:4130	0x75c079		4c895c2428		MOVQ R11, 0x28(SP)										
  members_string.go:4130	0x75c07e		4c8b9c24e0010000	MOVQ 0x1e0(SP), R11										
  members_string.go:4130	0x75c086		4c895c2430		MOVQ R11, 0x30(SP)										
  members_string.go:4130	0x75c08b		488b8424a8010000	MOVQ 0x1a8(SP), AX										
  members_string.go:4130	0x75c093		4889d3			MOVQ DX, BX											
  members_string.go:4130	0x75c096		488b8c2490010000	MOVQ 0x190(SP), CX										
  members_string.go:4130	0x75c09e		488bbc2498010000	MOVQ 0x198(SP), DI										
  members_string.go:4130	0x75c0a6		488bb424a0010000	MOVQ 0x1a0(SP), SI										
  members_string.go:4130	0x75c0ae		4c8d0593690500		LEAQ 0x56993(IP), R8										
  members_string.go:4130	0x75c0b5		41b90c000000		MOVL $0xc, R9											
  members_string.go:4130	0x75c0bb		4c8b9424e8010000	MOVQ 0x1e8(SP), R10										
  members_string.go:4130	0x75c0c3		e8d85df1ff		CALL github.com/mgomes/vibescript/internal/runtime.newBlockCallRunner(SB)			
  members_string.go:4131	0x75c0c8		4885db			TESTQ BX, BX											
  members_string.go:4131	0x75c0cb		7417			JE 0x75c0e4											
  members_string.go:4132	0x75c0cd		31c0			XORL AX, AX											
  members_string.go:4132	0x75c0cf		31ff			XORL DI, DI											
  members_string.go:4132	0x75c0d1		4889de			MOVQ BX, SI											
  members_string.go:4132	0x75c0d4		4989c8			MOVQ CX, R8											
  members_string.go:4132	0x75c0d7		31db			XORL BX, BX											
  members_string.go:4132	0x75c0d9		31c9			XORL CX, CX											
  members_string.go:4132	0x75c0db		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4132	0x75c0e2		5d			POPQ BP												
  members_string.go:4132	0x75c0e3		c3			RET												
  members_string.go:4134	0x75c0e4		488b942400010000	MOVQ 0x100(SP), DX										
  members_string.go:4134	0x75c0ec		4889942448010000	MOVQ DX, 0x148(SP)										
  members_string.go:4134	0x75c0f4		488b9424f0000000	MOVQ 0xf0(SP), DX										
  members_string.go:4134	0x75c0fc		4889942450010000	MOVQ DX, 0x150(SP)										
  members_string.go:4134	0x75c104		488b9424f8000000	MOVQ 0xf8(SP), DX										
  members_string.go:4134	0x75c10c		4889942460010000	MOVQ DX, 0x160(SP)										
  members_string.go:4134	0x75c114		488b942438010000	MOVQ 0x138(SP), DX										
  members_string.go:4134	0x75c11c		4889942458010000	MOVQ DX, 0x158(SP)										
  eval.go:1785			0x75c124		488d9c2448010000	LEAQ 0x148(SP), BX										
  eval.go:1785			0x75c12c		b901000000		MOVL $0x1, CX											
  eval.go:1785			0x75c131		89cf			MOVL CX, DI											
  eval.go:1785			0x75c133		31f6			XORL SI, SI											
  eval.go:1785			0x75c135		4531c0			XORL R8, R8											
  eval.go:1785			0x75c138		4589c1			MOVL R8, R9											
  eval.go:1785			0x75c13b		0f1f440000		NOPL 0(AX)(AX*1)										
  eval.go:1785			0x75c140		e89b62f1ff		CALL github.com/mgomes/vibescript/internal/runtime.(*blockCallRunner).callWithChargedRoots(SB)	
  members_string.go:4134	0x75c145		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4134	0x75c14c		5d			POPQ BP												
  members_string.go:4134	0x75c14d		c3			RET												
  members_string.go:4136	0x75c14e		31f6			XORL SI, SI											
  members_string.go:4136	0x75c150		4531c0			XORL R8, R8											
  members_string.go:4136	0x75c153		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4136	0x75c15a		5d			POPQ BP												
  members_string.go:4136	0x75c15b		c3			RET												
  aliases.go:1367		0x75c15c		4c89de			MOVQ R11, SI											
  aliases.go:1367		0x75c15f		4c8b842498010000	MOVQ 0x198(SP), R8										
  aliases.go:1367		0x75c167		e9a8feffff		JMP 0x75c014											
  value_accessors.go:183	0x75c16c		4c89fe			MOVQ R15, SI											
  value_accessors.go:183	0x75c16f		4d21ef			ANDQ R13, R15											
  value_accessors.go:183	0x75c172		49c1e704		SHLQ $0x4, R15											
  value_accessors.go:183	0x75c176		4f8b442708		MOVQ 0x8(R15)(R12*1), R8									
  value_accessors.go:183	0x75c17b		0f1f440000		NOPL 0(AX)(AX*1)										
  value_accessors.go:183	0x75c180		4d39c3			CMPQ R11, R8											
  value_accessors.go:183	0x75c183		744d			JE 0x75c1d2											
  value_accessors.go:183	0x75c185		4c8d7e01		LEAQ 0x1(SI), R15										
  value_accessors.go:183	0x75c189		4d85c0			TESTQ R8, R8											
  value_accessors.go:183	0x75c18c		75de			JNE 0x75c16c											
  value_accessors.go:183	0x75c18e		488d054b243f00		LEAQ github.com/mgomes/vibescript/internal/runtime..typeAssert.357(SB), AX			
  value_accessors.go:183	0x75c195		4c89db			MOVQ R11, BX											
  value_accessors.go:183	0x75c198		e86310ccff		CALL runtime.typeAssert(SB)									
  members_string.go:4136	0x75c19d		488b8c2438010000	MOVQ 0x138(SP), CX										
  members_string.go:4130	0x75c1a5		488b942488010000	MOVQ 0x188(SP), DX										
  members_string.go:4136	0x75c1ad		488b9c24f0000000	MOVQ 0xf0(SP), BX										
  members_string.go:4130	0x75c1b5		488bb42490010000	MOVQ 0x190(SP), SI										
  members_string.go:4136	0x75c1bd		488bbc24f8000000	MOVQ 0xf8(SP), DI										
  value_accessors.go:183	0x75c1c5		4989c3			MOVQ AX, R11											
  members_string.go:4136	0x75c1c8		488b842400010000	MOVQ 0x100(SP), AX										
  value_accessors.go:183	0x75c1d0		eb8a			JMP 0x75c15c											
  value_accessors.go:183	0x75c1d2		4f8b642710		MOVQ 0x10(R15)(R12*1), R12									
  members_string.go:4130	0x75c1d7		4c89de			MOVQ R11, SI											
  value_accessors.go:183	0x75c1da		4d89e3			MOVQ R12, R11											
  value_accessors.go:183	0x75c1dd		0f1f00			NOPL 0(AX)											
  value_accessors.go:183	0x75c1e0		e977ffffff		JMP 0x75c15c											
  utf8.go:449			0x75c1e5		48ffc2			INCQ DX												
  utf8.go:448			0x75c1e8		4c39d9			CMPQ CX, R11											
  utf8.go:448			0x75c1eb		7e4b			JLE 0x75c238											
  utf8.go:448			0x75c1ed		450fb6243b		MOVZX 0(R11)(DI*1), R12										
  utf8.go:448			0x75c1f2		4183fc7f		CMPL R12, $0x7f											
  utf8.go:448			0x75c1f6		7f05			JG 0x75c1fd											
  utf8.go:448			0x75c1f8		49ffc3			INCQ R11											
  utf8.go:448			0x75c1fb		ebe8			JMP 0x75c1e5											
  utf8.go:448			0x75c1fd		48899424c8000000	MOVQ DX, 0xc8(SP)										
  utf8.go:448			0x75c205		4889f8			MOVQ DI, AX											
  utf8.go:448			0x75c208		4889cb			MOVQ CX, BX											
  utf8.go:448			0x75c20b		4c89d9			MOVQ R11, CX											
  utf8.go:448			0x75c20e		e8ed0fd2ff		CALL runtime.decoderune(SB)									
  utf8.go:448			0x75c213		488b8c24d8000000	MOVQ 0xd8(SP), CX										
  utf8.go:449			0x75c21b		488b9424c8000000	MOVQ 0xc8(SP), DX										
  utf8.go:448			0x75c223		488bbc2428010000	MOVQ 0x128(SP), DI										
  members_string.go:4108	0x75c22b		4c8b9424d0000000	MOVQ 0xd0(SP), R10										
  utf8.go:449			0x75c233		4989db			MOVQ BX, R11											
  utf8.go:448			0x75c236		ebad			JMP 0x75c1e5											
  members_string.go:2136	0x75c238		4889c8			MOVQ CX, AX											
  members_string.go:4108	0x75c23b		4889d1			MOVQ DX, CX											
  members_string.go:4108	0x75c23e		6690			NOPW												
  members_string.go:4108	0x75c240		e9d7fbffff		JMP 0x75be1c											
  utf8.go:449			0x75c245		48ffc2			INCQ DX												
  utf8.go:448			0x75c248		4c39de			CMPQ SI, R11											
  utf8.go:448			0x75c24b		7e4b			JLE 0x75c298											
  utf8.go:448			0x75c24d		450fb6243b		MOVZX 0(R11)(DI*1), R12										
  utf8.go:448			0x75c252		4183fc7f		CMPL R12, $0x7f											
  utf8.go:448			0x75c256		7f05			JG 0x75c25d											
  utf8.go:448			0x75c258		49ffc3			INCQ R11											
  utf8.go:448			0x75c25b		ebe8			JMP 0x75c245											
  utf8.go:448			0x75c25d		48899424c0000000	MOVQ DX, 0xc0(SP)										
  utf8.go:448			0x75c265		4889f8			MOVQ DI, AX											
  utf8.go:448			0x75c268		4889f3			MOVQ SI, BX											
  utf8.go:448			0x75c26b		4c89d9			MOVQ R11, CX											
  utf8.go:448			0x75c26e		e88d0fd2ff		CALL runtime.decoderune(SB)									
  members_string.go:1216	0x75c273		488b8424e0000000	MOVQ 0xe0(SP), AX										
  utf8.go:449			0x75c27b		488b9424c0000000	MOVQ 0xc0(SP), DX										
  utf8.go:448			0x75c283		488bb424d8000000	MOVQ 0xd8(SP), SI										
  utf8.go:448			0x75c28b		488bbc2428010000	MOVQ 0x128(SP), DI										
  utf8.go:449			0x75c293		4989db			MOVQ BX, R11											
  utf8.go:448			0x75c296		ebad			JMP 0x75c245											
  members_string.go:1100	0x75c298		4889f1			MOVQ SI, CX											
  members_string.go:1216	0x75c29b		4889d6			MOVQ DX, SI											
  members_string.go:1216	0x75c29e		6690			NOPW												
  members_string.go:1216	0x75c2a0		e963faffff		JMP 0x75bd08											
  members_string.go:4069	0x75c2a5		4889442428		MOVQ AX, 0x28(SP)										
  members_string.go:4069	0x75c2aa		48895c2430		MOVQ BX, 0x30(SP)										
  members_string.go:4069	0x75c2af		48894c2438		MOVQ CX, 0x38(SP)										
  members_string.go:4069	0x75c2b4		48897c2440		MOVQ DI, 0x40(SP)										
  members_string.go:4069	0x75c2b9		4889742448		MOVQ SI, 0x48(SP)										
  members_string.go:4069	0x75c2be		4c89442450		MOVQ R8, 0x50(SP)										
  members_string.go:4069	0x75c2c3		4c894c2458		MOVQ R9, 0x58(SP)										
  members_string.go:4069	0x75c2c8		4c89542460		MOVQ R10, 0x60(SP)										
  members_string.go:4069	0x75c2cd		4c895c2468		MOVQ R11, 0x68(SP)										
  members_string.go:4069	0x75c2d2		e86903d3ff		CALL runtime.morestack_noctxt.abi0(SB)								
  members_string.go:4069	0x75c2d7		488b442428		MOVQ 0x28(SP), AX										
  members_string.go:4069	0x75c2dc		488b5c2430		MOVQ 0x30(SP), BX										
  members_string.go:4069	0x75c2e1		488b4c2438		MOVQ 0x38(SP), CX										
  members_string.go:4069	0x75c2e6		488b7c2440		MOVQ 0x40(SP), DI										
  members_string.go:4069	0x75c2eb		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:4069	0x75c2f0		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4069	0x75c2f5		4c8b4c2458		MOVQ 0x58(SP), R9										
  members_string.go:4069	0x75c2fa		4c8b542460		MOVQ 0x60(SP), R10										
  members_string.go:4069	0x75c2ff		4c8b5c2468		MOVQ 0x68(SP), R11										
  members_string.go:4069	0x75c304		e997f6ffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func23(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func24(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4139	0x75c320		4c8d6424e8		LEAQ -0x18(SP), R12										
  members_string.go:4139	0x75c325		4d3b6610		CMPQ R12, 0x10(R14)										
  members_string.go:4139	0x75c329		0f8660030000		JBE 0x75c68f											
  members_string.go:4139	0x75c32f		55			PUSHQ BP											
  members_string.go:4139	0x75c330		4889e5			MOVQ SP, BP											
  members_string.go:4139	0x75c333		4881ec90000000		SUBQ $0x90, SP											
  members_string.go:4139	0x75c33a		48898c24d0000000	MOVQ CX, 0xd0(SP)										
  members_string.go:4139	0x75c342		4889bc24d8000000	MOVQ DI, 0xd8(SP)										
  members_string.go:4139	0x75c34a		4c898424e8000000	MOVQ R8, 0xe8(SP)										
  members_string.go:4140	0x75c352		4d85db			TESTQ R11, R11											
  members_string.go:4140	0x75c355		7405			JE 0x75c35c											
  members_string.go:4140	0x75c357		498b13			MOVQ 0(R11), DX											
  members_string.go:4140	0x75c35a		eb04			JMP 0x75c360											
  members_string.go:4140	0x75c35c		31d2			XORL DX, DX											
  members_string.go:4140	0x75c35e		6690			NOPW												
  members_string.go:4140	0x75c360		4885d2			TESTQ DX, DX											
  members_string.go:4140	0x75c363		0f8fbb020000		JG 0x75c624											
  members_string.go:4143	0x75c369		4d85c9			TESTQ R9, R9											
  members_string.go:4143	0x75c36c		7406			JE 0x75c374											
  members_string.go:4143	0x75c36e		4983f902		CMPQ R9, $0x2											
  members_string.go:4143	0x75c372		7e66			JLE 0x75c3da											
  errors.go:26			0x75c374		488d0549ae0600		LEAQ 0x6ae49(IP), AX										
  errors.go:26			0x75c37b		bb33000000		MOVL $0x33, BX											
  errors.go:26			0x75c380		31c9			XORL CX, CX											
  errors.go:26			0x75c382		31ff			XORL DI, DI											
  errors.go:26			0x75c384		89fe			MOVL DI, SI											
  errors.go:26			0x75c386		e8351bd8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75c38b		4885c0			TESTQ AX, AX											
  errors.go:26			0x75c38e		7533			JNE 0x75c3c3											
  errors.go:31			0x75c390		90			NOPL												
  errors.go:65			0x75c391		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75c396		488d1d83e33800		LEAQ 0x38e383(IP), BX										
  errors.go:65			0x75c39d		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75c3a2		e8f94fccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75c3a7		48c7400833000000	MOVQ $0x33, 0x8(AX)										
  errors.go:65			0x75c3af		488d150eae0600		LEAQ 0x6ae0e(IP), DX										
  errors.go:65			0x75c3b6		488910			MOVQ DX, 0(AX)											
  members_string.go:4144	0x75c3b9		4889c3			MOVQ AX, BX											
  members_string.go:4144	0x75c3bc		488d050dc13b00		LEAQ 0x3bc10d(IP), AX										
  members_string.go:4144	0x75c3c3		31c9			XORL CX, CX											
  members_string.go:4144	0x75c3c5		31ff			XORL DI, DI											
  members_string.go:4144	0x75c3c7		4889c6			MOVQ AX, SI											
  members_string.go:4144	0x75c3ca		4989d8			MOVQ BX, R8											
  members_string.go:4144	0x75c3cd		31c0			XORL AX, AX											
  members_string.go:4144	0x75c3cf		31db			XORL BX, BX											
  members_string.go:4144	0x75c3d1		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4144	0x75c3d8		5d			POPQ BP												
  members_string.go:4144	0x75c3d9		c3			RET												
  members_string.go:4140	0x75c3da		4889742470		MOVQ SI, 0x70(SP)										
  members_string.go:4140	0x75c3df		4889bc2488000000	MOVQ DI, 0x88(SP)										
  members_string.go:4140	0x75c3e7		4c898c24f0000000	MOVQ R9, 0xf0(SP)										
  members_string.go:4140	0x75c3ef		4c898424e8000000	MOVQ R8, 0xe8(SP)										
  members_string.go:4140	0x75c3f7		48895c2468		MOVQ BX, 0x68(SP)										
  members_string.go:4140	0x75c3fc		48894c2460		MOVQ CX, 0x60(SP)										
  members_string.go:4146	0x75c401		498b7808		MOVQ 0x8(R8), DI										
  members_string.go:4146	0x75c405		498b7010		MOVQ 0x10(R8), SI										
  members_string.go:4146	0x75c409		498b5018		MOVQ 0x18(R8), DX										
  members_string.go:4146	0x75c40d		498b08			MOVQ 0(R8), CX											
  members_string.go:4146	0x75c410		488d05156d0500		LEAQ 0x56d15(IP), AX										
  members_string.go:4146	0x75c417		bb0d000000		MOVL $0xd, BX											
  members_string.go:4146	0x75c41c		4989d0			MOVQ DX, R8											
  members_string.go:4146	0x75c41f		90			NOPL												
  members_string.go:4146	0x75c420		e8bb46fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4146	0x75c425		4885ff			TESTQ DI, DI											
  members_string.go:4146	0x75c428		0f85df010000		JNE 0x75c60d											
  members_string.go:4143	0x75c42e		488b9424f0000000	MOVQ 0xf0(SP), DX										
  members_string.go:4143	0x75c436		4883fa02		CMPQ DX, $0x2											
  members_string.go:4150	0x75c43a		7409			JE 0x75c445											
  members_string.go:4150	0x75c43c		31c0			XORL AX, AX											
  members_string.go:4150	0x75c43e		6690			NOPW												
  members_string.go:4150	0x75c440		e993000000		JMP 0x75c4d8											
  members_string.go:4151	0x75c445		488b9424e8000000	MOVQ 0xe8(SP), DX										
  members_string.go:4151	0x75c44d		488b4220		MOVQ 0x20(DX), AX										
  members_string.go:4151	0x75c451		488b5a28		MOVQ 0x28(DX), BX										
  members_string.go:4151	0x75c455		488b4a30		MOVQ 0x30(DX), CX										
  members_string.go:4151	0x75c459		488b7a38		MOVQ 0x38(DX), DI										
  members_string.go:4151	0x75c45d		0f1f00			NOPL 0(AX)											
  members_string.go:4151	0x75c460		e89b78fdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)				
  members_string.go:4152	0x75c465		4885db			TESTQ BX, BX											
  members_string.go:4152	0x75c468		7505			JNE 0x75c46f											
  members_string.go:4152	0x75c46a		4885c0			TESTQ AX, AX											
  members_string.go:4152	0x75c46d		7d69			JGE 0x75c4d8											
  errors.go:26			0x75c46f		488d053da60600		LEAQ 0x6a63d(IP), AX										
  errors.go:26			0x75c476		bb31000000		MOVL $0x31, BX											
  errors.go:26			0x75c47b		31c9			XORL CX, CX											
  errors.go:26			0x75c47d		31ff			XORL DI, DI											
  errors.go:26			0x75c47f		89fe			MOVL DI, SI											
  errors.go:26			0x75c481		e83a1ad8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75c486		4885c0			TESTQ AX, AX											
  errors.go:26			0x75c489		7536			JNE 0x75c4c1											
  errors.go:31			0x75c48b		90			NOPL												
  errors.go:65			0x75c48c		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75c491		488d1d88e23800		LEAQ 0x38e288(IP), BX										
  errors.go:65			0x75c498		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75c49d		0f1f00			NOPL 0(AX)											
  errors.go:65			0x75c4a0		e8fb4eccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75c4a5		48c7400831000000	MOVQ $0x31, 0x8(AX)										
  errors.go:65			0x75c4ad		488d15ffa50600		LEAQ 0x6a5ff(IP), DX										
  errors.go:65			0x75c4b4		488910			MOVQ DX, 0(AX)											
  members_string.go:4153	0x75c4b7		4889c3			MOVQ AX, BX											
  members_string.go:4153	0x75c4ba		488d050fc03b00		LEAQ 0x3bc00f(IP), AX										
  members_string.go:4153	0x75c4c1		31c9			XORL CX, CX											
  members_string.go:4153	0x75c4c3		31ff			XORL DI, DI											
  members_string.go:4153	0x75c4c5		4889c6			MOVQ AX, SI											
  members_string.go:4153	0x75c4c8		4989d8			MOVQ BX, R8											
  members_string.go:4153	0x75c4cb		31c0			XORL AX, AX											
  members_string.go:4153	0x75c4cd		31db			XORL BX, BX											
  members_string.go:4153	0x75c4cf		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4153	0x75c4d6		5d			POPQ BP												
  members_string.go:4153	0x75c4d7		c3			RET												
  members_string.go:4157	0x75c4d8		4889442458		MOVQ AX, 0x58(SP)										
  members_string.go:4157	0x75c4dd		488b9424e8000000	MOVQ 0xe8(SP), DX										
  members_string.go:4157	0x75c4e5		488b0a			MOVQ 0(DX), CX											
  members_string.go:4157	0x75c4e8		488b7a08		MOVQ 0x8(DX), DI										
  members_string.go:4157	0x75c4ec		488b7210		MOVQ 0x10(DX), SI										
  members_string.go:4157	0x75c4f0		4c8b4218		MOVQ 0x18(DX), R8										
  members_string.go:4157	0x75c4f4		488d05316c0500		LEAQ 0x56c31(IP), AX										
  members_string.go:4157	0x75c4fb		bb0d000000		MOVL $0xd, BX											
  members_string.go:4157	0x75c500		e8db45fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4158	0x75c505		4885ff			TESTQ DI, DI											
  members_string.go:4158	0x75c508		0f85e8000000		JNE 0x75c5f6											
  members_string.go:4157	0x75c50e		884c2447		MOVB CL, 0x47(SP)										
  members_string.go:4157	0x75c512		4889842480000000	MOVQ AX, 0x80(SP)										
  members_string.go:4157	0x75c51a		48895c2450		MOVQ BX, 0x50(SP)										
  members_string.go:4161	0x75c51f		488b442468		MOVQ 0x68(SP), AX										
  members_string.go:4161	0x75c524		488b5c2460		MOVQ 0x60(SP), BX										
  members_string.go:4161	0x75c529		488b8c2488000000	MOVQ 0x88(SP), CX										
  members_string.go:4161	0x75c531		488b7c2470		MOVQ 0x70(SP), DI										
  members_string.go:4161	0x75c536		e8e5fde4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  members_string.go:4161	0x75c53b		4889442478		MOVQ AX, 0x78(SP)										
  members_string.go:4161	0x75c540		48895c2448		MOVQ BX, 0x48(SP)										
  members_string.go:4162	0x75c545		4889c1			MOVQ AX, CX											
  members_string.go:4162	0x75c548		4889df			MOVQ BX, DI											
  members_string.go:4162	0x75c54b		488bb42480000000	MOVQ 0x80(SP), SI										
  members_string.go:4162	0x75c553		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4162	0x75c558		440fb64c2447		MOVZX 0x47(SP), R9										
  members_string.go:4162	0x75c55e		488d05c76b0500		LEAQ 0x56bc7(IP), AX										
  members_string.go:4162	0x75c565		bb0d000000		MOVL $0xd, BX											
  members_string.go:4162	0x75c56a		e8d15bf7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)			
  members_string.go:4162	0x75c56f		4885c0			TESTQ AX, AX											
  members_string.go:4162	0x75c572		756b			JNE 0x75c5df											
  members_string.go:2070	0x75c574		488b05c52f4000		MOVQ github.com/mgomes/vibescript/internal/runtime.compiledRegexps(SB), AX			
  members_string.go:4165	0x75c57b		90			NOPL												
  members_string.go:2070	0x75c57c		488d1da96b0500		LEAQ 0x56ba9(IP), BX										
  members_string.go:2070	0x75c583		b90d000000		MOVL $0xd, CX											
  members_string.go:2070	0x75c588		488b7c2478		MOVQ 0x78(SP), DI										
  members_string.go:2070	0x75c58d		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:2070	0x75c592		4c8b842480000000	MOVQ 0x80(SP), R8										
  members_string.go:2070	0x75c59a		4c8b4c2450		MOVQ 0x50(SP), R9										
  members_string.go:2070	0x75c59f		4c8b542458		MOVQ 0x58(SP), R10										
  members_string.go:2070	0x75c5a4		e8f75cf7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexMatchFromRuneOffsetWithCache(SB)	
  members_string.go:4166	0x75c5a9		4885db			TESTQ BX, BX											
  members_string.go:4166	0x75c5ac		7417			JE 0x75c5c5											
  members_string.go:4167	0x75c5ae		31c0			XORL AX, AX											
  members_string.go:4167	0x75c5b0		31ff			XORL DI, DI											
  members_string.go:4167	0x75c5b2		4889de			MOVQ BX, SI											
  members_string.go:4167	0x75c5b5		4989c8			MOVQ CX, R8											
  members_string.go:4167	0x75c5b8		31db			XORL BX, BX											
  members_string.go:4167	0x75c5ba		31c9			XORL CX, CX											
  members_string.go:4167	0x75c5bc		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4167	0x75c5c3		5d			POPQ BP												
  members_string.go:4167	0x75c5c4		c3			RET												
  members_string.go:4169	0x75c5c5		0fb6f8			MOVZX AL, DI											
  members_string.go:4169	0x75c5c8		b801000000		MOVL $0x1, AX											
  members_string.go:4169	0x75c5cd		31db			XORL BX, BX											
  members_string.go:4169	0x75c5cf		31c9			XORL CX, CX											
  members_string.go:4169	0x75c5d1		89de			MOVL BX, SI											
  members_string.go:4169	0x75c5d3		4189c8			MOVL CX, R8											
  members_string.go:4169	0x75c5d6		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4169	0x75c5dd		5d			POPQ BP												
  members_string.go:4169	0x75c5de		c3			RET												
  members_string.go:4163	0x75c5df		31c9			XORL CX, CX											
  members_string.go:4163	0x75c5e1		31ff			XORL DI, DI											
  members_string.go:4163	0x75c5e3		4889c6			MOVQ AX, SI											
  members_string.go:4163	0x75c5e6		4989d8			MOVQ BX, R8											
  members_string.go:4163	0x75c5e9		31c0			XORL AX, AX											
  members_string.go:4163	0x75c5eb		31db			XORL BX, BX											
  members_string.go:4163	0x75c5ed		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4163	0x75c5f4		5d			POPQ BP												
  members_string.go:4163	0x75c5f5		c3			RET												
  members_string.go:4159	0x75c5f6		31c0			XORL AX, AX											
  members_string.go:4159	0x75c5f8		31db			XORL BX, BX											
  members_string.go:4159	0x75c5fa		31c9			XORL CX, CX											
  members_string.go:4159	0x75c5fc		4989f0			MOVQ SI, R8											
  members_string.go:4159	0x75c5ff		4889fe			MOVQ DI, SI											
  members_string.go:4159	0x75c602		31ff			XORL DI, DI											
  members_string.go:4159	0x75c604		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4159	0x75c60b		5d			POPQ BP												
  members_string.go:4159	0x75c60c		c3			RET												
  members_string.go:4147	0x75c60d		31c0			XORL AX, AX											
  members_string.go:4147	0x75c60f		31db			XORL BX, BX											
  members_string.go:4147	0x75c611		31c9			XORL CX, CX											
  members_string.go:4147	0x75c613		4989f0			MOVQ SI, R8											
  members_string.go:4147	0x75c616		4889fe			MOVQ DI, SI											
  members_string.go:4147	0x75c619		31ff			XORL DI, DI											
  members_string.go:4147	0x75c61b		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4147	0x75c622		5d			POPQ BP												
  members_string.go:4147	0x75c623		c3			RET												
  errors.go:26			0x75c624		488d050f990600		LEAQ 0x6990f(IP), AX										
  errors.go:26			0x75c62b		bb2f000000		MOVL $0x2f, BX											
  errors.go:26			0x75c630		31c9			XORL CX, CX											
  errors.go:26			0x75c632		31ff			XORL DI, DI											
  errors.go:26			0x75c634		89fe			MOVL DI, SI											
  errors.go:26			0x75c636		e88518d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75c63b		0f1f440000		NOPL 0(AX)(AX*1)										
  errors.go:26			0x75c640		4885c0			TESTQ AX, AX											
  errors.go:26			0x75c643		7533			JNE 0x75c678											
  errors.go:31			0x75c645		90			NOPL												
  errors.go:65			0x75c646		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75c64b		488d1dcee03800		LEAQ 0x38e0ce(IP), BX										
  errors.go:65			0x75c652		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75c657		e8444dccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75c65c		48c740082f000000	MOVQ $0x2f, 0x8(AX)										
  errors.go:65			0x75c664		488d15cf980600		LEAQ 0x698cf(IP), DX										
  errors.go:65			0x75c66b		488910			MOVQ DX, 0(AX)											
  members_string.go:4141	0x75c66e		4889c3			MOVQ AX, BX											
  members_string.go:4141	0x75c671		488d0558be3b00		LEAQ 0x3bbe58(IP), AX										
  members_string.go:4141	0x75c678		31c9			XORL CX, CX											
  members_string.go:4141	0x75c67a		31ff			XORL DI, DI											
  members_string.go:4141	0x75c67c		4889c6			MOVQ AX, SI											
  members_string.go:4141	0x75c67f		4989d8			MOVQ BX, R8											
  members_string.go:4141	0x75c682		31c0			XORL AX, AX											
  members_string.go:4141	0x75c684		31db			XORL BX, BX											
  members_string.go:4141	0x75c686		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4141	0x75c68d		5d			POPQ BP												
  members_string.go:4141	0x75c68e		c3			RET												
  members_string.go:4139	0x75c68f		4889442428		MOVQ AX, 0x28(SP)										
  members_string.go:4139	0x75c694		48895c2430		MOVQ BX, 0x30(SP)										
  members_string.go:4139	0x75c699		48894c2438		MOVQ CX, 0x38(SP)										
  members_string.go:4139	0x75c69e		48897c2440		MOVQ DI, 0x40(SP)										
  members_string.go:4139	0x75c6a3		4889742448		MOVQ SI, 0x48(SP)										
  members_string.go:4139	0x75c6a8		4c89442450		MOVQ R8, 0x50(SP)										
  members_string.go:4139	0x75c6ad		4c894c2458		MOVQ R9, 0x58(SP)										
  members_string.go:4139	0x75c6b2		4c89542460		MOVQ R10, 0x60(SP)										
  members_string.go:4139	0x75c6b7		4c895c2468		MOVQ R11, 0x68(SP)										
  members_string.go:4139	0x75c6bc		0f1f4000		NOPL 0(AX)											
  members_string.go:4139	0x75c6c0		e87bffd2ff		CALL runtime.morestack_noctxt.abi0(SB)								
  members_string.go:4139	0x75c6c5		488b442428		MOVQ 0x28(SP), AX										
  members_string.go:4139	0x75c6ca		488b5c2430		MOVQ 0x30(SP), BX										
  members_string.go:4139	0x75c6cf		488b4c2438		MOVQ 0x38(SP), CX										
  members_string.go:4139	0x75c6d4		488b7c2440		MOVQ 0x40(SP), DI										
  members_string.go:4139	0x75c6d9		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:4139	0x75c6de		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4139	0x75c6e3		4c8b4c2458		MOVQ 0x58(SP), R9										
  members_string.go:4139	0x75c6e8		4c8b542460		MOVQ 0x60(SP), R10										
  members_string.go:4139	0x75c6ed		4c8b5c2468		MOVQ 0x68(SP), R11										
  members_string.go:4139	0x75c6f2		e929fcffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func24(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func25(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4172	0x75c700		4c8d642490		LEAQ -0x70(SP), R12								
  members_string.go:4172	0x75c705		4d3b6610		CMPQ R12, 0x10(R14)								
  members_string.go:4172	0x75c709		0f86a9030000		JBE 0x75cab8									
  members_string.go:4172	0x75c70f		55			PUSHQ BP									
  members_string.go:4172	0x75c710		4889e5			MOVQ SP, BP									
  members_string.go:4172	0x75c713		4881ece8000000		SUBQ $0xe8, SP									
  members_string.go:4172	0x75c71a		48898c2428010000	MOVQ CX, 0x128(SP)								
  members_string.go:4172	0x75c722		4889bc2430010000	MOVQ DI, 0x130(SP)								
  members_string.go:4172	0x75c72a		4c89842440010000	MOVQ R8, 0x140(SP)								
  members_string.go:4173	0x75c732		4d85db			TESTQ R11, R11									
  members_string.go:4173	0x75c735		7405			JE 0x75c73c									
  members_string.go:4173	0x75c737		498b13			MOVQ 0(R11), DX									
  members_string.go:4173	0x75c73a		eb04			JMP 0x75c740									
  members_string.go:4173	0x75c73c		31d2			XORL DX, DX									
  members_string.go:4173	0x75c73e		6690			NOPW										
  members_string.go:4173	0x75c740		4885d2			TESTQ DX, DX									
  members_string.go:4173	0x75c743		0f8f09030000		JG 0x75ca52									
  members_string.go:4176	0x75c749		4983f901		CMPQ R9, $0x1									
  members_string.go:4176	0x75c74d		7469			JE 0x75c7b8									
  errors.go:26			0x75c74f		488d05384c0600		LEAQ 0x64c38(IP), AX								
  errors.go:26			0x75c756		bb27000000		MOVL $0x27, BX									
  errors.go:26			0x75c75b		31c9			XORL CX, CX									
  errors.go:26			0x75c75d		31ff			XORL DI, DI									
  errors.go:26			0x75c75f		89fe			MOVL DI, SI									
  errors.go:26			0x75c761		e85a17d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75c766		4885c0			TESTQ AX, AX									
  errors.go:26			0x75c769		7536			JNE 0x75c7a1									
  errors.go:31			0x75c76b		90			NOPL										
  errors.go:65			0x75c76c		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75c771		488d1da8df3800		LEAQ 0x38dfa8(IP), BX								
  errors.go:65			0x75c778		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75c77d		0f1f00			NOPL 0(AX)									
  errors.go:65			0x75c780		e81b4cccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75c785		48c7400827000000	MOVQ $0x27, 0x8(AX)								
  errors.go:65			0x75c78d		488d15fa4b0600		LEAQ 0x64bfa(IP), DX								
  errors.go:65			0x75c794		488910			MOVQ DX, 0(AX)									
  members_string.go:4177	0x75c797		4889c3			MOVQ AX, BX									
  members_string.go:4177	0x75c79a		488d052fbd3b00		LEAQ 0x3bbd2f(IP), AX								
  members_string.go:4177	0x75c7a1		31c9			XORL CX, CX									
  members_string.go:4177	0x75c7a3		31ff			XORL DI, DI									
  members_string.go:4177	0x75c7a5		4889c6			MOVQ AX, SI									
  members_string.go:4177	0x75c7a8		4989d8			MOVQ BX, R8									
  members_string.go:4177	0x75c7ab		31c0			XORL AX, AX									
  members_string.go:4177	0x75c7ad		31db			XORL BX, BX									
  members_string.go:4177	0x75c7af		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4177	0x75c7b6		5d			POPQ BP										
  members_string.go:4177	0x75c7b7		c3			RET										
  members_string.go:4173	0x75c7b8		4889842418010000	MOVQ AX, 0x118(SP)								
  members_string.go:4173	0x75c7c0		4c899c2458010000	MOVQ R11, 0x158(SP)								
  members_string.go:4173	0x75c7c8		4c89842440010000	MOVQ R8, 0x140(SP)								
  members_string.go:4173	0x75c7d0		4889b424b8000000	MOVQ SI, 0xb8(SP)								
  members_string.go:4173	0x75c7d8		48899c24b0000000	MOVQ BX, 0xb0(SP)								
  members_string.go:4173	0x75c7e0		4889bc24e0000000	MOVQ DI, 0xe0(SP)								
  members_string.go:4173	0x75c7e8		48898c24a8000000	MOVQ CX, 0xa8(SP)								
  members_string.go:4173	0x75c7f0		4c898c2448010000	MOVQ R9, 0x148(SP)								
  members_string.go:4173	0x75c7f8		4c89942450010000	MOVQ R10, 0x150(SP)								
  members_string.go:4179	0x75c800		498b08			MOVQ 0(R8), CX									
  members_string.go:4179	0x75c803		498b7808		MOVQ 0x8(R8), DI								
  members_string.go:4179	0x75c807		498b7010		MOVQ 0x10(R8), SI								
  members_string.go:4179	0x75c80b		4d8b4018		MOVQ 0x18(R8), R8								
  members_string.go:4179	0x75c80f		488d05145b0500		LEAQ 0x55b14(IP), AX								
  members_string.go:4179	0x75c816		bb0b000000		MOVL $0xb, BX									
  members_string.go:4179	0x75c81b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4179	0x75c820		e8bb42fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)	
  members_string.go:4180	0x75c825		4885ff			TESTQ DI, DI									
  members_string.go:4180	0x75c828		0f850d020000		JNE 0x75ca3b									
  members_string.go:4179	0x75c82e		888c2497000000		MOVB CL, 0x97(SP)								
  members_string.go:4179	0x75c835		48898424c8000000	MOVQ AX, 0xc8(SP)								
  members_string.go:4179	0x75c83d		48899c24a0000000	MOVQ BX, 0xa0(SP)								
  members_string.go:4183	0x75c845		488b8424b0000000	MOVQ 0xb0(SP), AX								
  members_string.go:4183	0x75c84d		488b9c24a8000000	MOVQ 0xa8(SP), BX								
  members_string.go:4183	0x75c855		488b8c24e0000000	MOVQ 0xe0(SP), CX								
  members_string.go:4183	0x75c85d		488bbc24b8000000	MOVQ 0xb8(SP), DI								
  members_string.go:4183	0x75c865		e8b6fae4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4183	0x75c86a		48898424c0000000	MOVQ AX, 0xc0(SP)								
  members_string.go:4183	0x75c872		48899c2498000000	MOVQ BX, 0x98(SP)								
  members_string.go:4184	0x75c87a		4889c1			MOVQ AX, CX									
  members_string.go:4184	0x75c87d		4889df			MOVQ BX, DI									
  members_string.go:4184	0x75c880		488bb424c8000000	MOVQ 0xc8(SP), SI								
  members_string.go:4184	0x75c888		4c8b8424a0000000	MOVQ 0xa0(SP), R8								
  members_string.go:4184	0x75c890		440fb68c2497000000	MOVZX 0x97(SP), R9								
  members_string.go:4184	0x75c899		488d058a5a0500		LEAQ 0x55a8a(IP), AX								
  members_string.go:4184	0x75c8a0		bb0b000000		MOVL $0xb, BX									
  members_string.go:4184	0x75c8a5		e89658f7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)	
  members_string.go:4184	0x75c8aa		4885c0			TESTQ AX, AX									
  members_string.go:4184	0x75c8ad		0f8571010000		JNE 0x75ca24									
  members_string.go:4187	0x75c8b3		488b8424c8000000	MOVQ 0xc8(SP), AX								
  members_string.go:4187	0x75c8bb		488b9c24a0000000	MOVQ 0xa0(SP), BX								
  members_string.go:4187	0x75c8c3		e8d8d1faff		CALL github.com/mgomes/vibescript/internal/runtime.compileCachedRegex(SB)	
  members_string.go:4188	0x75c8c8		4885db			TESTQ BX, BX									
  members_string.go:4188	0x75c8cb		0f848e000000		JE 0x75c95f									
  members_string.go:4189	0x75c8d1		440f11bc24d0000000	MOVUPS X15, 0xd0(SP)								
  members_string.go:4189	0x75c8da		7404			JE 0x75c8e0									
  members_string.go:4189	0x75c8dc		488b5b08		MOVQ 0x8(BX), BX								
  members_string.go:4189	0x75c8e0		48899c24d0000000	MOVQ BX, 0xd0(SP)								
  members_string.go:4189	0x75c8e8		48898c24d8000000	MOVQ CX, 0xd8(SP)								
  errors.go:26			0x75c8f0		488d050adc0500		LEAQ 0x5dc0a(IP), AX								
  errors.go:26			0x75c8f7		bb1d000000		MOVL $0x1d, BX									
  errors.go:26			0x75c8fc		488d8c24d0000000	LEAQ 0xd0(SP), CX								
  errors.go:26			0x75c904		bf01000000		MOVL $0x1, DI									
  errors.go:26			0x75c909		89fe			MOVL DI, SI									
  errors.go:26			0x75c90b		e8b015d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75c910		4885c0			TESTQ AX, AX									
  errors.go:26			0x75c913		7533			JNE 0x75c948									
  errors.go:31			0x75c915		90			NOPL										
  errors.go:65			0x75c916		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75c91b		488d1dfedd3800		LEAQ 0x38ddfe(IP), BX								
  errors.go:65			0x75c922		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75c927		e8744accff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75c92c		48c740081d000000	MOVQ $0x1d, 0x8(AX)								
  errors.go:65			0x75c934		488d15c6db0500		LEAQ 0x5dbc6(IP), DX								
  errors.go:65			0x75c93b		488910			MOVQ DX, 0(AX)									
  members_string.go:4189	0x75c93e		4889c3			MOVQ AX, BX									
  members_string.go:4189	0x75c941		488d0588bb3b00		LEAQ 0x3bbb88(IP), AX								
  members_string.go:4189	0x75c948		31c9			XORL CX, CX									
  members_string.go:4189	0x75c94a		31ff			XORL DI, DI									
  members_string.go:4189	0x75c94c		4889c6			MOVQ AX, SI									
  members_string.go:4189	0x75c94f		4989d8			MOVQ BX, R8									
  members_string.go:4189	0x75c952		31c0			XORL AX, AX									
  members_string.go:4189	0x75c954		31db			XORL BX, BX									
  members_string.go:4189	0x75c956		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4189	0x75c95d		5d			POPQ BP										
  members_string.go:4189	0x75c95e		c3			RET										
  members_string.go:4191	0x75c95f		488b9424b0000000	MOVQ 0xb0(SP), DX								
  members_string.go:4191	0x75c967		48891424		MOVQ DX, 0(SP)									
  members_string.go:4191	0x75c96b		488b9424a8000000	MOVQ 0xa8(SP), DX								
  members_string.go:4191	0x75c973		4889542408		MOVQ DX, 0x8(SP)								
  members_string.go:4191	0x75c978		488b9424e0000000	MOVQ 0xe0(SP), DX								
  members_string.go:4191	0x75c980		4889542410		MOVQ DX, 0x10(SP)								
  members_string.go:4191	0x75c985		488b9424b8000000	MOVQ 0xb8(SP), DX								
  members_string.go:4191	0x75c98d		4889542418		MOVQ DX, 0x18(SP)								
  members_string.go:4191	0x75c992		488b942458010000	MOVQ 0x158(SP), DX								
  members_string.go:4191	0x75c99a		4889542420		MOVQ DX, 0x20(SP)								
  members_string.go:4191	0x75c99f		488b9424f8000000	MOVQ 0xf8(SP), DX								
  members_string.go:4191	0x75c9a7		4889542428		MOVQ DX, 0x28(SP)								
  members_string.go:4191	0x75c9ac		488b942400010000	MOVQ 0x100(SP), DX								
  members_string.go:4191	0x75c9b4		4889542430		MOVQ DX, 0x30(SP)								
  members_string.go:4191	0x75c9b9		488b942408010000	MOVQ 0x108(SP), DX								
  members_string.go:4191	0x75c9c1		4889542438		MOVQ DX, 0x38(SP)								
  members_string.go:4191	0x75c9c6		488b942410010000	MOVQ 0x110(SP), DX								
  members_string.go:4191	0x75c9ce		4889542440		MOVQ DX, 0x40(SP)								
  members_string.go:4191	0x75c9d3		4889c3			MOVQ AX, BX									
  members_string.go:4191	0x75c9d6		488b8c24c8000000	MOVQ 0xc8(SP), CX								
  members_string.go:4191	0x75c9de		488bbc24a0000000	MOVQ 0xa0(SP), DI								
  members_string.go:4191	0x75c9e6		488bb424c0000000	MOVQ 0xc0(SP), SI								
  members_string.go:4191	0x75c9ee		4c8b842498000000	MOVQ 0x98(SP), R8								
  members_string.go:4191	0x75c9f6		4c8b8c2440010000	MOVQ 0x140(SP), R9								
  members_string.go:4191	0x75c9fe		4c8b942448010000	MOVQ 0x148(SP), R10								
  members_string.go:4191	0x75ca06		4c8b9c2450010000	MOVQ 0x150(SP), R11								
  members_string.go:4191	0x75ca0e		488b842418010000	MOVQ 0x118(SP), AX								
  members_string.go:4191	0x75ca16		e88512f8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringScan(SB)		
  members_string.go:4191	0x75ca1b		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4191	0x75ca22		5d			POPQ BP										
  members_string.go:4191	0x75ca23		c3			RET										
  members_string.go:4185	0x75ca24		31c9			XORL CX, CX									
  members_string.go:4185	0x75ca26		31ff			XORL DI, DI									
  members_string.go:4185	0x75ca28		4889c6			MOVQ AX, SI									
  members_string.go:4185	0x75ca2b		4989d8			MOVQ BX, R8									
  members_string.go:4185	0x75ca2e		31c0			XORL AX, AX									
  members_string.go:4185	0x75ca30		31db			XORL BX, BX									
  members_string.go:4185	0x75ca32		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4185	0x75ca39		5d			POPQ BP										
  members_string.go:4185	0x75ca3a		c3			RET										
  members_string.go:4181	0x75ca3b		31c0			XORL AX, AX									
  members_string.go:4181	0x75ca3d		31db			XORL BX, BX									
  members_string.go:4181	0x75ca3f		31c9			XORL CX, CX									
  members_string.go:4181	0x75ca41		4989f0			MOVQ SI, R8									
  members_string.go:4181	0x75ca44		4889fe			MOVQ DI, SI									
  members_string.go:4181	0x75ca47		31ff			XORL DI, DI									
  members_string.go:4181	0x75ca49		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4181	0x75ca50		5d			POPQ BP										
  members_string.go:4181	0x75ca51		c3			RET										
  errors.go:26			0x75ca52		488d0506850600		LEAQ 0x68506(IP), AX								
  errors.go:26			0x75ca59		bb2d000000		MOVL $0x2d, BX									
  errors.go:26			0x75ca5e		31c9			XORL CX, CX									
  errors.go:26			0x75ca60		31ff			XORL DI, DI									
  errors.go:26			0x75ca62		89fe			MOVL DI, SI									
  errors.go:26			0x75ca64		e85714d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75ca69		4885c0			TESTQ AX, AX									
  errors.go:26			0x75ca6c		7533			JNE 0x75caa1									
  errors.go:31			0x75ca6e		90			NOPL										
  errors.go:65			0x75ca6f		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75ca74		488d1da5dc3800		LEAQ 0x38dca5(IP), BX								
  errors.go:65			0x75ca7b		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75ca80		e81b49ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75ca85		48c740082d000000	MOVQ $0x2d, 0x8(AX)								
  errors.go:65			0x75ca8d		488d15cb840600		LEAQ 0x684cb(IP), DX								
  errors.go:65			0x75ca94		488910			MOVQ DX, 0(AX)									
  members_string.go:4174	0x75ca97		4889c3			MOVQ AX, BX									
  members_string.go:4174	0x75ca9a		488d052fba3b00		LEAQ 0x3bba2f(IP), AX								
  members_string.go:4174	0x75caa1		31c9			XORL CX, CX									
  members_string.go:4174	0x75caa3		31ff			XORL DI, DI									
  members_string.go:4174	0x75caa5		4889c6			MOVQ AX, SI									
  members_string.go:4174	0x75caa8		4989d8			MOVQ BX, R8									
  members_string.go:4174	0x75caab		31c0			XORL AX, AX									
  members_string.go:4174	0x75caad		31db			XORL BX, BX									
  members_string.go:4174	0x75caaf		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4174	0x75cab6		5d			POPQ BP										
  members_string.go:4174	0x75cab7		c3			RET										
  members_string.go:4172	0x75cab8		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4172	0x75cabd		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4172	0x75cac2		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4172	0x75cac7		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4172	0x75cacc		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4172	0x75cad1		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4172	0x75cad6		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4172	0x75cadb		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4172	0x75cae0		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4172	0x75cae5		e856fbd2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4172	0x75caea		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4172	0x75caef		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4172	0x75caf4		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4172	0x75caf9		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4172	0x75cafe		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4172	0x75cb03		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4172	0x75cb08		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4172	0x75cb0d		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4172	0x75cb12		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4172	0x75cb17		e9e4fbffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func25(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func26(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4194	0x75cb20		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4194	0x75cb24		0f867a010000		JBE 0x75cca4									
  members_string.go:4194	0x75cb2a		55			PUSHQ BP									
  members_string.go:4194	0x75cb2b		4889e5			MOVQ SP, BP									
  members_string.go:4194	0x75cb2e		4883ec70		SUBQ $0x70, SP									
  members_string.go:4194	0x75cb32		48898c24b0000000	MOVQ CX, 0xb0(SP)								
  members_string.go:4194	0x75cb3a		4889bc24b8000000	MOVQ DI, 0xb8(SP)								
  members_string.go:4194	0x75cb42		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4195	0x75cb4a		4d85c9			TESTQ R9, R9									
  members_string.go:4195	0x75cb4d		7406			JE 0x75cb55									
  members_string.go:4195	0x75cb4f		4983f902		CMPQ R9, $0x2									
  members_string.go:4195	0x75cb53		7e63			JLE 0x75cbb8									
  errors.go:26			0x75cb55		488d056da30600		LEAQ 0x6a36d(IP), AX								
  errors.go:26			0x75cb5c		bb32000000		MOVL $0x32, BX									
  errors.go:26			0x75cb61		31c9			XORL CX, CX									
  errors.go:26			0x75cb63		31ff			XORL DI, DI									
  errors.go:26			0x75cb65		89fe			MOVL DI, SI									
  errors.go:26			0x75cb67		e85413d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75cb6c		4885c0			TESTQ AX, AX									
  errors.go:26			0x75cb6f		7533			JNE 0x75cba4									
  errors.go:31			0x75cb71		90			NOPL										
  errors.go:65			0x75cb72		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75cb77		488d1da2db3800		LEAQ 0x38dba2(IP), BX								
  errors.go:65			0x75cb7e		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75cb83		e81848ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75cb88		48c7400832000000	MOVQ $0x32, 0x8(AX)								
  errors.go:65			0x75cb90		488d1532a30600		LEAQ 0x6a332(IP), DX								
  errors.go:65			0x75cb97		488910			MOVQ DX, 0(AX)									
  members_string.go:4196	0x75cb9a		4889c3			MOVQ AX, BX									
  members_string.go:4196	0x75cb9d		488d052cb93b00		LEAQ 0x3bb92c(IP), AX								
  members_string.go:4196	0x75cba4		31c9			XORL CX, CX									
  members_string.go:4196	0x75cba6		31ff			XORL DI, DI									
  members_string.go:4196	0x75cba8		4889c6			MOVQ AX, SI									
  members_string.go:4196	0x75cbab		4989d8			MOVQ BX, R8									
  members_string.go:4196	0x75cbae		31c0			XORL AX, AX									
  members_string.go:4196	0x75cbb0		31db			XORL BX, BX									
  members_string.go:4196	0x75cbb2		4883c470		ADDQ $0x70, SP									
  members_string.go:4196	0x75cbb6		5d			POPQ BP										
  members_string.go:4196	0x75cbb7		c3			RET										
  members_string.go:4199	0x75cbb8		7404			JE 0x75cbbe									
  members_string.go:4199	0x75cbba		31d2			XORL DX, DX									
  members_string.go:4199	0x75cbbc		eb65			JMP 0x75cc23									
  members_string.go:4195	0x75cbbe		48898424a0000000	MOVQ AX, 0xa0(SP)								
  members_string.go:4195	0x75cbc6		48895c2460		MOVQ BX, 0x60(SP)								
  members_string.go:4195	0x75cbcb		4889742458		MOVQ SI, 0x58(SP)								
  members_string.go:4195	0x75cbd0		48894c2450		MOVQ CX, 0x50(SP)								
  members_string.go:4195	0x75cbd5		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4195	0x75cbdd		48897c2468		MOVQ DI, 0x68(SP)								
  members_string.go:4200	0x75cbe2		498b4020		MOVQ 0x20(R8), AX								
  members_string.go:4200	0x75cbe6		498b5828		MOVQ 0x28(R8), BX								
  members_string.go:4200	0x75cbea		498b4830		MOVQ 0x30(R8), CX								
  members_string.go:4200	0x75cbee		498b7838		MOVQ 0x38(R8), DI								
  members_string.go:4200	0x75cbf2		e80971fdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)		
  members_string.go:4201	0x75cbf7		4885db			TESTQ BX, BX									
  members_string.go:4201	0x75cbfa		7545			JNE 0x75cc41									
  members_string.go:4206	0x75cbfc		488b4c2450		MOVQ 0x50(SP), CX								
  members_string.go:4206	0x75cc01		488b5c2460		MOVQ 0x60(SP), BX								
  members_string.go:4206	0x75cc06		488b742458		MOVQ 0x58(SP), SI								
  members_string.go:4206	0x75cc0b		488b7c2468		MOVQ 0x68(SP), DI								
  members_string.go:4206	0x75cc10		4c8b8424c8000000	MOVQ 0xc8(SP), R8								
  members_string.go:4206	0x75cc18		4889c2			MOVQ AX, DX									
  members_string.go:4206	0x75cc1b		488b8424a0000000	MOVQ 0xa0(SP), AX								
  members_string.go:4206	0x75cc23		4d8b4808		MOVQ 0x8(R8), R9								
  members_string.go:4206	0x75cc27		4d8b5010		MOVQ 0x10(R8), R10								
  members_string.go:4206	0x75cc2b		4d8b5818		MOVQ 0x18(R8), R11								
  members_string.go:4206	0x75cc2f		4d8b00			MOVQ 0(R8), R8									
  members_string.go:4206	0x75cc32		48891424		MOVQ DX, 0(SP)									
  members_string.go:4206	0x75cc36		e8a50bf8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIndexResult(SB)	
  members_string.go:4206	0x75cc3b		4883c470		ADDQ $0x70, SP									
  members_string.go:4206	0x75cc3f		5d			POPQ BP										
  members_string.go:4206	0x75cc40		c3			RET										
  errors.go:26			0x75cc41		488d0529150600		LEAQ 0x61529(IP), AX								
  errors.go:26			0x75cc48		bb23000000		MOVL $0x23, BX									
  errors.go:26			0x75cc4d		31c9			XORL CX, CX									
  errors.go:26			0x75cc4f		31ff			XORL DI, DI									
  errors.go:26			0x75cc51		89fe			MOVL DI, SI									
  errors.go:26			0x75cc53		e86812d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75cc58		4885c0			TESTQ AX, AX									
  errors.go:26			0x75cc5b		7533			JNE 0x75cc90									
  errors.go:31			0x75cc5d		90			NOPL										
  errors.go:65			0x75cc5e		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75cc63		488d1db6da3800		LEAQ 0x38dab6(IP), BX								
  errors.go:65			0x75cc6a		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75cc6f		e82c47ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75cc74		48c7400823000000	MOVQ $0x23, 0x8(AX)								
  errors.go:65			0x75cc7c		488d15ee140600		LEAQ 0x614ee(IP), DX								
  errors.go:65			0x75cc83		488910			MOVQ DX, 0(AX)									
  members_string.go:4202	0x75cc86		4889c3			MOVQ AX, BX									
  members_string.go:4202	0x75cc89		488d0540b83b00		LEAQ 0x3bb840(IP), AX								
  members_string.go:4202	0x75cc90		31c9			XORL CX, CX									
  members_string.go:4202	0x75cc92		31ff			XORL DI, DI									
  members_string.go:4202	0x75cc94		4889c6			MOVQ AX, SI									
  members_string.go:4202	0x75cc97		4989d8			MOVQ BX, R8									
  members_string.go:4202	0x75cc9a		31c0			XORL AX, AX									
  members_string.go:4202	0x75cc9c		31db			XORL BX, BX									
  members_string.go:4202	0x75cc9e		4883c470		ADDQ $0x70, SP									
  members_string.go:4202	0x75cca2		5d			POPQ BP										
  members_string.go:4202	0x75cca3		c3			RET										
  members_string.go:4194	0x75cca4		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4194	0x75cca9		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4194	0x75ccae		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4194	0x75ccb3		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4194	0x75ccb8		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4194	0x75ccbd		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4194	0x75ccc2		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4194	0x75ccc7		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4194	0x75cccc		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4194	0x75ccd1		e86af9d2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4194	0x75ccd6		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4194	0x75ccdb		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4194	0x75cce0		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4194	0x75cce5		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4194	0x75ccea		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4194	0x75ccef		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4194	0x75ccf4		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4194	0x75ccf9		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4194	0x75ccfe		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4194	0x75cd03		e918feffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func26(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func27(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4209	0x75cd20		4c8d6424d0		LEAQ -0x30(SP), R12								
  members_string.go:4209	0x75cd25		4d3b6610		CMPQ R12, 0x10(R14)								
  members_string.go:4209	0x75cd29		0f8641030000		JBE 0x75d070									
  members_string.go:4209	0x75cd2f		55			PUSHQ BP									
  members_string.go:4209	0x75cd30		4889e5			MOVQ SP, BP									
  members_string.go:4209	0x75cd33		4881eca8000000		SUBQ $0xa8, SP									
  members_string.go:4209	0x75cd3a		48898c24e8000000	MOVQ CX, 0xe8(SP)								
  members_string.go:4209	0x75cd42		4889bc24f0000000	MOVQ DI, 0xf0(SP)								
  members_string.go:4209	0x75cd4a		4c89842400010000	MOVQ R8, 0x100(SP)								
  members_string.go:4210	0x75cd52		4d85c9			TESTQ R9, R9									
  members_string.go:4210	0x75cd55		7453			JE 0x75cdaa									
  members_string.go:4210	0x75cd57		4983f902		CMPQ R9, $0x2									
  members_string.go:4210	0x75cd5b		7f4d			JG 0x75cdaa									
  members_string.go:4210	0x75cd5d		48898424d8000000	MOVQ AX, 0xd8(SP)								
  members_string.go:4210	0x75cd65		48899c2488000000	MOVQ BX, 0x88(SP)								
  members_string.go:4210	0x75cd6d		4c898c2408010000	MOVQ R9, 0x108(SP)								
  members_string.go:4210	0x75cd75		4889b42480000000	MOVQ SI, 0x80(SP)								
  members_string.go:4210	0x75cd7d		4889bc24a0000000	MOVQ DI, 0xa0(SP)								
  members_string.go:4210	0x75cd85		48894c2478		MOVQ CX, 0x78(SP)								
  members_string.go:4210	0x75cd8a		4c89842400010000	MOVQ R8, 0x100(SP)								
  members_string.go:4213	0x75cd92		4889d8			MOVQ BX, AX									
  members_string.go:4213	0x75cd95		4889cb			MOVQ CX, BX									
  members_string.go:4213	0x75cd98		4889f9			MOVQ DI, CX									
  members_string.go:4213	0x75cd9b		4889f7			MOVQ SI, DI									
  members_string.go:4213	0x75cd9e		6690			NOPW										
  members_string.go:4213	0x75cda0		e87bf5e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:1178	0x75cda5		90			NOPL										
  members_string.go:1100	0x75cda6		31d2			XORL DX, DX									
  members_string.go:1100	0x75cda8		eb76			JMP 0x75ce20									
  errors.go:26			0x75cdaa		488d0546a40600		LEAQ 0x6a446(IP), AX								
  errors.go:26			0x75cdb1		bb33000000		MOVL $0x33, BX									
  errors.go:26			0x75cdb6		31c9			XORL CX, CX									
  errors.go:26			0x75cdb8		31ff			XORL DI, DI									
  errors.go:26			0x75cdba		89fe			MOVL DI, SI									
  errors.go:26			0x75cdbc		0f1f4000		NOPL 0(AX)									
  errors.go:26			0x75cdc0		e8fb10d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75cdc5		4885c0			TESTQ AX, AX									
  errors.go:26			0x75cdc8		7537			JNE 0x75ce01									
  errors.go:31			0x75cdca		90			NOPL										
  errors.go:65			0x75cdcb		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75cdd0		488d1d49d93800		LEAQ 0x38d949(IP), BX								
  errors.go:65			0x75cdd7		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75cddc		0f1f4000		NOPL 0(AX)									
  errors.go:65			0x75cde0		e8bb45ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75cde5		48c7400833000000	MOVQ $0x33, 0x8(AX)								
  errors.go:65			0x75cded		488d1503a40600		LEAQ 0x6a403(IP), DX								
  errors.go:65			0x75cdf4		488910			MOVQ DX, 0(AX)									
  members_string.go:4211	0x75cdf7		4889c3			MOVQ AX, BX									
  members_string.go:4211	0x75cdfa		488d05cfb63b00		LEAQ 0x3bb6cf(IP), AX								
  members_string.go:4211	0x75ce01		31c9			XORL CX, CX									
  members_string.go:4211	0x75ce03		31ff			XORL DI, DI									
  members_string.go:4211	0x75ce05		4889c6			MOVQ AX, SI									
  members_string.go:4211	0x75ce08		4989d8			MOVQ BX, R8									
  members_string.go:4211	0x75ce0b		31c0			XORL AX, AX									
  members_string.go:4211	0x75ce0d		31db			XORL BX, BX									
  members_string.go:4211	0x75ce0f		4881c4a8000000		ADDQ $0xa8, SP									
  members_string.go:4211	0x75ce16		5d			POPQ BP										
  members_string.go:4211	0x75ce17		c3			RET										
  members_string.go:1100	0x75ce18		48ffc2			INCQ DX										
  members_string.go:1100	0x75ce1b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:1100	0x75ce20		4839d3			CMPQ BX, DX									
  members_string.go:1100	0x75ce23		7e23			JLE 0x75ce48									
  members_string.go:1101	0x75ce25		440fb62410		MOVZX 0(AX)(DX*1), R12								
  members_string.go:1101	0x75ce2a		4180fc80		CMPL R12, $0x80									
  members_string.go:1101	0x75ce2e		72e8			JB 0x75ce18									
  members_string.go:4213	0x75ce30		48895c2468		MOVQ BX, 0x68(SP)								
  members_string.go:4213	0x75ce35		4889842498000000	MOVQ AX, 0x98(SP)								
  members_string.go:1181	0x75ce3d		90			NOPL										
  utf8.go:448			0x75ce3e		31d2			XORL DX, DX									
  utf8.go:448			0x75ce40		4531e4			XORL R12, R12									
  utf8.go:448			0x75ce43		e9d8010000		JMP 0x75d020									
  members_string.go:4210	0x75ce48		488b942408010000	MOVQ 0x108(SP), DX								
  members_string.go:4210	0x75ce50		4883fa02		CMPQ DX, $0x2									
  members_string.go:4214	0x75ce54		0f85cd000000		JNE 0x75cf27									
  members_string.go:4215	0x75ce5a		488b942400010000	MOVQ 0x100(SP), DX								
  members_string.go:4215	0x75ce62		488b5a28		MOVQ 0x28(DX), BX								
  members_string.go:4215	0x75ce66		488b4a30		MOVQ 0x30(DX), CX								
  members_string.go:4215	0x75ce6a		488b7a38		MOVQ 0x38(DX), DI								
  members_string.go:4215	0x75ce6e		488b4220		MOVQ 0x20(DX), AX								
  members_string.go:4215	0x75ce72		e8896efdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)		
  members_string.go:4216	0x75ce77		4885db			TESTQ BX, BX									
  members_string.go:4216	0x75ce7a		7466			JE 0x75cee2									
  errors.go:26			0x75ce7c		488d0567200600		LEAQ 0x62067(IP), AX								
  errors.go:26			0x75ce83		bb24000000		MOVL $0x24, BX									
  errors.go:26			0x75ce88		31c9			XORL CX, CX									
  errors.go:26			0x75ce8a		31ff			XORL DI, DI									
  errors.go:26			0x75ce8c		89fe			MOVL DI, SI									
  errors.go:26			0x75ce8e		e82d10d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75ce93		4885c0			TESTQ AX, AX									
  errors.go:26			0x75ce96		7533			JNE 0x75cecb									
  errors.go:31			0x75ce98		90			NOPL										
  errors.go:65			0x75ce99		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75ce9e		488d1d7bd83800		LEAQ 0x38d87b(IP), BX								
  errors.go:65			0x75cea5		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75ceaa		e8f144ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75ceaf		48c7400824000000	MOVQ $0x24, 0x8(AX)								
  errors.go:65			0x75ceb7		488d152c200600		LEAQ 0x6202c(IP), DX								
  errors.go:65			0x75cebe		488910			MOVQ DX, 0(AX)									
  members_string.go:4217	0x75cec1		4889c3			MOVQ AX, BX									
  members_string.go:4217	0x75cec4		488d0505b63b00		LEAQ 0x3bb605(IP), AX								
  members_string.go:4217	0x75cecb		31c9			XORL CX, CX									
  members_string.go:4217	0x75cecd		31ff			XORL DI, DI									
  members_string.go:4217	0x75cecf		4889c6			MOVQ AX, SI									
  members_string.go:4217	0x75ced2		4989d8			MOVQ BX, R8									
  members_string.go:4217	0x75ced5		31c0			XORL AX, AX									
  members_string.go:4217	0x75ced7		31db			XORL BX, BX									
  members_string.go:4217	0x75ced9		4881c4a8000000		ADDQ $0xa8, SP									
  members_string.go:4217	0x75cee0		5d			POPQ BP										
  members_string.go:4217	0x75cee1		c3			RET										
  members_string.go:4215	0x75cee2		4889442470		MOVQ AX, 0x70(SP)								
  members_string.go:4219	0x75cee7		488b842488000000	MOVQ 0x88(SP), AX								
  members_string.go:4219	0x75ceef		488b5c2478		MOVQ 0x78(SP), BX								
  members_string.go:4219	0x75cef4		488b8c24a0000000	MOVQ 0xa0(SP), CX								
  members_string.go:4219	0x75cefc		488bbc2480000000	MOVQ 0x80(SP), DI								
  members_string.go:4219	0x75cf04		e817f4e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:1213	0x75cf09		488b542470		MOVQ 0x70(SP), DX								
  members_string.go:1213	0x75cf0e		4885d2			TESTQ DX, DX									
  members_string.go:1213	0x75cf11		7d06			JGE 0x75cf19									
  members_string.go:1178	0x75cf13		90			NOPL										
  members_string.go:1100	0x75cf14		4531e4			XORL R12, R12									
  members_string.go:1100	0x75cf17		eb75			JMP 0x75cf8e									
  members_string.go:1100	0x75cf19		b801000000		MOVL $0x1, AX									
  members_string.go:1100	0x75cf1e		6690			NOPW										
  members_string.go:4219	0x75cf20		84c0			TESTL AL, AL									
  members_string.go:4220	0x75cf22		7451			JE 0x75cf75									
  members_string.go:4225	0x75cf24		4889d3			MOVQ DX, BX									
  members_string.go:4225	0x75cf27		488b942400010000	MOVQ 0x100(SP), DX								
  members_string.go:4225	0x75cf2f		4c8b4a08		MOVQ 0x8(DX), R9								
  members_string.go:4225	0x75cf33		4c8b5210		MOVQ 0x10(DX), R10								
  members_string.go:4225	0x75cf37		4c8b5a18		MOVQ 0x18(DX), R11								
  members_string.go:4225	0x75cf3b		4c8b02			MOVQ 0(DX), R8									
  members_string.go:4225	0x75cf3e		48891c24		MOVQ BX, 0(SP)									
  members_string.go:4225	0x75cf42		488b8424d8000000	MOVQ 0xd8(SP), AX								
  members_string.go:4225	0x75cf4a		488b9c2488000000	MOVQ 0x88(SP), BX								
  members_string.go:4225	0x75cf52		488b4c2478		MOVQ 0x78(SP), CX								
  members_string.go:4225	0x75cf57		488bbc24a0000000	MOVQ 0xa0(SP), DI								
  members_string.go:4225	0x75cf5f		488bb42480000000	MOVQ 0x80(SP), SI								
  members_string.go:4225	0x75cf67		e8740bf8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringRIndexResult(SB)	
  members_string.go:4225	0x75cf6c		4881c4a8000000		ADDQ $0xa8, SP									
  members_string.go:4225	0x75cf73		5d			POPQ BP										
  members_string.go:4225	0x75cf74		c3			RET										
  members_string.go:4221	0x75cf75		31c0			XORL AX, AX									
  members_string.go:4221	0x75cf77		31db			XORL BX, BX									
  members_string.go:4221	0x75cf79		31c9			XORL CX, CX									
  members_string.go:4221	0x75cf7b		31ff			XORL DI, DI									
  members_string.go:4221	0x75cf7d		89de			MOVL BX, SI									
  members_string.go:4221	0x75cf7f		4189c8			MOVL CX, R8									
  members_string.go:4221	0x75cf82		4881c4a8000000		ADDQ $0xa8, SP									
  members_string.go:4221	0x75cf89		5d			POPQ BP										
  members_string.go:4221	0x75cf8a		c3			RET										
  members_string.go:1100	0x75cf8b		49ffc4			INCQ R12									
  members_string.go:1100	0x75cf8e		4c39e3			CMPQ BX, R12									
  members_string.go:1100	0x75cf91		7e21			JLE 0x75cfb4									
  members_string.go:1101	0x75cf93		450fb62c04		MOVZX 0(R12)(AX*1), R13								
  members_string.go:1101	0x75cf98		4180fd80		CMPL R13, $0x80									
  members_string.go:1101	0x75cf9c		72ed			JB 0x75cf8b									
  members_string.go:4219	0x75cf9e		4889842490000000	MOVQ AX, 0x90(SP)								
  members_string.go:4219	0x75cfa6		48895c2460		MOVQ BX, 0x60(SP)								
  members_string.go:1181	0x75cfab		90			NOPL										
  utf8.go:448			0x75cfac		4531e4			XORL R12, R12									
  utf8.go:448			0x75cfaf		4531ed			XORL R13, R13									
  utf8.go:448			0x75cfb2		eb1e			JMP 0x75cfd2									
  members_string.go:1216	0x75cfb4		4801da			ADDQ BX, DX									
  members_string.go:1217	0x75cfb7		4885d2			TESTQ DX, DX									
  members_string.go:1217	0x75cfba		7d09			JGE 0x75cfc5									
  members_string.go:1217	0x75cfbc		31c0			XORL AX, AX									
  members_string.go:1217	0x75cfbe		31d2			XORL DX, DX									
  members_string.go:4219	0x75cfc0		e95bffffff		JMP 0x75cf20									
  members_string.go:4219	0x75cfc5		b801000000		MOVL $0x1, AX									
  members_string.go:4219	0x75cfca		e951ffffff		JMP 0x75cf20									
  utf8.go:449			0x75cfcf		49ffc4			INCQ R12									
  utf8.go:448			0x75cfd2		4c39eb			CMPQ BX, R13									
  utf8.go:448			0x75cfd5		7e3d			JLE 0x75d014									
  utf8.go:448			0x75cfd7		450fb67c0500		MOVZX 0(R13)(AX*1), R15								
  utf8.go:448			0x75cfdd		0f1f00			NOPL 0(AX)									
  utf8.go:448			0x75cfe0		4183ff7f		CMPL R15, $0x7f									
  utf8.go:448			0x75cfe4		7f05			JG 0x75cfeb									
  utf8.go:448			0x75cfe6		49ffc5			INCQ R13									
  utf8.go:448			0x75cfe9		ebe4			JMP 0x75cfcf									
  utf8.go:448			0x75cfeb		4c89642450		MOVQ R12, 0x50(SP)								
  utf8.go:448			0x75cff0		4c89e9			MOVQ R13, CX									
  utf8.go:448			0x75cff3		e80802d2ff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x75cff8		488b842490000000	MOVQ 0x90(SP), AX								
  members_string.go:1216	0x75d000		488b542470		MOVQ 0x70(SP), DX								
  utf8.go:449			0x75d005		4c8b642450		MOVQ 0x50(SP), R12								
  utf8.go:449			0x75d00a		4989dd			MOVQ BX, R13									
  utf8.go:448			0x75d00d		488b5c2460		MOVQ 0x60(SP), BX								
  utf8.go:448			0x75d012		ebbb			JMP 0x75cfcf									
  members_string.go:1216	0x75d014		4c89e3			MOVQ R12, BX									
  members_string.go:1216	0x75d017		eb9b			JMP 0x75cfb4									
  utf8.go:449			0x75d019		48ffc2			INCQ DX										
  utf8.go:449			0x75d01c		0f1f4000		NOPL 0(AX)									
  utf8.go:448			0x75d020		4c39e3			CMPQ BX, R12									
  utf8.go:448			0x75d023		7e37			JLE 0x75d05c									
  utf8.go:448			0x75d025		460fb62c20		MOVZX 0(AX)(R12*1), R13								
  utf8.go:448			0x75d02a		4183fd7f		CMPL R13, $0x7f									
  utf8.go:448			0x75d02e		7f05			JG 0x75d035									
  utf8.go:448			0x75d030		49ffc4			INCQ R12									
  utf8.go:448			0x75d033		ebe4			JMP 0x75d019									
  utf8.go:448			0x75d035		4889542458		MOVQ DX, 0x58(SP)								
  utf8.go:448			0x75d03a		4c89e1			MOVQ R12, CX									
  utf8.go:448			0x75d03d		0f1f00			NOPL 0(AX)									
  utf8.go:448			0x75d040		e8bb01d2ff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x75d045		488b842498000000	MOVQ 0x98(SP), AX								
  utf8.go:449			0x75d04d		488b542458		MOVQ 0x58(SP), DX								
  utf8.go:449			0x75d052		4989dc			MOVQ BX, R12									
  utf8.go:448			0x75d055		488b5c2468		MOVQ 0x68(SP), BX								
  utf8.go:448			0x75d05a		ebbd			JMP 0x75d019									
  members_string.go:4210	0x75d05c		4c8ba42408010000	MOVQ 0x108(SP), R12								
  members_string.go:4210	0x75d064		4983fc02		CMPQ R12, $0x2									
  members_string.go:4213	0x75d068		4889d3			MOVQ DX, BX									
  members_string.go:4213	0x75d06b		e9e4fdffff		JMP 0x75ce54									
  members_string.go:4209	0x75d070		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4209	0x75d075		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4209	0x75d07a		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4209	0x75d07f		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4209	0x75d084		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4209	0x75d089		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4209	0x75d08e		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4209	0x75d093		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4209	0x75d098		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4209	0x75d09d		0f1f00			NOPL 0(AX)									
  members_string.go:4209	0x75d0a0		e89bf5d2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4209	0x75d0a5		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4209	0x75d0aa		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4209	0x75d0af		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4209	0x75d0b4		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4209	0x75d0b9		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4209	0x75d0be		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4209	0x75d0c3		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4209	0x75d0c8		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4209	0x75d0cd		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4209	0x75d0d2		e949fcffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func27(SB)	

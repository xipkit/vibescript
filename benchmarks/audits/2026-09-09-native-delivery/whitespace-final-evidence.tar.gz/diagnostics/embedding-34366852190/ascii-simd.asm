TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB) /home/runner/work/vibescript/vibescript/ascii/vibes/value/value_methods.go
  value_methods.go:605		0x5aed00		4c8da42488feffff	LEAQ 0xfffffe88(SP), R12									
  value_methods.go:605		0x5aed08		4d3b6610		CMPQ R12, 0x10(R14)										
  value_methods.go:605		0x5aed0c		0f86c9060000		JBE 0x5af3db											
  value_methods.go:605		0x5aed12		55			PUSHQ BP											
  value_methods.go:605		0x5aed13		4889e5			MOVQ SP, BP											
  value_methods.go:605		0x5aed16		4881ecf0010000		SUBQ $0x1f0, SP											
  value_methods.go:605		0x5aed1d		48899c2408020000	MOVQ BX, 0x208(SP)										
  value_methods.go:605		0x5aed25		48898c2410020000	MOVQ CX, 0x210(SP)										
  value_methods.go:607		0x5aed2d		4889b42420020000	MOVQ SI, 0x220(SP)										
  value_methods.go:605		0x5aed35		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  value_methods.go:605		0x5aed3e		6690			NOPW												
  value_methods.go:607		0x5aed40		4883f805		CMPQ AX, $0x5											
  value_methods.go:607		0x5aed44		0f8493020000		JE 0x5aefdd											
  value_methods.go:627		0x5aed4a		4883f806		CMPQ AX, $0x6											
  value_methods.go:627		0x5aed4e		0f84d5000000		JE 0x5aee29											
  value_methods.go:647		0x5aed54		4883f814		CMPQ AX, $0x14											
  value_methods.go:647		0x5aed58		0f8488000000		JE 0x5aede6											
  value_methods.go:652		0x5aed5e		488b151b555b00		MOVQ github.com/mgomes/vibescript/vibes/value.RuntimeStringRuneLen(SB), DX			
  value_methods.go:652		0x5aed65		4885d2			TESTQ DX, DX											
  value_methods.go:652		0x5aed68		7449			JE 0x5aedb3											
  value_methods.go:607		0x5aed6a		4889bc2418010000	MOVQ DI, 0x118(SP)										
  value_methods.go:607		0x5aed72		48898c24e8010000	MOVQ CX, 0x1e8(SP)										
  value_methods.go:607		0x5aed7a		48899c2410010000	MOVQ BX, 0x110(SP)										
  value_methods.go:607		0x5aed82		4889842408010000	MOVQ AX, 0x108(SP)										
  value_methods.go:653		0x5aed8a		488b32			MOVQ 0(DX), SI											
  value_methods.go:653		0x5aed8d		ffd6			CALL SI												
  value_methods.go:653		0x5aed8f		84db			TESTL BL, BL											
  value_methods.go:653		0x5aed91		753b			JNE 0x5aedce											
  value_methods.go:657		0x5aed93		488b842408010000	MOVQ 0x108(SP), AX										
  value_methods.go:657		0x5aed9b		488b8c24e8010000	MOVQ 0x1e8(SP), CX										
  value_methods.go:657		0x5aeda3		488b9c2410010000	MOVQ 0x110(SP), BX										
  value_methods.go:657		0x5aedab		488bbc2418010000	MOVQ 0x118(SP), DI										
  value_methods.go:657		0x5aedb3		e868d5ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  value_methods.go:657		0x5aedb8		4889842428010000	MOVQ AX, 0x128(SP)										
  value_methods.go:657		0x5aedc0		48895c2458		MOVQ BX, 0x58(SP)										
  utf8.go:448			0x5aedc5		31d2			XORL DX, DX											
  utf8.go:448			0x5aedc7		31f6			XORL SI, SI											
  utf8.go:448			0x5aedc9		e9bd050000		JMP 0x5af38b											
  value_methods.go:654		0x5aedce		4889442440		MOVQ AX, 0x40(SP)										
  value_methods.go:659		0x5aedd3		e848d0e9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:654		0x5aedd8		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aeddd		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aede4		5d			POPQ BP												
  value_methods.go:659		0x5aede5		c3			RET												
  value_methods.go:650		0x5aede6		488d15fbc05500		LEAQ 0x55c0fb(IP), DX										
  value_methods.go:650		0x5aeded		4839d3			CMPQ BX, DX											
  value_methods.go:650		0x5aedf0		0f857b050000		JNE 0x5af371											
  value_methods.go:650		0x5aedf6		488b01			MOVQ 0(CX), AX											
  value_methods.go:650		0x5aedf9		488b5908		MOVQ 0x8(CX), BX										
  value_methods.go:650		0x5aedfd		488b5110		MOVQ 0x10(CX), DX										
  value_methods.go:650		0x5aee01		488b7918		MOVQ 0x18(CX), DI										
  value_methods.go:650		0x5aee05		488b7120		MOVQ 0x20(CX), SI										
  value_methods.go:650		0x5aee09		4889d1			MOVQ DX, CX											
  value_methods.go:650		0x5aee0c		e86f69ffff		CALL github.com/mgomes/vibescript/vibes/value.Regex.StringRuneLen(SB)				
  value_methods.go:650		0x5aee11		4889442440		MOVQ AX, 0x40(SP)										
  value_methods.go:659		0x5aee16		e805d0e9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:650		0x5aee1b		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aee20		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aee27		5d			POPQ BP												
  value_methods.go:659		0x5aee28		c3			RET												
  value_methods.go:628		0x5aee29		90			NOPL												
  value_accessors.go:113	0x5aee2a		488d155f0b5100		LEAQ 0x510b5f(IP), DX										
  value_accessors.go:113	0x5aee31		4839d3			CMPQ BX, DX											
  value_accessors.go:113	0x5aee34		0f8525050000		JNE 0x5af35f											
  value_accessors.go:113	0x5aee3a		488b19			MOVQ 0(CX), BX											
  value_accessors.go:113	0x5aee3d		0f1f00			NOPL 0(AX)											
  value_methods.go:629		0x5aee40		4885db			TESTQ BX, BX											
  value_methods.go:629		0x5aee43		7405			JE 0x5aee4a											
  value_methods.go:629		0x5aee45		488b13			MOVQ 0(BX), DX											
  value_methods.go:629		0x5aee48		eb02			JMP 0x5aee4c											
  value_methods.go:629		0x5aee4a		31d2			XORL DX, DX											
  value_methods.go:629		0x5aee4c		4885d2			TESTQ DX, DX											
  value_methods.go:629		0x5aee4f		0f846c010000		JE 0x5aefc1											
  value_accessors.go:113	0x5aee55		48899c24e0010000	MOVQ BX, 0x1e0(SP)										
  type.go:208			0x5aee5d		0fb615d0bf5100		MOVZX 0x51bfd0(IP), DX										
  value.go:165			0x5aee64		90			NOPL												
  type.go:208			0x5aee65		f6c220			TESTL $0x20, DL											
  value.go:3164			0x5aee68		b995000000		MOVL $0x95, CX											
  value.go:3164			0x5aee6d		ba15000000		MOVL $0x15, DX											
  value.go:3164			0x5aee72		480f45ca		CMOVNE DX, CX											
  value_methods.go:632		0x5aee76		488d05a3bf5100		LEAQ 0x51bfa3(IP), AX										
  value_methods.go:632		0x5aee7d		0f1f00			NOPL 0(AX)											
  value_methods.go:632		0x5aee80		e8fb7ff1ff		CALL reflect.Value.Pointer(SB)									
  value_methods.go:633		0x5aee85		4885c0			TESTQ AX, AX											
  value_methods.go:633		0x5aee88		7510			JNE 0x5aee9a											
  value_methods.go:629		0x5aee8a		488b9c24e0010000	MOVQ 0x1e0(SP), BX										
  value_methods.go:629		0x5aee92		4885db			TESTQ BX, BX											
  value_methods.go:633		0x5aee95		e9a9000000		JMP 0x5aef43											
  value_methods.go:632		0x5aee9a		4889442460		MOVQ AX, 0x60(SP)										
  value_methods.go:634		0x5aee9f		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:634		0x5aeea7		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:634		0x5aeeab		4889c1			MOVQ AX, CX											
  value_methods.go:634		0x5aeeae		488d05abc35100		LEAQ 0x51c3ab(IP), AX										
  value_methods.go:634		0x5aeeb5		e806fce5ff		CALL runtime.mapaccess2_fast64(SB)								
  value_methods.go:634		0x5aeeba		660f1f440000		NOPW 0(AX)(AX*1)										
  value_methods.go:634		0x5aeec0		84db			TESTL BL, BL											
  value_methods.go:634		0x5aeec2		0f85dd000000		JNE 0x5aefa5											
  value_methods.go:637		0x5aeec8		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:637		0x5aeed0		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:637		0x5aeed4		488d0585c35100		LEAQ 0x51c385(IP), AX										
  value_methods.go:637		0x5aeedb		488b4c2460		MOVQ 0x60(SP), CX										
  value_methods.go:637		0x5aeee0		e85bfee5ff		CALL runtime.mapassign_fast64(SB)								
  value_methods.go:637		0x5aeee5		8400			TESTB AL, 0(AX)											
  value_methods.go:638		0x5aeee7		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:638		0x5aeeef		488b5208		MOVQ 0x8(DX), DX										
  value_methods.go:638		0x5aeef3		488d35065c0000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB), SI	
  value_methods.go:638		0x5aeefa		4889b42438010000	MOVQ SI, 0x138(SP)										
  value_methods.go:638		0x5aef02		4889942440010000	MOVQ DX, 0x140(SP)										
  value_methods.go:638		0x5aef0a		488b542460		MOVQ 0x60(SP), DX										
  value_methods.go:638		0x5aef0f		4889942448010000	MOVQ DX, 0x148(SP)										
  value_methods.go:638		0x5aef17		488d942438010000	LEAQ 0x138(SP), DX										
  value_methods.go:638		0x5aef1f		48899424a0000000	MOVQ DX, 0xa0(SP)										
  value_methods.go:638		0x5aef27		488d842488000000	LEAQ 0x88(SP), AX										
  value_methods.go:638		0x5aef2f		e8ccc9e9ff		CALL runtime.deferprocStack(SB)									
  value_methods.go:629		0x5aef34		488b9c24e0010000	MOVQ 0x1e0(SP), BX										
  value_methods.go:629		0x5aef3c		0f1f4000		NOPL 0(AX)											
  value_methods.go:629		0x5aef40		4885db			TESTQ BX, BX											
  value_methods.go:641		0x5aef43		7405			JE 0x5aef4a											
  value_methods.go:641		0x5aef45		488b13			MOVQ 0(BX), DX											
  value_methods.go:641		0x5aef48		eb02			JMP 0x5aef4c											
  value_methods.go:641		0x5aef4a		31d2			XORL DX, DX											
  value_methods.go:1031		0x5aef4c		4883fa02		CMPQ DX, $0x2											
  value_methods.go:1031		0x5aef50		7d04			JGE 0x5aef56											
  value_methods.go:1031		0x5aef52		31d2			XORL DX, DX											
  value_methods.go:641		0x5aef54		eb08			JMP 0x5aef5e											
  value_methods.go:1034		0x5aef56		488d1412		LEAQ 0(DX)(DX*1), DX										
  value_methods.go:1034		0x5aef5a		488d52fe		LEAQ -0x2(DX), DX										
  value_methods.go:641		0x5aef5e		4889542438		MOVQ DX, 0x38(SP)										
  value_methods.go:642		0x5aef63		488d8c2478010000	LEAQ 0x178(SP), CX										
  value_methods.go:642		0x5aef6b		440f1139		MOVUPS X15, 0(CX)										
  value_methods.go:642		0x5aef6f		440f117910		MOVUPS X15, 0x10(CX)										
  value_methods.go:642		0x5aef74		440f117920		MOVUPS X15, 0x20(CX)										
  value_methods.go:642		0x5aef79		440f117930		MOVUPS X15, 0x30(CX)										
  value_methods.go:642		0x5aef7e		440f117940		MOVUPS X15, 0x40(CX)										
  value_methods.go:642		0x5aef83		440f117950		MOVUPS X15, 0x50(CX)										
  value_methods.go:642		0x5aef88		488d0591be5100		LEAQ 0x51be91(IP), AX										
  value_methods.go:642		0x5aef8f		e86c59e7ff		CALL runtime.mapIterStart(SB)									
  value_methods.go:641		0x5aef94		488b542438		MOVQ 0x38(SP), DX										
  value_methods.go:641		0x5aef99		4883c202		ADDQ $0x2, DX											
  value_methods.go:641		0x5aef9d		0f1f00			NOPL 0(AX)											
  value_methods.go:642		0x5aefa0		e9d4020000		JMP 0x5af279											
  value_methods.go:635		0x5aefa5		48c744244007000000	MOVQ $0x7, 0x40(SP)										
  value_methods.go:659		0x5aefae		e86dcee9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:635		0x5aefb3		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aefb8		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aefbf		5d			POPQ BP												
  value_methods.go:659		0x5aefc0		c3			RET												
  value_methods.go:630		0x5aefc1		48c744244002000000	MOVQ $0x2, 0x40(SP)										
  value_methods.go:659		0x5aefca		e851cee9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:630		0x5aefcf		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aefd4		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aefdb		5d			POPQ BP												
  value_methods.go:659		0x5aefdc		c3			RET												
  value_methods.go:608		0x5aefdd		90			NOPL												
  value_accessors.go:86		0x5aefde		488d1503095100		LEAQ 0x510903(IP), DX										
  value_accessors.go:86		0x5aefe5		4839d3			CMPQ BX, DX											
  value_accessors.go:86		0x5aefe8		0f8534020000		JNE 0x5af222											
  value_accessors.go:86		0x5aefee		488b5908		MOVQ 0x8(CX), BX										
  value_accessors.go:86		0x5aeff2		48895c2428		MOVQ BX, 0x28(SP)										
  value_accessors.go:86		0x5aeff7		488b5110		MOVQ 0x10(CX), DX										
  value_accessors.go:86		0x5aeffb		4889542430		MOVQ DX, 0x30(SP)										
  value_accessors.go:86		0x5af000		488b01			MOVQ 0(CX), AX											
  value_accessors.go:86		0x5af003		4889842420010000	MOVQ AX, 0x120(SP)										
  value_methods.go:610		0x5af00b		4889d1			MOVQ DX, CX											
  value_methods.go:610		0x5af00e		e84d6bedff		CALL runtime.convTslice(SB)									
  type.go:208			0x5af013		0fb615b2605100		MOVZX 0x5160b2(IP), DX										
  value.go:165			0x5af01a		90			NOPL												
  type.go:208			0x5af01b		f6c220			TESTL $0x20, DL											
  value.go:3164			0x5af01e		b997000000		MOVL $0x97, CX											
  value.go:3164			0x5af023		ba17000000		MOVL $0x17, DX											
  value.go:3164			0x5af028		480f45ca		CMOVNE DX, CX											
  value_methods.go:610		0x5af02c		4889c3			MOVQ AX, BX											
  value_methods.go:610		0x5af02f		488d0582605100		LEAQ 0x516082(IP), AX										
  value_methods.go:610		0x5af036		e8457ef1ff		CALL reflect.Value.Pointer(SB)									
  value_methods.go:610		0x5af03b		0f1f440000		NOPL 0(AX)(AX*1)										
  value_methods.go:614		0x5af040		4885c0			TESTQ AX, AX											
  value_methods.go:614		0x5af043		0f8407010000		JE 0x5af150											
  value_methods.go:610		0x5af049		4889842480000000	MOVQ AX, 0x80(SP)										
  value_methods.go:615		0x5af051		48898424e8000000	MOVQ AX, 0xe8(SP)										
  value_methods.go:615		0x5af059		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:615		0x5af05e		48899424f0000000	MOVQ DX, 0xf0(SP)										
  value_methods.go:615		0x5af066		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:615		0x5af06b		48899424f8000000	MOVQ DX, 0xf8(SP)										
  value_methods.go:615		0x5af073		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:615		0x5af07b		488b1a			MOVQ 0(DX), BX											
  value_methods.go:615		0x5af07e		488d05fbc35100		LEAQ 0x51c3fb(IP), AX										
  value_methods.go:615		0x5af085		488d8c24e8000000	LEAQ 0xe8(SP), CX										
  value_methods.go:615		0x5af08d		e88eeae5ff		CALL runtime.mapaccess2(SB)									
  value_methods.go:615		0x5af092		84db			TESTL BL, BL											
  value_methods.go:615		0x5af094		0f85f9000000		JNE 0x5af193											
  value_methods.go:618		0x5af09a		488b942480000000	MOVQ 0x80(SP), DX										
  value_methods.go:618		0x5af0a2		48899424e8000000	MOVQ DX, 0xe8(SP)										
  value_methods.go:618		0x5af0aa		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:618		0x5af0af		48899424f0000000	MOVQ DX, 0xf0(SP)										
  value_methods.go:618		0x5af0b7		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:618		0x5af0bc		48899424f8000000	MOVQ DX, 0xf8(SP)										
  value_methods.go:618		0x5af0c4		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:618		0x5af0cc		488b1a			MOVQ 0(DX), BX											
  value_methods.go:618		0x5af0cf		488d05aac35100		LEAQ 0x51c3aa(IP), AX										
  value_methods.go:618		0x5af0d6		488d8c24e8000000	LEAQ 0xe8(SP), CX										
  value_methods.go:618		0x5af0de		6690			NOPW												
  value_methods.go:618		0x5af0e0		e81bede5ff		CALL runtime.mapassign(SB)									
  value_methods.go:618		0x5af0e5		8400			TESTB AL, 0(AX)											
  value_methods.go:619		0x5af0e7		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:619		0x5af0ef		488b12			MOVQ 0(DX), DX											
  value_methods.go:619		0x5af0f2		488d35475a0000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB), SI	
  value_methods.go:619		0x5af0f9		4889b42450010000	MOVQ SI, 0x150(SP)										
  value_methods.go:619		0x5af101		4889942458010000	MOVQ DX, 0x158(SP)										
  value_methods.go:619		0x5af109		488b942480000000	MOVQ 0x80(SP), DX										
  value_methods.go:619		0x5af111		4889942460010000	MOVQ DX, 0x160(SP)										
  value_methods.go:619		0x5af119		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:619		0x5af11e		4889942468010000	MOVQ DX, 0x168(SP)										
  value_methods.go:619		0x5af126		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:619		0x5af12b		4889942470010000	MOVQ DX, 0x170(SP)										
  value_methods.go:619		0x5af133		488d942450010000	LEAQ 0x150(SP), DX										
  value_methods.go:619		0x5af13b		48899424d0000000	MOVQ DX, 0xd0(SP)										
  value_methods.go:619		0x5af143		488d8424b8000000	LEAQ 0xb8(SP), AX										
  value_methods.go:619		0x5af14b		e8b0c7e9ff		CALL runtime.deferprocStack(SB)									
  value_methods.go:1031		0x5af150		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:1031		0x5af155		4883fa02		CMPQ DX, $0x2											
  value_methods.go:1031		0x5af159		7d07			JGE 0x5af162											
  value_methods.go:1031		0x5af15b		4531c0			XORL R8, R8											
  value_methods.go:1031		0x5af15e		6690			NOPW												
  value_methods.go:622		0x5af160		eb08			JMP 0x5af16a											
  value_methods.go:1034		0x5af162		4c8d0412		LEAQ 0(DX)(DX*1), R8										
  value_methods.go:1034		0x5af166		4d8d40fe		LEAQ -0x2(R8), R8										
  value_methods.go:622		0x5af16a		4983c002		ADDQ $0x2, R8											
  value_methods.go:623		0x5af16e		4c8b8c2420010000	MOVQ 0x120(SP), R9										
  value_methods.go:623		0x5af176		e98a000000		JMP 0x5af205											
  value_methods.go:659		0x5af17b		0f1f440000		NOPL 0(AX)(AX*1)										
  value_methods.go:659		0x5af180		e89bcce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:619		0x5af185		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af18a		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af191		5d			POPQ BP												
  value_methods.go:659		0x5af192		c3			RET												
  value_methods.go:616		0x5af193		48c744244007000000	MOVQ $0x7, 0x40(SP)										
  value_methods.go:616		0x5af19c		0f1f4000		NOPL 0(AX)											
  value_methods.go:659		0x5af1a0		e87bcce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:616		0x5af1a5		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af1aa		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af1b1		5d			POPQ BP												
  value_methods.go:659		0x5af1b2		c3			RET												
  value_methods.go:623		0x5af1b3		4889942400010000	MOVQ DX, 0x100(SP)										
  value_methods.go:623		0x5af1bb		4c89442450		MOVQ R8, 0x50(SP)										
  value_methods.go:623		0x5af1c0		4c898c24d8010000	MOVQ R9, 0x1d8(SP)										
  value_methods.go:623		0x5af1c8		498b01			MOVQ 0(R9), AX											
  value_methods.go:623		0x5af1cb		498b4910		MOVQ 0x10(R9), CX										
  value_methods.go:623		0x5af1cf		498b7918		MOVQ 0x18(R9), DI										
  value_methods.go:623		0x5af1d3		498b5908		MOVQ 0x8(R9), BX										
  value_methods.go:624		0x5af1d7		488bb42420020000	MOVQ 0x220(SP), SI										
  value_methods.go:624		0x5af1df		90			NOPL												
  value_methods.go:624		0x5af1e0		e81bfbffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			
  value_methods.go:623		0x5af1e5		4c8b8c24d8010000	MOVQ 0x1d8(SP), R9										
  value_methods.go:623		0x5af1ed		4983c120		ADDQ $0x20, R9											
  value_methods.go:624		0x5af1f1		488b542450		MOVQ 0x50(SP), DX										
  value_methods.go:624		0x5af1f6		4c8d0402		LEAQ 0(DX)(AX*1), R8										
  value_methods.go:623		0x5af1fa		488b942400010000	MOVQ 0x100(SP), DX										
  value_methods.go:623		0x5af202		48ffca			DECQ DX												
  value_methods.go:623		0x5af205		4885d2			TESTQ DX, DX											
  value_methods.go:623		0x5af208		7fa9			JG 0x5af1b3											
  value_methods.go:626		0x5af20a		4c89442440		MOVQ R8, 0x40(SP)										
  value_methods.go:659		0x5af20f		e80ccce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:626		0x5af214		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af219		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af220		5d			POPQ BP												
  value_methods.go:659		0x5af221		c3			RET												
  value_accessors.go:86		0x5af222		4889d8			MOVQ BX, AX											
  value_accessors.go:86		0x5af225		4889d3			MOVQ DX, BX											
  value_accessors.go:86		0x5af228		488d0d71b85300		LEAQ 0x53b871(IP), CX										
  value_accessors.go:86		0x5af22f		e80cdce6ff		CALL runtime.panicdottypeE(SB)									
  value_methods.go:644		0x5af234		4c89c0			MOVQ R8, AX											
  value_methods.go:644		0x5af237		4c89d3			MOVQ R10, BX											
  value_methods.go:644		0x5af23a		488bb42420020000	MOVQ 0x220(SP), SI										
  value_methods.go:644		0x5af242		e8b9faffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			
  value_methods.go:644		0x5af247		4889842400010000	MOVQ AX, 0x100(SP)										
  value_methods.go:642		0x5af24f		488d842478010000	LEAQ 0x178(SP), AX										
  value_methods.go:642		0x5af257		e80457e7ff		CALL runtime.mapIterNext(SB)									
  value_methods.go:643		0x5af25c		488b542470		MOVQ 0x70(SP), DX										
  value_methods.go:643		0x5af261		4c8b442448		MOVQ 0x48(SP), R8										
  value_methods.go:643		0x5af266		4c01c2			ADDQ R8, DX											
  value_methods.go:644		0x5af269		4c8b842400010000	MOVQ 0x100(SP), R8										
  value_methods.go:644		0x5af271		4a8d1402		LEAQ 0(DX)(R8*1), DX										
  value_methods.go:644		0x5af275		488d5202		LEAQ 0x2(DX), DX										
  value_methods.go:642		0x5af279		4c8b842478010000	MOVQ 0x178(SP), R8										
  value_methods.go:642		0x5af281		4d85c0			TESTQ R8, R8											
  value_methods.go:642		0x5af284		0f84bd000000		JE 0x5af347											
  value_methods.go:642		0x5af28a		4889542448		MOVQ DX, 0x48(SP)										
  value_methods.go:642		0x5af28f		4c8b8c2480010000	MOVQ 0x180(SP), R9										
  value_methods.go:642		0x5af297		498b00			MOVQ 0(R8), AX											
  value_methods.go:642		0x5af29a		4889842430010000	MOVQ AX, 0x130(SP)										
  value_methods.go:642		0x5af2a2		498b5808		MOVQ 0x8(R8), BX										
  value_methods.go:642		0x5af2a6		48895c2478		MOVQ BX, 0x78(SP)										
  value_methods.go:642		0x5af2ab		4d8b01			MOVQ 0(R9), R8											
  value_methods.go:642		0x5af2ae		4c89842408010000	MOVQ R8, 0x108(SP)										
  value_methods.go:642		0x5af2b6		4d8b5108		MOVQ 0x8(R9), R10										
  value_methods.go:642		0x5af2ba		4c89942410010000	MOVQ R10, 0x110(SP)										
  value_methods.go:642		0x5af2c2		498b4910		MOVQ 0x10(R9), CX										
  value_methods.go:642		0x5af2c6		48898c24e8010000	MOVQ CX, 0x1e8(SP)										
  value_methods.go:642		0x5af2ce		498b7918		MOVQ 0x18(R9), DI										
  value_methods.go:642		0x5af2d2		4889bc2418010000	MOVQ DI, 0x118(SP)										
  utf8.go:448			0x5af2da		4531c9			XORL R9, R9											
  utf8.go:448			0x5af2dd		4531db			XORL R11, R11											
  utf8.go:448			0x5af2e0		eb03			JMP 0x5af2e5											
  utf8.go:449			0x5af2e2		49ffc1			INCQ R9												
  utf8.go:448			0x5af2e5		4c894c2470		MOVQ R9, 0x70(SP)										
  utf8.go:448			0x5af2ea		4939db			CMPQ R11, BX											
  utf8.go:448			0x5af2ed		0f8d41ffffff		JGE 0x5af234											
  utf8.go:448			0x5af2f3		450fb62403		MOVZX 0(R11)(AX*1), R12										
  utf8.go:448			0x5af2f8		4183fc7f		CMPL R12, $0x7f											
  utf8.go:448			0x5af2fc		7f05			JG 0x5af303											
  utf8.go:448			0x5af2fe		49ffc3			INCQ R11											
  utf8.go:448			0x5af301		ebdf			JMP 0x5af2e2											
  utf8.go:448			0x5af303		4c89d9			MOVQ R11, CX											
  utf8.go:448			0x5af306		e8f5deecff		CALL runtime.decoderune(SB)									
  utf8.go:448			0x5af30b		488b842430010000	MOVQ 0x130(SP), AX										
  value_methods.go:644		0x5af313		488b8c24e8010000	MOVQ 0x1e8(SP), CX										
  value_methods.go:643		0x5af31b		488b542448		MOVQ 0x48(SP), DX										
  value_methods.go:644		0x5af320		488bbc2418010000	MOVQ 0x118(SP), DI										
  value_methods.go:644		0x5af328		4c8b842408010000	MOVQ 0x108(SP), R8										
  utf8.go:449			0x5af330		4c8b4c2470		MOVQ 0x70(SP), R9										
  value_methods.go:644		0x5af335		4c8b942410010000	MOVQ 0x110(SP), R10										
  utf8.go:449			0x5af33d		4989db			MOVQ BX, R11											
  utf8.go:448			0x5af340		488b5c2478		MOVQ 0x78(SP), BX										
  utf8.go:448			0x5af345		eb9b			JMP 0x5af2e2											
  value_methods.go:646		0x5af347		4889542440		MOVQ DX, 0x40(SP)										
  value_methods.go:659		0x5af34c		e8cfcae9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:646		0x5af351		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af356		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af35d		5d			POPQ BP												
  value_methods.go:659		0x5af35e		c3			RET												
  value_accessors.go:113	0x5af35f		4889d8			MOVQ BX, AX											
  value_accessors.go:113	0x5af362		4889d3			MOVQ DX, BX											
  value_accessors.go:113	0x5af365		488d0d34b75300		LEAQ 0x53b734(IP), CX										
  value_accessors.go:113	0x5af36c		e8cfdae6ff		CALL runtime.panicdottypeE(SB)									
  value_methods.go:650		0x5af371		4889d8			MOVQ BX, AX											
  value_methods.go:650		0x5af374		4889d3			MOVQ DX, BX											
  value_methods.go:650		0x5af377		488d0d22b75300		LEAQ 0x53b722(IP), CX										
  value_methods.go:650		0x5af37e		6690			NOPW												
  value_methods.go:650		0x5af380		e8bbdae6ff		CALL runtime.panicdottypeE(SB)									
  utf8.go:449			0x5af385		48ffc6			INCQ SI												
  utf8.go:448			0x5af388		4889ca			MOVQ CX, DX											
  utf8.go:448			0x5af38b		4839d3			CMPQ BX, DX											
  utf8.go:448			0x5af38e		7e33			JLE 0x5af3c3											
  utf8.go:448			0x5af390		0fb63c10		MOVZX 0(AX)(DX*1), DI										
  utf8.go:448			0x5af394		83ff7f			CMPL DI, $0x7f											
  utf8.go:448			0x5af397		7f06			JG 0x5af39f											
  utf8.go:448			0x5af399		488d4a01		LEAQ 0x1(DX), CX										
  utf8.go:448			0x5af39d		ebe6			JMP 0x5af385											
  utf8.go:448			0x5af39f		4889742468		MOVQ SI, 0x68(SP)										
  utf8.go:448			0x5af3a4		4889d1			MOVQ DX, CX											
  utf8.go:448			0x5af3a7		e854deecff		CALL runtime.decoderune(SB)									
  utf8.go:448			0x5af3ac		488b842428010000	MOVQ 0x128(SP), AX										
  utf8.go:449			0x5af3b4		488b742468		MOVQ 0x68(SP), SI										
  utf8.go:449			0x5af3b9		4889d9			MOVQ BX, CX											
  utf8.go:448			0x5af3bc		488b5c2458		MOVQ 0x58(SP), BX										
  utf8.go:448			0x5af3c1		ebc2			JMP 0x5af385											
  value_methods.go:657		0x5af3c3		4889742440		MOVQ SI, 0x40(SP)										
  value_methods.go:659		0x5af3c8		e853cae9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:657		0x5af3cd		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af3d2		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af3d9		5d			POPQ BP												
  value_methods.go:659		0x5af3da		c3			RET												
  value_methods.go:605		0x5af3db		4889442408		MOVQ AX, 0x8(SP)										
  value_methods.go:605		0x5af3e0		48895c2410		MOVQ BX, 0x10(SP)										
  value_methods.go:605		0x5af3e5		48894c2418		MOVQ CX, 0x18(SP)										
  value_methods.go:605		0x5af3ea		48897c2420		MOVQ DI, 0x20(SP)										
  value_methods.go:605		0x5af3ef		4889742428		MOVQ SI, 0x28(SP)										
  value_methods.go:605		0x5af3f4		e847d2edff		CALL runtime.morestack_noctxt.abi0(SB)								
  value_methods.go:605		0x5af3f9		488b442408		MOVQ 0x8(SP), AX										
  value_methods.go:605		0x5af3fe		488b5c2410		MOVQ 0x10(SP), BX										
  value_methods.go:605		0x5af403		488b4c2418		MOVQ 0x18(SP), CX										
  value_methods.go:605		0x5af408		488b7c2420		MOVQ 0x20(SP), DI										
  value_methods.go:605		0x5af40d		488b742428		MOVQ 0x28(SP), SI										
  value_methods.go:605		0x5af412		e9e9f8ffff		JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB) /home/runner/work/vibescript/vibescript/ascii/vibes/value/value_methods.go
  value_methods.go:844		0x5b0780		4c8da42468feffff	LEAQ 0xfffffe68(SP), R12										
  value_methods.go:844		0x5b0788		4d3b6610		CMPQ R12, 0x10(R14)											
  value_methods.go:844		0x5b078c		0f86210a0000		JBE 0x5b11b3												
  value_methods.go:844		0x5b0792		55			PUSHQ BP												
  value_methods.go:844		0x5b0793		4889e5			MOVQ SP, BP												
  value_methods.go:844		0x5b0796		4881ec10020000		SUBQ $0x210, SP												
  value_methods.go:844		0x5b079d		48899c2428020000	MOVQ BX, 0x228(SP)											
  value_methods.go:844		0x5b07a5		48898c2430020000	MOVQ CX, 0x230(SP)											
  value_methods.go:845		0x5b07ad		4889b42440020000	MOVQ SI, 0x240(SP)											
  value_methods.go:845		0x5b07b5		4c89842448020000	MOVQ R8, 0x248(SP)											
  value_methods.go:845		0x5b07bd		48898c24f0010000	MOVQ CX, 0x1f0(SP)											
  value_methods.go:845		0x5b07c5		48899c24c8000000	MOVQ BX, 0xc8(SP)											
  value_methods.go:845		0x5b07cd		48898424c0000000	MOVQ AX, 0xc0(SP)											
  value_methods.go:845		0x5b07d5		4889bc24b8000000	MOVQ DI, 0xb8(SP)											
  value_methods.go:844		0x5b07dd		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:844		0x5b07e6		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:845		0x5b07ef		498b00			MOVQ 0(R8), AX												
  value_methods.go:845		0x5b07f2		4c89c2			MOVQ R8, DX												
  value_methods.go:845		0x5b07f5		ffd0			CALL AX													
  value_methods.go:845		0x5b07f7		660f1f840000000000	NOPW 0(AX)(AX*1)											
  value_methods.go:845		0x5b0800		4885c0			TESTQ AX, AX												
  value_methods.go:845		0x5b0803		0f854d050000		JNE 0x5b0d56												
  value_methods.go:849		0x5b0809		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:849		0x5b0811		4883f805		CMPQ AX, $0x5												
  value_methods.go:849		0x5b0815		0f85e5010000		JNE 0x5b0a00												
  value_methods.go:850		0x5b081b		90			NOPL													
  value_accessors.go:86		0x5b081c		488b8424c8000000	MOVQ 0xc8(SP), AX											
  value_accessors.go:86		0x5b0824		488d1dbdf05000		LEAQ 0x50f0bd(IP), BX											
  value_accessors.go:86		0x5b082b		4839d8			CMPQ AX, BX												
  value_accessors.go:86		0x5b082e		0f8572090000		JNE 0x5b11a6												
  value_accessors.go:86		0x5b0834		488b9424f0010000	MOVQ 0x1f0(SP), DX											
  value_accessors.go:86		0x5b083c		488b5a08		MOVQ 0x8(DX), BX											
  value_accessors.go:86		0x5b0840		48895c2430		MOVQ BX, 0x30(SP)											
  value_accessors.go:86		0x5b0845		488b4a10		MOVQ 0x10(DX), CX											
  value_accessors.go:86		0x5b0849		48894c2438		MOVQ CX, 0x38(SP)											
  value_accessors.go:86		0x5b084e		488b02			MOVQ 0(DX), AX												
  value_accessors.go:86		0x5b0851		4889842440010000	MOVQ AX, 0x140(SP)											
  value_methods.go:852		0x5b0859		e80253edff		CALL runtime.convTslice(SB)										
  type.go:208			0x5b085e		0fb61567485100		MOVZX 0x514867(IP), DX											
  value.go:165			0x5b0865		90			NOPL													
  type.go:208			0x5b0866		f6c220			TESTL $0x20, DL												
  value.go:3164			0x5b0869		b997000000		MOVL $0x97, CX												
  value.go:3164			0x5b086e		ba17000000		MOVL $0x17, DX												
  value.go:3164			0x5b0873		480f45ca		CMOVNE DX, CX												
  value_methods.go:852		0x5b0877		4889c3			MOVQ AX, BX												
  value_methods.go:852		0x5b087a		488d0537485100		LEAQ 0x514837(IP), AX											
  value_methods.go:852		0x5b0881		e8fa65f1ff		CALL reflect.Value.Pointer(SB)										
  value_methods.go:856		0x5b0886		4885c0			TESTQ AX, AX												
  value_methods.go:856		0x5b0889		0f840d010000		JE 0x5b099c												
  value_methods.go:852		0x5b088f		4889842490000000	MOVQ AX, 0x90(SP)											
  value_methods.go:857		0x5b0897		4889842498000000	MOVQ AX, 0x98(SP)											
  value_methods.go:857		0x5b089f		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:857		0x5b08a4		48899424a0000000	MOVQ DX, 0xa0(SP)											
  value_methods.go:857		0x5b08ac		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:857		0x5b08b1		48899424a8000000	MOVQ DX, 0xa8(SP)											
  value_methods.go:857		0x5b08b9		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:857		0x5b08c1		488b1a			MOVQ 0(DX), BX												
  value_methods.go:857		0x5b08c4		488d05b5ab5100		LEAQ 0x51abb5(IP), AX											
  value_methods.go:857		0x5b08cb		488d8c2498000000	LEAQ 0x98(SP), CX											
  value_methods.go:857		0x5b08d3		e848d2e5ff		CALL runtime.mapaccess2(SB)										
  value_methods.go:857		0x5b08d8		0f1f840000000000	NOPL 0(AX)(AX*1)											
  value_methods.go:857		0x5b08e0		84db			TESTL BL, BL												
  value_methods.go:857		0x5b08e2		0f85dd000000		JNE 0x5b09c5												
  value_methods.go:860		0x5b08e8		488b942490000000	MOVQ 0x90(SP), DX											
  value_methods.go:860		0x5b08f0		4889942498000000	MOVQ DX, 0x98(SP)											
  value_methods.go:860		0x5b08f8		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:860		0x5b08fd		48899424a0000000	MOVQ DX, 0xa0(SP)											
  value_methods.go:860		0x5b0905		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:860		0x5b090a		48899424a8000000	MOVQ DX, 0xa8(SP)											
  value_methods.go:860		0x5b0912		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:860		0x5b091a		488b1a			MOVQ 0(DX), BX												
  value_methods.go:860		0x5b091d		488d055cab5100		LEAQ 0x51ab5c(IP), AX											
  value_methods.go:860		0x5b0924		488d8c2498000000	LEAQ 0x98(SP), CX											
  value_methods.go:860		0x5b092c		e8cfd4e5ff		CALL runtime.mapassign(SB)										
  value_methods.go:860		0x5b0931		8400			TESTB AL, 0(AX)												
  value_methods.go:861		0x5b0933		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:861		0x5b093b		488b12			MOVQ 0(DX), DX												
  value_methods.go:861		0x5b093e		488d35fb420000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB), SI	
  value_methods.go:861		0x5b0945		4889b42460010000	MOVQ SI, 0x160(SP)											
  value_methods.go:861		0x5b094d		4889942468010000	MOVQ DX, 0x168(SP)											
  value_methods.go:861		0x5b0955		488b942490000000	MOVQ 0x90(SP), DX											
  value_methods.go:861		0x5b095d		4889942470010000	MOVQ DX, 0x170(SP)											
  value_methods.go:861		0x5b0965		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:861		0x5b096a		4889942478010000	MOVQ DX, 0x178(SP)											
  value_methods.go:861		0x5b0972		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:861		0x5b0977		4889942480010000	MOVQ DX, 0x180(SP)											
  value_methods.go:861		0x5b097f		488d942460010000	LEAQ 0x160(SP), DX											
  value_methods.go:861		0x5b0987		4889942418010000	MOVQ DX, 0x118(SP)											
  value_methods.go:861		0x5b098f		488d842400010000	LEAQ 0x100(SP), AX											
  value_methods.go:861		0x5b0997		e864afe9ff		CALL runtime.deferprocStack(SB)										
  value_methods.go:1031		0x5b099c		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:1031		0x5b09a1		4883fa02		CMPQ DX, $0x2												
  value_methods.go:1031		0x5b09a5		7d05			JGE 0x5b09ac												
  value_methods.go:1031		0x5b09a7		4531c9			XORL R9, R9												
  value_methods.go:864		0x5b09aa		eb08			JMP 0x5b09b4												
  value_methods.go:1034		0x5b09ac		4c8d0c12		LEAQ 0(DX)(DX*1), R9											
  value_methods.go:1034		0x5b09b0		4d8d49fe		LEAQ -0x2(R9), R9											
  value_methods.go:864		0x5b09b4		4983c102		ADDQ $0x2, R9												
  value_methods.go:865		0x5b09b8		4c8b942440010000	MOVQ 0x140(SP), R10											
  value_methods.go:865		0x5b09c0		e931070000		JMP 0x5b10f6												
  value_methods.go:858		0x5b09c5		48c744244807000000	MOVQ $0x7, 0x48(SP)											
  value_methods.go:858		0x5b09ce		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b09d7		e844b4e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:858		0x5b09dc		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:858		0x5b09e4		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:858		0x5b09ec		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b09f1		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b09f8		5d			POPQ BP													
  value_methods.go:918		0x5b09f9		c3			RET													
  value_methods.go:918		0x5b09fa		660f1f440000		NOPW 0(AX)(AX*1)											
  value_methods.go:873		0x5b0a00		4883f806		CMPQ AX, $0x6												
  value_methods.go:873		0x5b0a04		0f850e020000		JNE 0x5b0c18												
  value_methods.go:874		0x5b0a0a		90			NOPL													
  value_accessors.go:113	0x5b0a0b		488b8424c8000000	MOVQ 0xc8(SP), AX											
  value_accessors.go:113	0x5b0a13		488d1d76ef5000		LEAQ 0x50ef76(IP), BX											
  value_accessors.go:113	0x5b0a1a		660f1f440000		NOPW 0(AX)(AX*1)											
  value_accessors.go:113	0x5b0a20		4839d8			CMPQ AX, BX												
  value_accessors.go:113	0x5b0a23		0f85a1060000		JNE 0x5b10ca												
  value_accessors.go:113	0x5b0a29		488b9424f0010000	MOVQ 0x1f0(SP), DX											
  value_accessors.go:113	0x5b0a31		488b1a			MOVQ 0(DX), BX												
  value_methods.go:875		0x5b0a34		4885db			TESTQ BX, BX												
  value_methods.go:875		0x5b0a37		7405			JE 0x5b0a3e												
  value_methods.go:875		0x5b0a39		488b13			MOVQ 0(BX), DX												
  value_methods.go:875		0x5b0a3c		eb02			JMP 0x5b0a40												
  value_methods.go:875		0x5b0a3e		31d2			XORL DX, DX												
  value_methods.go:875		0x5b0a40		4885d2			TESTQ DX, DX												
  value_methods.go:875		0x5b0a43		0f849a010000		JE 0x5b0be3												
  value_accessors.go:113	0x5b0a49		48899c2448010000	MOVQ BX, 0x148(SP)											
  type.go:208			0x5b0a51		0fb615dca35100		MOVZX 0x51a3dc(IP), DX											
  value.go:165			0x5b0a58		90			NOPL													
  type.go:208			0x5b0a59		f6c220			TESTL $0x20, DL												
  value.go:3164			0x5b0a5c		b995000000		MOVL $0x95, CX												
  value.go:3164			0x5b0a61		ba15000000		MOVL $0x15, DX												
  value.go:3164			0x5b0a66		480f45ca		CMOVNE DX, CX												
  value_methods.go:878		0x5b0a6a		488d05afa35100		LEAQ 0x51a3af(IP), AX											
  value_methods.go:878		0x5b0a71		e80a64f1ff		CALL reflect.Value.Pointer(SB)										
  value_methods.go:879		0x5b0a76		4885c0			TESTQ AX, AX												
  value_methods.go:879		0x5b0a79		7510			JNE 0x5b0a8b												
  value_methods.go:875		0x5b0a7b		488b9c2448010000	MOVQ 0x148(SP), BX											
  value_methods.go:875		0x5b0a83		4885db			TESTQ BX, BX												
  value_methods.go:879		0x5b0a86		e99f000000		JMP 0x5b0b2a												
  value_methods.go:878		0x5b0a8b		4889442468		MOVQ AX, 0x68(SP)											
  value_methods.go:880		0x5b0a90		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:880		0x5b0a98		488b5a08		MOVQ 0x8(DX), BX											
  value_methods.go:880		0x5b0a9c		4889c1			MOVQ AX, CX												
  value_methods.go:880		0x5b0a9f		488d05baa75100		LEAQ 0x51a7ba(IP), AX											
  value_methods.go:880		0x5b0aa6		e815e0e5ff		CALL runtime.mapaccess2_fast64(SB)									
  value_methods.go:880		0x5b0aab		84db			TESTL BL, BL												
  value_methods.go:880		0x5b0aad		0f85f9000000		JNE 0x5b0bac												
  value_methods.go:883		0x5b0ab3		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:883		0x5b0abb		488b5a08		MOVQ 0x8(DX), BX											
  value_methods.go:883		0x5b0abf		488d059aa75100		LEAQ 0x51a79a(IP), AX											
  value_methods.go:883		0x5b0ac6		488b4c2468		MOVQ 0x68(SP), CX											
  value_methods.go:883		0x5b0acb		e870e2e5ff		CALL runtime.mapassign_fast64(SB)									
  value_methods.go:883		0x5b0ad0		8400			TESTB AL, 0(AX)												
  value_methods.go:884		0x5b0ad2		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:884		0x5b0ada		488b5208		MOVQ 0x8(DX), DX											
  value_methods.go:884		0x5b0ade		488d351b410000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB), SI	
  value_methods.go:884		0x5b0ae5		4889b424f8010000	MOVQ SI, 0x1f8(SP)											
  value_methods.go:884		0x5b0aed		4889942400020000	MOVQ DX, 0x200(SP)											
  value_methods.go:884		0x5b0af5		488b542468		MOVQ 0x68(SP), DX											
  value_methods.go:884		0x5b0afa		4889942408020000	MOVQ DX, 0x208(SP)											
  value_methods.go:884		0x5b0b02		488d9424f8010000	LEAQ 0x1f8(SP), DX											
  value_methods.go:884		0x5b0b0a		48899424e8000000	MOVQ DX, 0xe8(SP)											
  value_methods.go:884		0x5b0b12		488d8424d0000000	LEAQ 0xd0(SP), AX											
  value_methods.go:884		0x5b0b1a		e8e1ade9ff		CALL runtime.deferprocStack(SB)										
  value_methods.go:875		0x5b0b1f		488b9c2448010000	MOVQ 0x148(SP), BX											
  value_methods.go:875		0x5b0b27		4885db			TESTQ BX, BX												
  value_methods.go:887		0x5b0b2a		7405			JE 0x5b0b31												
  value_methods.go:887		0x5b0b2c		488b13			MOVQ 0(BX), DX												
  value_methods.go:887		0x5b0b2f		eb02			JMP 0x5b0b33												
  value_methods.go:887		0x5b0b31		31d2			XORL DX, DX												
  value_methods.go:1031		0x5b0b33		4883fa02		CMPQ DX, $0x2												
  value_methods.go:1031		0x5b0b37		7d04			JGE 0x5b0b3d												
  value_methods.go:1031		0x5b0b39		31d2			XORL DX, DX												
  value_methods.go:887		0x5b0b3b		eb08			JMP 0x5b0b45												
  value_methods.go:1034		0x5b0b3d		488d1412		LEAQ 0(DX)(DX*1), DX											
  value_methods.go:1034		0x5b0b41		488d52fe		LEAQ -0x2(DX), DX											
  value_methods.go:887		0x5b0b45		4889542440		MOVQ DX, 0x40(SP)											
  value_methods.go:888		0x5b0b4a		488d8c2488010000	LEAQ 0x188(SP), CX											
  value_methods.go:888		0x5b0b52		440f1139		MOVUPS X15, 0(CX)											
  value_methods.go:888		0x5b0b56		440f117910		MOVUPS X15, 0x10(CX)											
  value_methods.go:888		0x5b0b5b		440f117920		MOVUPS X15, 0x20(CX)											
  value_methods.go:888		0x5b0b60		440f117930		MOVUPS X15, 0x30(CX)											
  value_methods.go:888		0x5b0b65		440f117940		MOVUPS X15, 0x40(CX)											
  value_methods.go:888		0x5b0b6a		440f117950		MOVUPS X15, 0x50(CX)											
  value_methods.go:888		0x5b0b6f		488d05aaa25100		LEAQ 0x51a2aa(IP), AX											
  value_methods.go:888		0x5b0b76		e8853de7ff		CALL runtime.mapIterStart(SB)										
  value_methods.go:887		0x5b0b7b		488b542440		MOVQ 0x40(SP), DX											
  value_methods.go:887		0x5b0b80		4883c202		ADDQ $0x2, DX												
  value_methods.go:888		0x5b0b84		e9c7030000		JMP 0x5b0f50												
  value_methods.go:918		0x5b0b89		e892b2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:861		0x5b0b8e		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:861		0x5b0b96		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:861		0x5b0b9e		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0ba3		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0baa		5d			POPQ BP													
  value_methods.go:918		0x5b0bab		c3			RET													
  value_methods.go:881		0x5b0bac		48c744244807000000	MOVQ $0x7, 0x48(SP)											
  value_methods.go:881		0x5b0bb5		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:881		0x5b0bbe		6690			NOPW													
  value_methods.go:918		0x5b0bc0		e85bb2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:881		0x5b0bc5		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:881		0x5b0bcd		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:881		0x5b0bd5		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0bda		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0be1		5d			POPQ BP													
  value_methods.go:918		0x5b0be2		c3			RET													
  value_methods.go:876		0x5b0be3		48c744244802000000	MOVQ $0x2, 0x48(SP)											
  value_methods.go:876		0x5b0bec		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0bf5		e826b2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:876		0x5b0bfa		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:876		0x5b0c02		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:876		0x5b0c0a		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0c0f		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0c16		5d			POPQ BP													
  value_methods.go:918		0x5b0c17		c3			RET													
  value_methods.go:897		0x5b0c18		4883f814		CMPQ AX, $0x14												
  value_methods.go:897		0x5b0c1c		752d			JNE 0x5b0c4b												
  regex.go:180			0x5b0c1e		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0c26		488d1dbba25500		LEAQ 0x55a2bb(IP), BX											
  regex.go:180			0x5b0c2d		4839d8			CMPQ AX, BX												
  regex.go:180			0x5b0c30		0f85d9020000		JNE 0x5b0f0f												
  regex.go:180			0x5b0c36		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  regex.go:180			0x5b0c3e		4d8b4808		MOVQ 0x8(R8), R9											
  regex.go:180			0x5b0c42		49c1e906		SHRQ $0x6, R9												
  regex.go:180			0x5b0c46		e9da010000		JMP 0x5b0e25												
  value_methods.go:908		0x5b0c4b		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:908		0x5b0c53		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:908		0x5b0c5b		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:908		0x5b0c63		488bb42448020000	MOVQ 0x248(SP), SI											
  value_methods.go:908		0x5b0c6b		e850ebfeff		CALL github.com/mgomes/vibescript/vibes/value.chargeBigIntRenderSteps(SB)				
  value_methods.go:908		0x5b0c70		4885c0			TESTQ AX, AX												
  value_methods.go:908		0x5b0c73		0f85a1000000		JNE 0x5b0d1a												
  value_methods.go:911		0x5b0c79		488b1500365b00		MOVQ github.com/mgomes/vibescript/vibes/value.RuntimeStringRuneLen(SB), DX				
  value_methods.go:911		0x5b0c80		4885d2			TESTQ DX, DX												
  value_methods.go:911		0x5b0c83		7429			JE 0x5b0cae												
  value_methods.go:912		0x5b0c85		488b32			MOVQ 0(DX), SI												
  value_methods.go:912		0x5b0c88		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:912		0x5b0c90		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:912		0x5b0c98		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:912		0x5b0ca0		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:912		0x5b0ca8		ffd6			CALL SI													
  value_methods.go:912		0x5b0caa		84db			TESTL BL, BL												
  value_methods.go:912		0x5b0cac		753b			JNE 0x5b0ce9												
  value_methods.go:916		0x5b0cae		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:916		0x5b0cb6		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:916		0x5b0cbe		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:916		0x5b0cc6		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:916		0x5b0cce		e84db6ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)						
  value_methods.go:916		0x5b0cd3		4889842450010000	MOVQ AX, 0x150(SP)											
  value_methods.go:916		0x5b0cdb		48895c2460		MOVQ BX, 0x60(SP)											
  utf8.go:448			0x5b0ce0		31d2			XORL DX, DX												
  utf8.go:448			0x5b0ce2		31f6			XORL SI, SI												
  utf8.go:448			0x5b0ce4		e9af000000		JMP 0x5b0d98												
  value_methods.go:913		0x5b0ce9		4889442448		MOVQ AX, 0x48(SP)											
  value_methods.go:913		0x5b0cee		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0cf7		e824b1e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:913		0x5b0cfc		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:913		0x5b0d04		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:913		0x5b0d0c		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0d11		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0d18		5d			POPQ BP													
  value_methods.go:918		0x5b0d19		c3			RET													
  value_methods.go:909		0x5b0d1a		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:909		0x5b0d23		4889842430010000	MOVQ AX, 0x130(SP)											
  value_methods.go:909		0x5b0d2b		48899c2438010000	MOVQ BX, 0x138(SP)											
  value_methods.go:918		0x5b0d33		e8e8b0e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:909		0x5b0d38		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:909		0x5b0d40		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:909		0x5b0d48		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0d4d		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0d54		5d			POPQ BP													
  value_methods.go:918		0x5b0d55		c3			RET													
  value_methods.go:846		0x5b0d56		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:846		0x5b0d5f		4889842430010000	MOVQ AX, 0x130(SP)											
  value_methods.go:846		0x5b0d67		48899c2438010000	MOVQ BX, 0x138(SP)											
  value_methods.go:918		0x5b0d6f		e8acb0e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:846		0x5b0d74		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:846		0x5b0d7c		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:846		0x5b0d84		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0d89		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0d90		5d			POPQ BP													
  value_methods.go:918		0x5b0d91		c3			RET													
  utf8.go:449			0x5b0d92		48ffc6			INCQ SI													
  utf8.go:448			0x5b0d95		4889ca			MOVQ CX, DX												
  utf8.go:448			0x5b0d98		4839d3			CMPQ BX, DX												
  utf8.go:448			0x5b0d9b		7e33			JLE 0x5b0dd0												
  utf8.go:448			0x5b0d9d		0fb63c02		MOVZX 0(DX)(AX*1), DI											
  utf8.go:448			0x5b0da1		83ff7f			CMPL DI, $0x7f												
  utf8.go:448			0x5b0da4		7f06			JG 0x5b0dac												
  utf8.go:448			0x5b0da6		488d4a01		LEAQ 0x1(DX), CX											
  utf8.go:448			0x5b0daa		ebe6			JMP 0x5b0d92												
  utf8.go:448			0x5b0dac		4889742470		MOVQ SI, 0x70(SP)											
  utf8.go:448			0x5b0db1		4889d1			MOVQ DX, CX												
  utf8.go:448			0x5b0db4		e847c4ecff		CALL runtime.decoderune(SB)										
  utf8.go:448			0x5b0db9		488b842450010000	MOVQ 0x150(SP), AX											
  utf8.go:449			0x5b0dc1		488b742470		MOVQ 0x70(SP), SI											
  utf8.go:449			0x5b0dc6		4889d9			MOVQ BX, CX												
  utf8.go:448			0x5b0dc9		488b5c2460		MOVQ 0x60(SP), BX											
  utf8.go:448			0x5b0dce		ebc2			JMP 0x5b0d92												
  value_methods.go:916		0x5b0dd0		4889742448		MOVQ SI, 0x48(SP)											
  value_methods.go:916		0x5b0dd5		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0dde		6690			NOPW													
  value_methods.go:918		0x5b0de0		e83bb0e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:916		0x5b0de5		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:916		0x5b0ded		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:916		0x5b0df5		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0dfa		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0e01		5d			POPQ BP													
  value_methods.go:918		0x5b0e02		c3			RET													
  regex.go:180			0x5b0e03		4c8b8c24b0000000	MOVQ 0xb0(SP), R9											
  regex.go:180			0x5b0e0b		49ffc9			DECQ R9													
  regex.go:180			0x5b0e0e		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0e16		488d1dcba05500		LEAQ 0x55a0cb(IP), BX											
  value_methods.go:906		0x5b0e1d		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  regex.go:180			0x5b0e25		4d85c9			TESTQ R9, R9												
  regex.go:180			0x5b0e28		7e3a			JLE 0x5b0e64												
  regex.go:180			0x5b0e2a		4c898c24b0000000	MOVQ R9, 0xb0(SP)											
  regex.go:181			0x5b0e32		488b942448020000	MOVQ 0x248(SP), DX											
  regex.go:181			0x5b0e3a		488b02			MOVQ 0(DX), AX												
  regex.go:181			0x5b0e3d		ffd0			CALL AX													
  regex.go:181			0x5b0e3f		90			NOPL													
  regex.go:181			0x5b0e40		4885c0			TESTQ AX, AX												
  regex.go:181			0x5b0e43		74be			JE 0x5b0e03												
  value_methods.go:906		0x5b0e45		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  value_methods.go:903		0x5b0e4d		4889c1			MOVQ AX, CX												
  value_methods.go:903		0x5b0e50		4889da			MOVQ BX, DX												
  regex.go:180			0x5b0e53		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0e5b		488d1d86a05500		LEAQ 0x55a086(IP), BX											
  value_methods.go:903		0x5b0e62		eb04			JMP 0x5b0e68												
  value_methods.go:903		0x5b0e64		31c9			XORL CX, CX												
  value_methods.go:903		0x5b0e66		31d2			XORL DX, DX												
  value_methods.go:903		0x5b0e68		4885c9			TESTQ CX, CX												
  value_methods.go:903		0x5b0e6b		7556			JNE 0x5b0ec3												
  regex.go:180			0x5b0e6d		4839d8			CMPQ AX, BX												
  value_methods.go:906		0x5b0e70		0f858d000000		JNE 0x5b0f03												
  value_methods.go:906		0x5b0e76		498b00			MOVQ 0(R8), AX												
  value_methods.go:906		0x5b0e79		498b5808		MOVQ 0x8(R8), BX											
  value_methods.go:906		0x5b0e7d		498b4810		MOVQ 0x10(R8), CX											
  value_methods.go:906		0x5b0e81		498b7818		MOVQ 0x18(R8), DI											
  value_methods.go:906		0x5b0e85		498b7020		MOVQ 0x20(R8), SI											
  value_methods.go:906		0x5b0e89		e8f248ffff		CALL github.com/mgomes/vibescript/vibes/value.Regex.StringRuneLen(SB)					
  value_methods.go:906		0x5b0e8e		4889442448		MOVQ AX, 0x48(SP)											
  value_methods.go:906		0x5b0e93		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:906		0x5b0e9c		0f1f4000		NOPL 0(AX)												
  value_methods.go:918		0x5b0ea0		e87bafe9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:906		0x5b0ea5		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:906		0x5b0ead		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:906		0x5b0eb5		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0eba		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0ec1		5d			POPQ BP													
  value_methods.go:918		0x5b0ec2		c3			RET													
  value_methods.go:904		0x5b0ec3		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:904		0x5b0ecc		48898c2430010000	MOVQ CX, 0x130(SP)											
  value_methods.go:904		0x5b0ed4		4889942438010000	MOVQ DX, 0x138(SP)											
  value_methods.go:904		0x5b0edc		0f1f4000		NOPL 0(AX)												
  value_methods.go:918		0x5b0ee0		e83bafe9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:904		0x5b0ee5		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:904		0x5b0eed		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:904		0x5b0ef5		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0efa		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0f01		5d			POPQ BP													
  value_methods.go:918		0x5b0f02		c3			RET													
  value_methods.go:906		0x5b0f03		488d0d969b5300		LEAQ 0x539b96(IP), CX											
  value_methods.go:906		0x5b0f0a		e831bfe6ff		CALL runtime.panicdottypeE(SB)										
  regex.go:180			0x5b0f0f		488d0d8a9b5300		LEAQ 0x539b8a(IP), CX											
  regex.go:180			0x5b0f16		e825bfe6ff		CALL runtime.panicdottypeE(SB)										
  value_methods.go:890		0x5b0f1b		4889842480000000	MOVQ AX, 0x80(SP)											
  value_methods.go:889		0x5b0f23		48899424b0000000	MOVQ DX, 0xb0(SP)											
  value_methods.go:888		0x5b0f2b		488d842488010000	LEAQ 0x188(SP), AX											
  value_methods.go:888		0x5b0f33		e8283ae7ff		CALL runtime.mapIterNext(SB)										
  value_methods.go:894		0x5b0f38		488b8c2480000000	MOVQ 0x80(SP), CX											
  value_methods.go:894		0x5b0f40		488b9424b0000000	MOVQ 0xb0(SP), DX											
  value_methods.go:894		0x5b0f48		488d140a		LEAQ 0(DX)(CX*1), DX											
  value_methods.go:894		0x5b0f4c		488d5202		LEAQ 0x2(DX), DX											
  value_methods.go:888		0x5b0f50		4c8b8c2488010000	MOVQ 0x188(SP), R9											
  value_methods.go:888		0x5b0f58		0f1f840000000000	NOPL 0(AX)(AX*1)											
  value_methods.go:888		0x5b0f60		4d85c9			TESTQ R9, R9												
  value_methods.go:888		0x5b0f63		0f84f4000000		JE 0x5b105d												
  value_methods.go:888		0x5b0f69		4889542450		MOVQ DX, 0x50(SP)											
  value_methods.go:888		0x5b0f6e		4c8b942490010000	MOVQ 0x190(SP), R10											
  value_methods.go:888		0x5b0f76		498b01			MOVQ 0(R9), AX												
  value_methods.go:888		0x5b0f79		4889842458010000	MOVQ AX, 0x158(SP)											
  value_methods.go:888		0x5b0f81		498b5908		MOVQ 0x8(R9), BX											
  value_methods.go:888		0x5b0f85		48899c2488000000	MOVQ BX, 0x88(SP)											
  value_methods.go:888		0x5b0f8d		4d8b0a			MOVQ 0(R10), R9												
  value_methods.go:888		0x5b0f90		4c898c24c0000000	MOVQ R9, 0xc0(SP)											
  value_methods.go:888		0x5b0f98		4d8b5a08		MOVQ 0x8(R10), R11											
  value_methods.go:888		0x5b0f9c		4c899c24c8000000	MOVQ R11, 0xc8(SP)											
  value_methods.go:888		0x5b0fa4		498b4a10		MOVQ 0x10(R10), CX											
  value_methods.go:888		0x5b0fa8		48898c24f0010000	MOVQ CX, 0x1f0(SP)											
  value_methods.go:888		0x5b0fb0		498b7a18		MOVQ 0x18(R10), DI											
  value_methods.go:888		0x5b0fb4		4889bc24b8000000	MOVQ DI, 0xb8(SP)											
  utf8.go:448			0x5b0fbc		4531d2			XORL R10, R10												
  utf8.go:448			0x5b0fbf		4531e4			XORL R12, R12												
  utf8.go:448			0x5b0fc2		eb03			JMP 0x5b0fc7												
  utf8.go:449			0x5b0fc4		49ffc2			INCQ R10												
  utf8.go:448			0x5b0fc7		4c89542478		MOVQ R10, 0x78(SP)											
  utf8.go:448			0x5b0fcc		4939dc			CMPQ R12, BX												
  utf8.go:448			0x5b0fcf		7d58			JGE 0x5b1029												
  utf8.go:448			0x5b0fd1		450fb62c04		MOVZX 0(R12)(AX*1), R13											
  utf8.go:448			0x5b0fd6		4183fd7f		CMPL R13, $0x7f												
  utf8.go:448			0x5b0fda		7f06			JG 0x5b0fe2												
  utf8.go:448			0x5b0fdc		49ffc4			INCQ R12												
  utf8.go:448			0x5b0fdf		90			NOPL													
  utf8.go:448			0x5b0fe0		ebe2			JMP 0x5b0fc4												
  utf8.go:448			0x5b0fe2		4c89e1			MOVQ R12, CX												
  utf8.go:448			0x5b0fe5		e816c2ecff		CALL runtime.decoderune(SB)										
  utf8.go:448			0x5b0fea		488b842458010000	MOVQ 0x158(SP), AX											
  value_methods.go:890		0x5b0ff2		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:889		0x5b0ffa		488b542450		MOVQ 0x50(SP), DX											
  value_methods.go:890		0x5b0fff		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:890		0x5b1007		4c8b8c24c0000000	MOVQ 0xc0(SP), R9											
  utf8.go:449			0x5b100f		4c8b542478		MOVQ 0x78(SP), R10											
  value_methods.go:890		0x5b1014		4c8b9c24c8000000	MOVQ 0xc8(SP), R11											
  utf8.go:449			0x5b101c		4989dc			MOVQ BX, R12												
  utf8.go:448			0x5b101f		488b9c2488000000	MOVQ 0x88(SP), BX											
  utf8.go:448			0x5b1027		eb9b			JMP 0x5b0fc4												
  value_methods.go:890		0x5b1029		4c89c8			MOVQ R9, AX												
  value_methods.go:890		0x5b102c		4c89db			MOVQ R11, BX												
  value_methods.go:890		0x5b102f		488bb42440020000	MOVQ 0x240(SP), SI											
  value_methods.go:890		0x5b1037		4c8b842448020000	MOVQ 0x248(SP), R8											
  value_methods.go:890		0x5b103f		90			NOPL													
  value_methods.go:890		0x5b1040		e83bf7ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			
  value_methods.go:889		0x5b1045		488b542478		MOVQ 0x78(SP), DX											
  value_methods.go:889		0x5b104a		4c8b4c2450		MOVQ 0x50(SP), R9											
  value_methods.go:889		0x5b104f		4c01ca			ADDQ R9, DX												
  value_methods.go:891		0x5b1052		4885db			TESTQ BX, BX												
  value_methods.go:891		0x5b1055		0f84c0feffff		JE 0x5b0f1b												
  value_methods.go:891		0x5b105b		eb31			JMP 0x5b108e												
  value_methods.go:896		0x5b105d		4889542448		MOVQ DX, 0x48(SP)											
  value_methods.go:896		0x5b1062		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b106b		e8b0ade9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:896		0x5b1070		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:896		0x5b1078		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:896		0x5b1080		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b1085		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b108c		5d			POPQ BP													
  value_methods.go:918		0x5b108d		c3			RET													
  value_methods.go:892		0x5b108e		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:892		0x5b1097		48899c2430010000	MOVQ BX, 0x130(SP)											
  value_methods.go:892		0x5b109f		48898c2438010000	MOVQ CX, 0x138(SP)											
  value_methods.go:918		0x5b10a7		e874ade9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:892		0x5b10ac		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:892		0x5b10b4		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:892		0x5b10bc		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b10c1		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b10c8		5d			POPQ BP													
  value_methods.go:918		0x5b10c9		c3			RET													
  value_accessors.go:113	0x5b10ca		488d0dcf995300		LEAQ 0x5399cf(IP), CX											
  value_accessors.go:113	0x5b10d1		e86abde6ff		CALL runtime.panicdottypeE(SB)										
  value_methods.go:865		0x5b10d6		4c8b9424e8010000	MOVQ 0x1e8(SP), R10											
  value_methods.go:865		0x5b10de		4983c220		ADDQ $0x20, R10												
  value_methods.go:870		0x5b10e2		4c8b5c2458		MOVQ 0x58(SP), R11											
  value_methods.go:870		0x5b10e7		4d8d0c03		LEAQ 0(R11)(AX*1), R9											
  value_methods.go:865		0x5b10eb		488b9424b0000000	MOVQ 0xb0(SP), DX											
  value_methods.go:865		0x5b10f3		48ffca			DECQ DX													
  value_methods.go:865		0x5b10f6		4885d2			TESTQ DX, DX												
  value_methods.go:865		0x5b10f9		7e7a			JLE 0x5b1175												
  value_methods.go:865		0x5b10fb		48899424b0000000	MOVQ DX, 0xb0(SP)											
  value_methods.go:865		0x5b1103		4c894c2458		MOVQ R9, 0x58(SP)											
  value_methods.go:865		0x5b1108		4c899424e8010000	MOVQ R10, 0x1e8(SP)											
  value_methods.go:865		0x5b1110		498b02			MOVQ 0(R10), AX												
  value_methods.go:865		0x5b1113		498b5a08		MOVQ 0x8(R10), BX											
  value_methods.go:865		0x5b1117		498b4a10		MOVQ 0x10(R10), CX											
  value_methods.go:865		0x5b111b		498b7a18		MOVQ 0x18(R10), DI											
  value_methods.go:866		0x5b111f		488bb42440020000	MOVQ 0x240(SP), SI											
  value_methods.go:866		0x5b1127		4c8b842448020000	MOVQ 0x248(SP), R8											
  value_methods.go:866		0x5b112f		e84cf6ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			
  value_methods.go:867		0x5b1134		4885db			TESTQ BX, BX												
  value_methods.go:867		0x5b1137		749d			JE 0x5b10d6												
  value_methods.go:868		0x5b1139		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:868		0x5b1142		48899c2430010000	MOVQ BX, 0x130(SP)											
  value_methods.go:868		0x5b114a		48898c2438010000	MOVQ CX, 0x138(SP)											
  value_methods.go:918		0x5b1152		e8c9ace9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:868		0x5b1157		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:868		0x5b115f		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:868		0x5b1167		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b116c		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b1173		5d			POPQ BP													
  value_methods.go:918		0x5b1174		c3			RET													
  value_methods.go:872		0x5b1175		4c894c2448		MOVQ R9, 0x48(SP)											
  value_methods.go:872		0x5b117a		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b1183		e898ace9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:872		0x5b1188		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:872		0x5b1190		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:872		0x5b1198		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b119d		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b11a4		5d			POPQ BP													
  value_methods.go:918		0x5b11a5		c3			RET													
  value_accessors.go:86		0x5b11a6		488d0df3985300		LEAQ 0x5398f3(IP), CX											
  value_accessors.go:86		0x5b11ad		e88ebce6ff		CALL runtime.panicdottypeE(SB)										
  value_accessors.go:86		0x5b11b2		90			NOPL													
  value_methods.go:844		0x5b11b3		4889442408		MOVQ AX, 0x8(SP)											
  value_methods.go:844		0x5b11b8		48895c2410		MOVQ BX, 0x10(SP)											
  value_methods.go:844		0x5b11bd		48894c2418		MOVQ CX, 0x18(SP)											
  value_methods.go:844		0x5b11c2		48897c2420		MOVQ DI, 0x20(SP)											
  value_methods.go:844		0x5b11c7		4889742428		MOVQ SI, 0x28(SP)											
  value_methods.go:844		0x5b11cc		4c89442430		MOVQ R8, 0x30(SP)											
  value_methods.go:844		0x5b11d1		e86ab4edff		CALL runtime.morestack_noctxt.abi0(SB)									
  value_methods.go:844		0x5b11d6		488b442408		MOVQ 0x8(SP), AX											
  value_methods.go:844		0x5b11db		488b5c2410		MOVQ 0x10(SP), BX											
  value_methods.go:844		0x5b11e0		488b4c2418		MOVQ 0x18(SP), CX											
  value_methods.go:844		0x5b11e5		488b7c2420		MOVQ 0x20(SP), DI											
  value_methods.go:844		0x5b11ea		488b742428		MOVQ 0x28(SP), SI											
  value_methods.go:844		0x5b11ef		4c8b442430		MOVQ 0x30(SP), R8											
  value_methods.go:844		0x5b11f4		e987f5ffff		JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB) /home/runner/work/vibescript/vibescript/ascii/vibes/value/value_methods.go
  value_methods.go:638	0x5b4b00		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:638	0x5b4b04		7625			JBE 0x5b4b2b											
  value_methods.go:638	0x5b4b06		55			PUSHQ BP											
  value_methods.go:638	0x5b4b07		4889e5			MOVQ SP, BP											
  value_methods.go:638	0x5b4b0a		4883ec18		SUBQ $0x18, SP											
  value_methods.go:638	0x5b4b0e		488b4a10		MOVQ 0x10(DX), CX										
  value_methods.go:638	0x5b4b12		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:638	0x5b4b16		488d0543675100		LEAQ 0x516743(IP), AX										
  value_methods.go:638	0x5b4b1d		0f1f00			NOPL 0(AX)											
  value_methods.go:638	0x5b4b20		e83baae5ff		CALL runtime.mapdelete_fast64(SB)								
  value_methods.go:638	0x5b4b25		4883c418		ADDQ $0x18, SP											
  value_methods.go:638	0x5b4b29		5d			POPQ BP												
  value_methods.go:638	0x5b4b2a		c3			RET												
  value_methods.go:638	0x5b4b2b		e8707aedff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:638	0x5b4b30		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB) /home/runner/work/vibescript/vibescript/ascii/vibes/value/value_methods.go
  value_methods.go:619	0x5b4b40		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:619	0x5b4b44		7625			JBE 0x5b4b6b											
  value_methods.go:619	0x5b4b46		55			PUSHQ BP											
  value_methods.go:619	0x5b4b47		4889e5			MOVQ SP, BP											
  value_methods.go:619	0x5b4b4a		4883ec18		SUBQ $0x18, SP											
  value_methods.go:619	0x5b4b4e		488d4a10		LEAQ 0x10(DX), CX										
  value_methods.go:619	0x5b4b52		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:619	0x5b4b56		488d0523695100		LEAQ 0x516923(IP), AX										
  value_methods.go:619	0x5b4b5d		0f1f00			NOPL 0(AX)											
  value_methods.go:619	0x5b4b60		e83b17edff		CALL runtime.mapdelete(SB)									
  value_methods.go:619	0x5b4b65		4883c418		ADDQ $0x18, SP											
  value_methods.go:619	0x5b4b69		5d			POPQ BP												
  value_methods.go:619	0x5b4b6a		c3			RET												
  value_methods.go:619	0x5b4b6b		e8307aedff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:619	0x5b4b70		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB) /home/runner/work/vibescript/vibescript/ascii/vibes/value/value_methods.go
  value_methods.go:884	0x5b4c00		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:884	0x5b4c04		7625			JBE 0x5b4c2b											
  value_methods.go:884	0x5b4c06		55			PUSHQ BP											
  value_methods.go:884	0x5b4c07		4889e5			MOVQ SP, BP											
  value_methods.go:884	0x5b4c0a		4883ec18		SUBQ $0x18, SP											
  value_methods.go:884	0x5b4c0e		488b4a10		MOVQ 0x10(DX), CX										
  value_methods.go:884	0x5b4c12		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:884	0x5b4c16		488d0543665100		LEAQ 0x516643(IP), AX										
  value_methods.go:884	0x5b4c1d		0f1f00			NOPL 0(AX)											
  value_methods.go:884	0x5b4c20		e83ba9e5ff		CALL runtime.mapdelete_fast64(SB)								
  value_methods.go:884	0x5b4c25		4883c418		ADDQ $0x18, SP											
  value_methods.go:884	0x5b4c29		5d			POPQ BP												
  value_methods.go:884	0x5b4c2a		c3			RET												
  value_methods.go:884	0x5b4c2b		e87079edff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:884	0x5b4c30		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB) /home/runner/work/vibescript/vibescript/ascii/vibes/value/value_methods.go
  value_methods.go:861	0x5b4c40		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:861	0x5b4c44		7625			JBE 0x5b4c6b											
  value_methods.go:861	0x5b4c46		55			PUSHQ BP											
  value_methods.go:861	0x5b4c47		4889e5			MOVQ SP, BP											
  value_methods.go:861	0x5b4c4a		4883ec18		SUBQ $0x18, SP											
  value_methods.go:861	0x5b4c4e		488d4a10		LEAQ 0x10(DX), CX										
  value_methods.go:861	0x5b4c52		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:861	0x5b4c56		488d0523685100		LEAQ 0x516823(IP), AX										
  value_methods.go:861	0x5b4c5d		0f1f00			NOPL 0(AX)											
  value_methods.go:861	0x5b4c60		e83b16edff		CALL runtime.mapdelete(SB)									
  value_methods.go:861	0x5b4c65		4883c418		ADDQ $0x18, SP											
  value_methods.go:861	0x5b4c69		5d			POPQ BP												
  value_methods.go:861	0x5b4c6a		c3			RET												
  value_methods.go:861	0x5b4c6b		e83079edff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:861	0x5b4c70		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneIndex(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:1231	0x6cfb20		493b6610		CMPQ SP, 0x10(R14)									
  members_string.go:1231	0x6cfb24		0f8601030000		JBE 0x6cfe2b										
  members_string.go:1231	0x6cfb2a		55			PUSHQ BP										
  members_string.go:1231	0x6cfb2b		4889e5			MOVQ SP, BP										
  members_string.go:1231	0x6cfb2e		4883ec50		SUBQ $0x50, SP										
  members_string.go:1231	0x6cfb32		48895c2468		MOVQ BX, 0x68(SP)									
  members_string.go:1231	0x6cfb37		48897c2478		MOVQ DI, 0x78(SP)									
  members_string.go:1231	0x6cfb3c		0f1f4000		NOPL 0(AX)										
  members_string.go:1232	0x6cfb40		4d85c0			TESTQ R8, R8										
  members_string.go:1232	0x6cfb43		0f8c74020000		JL 0x6cfdbd										
  members_string.go:5185	0x6cfb49		4885c9			TESTQ CX, CX										
  members_string.go:5185	0x6cfb4c		7504			JNE 0x6cfb52										
  members_string.go:5185	0x6cfb4e		31d2			XORL DX, DX										
  members_string.go:1248	0x6cfb50		eb3d			JMP 0x6cfb8f										
  members_string.go:1232	0x6cfb52		4889c2			MOVQ AX, DX										
  members_string.go:5188	0x6cfb55		48b8ffffffffffffff7f	MOVQ $0x7fffffffffffffff, AX								
  members_string.go:1232	0x6cfb5f		4989d1			MOVQ DX, R9										
  members_string.go:5188	0x6cfb62		31d2			XORL DX, DX										
  members_string.go:5188	0x6cfb64		48f7f1			DIVQ CX											
  members_string.go:5188	0x6cfb67		4883f804		CMPQ AX, $0x4										
  members_string.go:5188	0x6cfb6b		7d0f			JGE 0x6cfb7c										
  members_string.go:1265	0x6cfb6d		4c89c8			MOVQ R9, AX										
  members_string.go:1265	0x6cfb70		48baffffffffffffff7f	MOVQ $0x7fffffffffffffff, DX								
  members_string.go:1248	0x6cfb7a		eb13			JMP 0x6cfb8f										
  members_string.go:5191	0x6cfb7c		4889ca			MOVQ CX, DX										
  members_string.go:5191	0x6cfb7f		48c1e102		SHLQ $0x2, CX										
  members_string.go:1265	0x6cfb83		4c89c8			MOVQ R9, AX										
  ascii_scan_simd_amd64.go:9	0x6cfb86		4989ca			MOVQ CX, R10										
  ascii_scan_simd_amd64.go:9	0x6cfb89		4889d1			MOVQ DX, CX										
  members_string.go:1248	0x6cfb8c		4c89d2			MOVQ R10, DX										
  members_string.go:1248	0x6cfb8f		4839d6			CMPQ SI, DX										
  members_string.go:1248	0x6cfb92		0f8f14020000		JG 0x6cfdac										
  members_string.go:1232	0x6cfb98		4889442460		MOVQ AX, 0x60(SP)									
  members_string.go:1232	0x6cfb9d		4c89842488000000	MOVQ R8, 0x88(SP)									
  members_string.go:1232	0x6cfba5		4889b42480000000	MOVQ SI, 0x80(SP)									
  members_string.go:1232	0x6cfbad		48897c2478		MOVQ DI, 0x78(SP)									
  members_string.go:1232	0x6cfbb2		48894c2470		MOVQ CX, 0x70(SP)									
  members_string.go:1232	0x6cfbb7		48895c2468		MOVQ BX, 0x68(SP)									
  ascii_scan_simd_amd64.go:9	0x6cfbbc		4889d8			MOVQ BX, AX										
  ascii_scan_simd_amd64.go:9	0x6cfbbf		4889cb			MOVQ CX, BX										
  ascii_scan_simd_amd64.go:9	0x6cfbc2		e87929f4ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIVector(SB)		
  ascii_scan_simd_amd64.go:9	0x6cfbc7		84c0			TESTL AL, AL										
  members_string.go:1251	0x6cfbc9		7504			JNE 0x6cfbcf										
  members_string.go:1251	0x6cfbcb		31c0			XORL AX, AX										
  members_string.go:1251	0x6cfbcd		eb16			JMP 0x6cfbe5										
  ascii_scan_simd_amd64.go:9	0x6cfbcf		488b442478		MOVQ 0x78(SP), AX									
  ascii_scan_simd_amd64.go:9	0x6cfbd4		488b9c2480000000	MOVQ 0x80(SP), BX									
  ascii_scan_simd_amd64.go:9	0x6cfbdc		0f1f4000		NOPL 0(AX)										
  ascii_scan_simd_amd64.go:9	0x6cfbe0		e85b29f4ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIVector(SB)		
  members_string.go:1251	0x6cfbe5		84c0			TESTL AL, AL										
  members_string.go:1251	0x6cfbe7		0f8488000000		JE 0x6cfc75										
  members_string.go:1252	0x6cfbed		488b5c2470		MOVQ 0x70(SP), BX									
  members_string.go:1252	0x6cfbf2		488b842488000000	MOVQ 0x88(SP), AX									
  members_string.go:1252	0x6cfbfa		4839c3			CMPQ BX, AX										
  members_string.go:1252	0x6cfbfd		7c65			JL 0x6cfc64										
  members_string.go:1255	0x6cfbff		488bbc2480000000	MOVQ 0x80(SP), DI									
  members_string.go:1255	0x6cfc07		4885ff			TESTQ DI, DI										
  members_string.go:1255	0x6cfc0a		744e			JE 0x6cfc5a										
  members_string.go:1258	0x6cfc0c		4829c3			SUBQ AX, BX										
  members_string.go:1258	0x6cfc0f		4889da			MOVQ BX, DX										
  members_string.go:1258	0x6cfc12		48f7da			NEGQ DX											
  members_string.go:1258	0x6cfc15		48c1fa3f		SARQ $0x3f, DX										
  members_string.go:1258	0x6cfc19		4821c2			ANDQ AX, DX										
  members_string.go:1258	0x6cfc1c		488b742468		MOVQ 0x68(SP), SI									
  members_string.go:1258	0x6cfc21		488d0416		LEAQ 0(SI)(DX*1), AX									
  strings.go:1264		0x6cfc25		488b4c2478		MOVQ 0x78(SP), CX									
  strings.go:1264		0x6cfc2a		e87154d4ff		CALL internal/stringslite.Index(SB)							
  members_string.go:1259	0x6cfc2f		4885c0			TESTQ AX, AX										
  members_string.go:1259	0x6cfc32		7d11			JGE 0x6cfc45										
  members_string.go:1260	0x6cfc34		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1260	0x6cfc3b		31db			XORL BX, BX										
  members_string.go:1260	0x6cfc3d		31c9			XORL CX, CX										
  members_string.go:1260	0x6cfc3f		4883c450		ADDQ $0x50, SP										
  members_string.go:1260	0x6cfc43		5d			POPQ BP											
  members_string.go:1260	0x6cfc44		c3			RET											
  members_string.go:1262	0x6cfc45		488b942488000000	MOVQ 0x88(SP), DX									
  members_string.go:1262	0x6cfc4d		4801d0			ADDQ DX, AX										
  members_string.go:1262	0x6cfc50		31db			XORL BX, BX										
  members_string.go:1262	0x6cfc52		31c9			XORL CX, CX										
  members_string.go:1262	0x6cfc54		4883c450		ADDQ $0x50, SP										
  members_string.go:1262	0x6cfc58		5d			POPQ BP											
  members_string.go:1262	0x6cfc59		c3			RET											
  members_string.go:1256	0x6cfc5a		31db			XORL BX, BX										
  members_string.go:1256	0x6cfc5c		31c9			XORL CX, CX										
  members_string.go:1256	0x6cfc5e		4883c450		ADDQ $0x50, SP										
  members_string.go:1256	0x6cfc62		5d			POPQ BP											
  members_string.go:1256	0x6cfc63		c3			RET											
  members_string.go:1253	0x6cfc64		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1253	0x6cfc6b		31db			XORL BX, BX										
  members_string.go:1253	0x6cfc6d		31c9			XORL CX, CX										
  members_string.go:1253	0x6cfc6f		4883c450		ADDQ $0x50, SP										
  members_string.go:1253	0x6cfc73		5d			POPQ BP											
  members_string.go:1253	0x6cfc74		c3			RET											
  members_string.go:1264	0x6cfc75		488b442468		MOVQ 0x68(SP), AX									
  members_string.go:1264	0x6cfc7a		488b5c2470		MOVQ 0x70(SP), BX									
  members_string.go:1264	0x6cfc7f		90			NOPL											
  members_string.go:1264	0x6cfc80		e8dbf2ddff		CALL unicode/utf8.ValidString(SB)							
  members_string.go:1264	0x6cfc85		84c0			TESTL AL, AL										
  members_string.go:1264	0x6cfc87		7416			JE 0x6cfc9f										
  members_string.go:1264	0x6cfc89		488b442478		MOVQ 0x78(SP), AX									
  members_string.go:1264	0x6cfc8e		488b9c2480000000	MOVQ 0x80(SP), BX									
  members_string.go:1264	0x6cfc96		e8c5f2ddff		CALL unicode/utf8.ValidString(SB)							
  members_string.go:1264	0x6cfc9b		84c0			TESTL AL, AL										
  members_string.go:1264	0x6cfc9d		752f			JNE 0x6cfcce										
  members_string.go:1265	0x6cfc9f		488b442460		MOVQ 0x60(SP), AX									
  members_string.go:1265	0x6cfca4		488b5c2468		MOVQ 0x68(SP), BX									
  members_string.go:1265	0x6cfca9		488b4c2470		MOVQ 0x70(SP), CX									
  members_string.go:1265	0x6cfcae		488b7c2478		MOVQ 0x78(SP), DI									
  members_string.go:1265	0x6cfcb3		488bb42480000000	MOVQ 0x80(SP), SI									
  members_string.go:1265	0x6cfcbb		4c8b842488000000	MOVQ 0x88(SP), R8									
  members_string.go:1265	0x6cfcc3		e8f8020000		CALL github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB)		
  members_string.go:1265	0x6cfcc8		4883c450		ADDQ $0x50, SP										
  members_string.go:1265	0x6cfccc		5d			POPQ BP											
  members_string.go:1265	0x6cfccd		c3			RET											
  members_string.go:1267	0x6cfcce		488b442468		MOVQ 0x68(SP), AX									
  members_string.go:1267	0x6cfcd3		488b5c2470		MOVQ 0x70(SP), BX									
  members_string.go:1267	0x6cfcd8		488b8c2488000000	MOVQ 0x88(SP), CX									
  members_string.go:1267	0x6cfce0		e8fbfbffff		CALL github.com/mgomes/vibescript/internal/runtime.stringByteIndexForRuneOffset(SB)	
  members_string.go:1267	0x6cfce5		84db			TESTL BL, BL										
  members_string.go:1268	0x6cfce7		0f84ae000000		JE 0x6cfd9b										
  members_string.go:1271	0x6cfced		488bbc2480000000	MOVQ 0x80(SP), DI									
  members_string.go:1271	0x6cfcf5		4885ff			TESTQ DI, DI										
  members_string.go:1271	0x6cfcf8		0f848b000000		JE 0x6cfd89										
  members_string.go:1274	0x6cfcfe		488b5c2470		MOVQ 0x70(SP), BX									
  members_string.go:1274	0x6cfd03		4839d8			CMPQ AX, BX										
  members_string.go:1274	0x6cfd06		0f8719010000		JA 0x6cfe25										
  members_string.go:1267	0x6cfd0c		4889442430		MOVQ AX, 0x30(SP)									
  members_string.go:1274	0x6cfd11		4889da			MOVQ BX, DX										
  members_string.go:1274	0x6cfd14		4829c2			SUBQ AX, DX										
  members_string.go:1274	0x6cfd17		4889d3			MOVQ DX, BX										
  members_string.go:1274	0x6cfd1a		48f7da			NEGQ DX											
  members_string.go:1274	0x6cfd1d		48c1fa3f		SARQ $0x3f, DX										
  members_string.go:1274	0x6cfd21		4821c2			ANDQ AX, DX										
  members_string.go:1274	0x6cfd24		488b742468		MOVQ 0x68(SP), SI									
  members_string.go:1274	0x6cfd29		488d0432		LEAQ 0(DX)(SI*1), AX									
  strings.go:1264		0x6cfd2d		488b4c2478		MOVQ 0x78(SP), CX									
  strings.go:1264		0x6cfd32		e86953d4ff		CALL internal/stringslite.Index(SB)							
  members_string.go:1275	0x6cfd37		4885c0			TESTQ AX, AX										
  members_string.go:1275	0x6cfd3a		7c3c			JL 0x6cfd78										
  members_string.go:1278	0x6cfd3c		488b542430		MOVQ 0x30(SP), DX									
  members_string.go:1278	0x6cfd41		488d3402		LEAQ 0(DX)(AX*1), SI									
  members_string.go:1278	0x6cfd45		488b7c2470		MOVQ 0x70(SP), DI									
  members_string.go:1278	0x6cfd4a		4839f7			CMPQ DI, SI										
  members_string.go:1278	0x6cfd4d		0f82c8000000		JB 0x6cfe1b										
  strings.go:1264		0x6cfd53		4889442440		MOVQ AX, 0x40(SP)									
  members_string.go:1278	0x6cfd58		4889c3			MOVQ AX, BX										
  members_string.go:1278	0x6cfd5b		48f7d8			NEGQ AX											
  members_string.go:1278	0x6cfd5e		48c1f83f		SARQ $0x3f, AX										
  members_string.go:1278	0x6cfd62		4821d0			ANDQ DX, AX										
  members_string.go:1278	0x6cfd65		488b542468		MOVQ 0x68(SP), DX									
  members_string.go:1278	0x6cfd6a		4801d0			ADDQ DX, AX										
  members_string.go:1278	0x6cfd6d		4889442448		MOVQ AX, 0x48(SP)									
  utf8.go:448			0x6cfd72		31d2			XORL DX, DX										
  utf8.go:448			0x6cfd74		31f6			XORL SI, SI										
  utf8.go:448			0x6cfd76		eb59			JMP 0x6cfdd1										
  members_string.go:1276	0x6cfd78		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1276	0x6cfd7f		31db			XORL BX, BX										
  members_string.go:1276	0x6cfd81		31c9			XORL CX, CX										
  members_string.go:1276	0x6cfd83		4883c450		ADDQ $0x50, SP										
  members_string.go:1276	0x6cfd87		5d			POPQ BP											
  members_string.go:1276	0x6cfd88		c3			RET											
  members_string.go:1272	0x6cfd89		488b842488000000	MOVQ 0x88(SP), AX									
  members_string.go:1272	0x6cfd91		31db			XORL BX, BX										
  members_string.go:1272	0x6cfd93		31c9			XORL CX, CX										
  members_string.go:1272	0x6cfd95		4883c450		ADDQ $0x50, SP										
  members_string.go:1272	0x6cfd99		5d			POPQ BP											
  members_string.go:1272	0x6cfd9a		c3			RET											
  members_string.go:1269	0x6cfd9b		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1269	0x6cfda2		31db			XORL BX, BX										
  members_string.go:1269	0x6cfda4		31c9			XORL CX, CX										
  members_string.go:1269	0x6cfda6		4883c450		ADDQ $0x50, SP										
  members_string.go:1269	0x6cfdaa		5d			POPQ BP											
  members_string.go:1269	0x6cfdab		c3			RET											
  members_string.go:1249	0x6cfdac		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1249	0x6cfdb3		31db			XORL BX, BX										
  members_string.go:1249	0x6cfdb5		31c9			XORL CX, CX										
  members_string.go:1249	0x6cfdb7		4883c450		ADDQ $0x50, SP										
  members_string.go:1249	0x6cfdbb		5d			POPQ BP											
  members_string.go:1249	0x6cfdbc		c3			RET											
  members_string.go:1233	0x6cfdbd		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1233	0x6cfdc4		31db			XORL BX, BX										
  members_string.go:1233	0x6cfdc6		31c9			XORL CX, CX										
  members_string.go:1233	0x6cfdc8		4883c450		ADDQ $0x50, SP										
  members_string.go:1233	0x6cfdcc		5d			POPQ BP											
  members_string.go:1233	0x6cfdcd		c3			RET											
  utf8.go:449			0x6cfdce		48ffc2			INCQ DX											
  utf8.go:448			0x6cfdd1		4839f3			CMPQ BX, SI										
  utf8.go:448			0x6cfdd4		7e2f			JLE 0x6cfe05										
  utf8.go:448			0x6cfdd6		0fb63c30		MOVZX 0(AX)(SI*1), DI									
  utf8.go:448			0x6cfdda		83ff7f			CMPL DI, $0x7f										
  utf8.go:448			0x6cfddd		7f05			JG 0x6cfde4										
  utf8.go:448			0x6cfddf		48ffc6			INCQ SI											
  utf8.go:448			0x6cfde2		ebea			JMP 0x6cfdce										
  utf8.go:448			0x6cfde4		4889542438		MOVQ DX, 0x38(SP)									
  utf8.go:448			0x6cfde9		4889f1			MOVQ SI, CX										
  utf8.go:448			0x6cfdec		e80fd4daff		CALL runtime.decoderune(SB)								
  utf8.go:448			0x6cfdf1		488b442448		MOVQ 0x48(SP), AX									
  utf8.go:449			0x6cfdf6		488b542438		MOVQ 0x38(SP), DX									
  utf8.go:449			0x6cfdfb		4889de			MOVQ BX, SI										
  utf8.go:448			0x6cfdfe		488b5c2440		MOVQ 0x40(SP), BX									
  utf8.go:448			0x6cfe03		ebc9			JMP 0x6cfdce										
  members_string.go:1278	0x6cfe05		488bb42488000000	MOVQ 0x88(SP), SI									
  members_string.go:1278	0x6cfe0d		488d0416		LEAQ 0(SI)(DX*1), AX									
  members_string.go:1278	0x6cfe11		31db			XORL BX, BX										
  members_string.go:1278	0x6cfe13		31c9			XORL CX, CX										
  members_string.go:1278	0x6cfe15		4883c450		ADDQ $0x50, SP										
  members_string.go:1278	0x6cfe19		5d			POPQ BP											
  members_string.go:1278	0x6cfe1a		c3			RET											
  members_string.go:1278	0x6cfe1b		0f1f440000		NOPL 0(AX)(AX*1)									
  members_string.go:1278	0x6cfe20		e85be4dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1274	0x6cfe25		e856e4dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1274	0x6cfe2a		90			NOPL											
  members_string.go:1231	0x6cfe2b		4889442408		MOVQ AX, 0x8(SP)									
  members_string.go:1231	0x6cfe30		48895c2410		MOVQ BX, 0x10(SP)									
  members_string.go:1231	0x6cfe35		48894c2418		MOVQ CX, 0x18(SP)									
  members_string.go:1231	0x6cfe3a		48897c2420		MOVQ DI, 0x20(SP)									
  members_string.go:1231	0x6cfe3f		4889742428		MOVQ SI, 0x28(SP)									
  members_string.go:1231	0x6cfe44		4c89442430		MOVQ R8, 0x30(SP)									
  members_string.go:1231	0x6cfe49		e8f2c7dbff		CALL runtime.morestack_noctxt.abi0(SB)							
  members_string.go:1231	0x6cfe4e		488b442408		MOVQ 0x8(SP), AX									
  members_string.go:1231	0x6cfe53		488b5c2410		MOVQ 0x10(SP), BX									
  members_string.go:1231	0x6cfe58		488b4c2418		MOVQ 0x18(SP), CX									
  members_string.go:1231	0x6cfe5d		488b7c2420		MOVQ 0x20(SP), DI									
  members_string.go:1231	0x6cfe62		488b742428		MOVQ 0x28(SP), SI									
  members_string.go:1231	0x6cfe67		4c8b442430		MOVQ 0x30(SP), R8									
  members_string.go:1231	0x6cfe6c		e9affcffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneIndex(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:1305	0x6cffc0		4c8da424c0feffff	LEAQ 0xfffffec0(SP), R12								
  members_string.go:1305	0x6cffc8		4d3b6610		CMPQ R12, 0x10(R14)									
  members_string.go:1305	0x6cffcc		0f865f020000		JBE 0x6d0231										
  members_string.go:1305	0x6cffd2		55			PUSHQ BP										
  members_string.go:1305	0x6cffd3		4889e5			MOVQ SP, BP										
  members_string.go:1305	0x6cffd6		4881ecb8010000		SUBQ $0x1b8, SP										
  members_string.go:1306	0x6cffdd		4c898424f0010000	MOVQ R8, 0x1f0(SP)									
  members_string.go:1306	0x6cffe5		48898c24d8010000	MOVQ CX, 0x1d8(SP)									
  members_string.go:1306	0x6cffed		48899c24d0010000	MOVQ BX, 0x1d0(SP)									
  members_string.go:1306	0x6cfff5		4889b424e8010000	MOVQ SI, 0x1e8(SP)									
  members_string.go:1306	0x6cfffd		4889bc24e0010000	MOVQ DI, 0x1e0(SP)									
  members_string.go:1306	0x6d0005		e876feffff		CALL github.com/mgomes/vibescript/internal/runtime.reserveFallbackSearchScratch(SB)	
  members_string.go:1306	0x6d000a		4885c0			TESTQ AX, AX										
  members_string.go:1306	0x6d000d		0f859b010000		JNE 0x6d01ae										
  members_string.go:1309	0x6d0013		488d8424e8000000	LEAQ 0xe8(SP), AX									
  members_string.go:1309	0x6d001b		488b9c24d0010000	MOVQ 0x1d0(SP), BX									
  members_string.go:1309	0x6d0023		488b8c24d8010000	MOVQ 0x1d8(SP), CX									
  members_string.go:1309	0x6d002b		e850add9ff		CALL runtime.stringtoslicerune(SB)							
  members_string.go:1309	0x6d0030		48899c2488010000	MOVQ BX, 0x188(SP)									
  members_string.go:1309	0x6d0038		48898424a8010000	MOVQ AX, 0x1a8(SP)									
  members_string.go:1309	0x6d0040		48898c2490010000	MOVQ CX, 0x190(SP)									
  members_string.go:1310	0x6d0048		488d442468		LEAQ 0x68(SP), AX									
  members_string.go:1310	0x6d004d		488b9c24e0010000	MOVQ 0x1e0(SP), BX									
  members_string.go:1310	0x6d0055		488b8c24e8010000	MOVQ 0x1e8(SP), CX									
  members_string.go:1310	0x6d005d		0f1f00			NOPL 0(AX)										
  members_string.go:1310	0x6d0060		e81badd9ff		CALL runtime.stringtoslicerune(SB)							
  members_string.go:1311	0x6d0065		488b942488010000	MOVQ 0x188(SP), DX									
  members_string.go:1311	0x6d006d		488bb424f0010000	MOVQ 0x1f0(SP), SI									
  members_string.go:1311	0x6d0075		4839f2			CMPQ DX, SI										
  members_string.go:1311	0x6d0078		0f8c1c010000		JL 0x6d019a										
  members_string.go:1311	0x6d007e		6690			NOPW											
  members_string.go:1314	0x6d0080		4885db			TESTQ BX, BX										
  members_string.go:1314	0x6d0083		0f8401010000		JE 0x6d018a										
  members_string.go:1317	0x6d0089		4989d0			MOVQ DX, R8										
  members_string.go:1317	0x6d008c		4829da			SUBQ BX, DX										
  members_string.go:1318	0x6d008f		4839d6			CMPQ SI, DX										
  members_string.go:1318	0x6d0092		0f8fde000000		JG 0x6d0176										
  members_string.go:1318	0x6d0098		0f1f840000000000	NOPL 0(AX)(AX*1)									
  members_string.go:1311	0x6d00a0		4939f0			CMPQ R8, SI										
  members_string.go:1328	0x6d00a3		0f8282010000		JB 0x6d022b										
  members_string.go:1310	0x6d00a9		48899c2470010000	MOVQ BX, 0x170(SP)									
  members_string.go:1310	0x6d00b1		48898424a0010000	MOVQ AX, 0x1a0(SP)									
  members_string.go:1310	0x6d00b9		48898c2478010000	MOVQ CX, 0x178(SP)									
  members_string.go:1328	0x6d00c1		4929f0			SUBQ SI, R8										
  members_string.go:1328	0x6d00c4		488bbc2490010000	MOVQ 0x190(SP), DI									
  members_string.go:1328	0x6d00cc		4829f7			SUBQ SI, DI										
  members_string.go:1328	0x6d00cf		488b9424a8010000	MOVQ 0x1a8(SP), DX									
  members_string.go:1328	0x6d00d7		488d1cb2		LEAQ 0(DX)(SI*4), BX									
  members_string.go:1328	0x6d00db		488d442448		LEAQ 0x48(SP), AX									
  members_string.go:1328	0x6d00e0		4c89c1			MOVQ R8, CX										
  members_string.go:1328	0x6d00e3		e818aed9ff		CALL runtime.slicerunetostring(SB)							
  members_string.go:1328	0x6d00e8		48898424b0010000	MOVQ AX, 0x1b0(SP)									
  members_string.go:1328	0x6d00f0		48899c2498010000	MOVQ BX, 0x198(SP)									
  members_string.go:1329	0x6d00f8		488d442428		LEAQ 0x28(SP), AX									
  members_string.go:1329	0x6d00fd		488b9c24a0010000	MOVQ 0x1a0(SP), BX									
  members_string.go:1329	0x6d0105		488b8c2470010000	MOVQ 0x170(SP), CX									
  members_string.go:1329	0x6d010d		488bbc2478010000	MOVQ 0x178(SP), DI									
  members_string.go:1329	0x6d0115		e8e6add9ff		CALL runtime.slicerunetostring(SB)							
  strings.go:1264		0x6d011a		4889c1			MOVQ AX, CX										
  strings.go:1264		0x6d011d		4889df			MOVQ BX, DI										
  strings.go:1264		0x6d0120		488b8424b0010000	MOVQ 0x1b0(SP), AX									
  strings.go:1264		0x6d0128		488b9c2498010000	MOVQ 0x198(SP), BX									
  strings.go:1264		0x6d0130		e86b4fd4ff		CALL internal/stringslite.Index(SB)							
  members_string.go:1330	0x6d0135		4885c0			TESTQ AX, AX										
  members_string.go:1330	0x6d0138		7c28			JL 0x6d0162										
  members_string.go:1333	0x6d013a		488b942498010000	MOVQ 0x198(SP), DX									
  members_string.go:1333	0x6d0142		4839d0			CMPQ AX, DX										
  members_string.go:1333	0x6d0145		0f87db000000		JA 0x6d0226										
  strings.go:1264		0x6d014b		4889842468010000	MOVQ AX, 0x168(SP)									
  utf8.go:448			0x6d0153		31d2			XORL DX, DX										
  utf8.go:448			0x6d0155		488bb424b0010000	MOVQ 0x1b0(SP), SI									
  utf8.go:448			0x6d015d		31c9			XORL CX, CX										
  utf8.go:448			0x6d015f		90			NOPL											
  utf8.go:448			0x6d0160		eb65			JMP 0x6d01c7										
  members_string.go:1331	0x6d0162		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1331	0x6d0169		31db			XORL BX, BX										
  members_string.go:1331	0x6d016b		31c9			XORL CX, CX										
  members_string.go:1331	0x6d016d		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1331	0x6d0174		5d			POPQ BP											
  members_string.go:1331	0x6d0175		c3			RET											
  members_string.go:1319	0x6d0176		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1319	0x6d017d		31db			XORL BX, BX										
  members_string.go:1319	0x6d017f		31c9			XORL CX, CX										
  members_string.go:1319	0x6d0181		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1319	0x6d0188		5d			POPQ BP											
  members_string.go:1319	0x6d0189		c3			RET											
  members_string.go:1315	0x6d018a		4889f0			MOVQ SI, AX										
  members_string.go:1315	0x6d018d		31db			XORL BX, BX										
  members_string.go:1315	0x6d018f		31c9			XORL CX, CX										
  members_string.go:1315	0x6d0191		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1315	0x6d0198		5d			POPQ BP											
  members_string.go:1315	0x6d0199		c3			RET											
  members_string.go:1312	0x6d019a		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1312	0x6d01a1		31db			XORL BX, BX										
  members_string.go:1312	0x6d01a3		31c9			XORL CX, CX										
  members_string.go:1312	0x6d01a5		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1312	0x6d01ac		5d			POPQ BP											
  members_string.go:1312	0x6d01ad		c3			RET											
  members_string.go:1307	0x6d01ae		4889d9			MOVQ BX, CX										
  members_string.go:1307	0x6d01b1		4889c3			MOVQ AX, BX										
  members_string.go:1307	0x6d01b4		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1307	0x6d01bb		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1307	0x6d01c2		5d			POPQ BP											
  members_string.go:1307	0x6d01c3		c3			RET											
  utf8.go:449			0x6d01c4		48ffc1			INCQ CX											
  utf8.go:448			0x6d01c7		4839d0			CMPQ AX, DX										
  utf8.go:448			0x6d01ca		7e41			JLE 0x6d020d										
  utf8.go:448			0x6d01cc		0fb63c16		MOVZX 0(SI)(DX*1), DI									
  utf8.go:448			0x6d01d0		83ff7f			CMPL DI, $0x7f										
  utf8.go:448			0x6d01d3		7f05			JG 0x6d01da										
  utf8.go:448			0x6d01d5		48ffc2			INCQ DX											
  utf8.go:448			0x6d01d8		ebea			JMP 0x6d01c4										
  utf8.go:448			0x6d01da		48898c2480010000	MOVQ CX, 0x180(SP)									
  utf8.go:448			0x6d01e2		4889c3			MOVQ AX, BX										
  utf8.go:448			0x6d01e5		4889d1			MOVQ DX, CX										
  utf8.go:448			0x6d01e8		4889f0			MOVQ SI, AX										
  utf8.go:448			0x6d01eb		e810d0daff		CALL runtime.decoderune(SB)								
  utf8.go:448			0x6d01f0		488b842468010000	MOVQ 0x168(SP), AX									
  utf8.go:449			0x6d01f8		488b8c2480010000	MOVQ 0x180(SP), CX									
  utf8.go:448			0x6d0200		488bb424b0010000	MOVQ 0x1b0(SP), SI									
  utf8.go:449			0x6d0208		4889da			MOVQ BX, DX										
  utf8.go:448			0x6d020b		ebb7			JMP 0x6d01c4										
  members_string.go:1333	0x6d020d		488b9424f0010000	MOVQ 0x1f0(SP), DX									
  members_string.go:1333	0x6d0215		488d040a		LEAQ 0(DX)(CX*1), AX									
  members_string.go:1333	0x6d0219		31db			XORL BX, BX										
  members_string.go:1333	0x6d021b		31c9			XORL CX, CX										
  members_string.go:1333	0x6d021d		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1333	0x6d0224		5d			POPQ BP											
  members_string.go:1333	0x6d0225		c3			RET											
  members_string.go:1333	0x6d0226		e855e0dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1328	0x6d022b		e850e0dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1328	0x6d0230		90			NOPL											
  members_string.go:1305	0x6d0231		4889442408		MOVQ AX, 0x8(SP)									
  members_string.go:1305	0x6d0236		48895c2410		MOVQ BX, 0x10(SP)									
  members_string.go:1305	0x6d023b		48894c2418		MOVQ CX, 0x18(SP)									
  members_string.go:1305	0x6d0240		48897c2420		MOVQ DI, 0x20(SP)									
  members_string.go:1305	0x6d0245		4889742428		MOVQ SI, 0x28(SP)									
  members_string.go:1305	0x6d024a		4c89442430		MOVQ R8, 0x30(SP)									
  members_string.go:1305	0x6d024f		e8ecc3dbff		CALL runtime.morestack_noctxt.abi0(SB)							
  members_string.go:1305	0x6d0254		488b442408		MOVQ 0x8(SP), AX									
  members_string.go:1305	0x6d0259		488b5c2410		MOVQ 0x10(SP), BX									
  members_string.go:1305	0x6d025e		488b4c2418		MOVQ 0x18(SP), CX									
  members_string.go:1305	0x6d0263		488b7c2420		MOVQ 0x20(SP), DI									
  members_string.go:1305	0x6d0268		488b742428		MOVQ 0x28(SP), SI									
  members_string.go:1305	0x6d026d		4c8b442430		MOVQ 0x30(SP), R8									
  members_string.go:1305	0x6d0272		e949fdffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB)		

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneSlice(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:1454	0x6d0980		4c8d6424a0		LEAQ -0x60(SP), R12									
  members_string.go:1454	0x6d0985		4d3b6610		CMPQ R12, 0x10(R14)									
  members_string.go:1454	0x6d0989		0f865b020000		JBE 0x6d0bea										
  members_string.go:1454	0x6d098f		55			PUSHQ BP										
  members_string.go:1454	0x6d0990		4889e5			MOVQ SP, BP										
  members_string.go:1454	0x6d0993		4881ecd8000000		SUBQ $0xd8, SP										
  members_string.go:1454	0x6d099a		48898424e8000000	MOVQ AX, 0xe8(SP)									
  members_string.go:1455	0x6d09a2		4885ff			TESTQ DI, DI										
  members_string.go:1455	0x6d09a5		7c53			JL 0x6d09fa										
  members_string.go:1455	0x6d09a7		4889bc2400010000	MOVQ DI, 0x100(SP)									
  members_string.go:1455	0x6d09af		48898424e8000000	MOVQ AX, 0xe8(SP)									
  members_string.go:1455	0x6d09b7		48899c24f0000000	MOVQ BX, 0xf0(SP)									
  members_string.go:1455	0x6d09bf		90			NOPL											
  members_string.go:1458	0x6d09c0		4885c9			TESTQ CX, CX										
  members_string.go:1458	0x6d09c3		7d67			JGE 0x6d0a2c										
  members_string.go:1455	0x6d09c5		48898c24f8000000	MOVQ CX, 0xf8(SP)									
  ascii_scan_simd_amd64.go:9	0x6d09cd		e86e1bf4ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIVector(SB)		
  ascii_scan_simd_amd64.go:9	0x6d09d2		84c0			TESTL AL, AL										
  members_string.go:1186	0x6d09d4		751a			JNE 0x6d09f0										
  members_string.go:1189	0x6d09d6		90			NOPL											
  utf8.go:448			0x6d09d7		31d2			XORL DX, DX										
  utf8.go:448			0x6d09d9		31f6			XORL SI, SI										
  utf8.go:448			0x6d09db		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  utf8.go:448			0x6d09e3		488b8424e8000000	MOVQ 0xe8(SP), AX									
  utf8.go:448			0x6d09eb		e9b0010000		JMP 0x6d0ba0										
  members_string.go:1459	0x6d09f0		488b8424f0000000	MOVQ 0xf0(SP), AX									
  members_string.go:1459	0x6d09f8		eb11			JMP 0x6d0a0b										
  members_string.go:1456	0x6d09fa		31c0			XORL AX, AX										
  members_string.go:1456	0x6d09fc		31db			XORL BX, BX										
  members_string.go:1456	0x6d09fe		31c9			XORL CX, CX										
  members_string.go:1456	0x6d0a00		89cf			MOVL CX, DI										
  members_string.go:1456	0x6d0a02		4881c4d8000000		ADDQ $0xd8, SP										
  members_string.go:1456	0x6d0a09		5d			POPQ BP											
  members_string.go:1456	0x6d0a0a		c3			RET											
  members_string.go:1459	0x6d0a0b		488b9424f8000000	MOVQ 0xf8(SP), DX									
  members_string.go:1459	0x6d0a13		488d0c10		LEAQ 0(AX)(DX*1), CX									
  members_string.go:1460	0x6d0a17		4885c9			TESTQ CX, CX										
  members_string.go:1460	0x6d0a1a		7c4f			JL 0x6d0a6b										
  members_string.go:1464	0x6d0a1c		488b8424e8000000	MOVQ 0xe8(SP), AX									
  members_string.go:1464	0x6d0a24		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  members_string.go:1464	0x6d0a2c		e8afeeffff		CALL github.com/mgomes/vibescript/internal/runtime.stringByteIndexForRuneOffset(SB)	
  members_string.go:1464	0x6d0a31		84db			TESTL BL, BL										
  members_string.go:1465	0x6d0a33		7425			JE 0x6d0a5a										
  members_string.go:1464	0x6d0a35		48898424b8000000	MOVQ AX, 0xb8(SP)									
  members_string.go:1469	0x6d0a3d		488bbc2400010000	MOVQ 0x100(SP), DI									
  members_string.go:1469	0x6d0a45		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  members_string.go:1469	0x6d0a4d		488b8c24e8000000	MOVQ 0xe8(SP), CX									
  members_string.go:1464	0x6d0a55		4889c2			MOVQ AX, DX										
  members_string.go:1469	0x6d0a58		eb28			JMP 0x6d0a82										
  members_string.go:1466	0x6d0a5a		31c0			XORL AX, AX										
  members_string.go:1466	0x6d0a5c		31db			XORL BX, BX										
  members_string.go:1466	0x6d0a5e		31c9			XORL CX, CX										
  members_string.go:1466	0x6d0a60		89cf			MOVL CX, DI										
  members_string.go:1466	0x6d0a62		4881c4d8000000		ADDQ $0xd8, SP										
  members_string.go:1466	0x6d0a69		5d			POPQ BP											
  members_string.go:1466	0x6d0a6a		c3			RET											
  members_string.go:1461	0x6d0a6b		31c0			XORL AX, AX										
  members_string.go:1461	0x6d0a6d		31db			XORL BX, BX										
  members_string.go:1461	0x6d0a6f		31c9			XORL CX, CX										
  members_string.go:1461	0x6d0a71		89cf			MOVL CX, DI										
  members_string.go:1461	0x6d0a73		4881c4d8000000		ADDQ $0xd8, SP										
  members_string.go:1461	0x6d0a7a		5d			POPQ BP											
  members_string.go:1461	0x6d0a7b		c3			RET											
  members_string.go:1474	0x6d0a7c		4801f0			ADDQ SI, AX										
  members_string.go:1469	0x6d0a7f		48ffcf			DECQ DI											
  members_string.go:1469	0x6d0a82		4885ff			TESTQ DI, DI										
  members_string.go:1469	0x6d0a85		7e6e			JLE 0x6d0af5										
  members_string.go:1470	0x6d0a87		4839c3			CMPQ BX, AX										
  members_string.go:1470	0x6d0a8a		7469			JE 0x6d0af5										
  members_string.go:1473	0x6d0a8c		0f8203010000		JB 0x6d0b95										
  utf8.go:223			0x6d0a92		0fb63401		MOVZX 0(CX)(AX*1), SI									
  members_string.go:1473	0x6d0a96		4989d8			MOVQ BX, R8										
  members_string.go:1473	0x6d0a99		4929c0			SUBQ AX, R8										
  members_string.go:1473	0x6d0a9c		4c8d0c08		LEAQ 0(AX)(CX*1), R9									
  utf8.go:223			0x6d0aa0		4080fe80		CMPL SI, $0x80										
  utf8.go:223			0x6d0aa4		7307			JAE 0x6d0aad										
  utf8.go:223			0x6d0aa6		be01000000		MOVL $0x1, SI										
  members_string.go:1473	0x6d0aab		ebcf			JMP 0x6d0a7c										
  members_string.go:1469	0x6d0aad		4889bc24c8000000	MOVQ DI, 0xc8(SP)									
  members_string.go:1469	0x6d0ab5		48898424c0000000	MOVQ AX, 0xc0(SP)									
  utf8.go:226			0x6d0abd		4c89c8			MOVQ R9, AX										
  utf8.go:226			0x6d0ac0		4c89c3			MOVQ R8, BX										
  utf8.go:226			0x6d0ac3		e838deddff		CALL unicode/utf8.decodeRuneInStringSlow(SB)						
  members_string.go:1474	0x6d0ac8		488b8424c0000000	MOVQ 0xc0(SP), AX									
  utf8.go:223			0x6d0ad0		488b8c24e8000000	MOVQ 0xe8(SP), CX									
  members_string.go:1476	0x6d0ad8		488b9424b8000000	MOVQ 0xb8(SP), DX									
  members_string.go:1469	0x6d0ae0		488bbc24c8000000	MOVQ 0xc8(SP), DI									
  members_string.go:1473	0x6d0ae8		4889de			MOVQ BX, SI										
  members_string.go:1470	0x6d0aeb		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  members_string.go:1473	0x6d0af3		eb87			JMP 0x6d0a7c										
  members_string.go:1476	0x6d0af5		4839c3			CMPQ BX, AX										
  members_string.go:1476	0x6d0af8		0f8292000000		JB 0x6d0b90										
  members_string.go:1476	0x6d0afe		6690			NOPW											
  members_string.go:1476	0x6d0b00		4839c2			CMPQ DX, AX										
  members_string.go:1476	0x6d0b03		0f8782000000		JA 0x6d0b8b										
  members_string.go:1476	0x6d0b09		4829d0			SUBQ DX, AX										
  members_string.go:1476	0x6d0b0c		48898424b0000000	MOVQ AX, 0xb0(SP)									
  members_string.go:1476	0x6d0b14		4889c3			MOVQ AX, BX										
  members_string.go:1476	0x6d0b17		48f7d8			NEGQ AX											
  members_string.go:1476	0x6d0b1a		48c1f83f		SARQ $0x3f, AX										
  members_string.go:1476	0x6d0b1e		4821d0			ANDQ DX, AX										
  members_string.go:1476	0x6d0b21		4801c8			ADDQ CX, AX										
  members_string.go:1476	0x6d0b24		48898424d0000000	MOVQ AX, 0xd0(SP)									
  members_string.go:1441	0x6d0b2c		e82fe4ddff		CALL unicode/utf8.ValidString(SB)							
  members_string.go:1441	0x6d0b31		88442427		MOVB AL, 0x27(SP)									
  members_string.go:1441	0x6d0b35		84c0			TESTL AL, AL										
  members_string.go:1441	0x6d0b37		7412			JE 0x6d0b4b										
  members_string.go:1476	0x6d0b39		488b9c24b0000000	MOVQ 0xb0(SP), BX									
  members_string.go:1476	0x6d0b41		488b8424d0000000	MOVQ 0xd0(SP), AX									
  members_string.go:1476	0x6d0b49		eb2a			JMP 0x6d0b75										
  members_string.go:1444	0x6d0b4b		488d442428		LEAQ 0x28(SP), AX									
  members_string.go:1444	0x6d0b50		488b9c24d0000000	MOVQ 0xd0(SP), BX									
  members_string.go:1444	0x6d0b58		488b8c24b0000000	MOVQ 0xb0(SP), CX									
  members_string.go:1444	0x6d0b60		e81ba2d9ff		CALL runtime.stringtoslicerune(SB)							
  members_string.go:1444	0x6d0b65		4889cf			MOVQ CX, DI										
  members_string.go:1444	0x6d0b68		4889d9			MOVQ BX, CX										
  members_string.go:1444	0x6d0b6b		4889c3			MOVQ AX, BX										
  members_string.go:1444	0x6d0b6e		31c0			XORL AX, AX										
  members_string.go:1444	0x6d0b70		e88ba3d9ff		CALL runtime.slicerunetostring(SB)							
  members_string.go:1476	0x6d0b75		0fb64c2427		MOVZX 0x27(SP), CX									
  members_string.go:1476	0x6d0b7a		83f101			XORL $0x1, CX										
  members_string.go:1476	0x6d0b7d		bf01000000		MOVL $0x1, DI										
  members_string.go:1476	0x6d0b82		4881c4d8000000		ADDQ $0xd8, SP										
  members_string.go:1476	0x6d0b89		5d			POPQ BP											
  members_string.go:1476	0x6d0b8a		c3			RET											
  members_string.go:1476	0x6d0b8b		e8f0d6dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1476	0x6d0b90		e8ebd6dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1473	0x6d0b95		e8e6d6dbff		CALL runtime.panicBounds(SB)								
  utf8.go:449			0x6d0b9a		48ffc2			INCQ DX											
  utf8.go:449			0x6d0b9d		0f1f00			NOPL 0(AX)										
  utf8.go:448			0x6d0ba0		4839f3			CMPQ BX, SI										
  utf8.go:448			0x6d0ba3		7e3d			JLE 0x6d0be2										
  utf8.go:448			0x6d0ba5		440fb60430		MOVZX 0(AX)(SI*1), R8									
  utf8.go:448			0x6d0baa		4183f87f		CMPL R8, $0x7f										
  utf8.go:448			0x6d0bae		7f05			JG 0x6d0bb5										
  utf8.go:448			0x6d0bb0		48ffc6			INCQ SI											
  utf8.go:448			0x6d0bb3		ebe5			JMP 0x6d0b9a										
  utf8.go:448			0x6d0bb5		48899424a8000000	MOVQ DX, 0xa8(SP)									
  utf8.go:448			0x6d0bbd		4889f1			MOVQ SI, CX										
  utf8.go:448			0x6d0bc0		e83bc6daff		CALL runtime.decoderune(SB)								
  utf8.go:448			0x6d0bc5		488b8424e8000000	MOVQ 0xe8(SP), AX									
  utf8.go:449			0x6d0bcd		488b9424a8000000	MOVQ 0xa8(SP), DX									
  utf8.go:449			0x6d0bd5		4889de			MOVQ BX, SI										
  utf8.go:448			0x6d0bd8		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  utf8.go:448			0x6d0be0		ebb8			JMP 0x6d0b9a										
  members_string.go:1459	0x6d0be2		4889d0			MOVQ DX, AX										
  members_string.go:1459	0x6d0be5		e921feffff		JMP 0x6d0a0b										
  members_string.go:1454	0x6d0bea		4889442408		MOVQ AX, 0x8(SP)									
  members_string.go:1454	0x6d0bef		48895c2410		MOVQ BX, 0x10(SP)									
  members_string.go:1454	0x6d0bf4		48894c2418		MOVQ CX, 0x18(SP)									
  members_string.go:1454	0x6d0bf9		48897c2420		MOVQ DI, 0x20(SP)									
  members_string.go:1454	0x6d0bfe		6690			NOPW											
  members_string.go:1454	0x6d0c00		e83bbadbff		CALL runtime.morestack_noctxt.abi0(SB)							
  members_string.go:1454	0x6d0c05		488b442408		MOVQ 0x8(SP), AX									
  members_string.go:1454	0x6d0c0a		488b5c2410		MOVQ 0x10(SP), BX									
  members_string.go:1454	0x6d0c0f		488b4c2418		MOVQ 0x18(SP), CX									
  members_string.go:1454	0x6d0c14		488b7c2420		MOVQ 0x20(SP), DI									
  members_string.go:1454	0x6d0c19		e962fdffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneSlice(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func2(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:3782	0x75aa60		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:3782	0x75aa64		0f861e010000		JBE 0x75ab88									
  members_string.go:3782	0x75aa6a		55			PUSHQ BP									
  members_string.go:3782	0x75aa6b		4889e5			MOVQ SP, BP									
  members_string.go:3782	0x75aa6e		4883ec40		SUBQ $0x40, SP									
  members_string.go:3782	0x75aa72		48898c2480000000	MOVQ CX, 0x80(SP)								
  members_string.go:3782	0x75aa7a		4889bc2488000000	MOVQ DI, 0x88(SP)								
  members_string.go:3782	0x75aa82		4c89842498000000	MOVQ R8, 0x98(SP)								
  members_string.go:3783	0x75aa8a		4d85c9			TESTQ R9, R9									
  members_string.go:3783	0x75aa8d		7466			JE 0x75aaf5									
  errors.go:26			0x75aa8f		488d0554730600		LEAQ 0x67354(IP), AX								
  errors.go:26			0x75aa96		bb25000000		MOVL $0x25, BX									
  errors.go:26			0x75aa9b		31c9			XORL CX, CX									
  errors.go:26			0x75aa9d		31ff			XORL DI, DI									
  errors.go:26			0x75aa9f		89fe			MOVL DI, SI									
  errors.go:26			0x75aaa1		e81a34d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75aaa6		4885c0			TESTQ AX, AX									
  errors.go:26			0x75aaa9		7536			JNE 0x75aae1									
  errors.go:31			0x75aaab		90			NOPL										
  errors.go:65			0x75aaac		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75aab1		488d1dd8413900		LEAQ 0x3941d8(IP), BX								
  errors.go:65			0x75aab8		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75aabd		0f1f00			NOPL 0(AX)									
  errors.go:65			0x75aac0		e8db68ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75aac5		48c7400825000000	MOVQ $0x25, 0x8(AX)								
  errors.go:65			0x75aacd		488d1516730600		LEAQ 0x67316(IP), DX								
  errors.go:65			0x75aad4		488910			MOVQ DX, 0(AX)									
  members_string.go:3784	0x75aad7		4889c3			MOVQ AX, BX									
  members_string.go:3784	0x75aada		488d055f1f3c00		LEAQ 0x3c1f5f(IP), AX								
  members_string.go:3784	0x75aae1		31c9			XORL CX, CX									
  members_string.go:3784	0x75aae3		31ff			XORL DI, DI									
  members_string.go:3784	0x75aae5		4889c6			MOVQ AX, SI									
  members_string.go:3784	0x75aae8		4989d8			MOVQ BX, R8									
  members_string.go:3784	0x75aaeb		31c0			XORL AX, AX									
  members_string.go:3784	0x75aaed		31db			XORL BX, BX									
  members_string.go:3784	0x75aaef		4883c440		ADDQ $0x40, SP									
  members_string.go:3784	0x75aaf3		5d			POPQ BP										
  members_string.go:3784	0x75aaf4		c3			RET										
  members_string.go:3786	0x75aaf5		4889d8			MOVQ BX, AX									
  members_string.go:3786	0x75aaf8		4889cb			MOVQ CX, BX									
  members_string.go:3786	0x75aafb		4889f9			MOVQ DI, CX									
  members_string.go:3786	0x75aafe		4889f7			MOVQ SI, DI									
  members_string.go:3786	0x75ab01		e81a18e5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:3786	0x75ab06		4889442438		MOVQ AX, 0x38(SP)								
  members_string.go:3786	0x75ab0b		48895c2428		MOVQ BX, 0x28(SP)								
  ascii_scan_simd_amd64.go:9	0x75ab10		e82b7aebff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIVector(SB)	
  ascii_scan_simd_amd64.go:9	0x75ab15		84c0			TESTL AL, AL									
  members_string.go:1186	0x75ab17		7512			JNE 0x75ab2b									
  members_string.go:1189	0x75ab19		90			NOPL										
  utf8.go:448			0x75ab1a		31d2			XORL DX, DX									
  utf8.go:448			0x75ab1c		4531c9			XORL R9, R9									
  utf8.go:448			0x75ab1f		488b5c2428		MOVQ 0x28(SP), BX								
  utf8.go:448			0x75ab24		488b442438		MOVQ 0x38(SP), AX								
  utf8.go:448			0x75ab29		eb22			JMP 0x75ab4d									
  members_string.go:3786	0x75ab2b		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:3786	0x75ab30		31db			XORL BX, BX									
  members_string.go:3786	0x75ab32		31c9			XORL CX, CX									
  members_string.go:3786	0x75ab34		4889c7			MOVQ AX, DI									
  members_string.go:3786	0x75ab37		89de			MOVL BX, SI									
  members_string.go:3786	0x75ab39		4189c8			MOVL CX, R8									
  members_string.go:3786	0x75ab3c		b802000000		MOVL $0x2, AX									
  members_string.go:3786	0x75ab41		4883c440		ADDQ $0x40, SP									
  members_string.go:3786	0x75ab45		5d			POPQ BP										
  members_string.go:3786	0x75ab46		c3			RET										
  utf8.go:449			0x75ab47		48ffc2			INCQ DX										
  utf8.go:448			0x75ab4a		4989f9			MOVQ DI, R9									
  utf8.go:448			0x75ab4d		4c39cb			CMPQ BX, R9									
  utf8.go:448			0x75ab50		7e31			JLE 0x75ab83									
  utf8.go:448			0x75ab52		420fb63c08		MOVZX 0(AX)(R9*1), DI								
  utf8.go:448			0x75ab57		83ff7f			CMPL DI, $0x7f									
  utf8.go:448			0x75ab5a		7f06			JG 0x75ab62									
  utf8.go:448			0x75ab5c		498d7901		LEAQ 0x1(R9), DI								
  utf8.go:448			0x75ab60		ebe5			JMP 0x75ab47									
  utf8.go:448			0x75ab62		4889542430		MOVQ DX, 0x30(SP)								
  utf8.go:448			0x75ab67		4c89c9			MOVQ R9, CX									
  utf8.go:448			0x75ab6a		e89126d2ff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x75ab6f		488b442438		MOVQ 0x38(SP), AX								
  utf8.go:449			0x75ab74		488b542430		MOVQ 0x30(SP), DX								
  utf8.go:449			0x75ab79		4889df			MOVQ BX, DI									
  utf8.go:448			0x75ab7c		488b5c2428		MOVQ 0x28(SP), BX								
  utf8.go:448			0x75ab81		ebc4			JMP 0x75ab47									
  members_string.go:3786	0x75ab83		4889d0			MOVQ DX, AX									
  members_string.go:3786	0x75ab86		eba8			JMP 0x75ab30									
  members_string.go:3782	0x75ab88		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:3782	0x75ab8d		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:3782	0x75ab92		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:3782	0x75ab97		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:3782	0x75ab9c		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:3782	0x75aba1		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:3782	0x75aba6		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:3782	0x75abab		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:3782	0x75abb0		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:3782	0x75abb5		e8861ad3ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:3782	0x75abba		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:3782	0x75abbf		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:3782	0x75abc4		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:3782	0x75abc9		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:3782	0x75abce		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:3782	0x75abd3		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:3782	0x75abd8		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:3782	0x75abdd		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:3782	0x75abe2		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:3782	0x75abe7		e974feffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func2(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func20(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4023	0x75d680		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4023	0x75d684		0f8615010000		JBE 0x75d79f									
  members_string.go:4023	0x75d68a		55			PUSHQ BP									
  members_string.go:4023	0x75d68b		4889e5			MOVQ SP, BP									
  members_string.go:4023	0x75d68e		4883ec38		SUBQ $0x38, SP									
  members_string.go:4023	0x75d692		48894c2478		MOVQ CX, 0x78(SP)								
  members_string.go:4023	0x75d697		4889bc2480000000	MOVQ DI, 0x80(SP)								
  members_string.go:4023	0x75d69f		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4024	0x75d6a7		4983f901		CMPQ R9, $0x1									
  members_string.go:4024	0x75d6ab		0f858b000000		JNE 0x75d73c									
  members_string.go:4027	0x75d6b1		49833804		CMPQ 0(R8), $0x4								
  members_string.go:4027	0x75d6b5		7413			JE 0x75d6ca									
  members_string.go:4028	0x75d6b7		31c0			XORL AX, AX									
  members_string.go:4028	0x75d6b9		31db			XORL BX, BX									
  members_string.go:4028	0x75d6bb		31c9			XORL CX, CX									
  members_string.go:4028	0x75d6bd		31ff			XORL DI, DI									
  members_string.go:4028	0x75d6bf		89de			MOVL BX, SI									
  members_string.go:4028	0x75d6c1		4189c8			MOVL CX, R8									
  members_string.go:4028	0x75d6c4		4883c438		ADDQ $0x38, SP									
  members_string.go:4028	0x75d6c8		5d			POPQ BP										
  members_string.go:4028	0x75d6c9		c3			RET										
  members_string.go:4024	0x75d6ca		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4030	0x75d6d2		4889d8			MOVQ BX, AX									
  members_string.go:4030	0x75d6d5		4889cb			MOVQ CX, BX									
  members_string.go:4030	0x75d6d8		4889f9			MOVQ DI, CX									
  members_string.go:4030	0x75d6db		4889f7			MOVQ SI, DI									
  members_string.go:4030	0x75d6de		6690			NOPW										
  members_string.go:4030	0x75d6e0		e83bece4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4030	0x75d6e5		4889442430		MOVQ AX, 0x30(SP)								
  members_string.go:4030	0x75d6ea		48895c2428		MOVQ BX, 0x28(SP)								
  members_string.go:4030	0x75d6ef		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4030	0x75d6f7		488b02			MOVQ 0(DX), AX									
  members_string.go:4030	0x75d6fa		488b4a10		MOVQ 0x10(DX), CX								
  members_string.go:4030	0x75d6fe		488b7a18		MOVQ 0x18(DX), DI								
  members_string.go:4030	0x75d702		488b5a08		MOVQ 0x8(DX), BX								
  members_string.go:4030	0x75d706		e815ece4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:1152	0x75d70b		4889c1			MOVQ AX, CX									
  members_string.go:1152	0x75d70e		4889df			MOVQ BX, DI									
  members_string.go:1152	0x75d711		488b442430		MOVQ 0x30(SP), AX								
  members_string.go:1152	0x75d716		488b5c2428		MOVQ 0x28(SP), BX								
  members_string.go:1152	0x75d71b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:1152	0x75d720		e8fb48ebff		CALL github.com/mgomes/vibescript/internal/runtime.asciiCaseCompareImpl(SB)	
  members_string.go:4030	0x75d725		31db			XORL BX, BX									
  members_string.go:4030	0x75d727		31c9			XORL CX, CX									
  members_string.go:4030	0x75d729		4889c7			MOVQ AX, DI									
  members_string.go:4030	0x75d72c		89de			MOVL BX, SI									
  members_string.go:4030	0x75d72e		4189c8			MOVL CX, R8									
  members_string.go:4030	0x75d731		b802000000		MOVL $0x2, AX									
  members_string.go:4030	0x75d736		4883c438		ADDQ $0x38, SP									
  members_string.go:4030	0x75d73a		5d			POPQ BP										
  members_string.go:4030	0x75d73b		c3			RET										
  errors.go:26			0x75d73c		488d052e710600		LEAQ 0x6712e(IP), AX								
  errors.go:26			0x75d743		bb29000000		MOVL $0x29, BX									
  errors.go:26			0x75d748		31c9			XORL CX, CX									
  errors.go:26			0x75d74a		31ff			XORL DI, DI									
  errors.go:26			0x75d74c		89fe			MOVL DI, SI									
  errors.go:26			0x75d74e		e86d07d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75d753		4885c0			TESTQ AX, AX									
  errors.go:26			0x75d756		7533			JNE 0x75d78b									
  errors.go:31			0x75d758		90			NOPL										
  errors.go:65			0x75d759		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75d75e		488d1d2b153900		LEAQ 0x39152b(IP), BX								
  errors.go:65			0x75d765		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75d76a		e8313cccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75d76f		48c7400829000000	MOVQ $0x29, 0x8(AX)								
  errors.go:65			0x75d777		488d15f3700600		LEAQ 0x670f3(IP), DX								
  errors.go:65			0x75d77e		488910			MOVQ DX, 0(AX)									
  members_string.go:4025	0x75d781		4889c3			MOVQ AX, BX									
  members_string.go:4025	0x75d784		488d05b5f23b00		LEAQ 0x3bf2b5(IP), AX								
  members_string.go:4025	0x75d78b		31c9			XORL CX, CX									
  members_string.go:4025	0x75d78d		31ff			XORL DI, DI									
  members_string.go:4025	0x75d78f		4889c6			MOVQ AX, SI									
  members_string.go:4025	0x75d792		4989d8			MOVQ BX, R8									
  members_string.go:4025	0x75d795		31c0			XORL AX, AX									
  members_string.go:4025	0x75d797		31db			XORL BX, BX									
  members_string.go:4025	0x75d799		4883c438		ADDQ $0x38, SP									
  members_string.go:4025	0x75d79d		5d			POPQ BP										
  members_string.go:4025	0x75d79e		c3			RET										
  members_string.go:4023	0x75d79f		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4023	0x75d7a4		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4023	0x75d7a9		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4023	0x75d7ae		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4023	0x75d7b3		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4023	0x75d7b8		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4023	0x75d7bd		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4023	0x75d7c2		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4023	0x75d7c7		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4023	0x75d7cc		e86feed2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4023	0x75d7d1		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4023	0x75d7d6		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4023	0x75d7db		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4023	0x75d7e0		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4023	0x75d7e5		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4023	0x75d7ea		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4023	0x75d7ef		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4023	0x75d7f4		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4023	0x75d7f9		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4023	0x75d7fe		6690			NOPW										
  members_string.go:4023	0x75d800		e97bfeffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func20(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func21(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4033	0x75d820		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4033	0x75d824		0f8615010000		JBE 0x75d93f									
  members_string.go:4033	0x75d82a		55			PUSHQ BP									
  members_string.go:4033	0x75d82b		4889e5			MOVQ SP, BP									
  members_string.go:4033	0x75d82e		4883ec38		SUBQ $0x38, SP									
  members_string.go:4033	0x75d832		48894c2478		MOVQ CX, 0x78(SP)								
  members_string.go:4033	0x75d837		4889bc2480000000	MOVQ DI, 0x80(SP)								
  members_string.go:4033	0x75d83f		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4034	0x75d847		4983f901		CMPQ R9, $0x1									
  members_string.go:4034	0x75d84b		0f858b000000		JNE 0x75d8dc									
  members_string.go:4037	0x75d851		49833804		CMPQ 0(R8), $0x4								
  members_string.go:4037	0x75d855		7413			JE 0x75d86a									
  members_string.go:4038	0x75d857		31c0			XORL AX, AX									
  members_string.go:4038	0x75d859		31db			XORL BX, BX									
  members_string.go:4038	0x75d85b		31c9			XORL CX, CX									
  members_string.go:4038	0x75d85d		31ff			XORL DI, DI									
  members_string.go:4038	0x75d85f		89de			MOVL BX, SI									
  members_string.go:4038	0x75d861		4189c8			MOVL CX, R8									
  members_string.go:4038	0x75d864		4883c438		ADDQ $0x38, SP									
  members_string.go:4038	0x75d868		5d			POPQ BP										
  members_string.go:4038	0x75d869		c3			RET										
  members_string.go:4034	0x75d86a		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4040	0x75d872		4889d8			MOVQ BX, AX									
  members_string.go:4040	0x75d875		4889cb			MOVQ CX, BX									
  members_string.go:4040	0x75d878		4889f9			MOVQ DI, CX									
  members_string.go:4040	0x75d87b		4889f7			MOVQ SI, DI									
  members_string.go:4040	0x75d87e		6690			NOPW										
  members_string.go:4040	0x75d880		e89beae4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4040	0x75d885		4889442430		MOVQ AX, 0x30(SP)								
  members_string.go:4040	0x75d88a		48895c2428		MOVQ BX, 0x28(SP)								
  members_string.go:4040	0x75d88f		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4040	0x75d897		488b02			MOVQ 0(DX), AX									
  members_string.go:4040	0x75d89a		488b5a08		MOVQ 0x8(DX), BX								
  members_string.go:4040	0x75d89e		488b4a10		MOVQ 0x10(DX), CX								
  members_string.go:4040	0x75d8a2		488b7a18		MOVQ 0x18(DX), DI								
  members_string.go:4040	0x75d8a6		e875eae4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4040	0x75d8ab		4889c1			MOVQ AX, CX									
  members_string.go:4040	0x75d8ae		4889df			MOVQ BX, DI									
  members_string.go:4040	0x75d8b1		488b442430		MOVQ 0x30(SP), AX								
  members_string.go:4040	0x75d8b6		488b5c2428		MOVQ 0x28(SP), BX								
  members_string.go:4040	0x75d8bb		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4040	0x75d8c0		e85b1ff7ff		CALL github.com/mgomes/vibescript/internal/runtime.caseInsensitiveEqual(SB)	
  members_string.go:4040	0x75d8c5		0fb6f8			MOVZX AL, DI									
  members_string.go:4040	0x75d8c8		b801000000		MOVL $0x1, AX									
  members_string.go:4040	0x75d8cd		31db			XORL BX, BX									
  members_string.go:4040	0x75d8cf		31c9			XORL CX, CX									
  members_string.go:4040	0x75d8d1		89de			MOVL BX, SI									
  members_string.go:4040	0x75d8d3		4189c8			MOVL CX, R8									
  members_string.go:4040	0x75d8d6		4883c438		ADDQ $0x38, SP									
  members_string.go:4040	0x75d8da		5d			POPQ BP										
  members_string.go:4040	0x75d8db		c3			RET										
  errors.go:26			0x75d8dc		488d05037a0600		LEAQ 0x67a03(IP), AX								
  errors.go:26			0x75d8e3		bb2a000000		MOVL $0x2a, BX									
  errors.go:26			0x75d8e8		31c9			XORL CX, CX									
  errors.go:26			0x75d8ea		31ff			XORL DI, DI									
  errors.go:26			0x75d8ec		89fe			MOVL DI, SI									
  errors.go:26			0x75d8ee		e8cd05d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75d8f3		4885c0			TESTQ AX, AX									
  errors.go:26			0x75d8f6		7533			JNE 0x75d92b									
  errors.go:31			0x75d8f8		90			NOPL										
  errors.go:65			0x75d8f9		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75d8fe		488d1d8b133900		LEAQ 0x39138b(IP), BX								
  errors.go:65			0x75d905		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75d90a		e8913accff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75d90f		48c740082a000000	MOVQ $0x2a, 0x8(AX)								
  errors.go:65			0x75d917		488d15c8790600		LEAQ 0x679c8(IP), DX								
  errors.go:65			0x75d91e		488910			MOVQ DX, 0(AX)									
  members_string.go:4035	0x75d921		4889c3			MOVQ AX, BX									
  members_string.go:4035	0x75d924		488d0515f13b00		LEAQ 0x3bf115(IP), AX								
  members_string.go:4035	0x75d92b		31c9			XORL CX, CX									
  members_string.go:4035	0x75d92d		31ff			XORL DI, DI									
  members_string.go:4035	0x75d92f		4889c6			MOVQ AX, SI									
  members_string.go:4035	0x75d932		4989d8			MOVQ BX, R8									
  members_string.go:4035	0x75d935		31c0			XORL AX, AX									
  members_string.go:4035	0x75d937		31db			XORL BX, BX									
  members_string.go:4035	0x75d939		4883c438		ADDQ $0x38, SP									
  members_string.go:4035	0x75d93d		5d			POPQ BP										
  members_string.go:4035	0x75d93e		c3			RET										
  members_string.go:4033	0x75d93f		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4033	0x75d944		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4033	0x75d949		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4033	0x75d94e		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4033	0x75d953		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4033	0x75d958		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4033	0x75d95d		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4033	0x75d962		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4033	0x75d967		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4033	0x75d96c		e8cfecd2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4033	0x75d971		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4033	0x75d976		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4033	0x75d97b		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4033	0x75d980		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4033	0x75d985		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4033	0x75d98a		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4033	0x75d98f		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4033	0x75d994		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4033	0x75d999		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4033	0x75d99e		6690			NOPW										
  members_string.go:4033	0x75d9a0		e97bfeffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func21(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func22(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4043	0x75d9c0		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4043	0x75d9c4		0f8684000000		JBE 0x75da4e									
  members_string.go:4043	0x75d9ca		55			PUSHQ BP									
  members_string.go:4043	0x75d9cb		4889e5			MOVQ SP, BP									
  members_string.go:4043	0x75d9ce		4883ec70		SUBQ $0x70, SP									
  members_string.go:4043	0x75d9d2		48898c24b0000000	MOVQ CX, 0xb0(SP)								
  members_string.go:4043	0x75d9da		4889bc24b8000000	MOVQ DI, 0xb8(SP)								
  members_string.go:4043	0x75d9e2		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4044	0x75d9ea		4c891c24		MOVQ R11, 0(SP)									
  members_string.go:4044	0x75d9ee		488b942480000000	MOVQ 0x80(SP), DX								
  members_string.go:4044	0x75d9f6		4889542408		MOVQ DX, 0x8(SP)								
  members_string.go:4044	0x75d9fb		488b942488000000	MOVQ 0x88(SP), DX								
  members_string.go:4044	0x75da03		4889542410		MOVQ DX, 0x10(SP)								
  members_string.go:4044	0x75da08		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4044	0x75da10		4889542418		MOVQ DX, 0x18(SP)								
  members_string.go:4044	0x75da15		488b942498000000	MOVQ 0x98(SP), DX								
  members_string.go:4044	0x75da1d		4889542420		MOVQ DX, 0x20(SP)								
  members_string.go:4044	0x75da22		488d05bc840500		LEAQ 0x584bc(IP), AX								
  members_string.go:4044	0x75da29		4d89d3			MOVQ R10, R11									
  members_string.go:4044	0x75da2c		4d89ca			MOVQ R9, R10									
  members_string.go:4044	0x75da2f		4d89c1			MOVQ R8, R9									
  members_string.go:4044	0x75da32		4989f0			MOVQ SI, R8									
  members_string.go:4044	0x75da35		4889fe			MOVQ DI, SI									
  members_string.go:4044	0x75da38		4889cf			MOVQ CX, DI									
  members_string.go:4044	0x75da3b		4889d9			MOVQ BX, CX									
  members_string.go:4044	0x75da3e		bb0f000000		MOVL $0xf, BX									
  members_string.go:4044	0x75da43		e8b8ebfdff		CALL github.com/mgomes/vibescript/internal/runtime.comparableBetween(SB)	
  members_string.go:4044	0x75da48		4883c470		ADDQ $0x70, SP									
  members_string.go:4044	0x75da4c		5d			POPQ BP										
  members_string.go:4044	0x75da4d		c3			RET										
  members_string.go:4043	0x75da4e		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4043	0x75da53		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4043	0x75da58		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4043	0x75da5d		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4043	0x75da62		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4043	0x75da67		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4043	0x75da6c		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4043	0x75da71		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4043	0x75da76		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4043	0x75da7b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4043	0x75da80		e8bbebd2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4043	0x75da85		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4043	0x75da8a		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4043	0x75da8f		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4043	0x75da94		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4043	0x75da99		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4043	0x75da9e		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4043	0x75daa3		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4043	0x75daa8		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4043	0x75daad		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4043	0x75dab2		e909ffffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func22(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func23(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4047	0x75dac0		4c8da42410ffffff	LEAQ 0xffffff10(SP), R12									
  members_string.go:4047	0x75dac8		4d3b6610		CMPQ R12, 0x10(R14)										
  members_string.go:4047	0x75dacc		0f863e080000		JBE 0x75e310											
  members_string.go:4047	0x75dad2		55			PUSHQ BP											
  members_string.go:4047	0x75dad3		4889e5			MOVQ SP, BP											
  members_string.go:4047	0x75dad6		4881ec68010000		SUBQ $0x168, SP											
  members_string.go:4047	0x75dadd		48898c24a8010000	MOVQ CX, 0x1a8(SP)										
  members_string.go:4047	0x75dae5		4889bc24b0010000	MOVQ DI, 0x1b0(SP)										
  members_string.go:4047	0x75daed		4c898424c0010000	MOVQ R8, 0x1c0(SP)										
  members_string.go:4048	0x75daf5		4d85db			TESTQ R11, R11											
  members_string.go:4048	0x75daf8		7405			JE 0x75daff											
  members_string.go:4048	0x75dafa		498b13			MOVQ 0(R11), DX											
  members_string.go:4048	0x75dafd		eb02			JMP 0x75db01											
  members_string.go:4048	0x75daff		31d2			XORL DX, DX											
  members_string.go:4048	0x75db01		4885d2			TESTQ DX, DX											
  members_string.go:4048	0x75db04		0f8f63030000		JG 0x75de6d											
  members_string.go:4051	0x75db0a		4d85c9			TESTQ R9, R9											
  members_string.go:4051	0x75db0d		7406			JE 0x75db15											
  members_string.go:4051	0x75db0f		4983f902		CMPQ R9, $0x2											
  members_string.go:4051	0x75db13		7e66			JLE 0x75db7b											
  errors.go:26			0x75db15		488d057bb30600		LEAQ 0x6b37b(IP), AX										
  errors.go:26			0x75db1c		bb32000000		MOVL $0x32, BX											
  errors.go:26			0x75db21		31c9			XORL CX, CX											
  errors.go:26			0x75db23		31ff			XORL DI, DI											
  errors.go:26			0x75db25		89fe			MOVL DI, SI											
  errors.go:26			0x75db27		e89403d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75db2c		4885c0			TESTQ AX, AX											
  errors.go:26			0x75db2f		7533			JNE 0x75db64											
  errors.go:31			0x75db31		90			NOPL												
  errors.go:65			0x75db32		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75db37		488d1d52113900		LEAQ 0x391152(IP), BX										
  errors.go:65			0x75db3e		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75db43		e85838ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75db48		48c7400832000000	MOVQ $0x32, 0x8(AX)										
  errors.go:65			0x75db50		488d1540b30600		LEAQ 0x6b340(IP), DX										
  errors.go:65			0x75db57		488910			MOVQ DX, 0(AX)											
  members_string.go:4052	0x75db5a		4889c3			MOVQ AX, BX											
  members_string.go:4052	0x75db5d		488d05dcee3b00		LEAQ 0x3beedc(IP), AX										
  members_string.go:4052	0x75db64		31c9			XORL CX, CX											
  members_string.go:4052	0x75db66		31ff			XORL DI, DI											
  members_string.go:4052	0x75db68		4889c6			MOVQ AX, SI											
  members_string.go:4052	0x75db6b		4989d8			MOVQ BX, R8											
  members_string.go:4052	0x75db6e		31c0			XORL AX, AX											
  members_string.go:4052	0x75db70		31db			XORL BX, BX											
  members_string.go:4052	0x75db72		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4052	0x75db79		5d			POPQ BP												
  members_string.go:4052	0x75db7a		c3			RET												
  members_string.go:4048	0x75db7b		4889842498010000	MOVQ AX, 0x198(SP)										
  members_string.go:4048	0x75db83		4c899c24d8010000	MOVQ R11, 0x1d8(SP)										
  members_string.go:4048	0x75db8b		4c898c24c8010000	MOVQ R9, 0x1c8(SP)										
  members_string.go:4048	0x75db93		4889b42408010000	MOVQ SI, 0x108(SP)										
  members_string.go:4048	0x75db9b		4c898424c0010000	MOVQ R8, 0x1c0(SP)										
  members_string.go:4048	0x75dba3		4c899424d0010000	MOVQ R10, 0x1d0(SP)										
  members_string.go:4048	0x75dbab		4889bc2430010000	MOVQ DI, 0x130(SP)										
  members_string.go:4048	0x75dbb3		48898c2400010000	MOVQ CX, 0x100(SP)										
  members_string.go:4048	0x75dbbb		48899c24f8000000	MOVQ BX, 0xf8(SP)										
  members_string.go:4054	0x75dbc3		498b7808		MOVQ 0x8(R8), DI										
  members_string.go:4054	0x75dbc7		498b7010		MOVQ 0x10(R8), SI										
  members_string.go:4054	0x75dbcb		498b5018		MOVQ 0x18(R8), DX										
  members_string.go:4054	0x75dbcf		498b08			MOVQ 0(R8), CX											
  members_string.go:4054	0x75dbd2		488d056f6e0500		LEAQ 0x56e6f(IP), AX										
  members_string.go:4054	0x75dbd9		bb0c000000		MOVL $0xc, BX											
  members_string.go:4054	0x75dbde		4989d0			MOVQ DX, R8											
  members_string.go:4054	0x75dbe1		e87a44fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4055	0x75dbe6		4885ff			TESTQ DI, DI											
  members_string.go:4055	0x75dbe9		0f8567020000		JNE 0x75de56											
  members_string.go:4054	0x75dbef		48899c24d0000000	MOVQ BX, 0xd0(SP)										
  members_string.go:4054	0x75dbf7		4889842420010000	MOVQ AX, 0x120(SP)										
  members_string.go:4054	0x75dbff		888c24af000000		MOVB CL, 0xaf(SP)										
  members_string.go:4058	0x75dc06		488b8424f8000000	MOVQ 0xf8(SP), AX										
  members_string.go:4058	0x75dc0e		488b9c2400010000	MOVQ 0x100(SP), BX										
  members_string.go:4058	0x75dc16		488b8c2430010000	MOVQ 0x130(SP), CX										
  members_string.go:4058	0x75dc1e		488bbc2408010000	MOVQ 0x108(SP), DI										
  members_string.go:4058	0x75dc26		e8f5e6e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  members_string.go:4058	0x75dc2b		4889842418010000	MOVQ AX, 0x118(SP)										
  members_string.go:4058	0x75dc33		48899c24c8000000	MOVQ BX, 0xc8(SP)										
  members_string.go:4059	0x75dc3b		4889c1			MOVQ AX, CX											
  members_string.go:4059	0x75dc3e		4889df			MOVQ BX, DI											
  members_string.go:4059	0x75dc41		488bb42420010000	MOVQ 0x120(SP), SI										
  members_string.go:4059	0x75dc49		4c8b8424d0000000	MOVQ 0xd0(SP), R8										
  members_string.go:4059	0x75dc51		440fb68c24af000000	MOVZX 0xaf(SP), R9										
  members_string.go:4059	0x75dc5a		488d05e76d0500		LEAQ 0x56de7(IP), AX										
  members_string.go:4059	0x75dc61		bb0c000000		MOVL $0xc, BX											
  members_string.go:4059	0x75dc66		e8155bf7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)			
  members_string.go:4059	0x75dc6b		4885c0			TESTQ AX, AX											
  members_string.go:4059	0x75dc6e		0f85cb010000		JNE 0x75de3f											
  members_string.go:4051	0x75dc74		488b9424c8010000	MOVQ 0x1c8(SP), DX										
  members_string.go:4051	0x75dc7c		0f1f4000		NOPL 0(AX)											
  members_string.go:4051	0x75dc80		4883fa02		CMPQ DX, $0x2											
  members_string.go:4074	0x75dc84		7408			JE 0x75dc8e											
  members_string.go:4074	0x75dc86		4531d2			XORL R10, R10											
  members_string.go:4074	0x75dc89		e959020000		JMP 0x75dee7											
  members_string.go:4075	0x75dc8e		488b9424c0010000	MOVQ 0x1c0(SP), DX										
  members_string.go:4075	0x75dc96		488b4220		MOVQ 0x20(DX), AX										
  members_string.go:4075	0x75dc9a		488b5a28		MOVQ 0x28(DX), BX										
  members_string.go:4075	0x75dc9e		488b4a30		MOVQ 0x30(DX), CX										
  members_string.go:4075	0x75dca2		488b7a38		MOVQ 0x38(DX), DI										
  members_string.go:4075	0x75dca6		e8157dfdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)				
  members_string.go:4076	0x75dcab		4885db			TESTQ BX, BX											
  members_string.go:4076	0x75dcae		7468			JE 0x75dd18											
  errors.go:26			0x75dcb0		488d0599270600		LEAQ 0x62799(IP), AX										
  errors.go:26			0x75dcb7		bb23000000		MOVL $0x23, BX											
  errors.go:26			0x75dcbc		31c9			XORL CX, CX											
  errors.go:26			0x75dcbe		31ff			XORL DI, DI											
  errors.go:26			0x75dcc0		89fe			MOVL DI, SI											
  errors.go:26			0x75dcc2		e8f901d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75dcc7		4885c0			TESTQ AX, AX											
  errors.go:26			0x75dcca		7535			JNE 0x75dd01											
  errors.go:31			0x75dccc		90			NOPL												
  errors.go:65			0x75dccd		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75dcd2		488d1db70f3900		LEAQ 0x390fb7(IP), BX										
  errors.go:65			0x75dcd9		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75dcde		6690			NOPW												
  errors.go:65			0x75dce0		e8bb36ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75dce5		48c7400823000000	MOVQ $0x23, 0x8(AX)										
  errors.go:65			0x75dced		488d155c270600		LEAQ 0x6275c(IP), DX										
  errors.go:65			0x75dcf4		488910			MOVQ DX, 0(AX)											
  members_string.go:4077	0x75dcf7		4889c3			MOVQ AX, BX											
  members_string.go:4077	0x75dcfa		488d053fed3b00		LEAQ 0x3bed3f(IP), AX										
  members_string.go:4077	0x75dd01		31c9			XORL CX, CX											
  members_string.go:4077	0x75dd03		31ff			XORL DI, DI											
  members_string.go:4077	0x75dd05		4889c6			MOVQ AX, SI											
  members_string.go:4077	0x75dd08		4989d8			MOVQ BX, R8											
  members_string.go:4077	0x75dd0b		31c0			XORL AX, AX											
  members_string.go:4077	0x75dd0d		31db			XORL BX, BX											
  members_string.go:4077	0x75dd0f		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4077	0x75dd16		5d			POPQ BP												
  members_string.go:4077	0x75dd17		c3			RET												
  members_string.go:4079	0x75dd18		488b9c24c8000000	MOVQ 0xc8(SP), BX										
  members_string.go:4079	0x75dd20		4889c1			MOVQ AX, CX											
  members_string.go:4079	0x75dd23		488b842418010000	MOVQ 0x118(SP), AX										
  members_string.go:4079	0x75dd2b		e8f01cf7ff		CALL github.com/mgomes/vibescript/internal/runtime.stringEffectiveOffset(SB)			
  members_string.go:4079	0x75dd30		84db			TESTL BL, BL											
  members_string.go:4080	0x75dd32		7449			JE 0x75dd7d											
  members_string.go:4079	0x75dd34		48898424d8000000	MOVQ AX, 0xd8(SP)										
  ascii_scan_simd_amd64.go:9	0x75dd3c		488b842418010000	MOVQ 0x118(SP), AX										
  ascii_scan_simd_amd64.go:9	0x75dd44		488b9c24c8000000	MOVQ 0xc8(SP), BX										
  ascii_scan_simd_amd64.go:9	0x75dd4c		e8ef47ebff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIVector(SB)			
  ascii_scan_simd_amd64.go:9	0x75dd51		84c0			TESTL AL, AL											
  members_string.go:1186	0x75dd53		751b			JNE 0x75dd70											
  members_string.go:1189	0x75dd55		90			NOPL												
  utf8.go:448			0x75dd56		31d2			XORL DX, DX											
  utf8.go:448			0x75dd58		4531db			XORL R11, R11											
  utf8.go:448			0x75dd5b		488bb424c8000000	MOVQ 0xc8(SP), SI										
  utf8.go:448			0x75dd63		488bbc2418010000	MOVQ 0x118(SP), DI										
  utf8.go:448			0x75dd6b		e950050000		JMP 0x75e2c0											
  members_string.go:4086	0x75dd70		488b8424c8000000	MOVQ 0xc8(SP), AX										
  members_string.go:4086	0x75dd78		e95b010000		JMP 0x75ded8											
  members_string.go:4081	0x75dd7d		488b842420010000	MOVQ 0x120(SP), AX										
  members_string.go:4081	0x75dd85		488b9c24d0000000	MOVQ 0xd0(SP), BX										
  members_string.go:4081	0x75dd8d		e88ed2faff		CALL github.com/mgomes/vibescript/internal/runtime.compileCachedRegex(SB)			
  members_string.go:4081	0x75dd92		4885db			TESTQ BX, BX											
  members_string.go:4081	0x75dd95		0f848e000000		JE 0x75de29											
  members_string.go:4082	0x75dd9b		440f11bc2458010000	MOVUPS X15, 0x158(SP)										
  members_string.go:4082	0x75dda4		7404			JE 0x75ddaa											
  members_string.go:4082	0x75dda6		488b5b08		MOVQ 0x8(BX), BX										
  members_string.go:4082	0x75ddaa		48899c2458010000	MOVQ BX, 0x158(SP)										
  members_string.go:4082	0x75ddb2		48898c2460010000	MOVQ CX, 0x160(SP)										
  errors.go:26			0x75ddba		488d05f9ef0500		LEAQ 0x5eff9(IP), AX										
  errors.go:26			0x75ddc1		bb1e000000		MOVL $0x1e, BX											
  errors.go:26			0x75ddc6		488d8c2458010000	LEAQ 0x158(SP), CX										
  errors.go:26			0x75ddce		bf01000000		MOVL $0x1, DI											
  errors.go:26			0x75ddd3		89fe			MOVL DI, SI											
  errors.go:26			0x75ddd5		e8e600d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75ddda		4885c0			TESTQ AX, AX											
  errors.go:26			0x75dddd		7533			JNE 0x75de12											
  errors.go:31			0x75dddf		90			NOPL												
  errors.go:65			0x75dde0		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75dde5		488d1da40e3900		LEAQ 0x390ea4(IP), BX										
  errors.go:65			0x75ddec		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75ddf1		e8aa35ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75ddf6		48c740081e000000	MOVQ $0x1e, 0x8(AX)										
  errors.go:65			0x75ddfe		488d15b5ef0500		LEAQ 0x5efb5(IP), DX										
  errors.go:65			0x75de05		488910			MOVQ DX, 0(AX)											
  members_string.go:4082	0x75de08		4889c3			MOVQ AX, BX											
  members_string.go:4082	0x75de0b		488d052eec3b00		LEAQ 0x3bec2e(IP), AX										
  members_string.go:4082	0x75de12		31c9			XORL CX, CX											
  members_string.go:4082	0x75de14		31ff			XORL DI, DI											
  members_string.go:4082	0x75de16		4889c6			MOVQ AX, SI											
  members_string.go:4082	0x75de19		4989d8			MOVQ BX, R8											
  members_string.go:4082	0x75de1c		31c0			XORL AX, AX											
  members_string.go:4082	0x75de1e		31db			XORL BX, BX											
  members_string.go:4082	0x75de20		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4082	0x75de27		5d			POPQ BP												
  members_string.go:4082	0x75de28		c3			RET												
  members_string.go:4084	0x75de29		31c0			XORL AX, AX											
  members_string.go:4084	0x75de2b		31db			XORL BX, BX											
  members_string.go:4084	0x75de2d		31c9			XORL CX, CX											
  members_string.go:4084	0x75de2f		31ff			XORL DI, DI											
  members_string.go:4084	0x75de31		89de			MOVL BX, SI											
  members_string.go:4084	0x75de33		4189c8			MOVL CX, R8											
  members_string.go:4084	0x75de36		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4084	0x75de3d		5d			POPQ BP												
  members_string.go:4084	0x75de3e		c3			RET												
  members_string.go:4060	0x75de3f		31c9			XORL CX, CX											
  members_string.go:4060	0x75de41		31ff			XORL DI, DI											
  members_string.go:4060	0x75de43		4889c6			MOVQ AX, SI											
  members_string.go:4060	0x75de46		4989d8			MOVQ BX, R8											
  members_string.go:4060	0x75de49		31c0			XORL AX, AX											
  members_string.go:4060	0x75de4b		31db			XORL BX, BX											
  members_string.go:4060	0x75de4d		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4060	0x75de54		5d			POPQ BP												
  members_string.go:4060	0x75de55		c3			RET												
  members_string.go:4056	0x75de56		31c0			XORL AX, AX											
  members_string.go:4056	0x75de58		31db			XORL BX, BX											
  members_string.go:4056	0x75de5a		31c9			XORL CX, CX											
  members_string.go:4056	0x75de5c		4989f0			MOVQ SI, R8											
  members_string.go:4056	0x75de5f		4889fe			MOVQ DI, SI											
  members_string.go:4056	0x75de62		31ff			XORL DI, DI											
  members_string.go:4056	0x75de64		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4056	0x75de6b		5d			POPQ BP												
  members_string.go:4056	0x75de6c		c3			RET												
  errors.go:26			0x75de6d		488d05a9990600		LEAQ 0x699a9(IP), AX										
  errors.go:26			0x75de74		bb2e000000		MOVL $0x2e, BX											
  errors.go:26			0x75de79		31c9			XORL CX, CX											
  errors.go:26			0x75de7b		31ff			XORL DI, DI											
  errors.go:26			0x75de7d		89fe			MOVL DI, SI											
  errors.go:26			0x75de7f		90			NOPL												
  errors.go:26			0x75de80		e83b00d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75de85		4885c0			TESTQ AX, AX											
  errors.go:26			0x75de88		7537			JNE 0x75dec1											
  errors.go:31			0x75de8a		90			NOPL												
  errors.go:65			0x75de8b		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75de90		488d1df90d3900		LEAQ 0x390df9(IP), BX										
  errors.go:65			0x75de97		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75de9c		0f1f4000		NOPL 0(AX)											
  errors.go:65			0x75dea0		e8fb34ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75dea5		48c740082e000000	MOVQ $0x2e, 0x8(AX)										
  errors.go:65			0x75dead		488d1569990600		LEAQ 0x69969(IP), DX										
  errors.go:65			0x75deb4		488910			MOVQ DX, 0(AX)											
  members_string.go:4049	0x75deb7		4889c3			MOVQ AX, BX											
  members_string.go:4049	0x75deba		488d057feb3b00		LEAQ 0x3beb7f(IP), AX										
  members_string.go:4049	0x75dec1		31c9			XORL CX, CX											
  members_string.go:4049	0x75dec3		31ff			XORL DI, DI											
  members_string.go:4049	0x75dec5		4889c6			MOVQ AX, SI											
  members_string.go:4049	0x75dec8		4989d8			MOVQ BX, R8											
  members_string.go:4049	0x75decb		31c0			XORL AX, AX											
  members_string.go:4049	0x75decd		31db			XORL BX, BX											
  members_string.go:4049	0x75decf		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4049	0x75ded6		5d			POPQ BP												
  members_string.go:4049	0x75ded7		c3			RET												
  members_string.go:4086	0x75ded8		4c8b9424d8000000	MOVQ 0xd8(SP), R10										
  members_string.go:4086	0x75dee0		4939c2			CMPQ R10, AX											
  members_string.go:4089	0x75dee3		4c0f4fd0		CMOVG AX, R10											
  members_string.go:2100	0x75dee7		488b0552664000		MOVQ github.com/mgomes/vibescript/internal/runtime.compiledRegexps(SB), AX			
  members_string.go:4091	0x75deee		90			NOPL												
  members_string.go:2100	0x75deef		488d1d526b0500		LEAQ 0x56b52(IP), BX										
  members_string.go:2100	0x75def6		b90c000000		MOVL $0xc, CX											
  members_string.go:2100	0x75defb		488bbc2418010000	MOVQ 0x118(SP), DI										
  members_string.go:2100	0x75df03		488bb424c8000000	MOVQ 0xc8(SP), SI										
  members_string.go:2100	0x75df0b		4c8b842420010000	MOVQ 0x120(SP), R8										
  members_string.go:2100	0x75df13		4c8b8c24d0000000	MOVQ 0xd0(SP), R9										
  members_string.go:2100	0x75df1b		0f1f440000		NOPL 0(AX)(AX*1)										
  members_string.go:2100	0x75df20		e87b5ef7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexSubmatchFromRuneOffsetWithCache(SB)	
  members_string.go:4092	0x75df25		4885ff			TESTQ DI, DI											
  members_string.go:4092	0x75df28		0f85a5010000		JNE 0x75e0d3											
  members_string.go:4095	0x75df2e		4885c0			TESTQ AX, AX											
  members_string.go:4095	0x75df31		0f8486010000		JE 0x75e0bd											
  members_string.go:2100	0x75df37		48898c24b8000000	MOVQ CX, 0xb8(SP)										
  members_string.go:2100	0x75df3f		48899c24b0000000	MOVQ BX, 0xb0(SP)										
  members_string.go:2100	0x75df47		4889842410010000	MOVQ AX, 0x110(SP)										
  members_string.go:4100	0x75df4f		488b842420010000	MOVQ 0x120(SP), AX										
  members_string.go:4100	0x75df57		488b9c24d0000000	MOVQ 0xd0(SP), BX										
  members_string.go:4100	0x75df5f		90			NOPL												
  members_string.go:4100	0x75df60		e8bb5df7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexSubexpNames(SB)				
  members_string.go:4100	0x75df65		488b9424f8000000	MOVQ 0xf8(SP), DX										
  members_string.go:4100	0x75df6d		48891424		MOVQ DX, 0(SP)											
  members_string.go:4100	0x75df71		488b942400010000	MOVQ 0x100(SP), DX										
  members_string.go:4100	0x75df79		4889542408		MOVQ DX, 0x8(SP)										
  members_string.go:4100	0x75df7e		488b942430010000	MOVQ 0x130(SP), DX										
  members_string.go:4100	0x75df86		4889542410		MOVQ DX, 0x10(SP)										
  members_string.go:4100	0x75df8b		488b942408010000	MOVQ 0x108(SP), DX										
  members_string.go:4100	0x75df93		4889542418		MOVQ DX, 0x18(SP)										
  members_string.go:4100	0x75df98		488b9424c0010000	MOVQ 0x1c0(SP), DX										
  members_string.go:4100	0x75dfa0		4889542420		MOVQ DX, 0x20(SP)										
  members_string.go:4100	0x75dfa5		488b9424c8010000	MOVQ 0x1c8(SP), DX										
  members_string.go:4100	0x75dfad		4889542428		MOVQ DX, 0x28(SP)										
  members_string.go:4100	0x75dfb2		488b9424d0010000	MOVQ 0x1d0(SP), DX										
  members_string.go:4100	0x75dfba		4889542430		MOVQ DX, 0x30(SP)										
  members_string.go:4100	0x75dfbf		488b9424d8010000	MOVQ 0x1d8(SP), DX										
  members_string.go:4100	0x75dfc7		4889542438		MOVQ DX, 0x38(SP)										
  members_string.go:4100	0x75dfcc		488b942478010000	MOVQ 0x178(SP), DX										
  members_string.go:4100	0x75dfd4		4889542440		MOVQ DX, 0x40(SP)										
  members_string.go:4100	0x75dfd9		488b942480010000	MOVQ 0x180(SP), DX										
  members_string.go:4100	0x75dfe1		4889542448		MOVQ DX, 0x48(SP)										
  members_string.go:4100	0x75dfe6		488b942488010000	MOVQ 0x188(SP), DX										
  members_string.go:4100	0x75dfee		4889542450		MOVQ DX, 0x50(SP)										
  members_string.go:4100	0x75dff3		488b942490010000	MOVQ 0x190(SP), DX										
  members_string.go:4100	0x75dffb		4889542458		MOVQ DX, 0x58(SP)										
  members_string.go:4100	0x75e000		488bbc2410010000	MOVQ 0x110(SP), DI										
  members_string.go:4100	0x75e008		488bb424b0000000	MOVQ 0xb0(SP), SI										
  members_string.go:4100	0x75e010		4c8b8424b8000000	MOVQ 0xb8(SP), R8										
  members_string.go:4100	0x75e018		4989c1			MOVQ AX, R9											
  members_string.go:4100	0x75e01b		4989da			MOVQ BX, R10											
  members_string.go:4100	0x75e01e		4989cb			MOVQ CX, R11											
  members_string.go:4100	0x75e021		488b842498010000	MOVQ 0x198(SP), AX										
  members_string.go:4100	0x75e029		488b9c2418010000	MOVQ 0x118(SP), BX										
  members_string.go:4100	0x75e031		488b8c24c8000000	MOVQ 0xc8(SP), CX										
  members_string.go:4100	0x75e039		e8e28ff3ff		CALL github.com/mgomes/vibescript/internal/runtime.newMatchData(SB)				
  members_string.go:4100	0x75e03e		6690			NOPW												
  members_string.go:4101	0x75e040		4885f6			TESTQ SI, SI											
  members_string.go:4101	0x75e043		7567			JNE 0x75e0ac											
  members_string.go:4100	0x75e045		48898424f0000000	MOVQ AX, 0xf0(SP)										
  members_string.go:4100	0x75e04d		48899c24e8000000	MOVQ BX, 0xe8(SP)										
  members_string.go:4100	0x75e055		48898c2428010000	MOVQ CX, 0x128(SP)										
  members_string.go:4100	0x75e05d		4889bc24e0000000	MOVQ DI, 0xe0(SP)										
  aliases.go:1400		0x75e065		90			NOPL												
  value_accessors.go:180	0x75e066		488b942478010000	MOVQ 0x178(SP), DX										
  value_accessors.go:180	0x75e06e		4883fa0f		CMPQ DX, $0xf											
  value_accessors.go:180	0x75e072		7531			JNE 0x75e0a5											
  value_accessors.go:183	0x75e074		4c8b9c2480010000	MOVQ 0x180(SP), R11										
  value_accessors.go:183	0x75e07c		0f1f4000		NOPL 0(AX)											
  value_accessors.go:183	0x75e080		4d85db			TESTQ R11, R11											
  value_accessors.go:183	0x75e083		7414			JE 0x75e099											
  value_accessors.go:183	0x75e085		4c8b2554553f00		MOVQ github.com/mgomes/vibescript/internal/runtime..typeAssert.357(SB), R12			
  value_accessors.go:183	0x75e08c		4d8b2c24		MOVQ 0(R12), R13										
  value_accessors.go:183	0x75e090		458b7b10		MOVL 0x10(R11), R15										
  value_accessors.go:183	0x75e094		e9ac010000		JMP 0x75e245											
  members_string.go:4047	0x75e099		4c89de			MOVQ R11, SI											
  members_string.go:4047	0x75e09c		0f1f4000		NOPL 0(AX)											
  value_accessors.go:183	0x75e0a0		e98f010000		JMP 0x75e234											
  value_accessors.go:183	0x75e0a5		31f6			XORL SI, SI											
  value_accessors.go:183	0x75e0a7		4531c0			XORL R8, R8											
  aliases.go:1367		0x75e0aa		eb3e			JMP 0x75e0ea											
  members_string.go:4102	0x75e0ac		31c0			XORL AX, AX											
  members_string.go:4102	0x75e0ae		31db			XORL BX, BX											
  members_string.go:4102	0x75e0b0		31c9			XORL CX, CX											
  members_string.go:4102	0x75e0b2		31ff			XORL DI, DI											
  members_string.go:4102	0x75e0b4		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4102	0x75e0bb		5d			POPQ BP												
  members_string.go:4102	0x75e0bc		c3			RET												
  members_string.go:4098	0x75e0bd		31c0			XORL AX, AX											
  members_string.go:4098	0x75e0bf		31db			XORL BX, BX											
  members_string.go:4098	0x75e0c1		31c9			XORL CX, CX											
  members_string.go:4098	0x75e0c3		31ff			XORL DI, DI											
  members_string.go:4098	0x75e0c5		89de			MOVL BX, SI											
  members_string.go:4098	0x75e0c7		4189c8			MOVL CX, R8											
  members_string.go:4098	0x75e0ca		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4098	0x75e0d1		5d			POPQ BP												
  members_string.go:4098	0x75e0d2		c3			RET												
  members_string.go:4093	0x75e0d3		31c0			XORL AX, AX											
  members_string.go:4093	0x75e0d5		31db			XORL BX, BX											
  members_string.go:4093	0x75e0d7		31c9			XORL CX, CX											
  members_string.go:4093	0x75e0d9		4989f0			MOVQ SI, R8											
  members_string.go:4093	0x75e0dc		4889fe			MOVQ DI, SI											
  members_string.go:4093	0x75e0df		31ff			XORL DI, DI											
  members_string.go:4093	0x75e0e1		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4093	0x75e0e8		5d			POPQ BP												
  members_string.go:4093	0x75e0e9		c3			RET												
  aliases.go:1367		0x75e0ea		4c8d1daff13b00		LEAQ 0x3bf1af(IP), R11										
  aliases.go:1367		0x75e0f1		4c39de			CMPQ SI, R11											
  aliases.go:1367		0x75e0f4		740a			JE 0x75e100											
  aliases.go:1367		0x75e0f6		4531c0			XORL R8, R8											
  aliases.go:1367		0x75e0f9		0f1f8000000000		NOPL 0(AX)											
  members_string.go:4104	0x75e100		4d85c0			TESTQ R8, R8											
  members_string.go:4104	0x75e103		0f841d010000		JE 0x75e226											
  members_string.go:4108	0x75e109		4c8b9c24f8000000	MOVQ 0xf8(SP), R11										
  members_string.go:4108	0x75e111		4c891c24		MOVQ R11, 0(SP)											
  members_string.go:4108	0x75e115		4c8b9c2400010000	MOVQ 0x100(SP), R11										
  members_string.go:4108	0x75e11d		4c895c2408		MOVQ R11, 0x8(SP)										
  members_string.go:4108	0x75e122		4c8b9c2430010000	MOVQ 0x130(SP), R11										
  members_string.go:4108	0x75e12a		4c895c2410		MOVQ R11, 0x10(SP)										
  members_string.go:4108	0x75e12f		4c8b9c2408010000	MOVQ 0x108(SP), R11										
  members_string.go:4108	0x75e137		4c895c2418		MOVQ R11, 0x18(SP)										
  members_string.go:4108	0x75e13c		4c8b9c24c0010000	MOVQ 0x1c0(SP), R11										
  members_string.go:4108	0x75e144		4c895c2420		MOVQ R11, 0x20(SP)										
  members_string.go:4108	0x75e149		4c8b9c24c8010000	MOVQ 0x1c8(SP), R11										
  members_string.go:4108	0x75e151		4c895c2428		MOVQ R11, 0x28(SP)										
  members_string.go:4108	0x75e156		4c8b9c24d0010000	MOVQ 0x1d0(SP), R11										
  members_string.go:4108	0x75e15e		4c895c2430		MOVQ R11, 0x30(SP)										
  members_string.go:4108	0x75e163		488b842498010000	MOVQ 0x198(SP), AX										
  members_string.go:4108	0x75e16b		4889d3			MOVQ DX, BX											
  members_string.go:4108	0x75e16e		488b8c2480010000	MOVQ 0x180(SP), CX										
  members_string.go:4108	0x75e176		488bbc2488010000	MOVQ 0x188(SP), DI										
  members_string.go:4108	0x75e17e		488bb42490010000	MOVQ 0x190(SP), SI										
  members_string.go:4108	0x75e186		4c8d05bb680500		LEAQ 0x568bb(IP), R8										
  members_string.go:4108	0x75e18d		41b90c000000		MOVL $0xc, R9											
  members_string.go:4108	0x75e193		4c8b9424d8010000	MOVQ 0x1d8(SP), R10										
  members_string.go:4108	0x75e19b		0f1f440000		NOPL 0(AX)(AX*1)										
  members_string.go:4108	0x75e1a0		e81b4cf1ff		CALL github.com/mgomes/vibescript/internal/runtime.newBlockCallRunner(SB)			
  members_string.go:4109	0x75e1a5		4885db			TESTQ BX, BX											
  members_string.go:4109	0x75e1a8		7417			JE 0x75e1c1											
  members_string.go:4110	0x75e1aa		31c0			XORL AX, AX											
  members_string.go:4110	0x75e1ac		31ff			XORL DI, DI											
  members_string.go:4110	0x75e1ae		4889de			MOVQ BX, SI											
  members_string.go:4110	0x75e1b1		4989c8			MOVQ CX, R8											
  members_string.go:4110	0x75e1b4		31db			XORL BX, BX											
  members_string.go:4110	0x75e1b6		31c9			XORL CX, CX											
  members_string.go:4110	0x75e1b8		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4110	0x75e1bf		5d			POPQ BP												
  members_string.go:4110	0x75e1c0		c3			RET												
  members_string.go:4112	0x75e1c1		488b9424f0000000	MOVQ 0xf0(SP), DX										
  members_string.go:4112	0x75e1c9		4889942438010000	MOVQ DX, 0x138(SP)										
  members_string.go:4112	0x75e1d1		488b9424e8000000	MOVQ 0xe8(SP), DX										
  members_string.go:4112	0x75e1d9		4889942440010000	MOVQ DX, 0x140(SP)										
  members_string.go:4112	0x75e1e1		488b9424e0000000	MOVQ 0xe0(SP), DX										
  members_string.go:4112	0x75e1e9		4889942450010000	MOVQ DX, 0x150(SP)										
  members_string.go:4112	0x75e1f1		488b942428010000	MOVQ 0x128(SP), DX										
  members_string.go:4112	0x75e1f9		4889942448010000	MOVQ DX, 0x148(SP)										
  eval.go:1785			0x75e201		488d9c2438010000	LEAQ 0x138(SP), BX										
  eval.go:1785			0x75e209		b901000000		MOVL $0x1, CX											
  eval.go:1785			0x75e20e		89cf			MOVL CX, DI											
  eval.go:1785			0x75e210		31f6			XORL SI, SI											
  eval.go:1785			0x75e212		4531c0			XORL R8, R8											
  eval.go:1785			0x75e215		4589c1			MOVL R8, R9											
  eval.go:1785			0x75e218		e8e350f1ff		CALL github.com/mgomes/vibescript/internal/runtime.(*blockCallRunner).callWithChargedRoots(SB)	
  members_string.go:4112	0x75e21d		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4112	0x75e224		5d			POPQ BP												
  members_string.go:4112	0x75e225		c3			RET												
  members_string.go:4114	0x75e226		31f6			XORL SI, SI											
  members_string.go:4114	0x75e228		4531c0			XORL R8, R8											
  members_string.go:4114	0x75e22b		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4114	0x75e232		5d			POPQ BP												
  members_string.go:4114	0x75e233		c3			RET												
  aliases.go:1367		0x75e234		4c89de			MOVQ R11, SI											
  aliases.go:1367		0x75e237		4c8b842488010000	MOVQ 0x188(SP), R8										
  aliases.go:1367		0x75e23f		90			NOPL												
  aliases.go:1367		0x75e240		e9a5feffff		JMP 0x75e0ea											
  value_accessors.go:183	0x75e245		4c89fe			MOVQ R15, SI											
  value_accessors.go:183	0x75e248		4d21ef			ANDQ R13, R15											
  value_accessors.go:183	0x75e24b		49c1e704		SHLQ $0x4, R15											
  value_accessors.go:183	0x75e24f		4f8b442708		MOVQ 0x8(R15)(R12*1), R8									
  value_accessors.go:183	0x75e254		4d39c3			CMPQ R11, R8											
  value_accessors.go:183	0x75e257		7450			JE 0x75e2a9											
  value_accessors.go:183	0x75e259		4c8d7e01		LEAQ 0x1(SI), R15										
  value_accessors.go:183	0x75e25d		0f1f00			NOPL 0(AX)											
  value_accessors.go:183	0x75e260		4d85c0			TESTQ R8, R8											
  value_accessors.go:183	0x75e263		75e0			JNE 0x75e245											
  value_accessors.go:183	0x75e265		488d0574533f00		LEAQ github.com/mgomes/vibescript/internal/runtime..typeAssert.357(SB), AX			
  value_accessors.go:183	0x75e26c		4c89db			MOVQ R11, BX											
  value_accessors.go:183	0x75e26f		e88cefcbff		CALL runtime.typeAssert(SB)									
  members_string.go:4114	0x75e274		488b8c2428010000	MOVQ 0x128(SP), CX										
  members_string.go:4108	0x75e27c		488b942478010000	MOVQ 0x178(SP), DX										
  members_string.go:4114	0x75e284		488b9c24e8000000	MOVQ 0xe8(SP), BX										
  members_string.go:4108	0x75e28c		488bb42480010000	MOVQ 0x180(SP), SI										
  members_string.go:4114	0x75e294		488bbc24e0000000	MOVQ 0xe0(SP), DI										
  value_accessors.go:183	0x75e29c		4989c3			MOVQ AX, R11											
  members_string.go:4114	0x75e29f		488b8424f0000000	MOVQ 0xf0(SP), AX										
  value_accessors.go:183	0x75e2a7		eb8b			JMP 0x75e234											
  value_accessors.go:183	0x75e2a9		4f8b642710		MOVQ 0x10(R15)(R12*1), R12									
  members_string.go:4108	0x75e2ae		4c89de			MOVQ R11, SI											
  value_accessors.go:183	0x75e2b1		4d89e3			MOVQ R12, R11											
  value_accessors.go:183	0x75e2b4		e97bffffff		JMP 0x75e234											
  utf8.go:449			0x75e2b9		48ffc2			INCQ DX												
  utf8.go:449			0x75e2bc		0f1f4000		NOPL 0(AX)											
  utf8.go:448			0x75e2c0		4c39de			CMPQ SI, R11											
  utf8.go:448			0x75e2c3		7e43			JLE 0x75e308											
  utf8.go:448			0x75e2c5		460fb6241f		MOVZX 0(DI)(R11*1), R12										
  utf8.go:448			0x75e2ca		4183fc7f		CMPL R12, $0x7f											
  utf8.go:448			0x75e2ce		7f05			JG 0x75e2d5											
  utf8.go:448			0x75e2d0		49ffc3			INCQ R11											
  utf8.go:448			0x75e2d3		ebe4			JMP 0x75e2b9											
  utf8.go:448			0x75e2d5		48899424c0000000	MOVQ DX, 0xc0(SP)										
  utf8.go:448			0x75e2dd		4889f8			MOVQ DI, AX											
  utf8.go:448			0x75e2e0		4889f3			MOVQ SI, BX											
  utf8.go:448			0x75e2e3		4c89d9			MOVQ R11, CX											
  utf8.go:448			0x75e2e6		e815efd1ff		CALL runtime.decoderune(SB)									
  utf8.go:449			0x75e2eb		488b9424c0000000	MOVQ 0xc0(SP), DX										
  utf8.go:448			0x75e2f3		488bb424c8000000	MOVQ 0xc8(SP), SI										
  utf8.go:448			0x75e2fb		488bbc2418010000	MOVQ 0x118(SP), DI										
  utf8.go:449			0x75e303		4989db			MOVQ BX, R11											
  utf8.go:448			0x75e306		ebb1			JMP 0x75e2b9											
  members_string.go:4086	0x75e308		4889d0			MOVQ DX, AX											
  members_string.go:4086	0x75e30b		e9c8fbffff		JMP 0x75ded8											
  members_string.go:4047	0x75e310		4889442428		MOVQ AX, 0x28(SP)										
  members_string.go:4047	0x75e315		48895c2430		MOVQ BX, 0x30(SP)										
  members_string.go:4047	0x75e31a		48894c2438		MOVQ CX, 0x38(SP)										
  members_string.go:4047	0x75e31f		48897c2440		MOVQ DI, 0x40(SP)										
  members_string.go:4047	0x75e324		4889742448		MOVQ SI, 0x48(SP)										
  members_string.go:4047	0x75e329		4c89442450		MOVQ R8, 0x50(SP)										
  members_string.go:4047	0x75e32e		4c894c2458		MOVQ R9, 0x58(SP)										
  members_string.go:4047	0x75e333		4c89542460		MOVQ R10, 0x60(SP)										
  members_string.go:4047	0x75e338		4c895c2468		MOVQ R11, 0x68(SP)										
  members_string.go:4047	0x75e33d		0f1f00			NOPL 0(AX)											
  members_string.go:4047	0x75e340		e8fbe2d2ff		CALL runtime.morestack_noctxt.abi0(SB)								
  members_string.go:4047	0x75e345		488b442428		MOVQ 0x28(SP), AX										
  members_string.go:4047	0x75e34a		488b5c2430		MOVQ 0x30(SP), BX										
  members_string.go:4047	0x75e34f		488b4c2438		MOVQ 0x38(SP), CX										
  members_string.go:4047	0x75e354		488b7c2440		MOVQ 0x40(SP), DI										
  members_string.go:4047	0x75e359		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:4047	0x75e35e		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4047	0x75e363		4c8b4c2458		MOVQ 0x58(SP), R9										
  members_string.go:4047	0x75e368		4c8b542460		MOVQ 0x60(SP), R10										
  members_string.go:4047	0x75e36d		4c8b5c2468		MOVQ 0x68(SP), R11										
  members_string.go:4047	0x75e372		e949f7ffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func23(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func24(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4117	0x75e380		4c8d6424e8		LEAQ -0x18(SP), R12										
  members_string.go:4117	0x75e385		4d3b6610		CMPQ R12, 0x10(R14)										
  members_string.go:4117	0x75e389		0f8660030000		JBE 0x75e6ef											
  members_string.go:4117	0x75e38f		55			PUSHQ BP											
  members_string.go:4117	0x75e390		4889e5			MOVQ SP, BP											
  members_string.go:4117	0x75e393		4881ec90000000		SUBQ $0x90, SP											
  members_string.go:4117	0x75e39a		48898c24d0000000	MOVQ CX, 0xd0(SP)										
  members_string.go:4117	0x75e3a2		4889bc24d8000000	MOVQ DI, 0xd8(SP)										
  members_string.go:4117	0x75e3aa		4c898424e8000000	MOVQ R8, 0xe8(SP)										
  members_string.go:4118	0x75e3b2		4d85db			TESTQ R11, R11											
  members_string.go:4118	0x75e3b5		7405			JE 0x75e3bc											
  members_string.go:4118	0x75e3b7		498b13			MOVQ 0(R11), DX											
  members_string.go:4118	0x75e3ba		eb04			JMP 0x75e3c0											
  members_string.go:4118	0x75e3bc		31d2			XORL DX, DX											
  members_string.go:4118	0x75e3be		6690			NOPW												
  members_string.go:4118	0x75e3c0		4885d2			TESTQ DX, DX											
  members_string.go:4118	0x75e3c3		0f8fbb020000		JG 0x75e684											
  members_string.go:4121	0x75e3c9		4d85c9			TESTQ R9, R9											
  members_string.go:4121	0x75e3cc		7406			JE 0x75e3d4											
  members_string.go:4121	0x75e3ce		4983f902		CMPQ R9, $0x2											
  members_string.go:4121	0x75e3d2		7e66			JLE 0x75e43a											
  errors.go:26			0x75e3d4		488d05e9ad0600		LEAQ 0x6ade9(IP), AX										
  errors.go:26			0x75e3db		bb33000000		MOVL $0x33, BX											
  errors.go:26			0x75e3e0		31c9			XORL CX, CX											
  errors.go:26			0x75e3e2		31ff			XORL DI, DI											
  errors.go:26			0x75e3e4		89fe			MOVL DI, SI											
  errors.go:26			0x75e3e6		e8d5fad7ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75e3eb		4885c0			TESTQ AX, AX											
  errors.go:26			0x75e3ee		7533			JNE 0x75e423											
  errors.go:31			0x75e3f0		90			NOPL												
  errors.go:65			0x75e3f1		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75e3f6		488d1d93083900		LEAQ 0x390893(IP), BX										
  errors.go:65			0x75e3fd		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75e402		e8992fccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75e407		48c7400833000000	MOVQ $0x33, 0x8(AX)										
  errors.go:65			0x75e40f		488d15aead0600		LEAQ 0x6adae(IP), DX										
  errors.go:65			0x75e416		488910			MOVQ DX, 0(AX)											
  members_string.go:4122	0x75e419		4889c3			MOVQ AX, BX											
  members_string.go:4122	0x75e41c		488d051de63b00		LEAQ 0x3be61d(IP), AX										
  members_string.go:4122	0x75e423		31c9			XORL CX, CX											
  members_string.go:4122	0x75e425		31ff			XORL DI, DI											
  members_string.go:4122	0x75e427		4889c6			MOVQ AX, SI											
  members_string.go:4122	0x75e42a		4989d8			MOVQ BX, R8											
  members_string.go:4122	0x75e42d		31c0			XORL AX, AX											
  members_string.go:4122	0x75e42f		31db			XORL BX, BX											
  members_string.go:4122	0x75e431		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4122	0x75e438		5d			POPQ BP												
  members_string.go:4122	0x75e439		c3			RET												
  members_string.go:4118	0x75e43a		4889742470		MOVQ SI, 0x70(SP)										
  members_string.go:4118	0x75e43f		4889bc2488000000	MOVQ DI, 0x88(SP)										
  members_string.go:4118	0x75e447		4c898c24f0000000	MOVQ R9, 0xf0(SP)										
  members_string.go:4118	0x75e44f		4c898424e8000000	MOVQ R8, 0xe8(SP)										
  members_string.go:4118	0x75e457		48895c2468		MOVQ BX, 0x68(SP)										
  members_string.go:4118	0x75e45c		48894c2460		MOVQ CX, 0x60(SP)										
  members_string.go:4124	0x75e461		498b7808		MOVQ 0x8(R8), DI										
  members_string.go:4124	0x75e465		498b7010		MOVQ 0x10(R8), SI										
  members_string.go:4124	0x75e469		498b5018		MOVQ 0x18(R8), DX										
  members_string.go:4124	0x75e46d		498b08			MOVQ 0(R8), CX											
  members_string.go:4124	0x75e470		488d05b56c0500		LEAQ 0x56cb5(IP), AX										
  members_string.go:4124	0x75e477		bb0d000000		MOVL $0xd, BX											
  members_string.go:4124	0x75e47c		4989d0			MOVQ DX, R8											
  members_string.go:4124	0x75e47f		90			NOPL												
  members_string.go:4124	0x75e480		e8db3bfbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4124	0x75e485		4885ff			TESTQ DI, DI											
  members_string.go:4124	0x75e488		0f85df010000		JNE 0x75e66d											
  members_string.go:4121	0x75e48e		488b9424f0000000	MOVQ 0xf0(SP), DX										
  members_string.go:4121	0x75e496		4883fa02		CMPQ DX, $0x2											
  members_string.go:4128	0x75e49a		7409			JE 0x75e4a5											
  members_string.go:4128	0x75e49c		31c0			XORL AX, AX											
  members_string.go:4128	0x75e49e		6690			NOPW												
  members_string.go:4128	0x75e4a0		e993000000		JMP 0x75e538											
  members_string.go:4129	0x75e4a5		488b9424e8000000	MOVQ 0xe8(SP), DX										
  members_string.go:4129	0x75e4ad		488b4220		MOVQ 0x20(DX), AX										
  members_string.go:4129	0x75e4b1		488b5a28		MOVQ 0x28(DX), BX										
  members_string.go:4129	0x75e4b5		488b4a30		MOVQ 0x30(DX), CX										
  members_string.go:4129	0x75e4b9		488b7a38		MOVQ 0x38(DX), DI										
  members_string.go:4129	0x75e4bd		0f1f00			NOPL 0(AX)											
  members_string.go:4129	0x75e4c0		e8fb74fdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)				
  members_string.go:4130	0x75e4c5		4885db			TESTQ BX, BX											
  members_string.go:4130	0x75e4c8		7505			JNE 0x75e4cf											
  members_string.go:4130	0x75e4ca		4885c0			TESTQ AX, AX											
  members_string.go:4130	0x75e4cd		7d69			JGE 0x75e538											
  errors.go:26			0x75e4cf		488d05dda50600		LEAQ 0x6a5dd(IP), AX										
  errors.go:26			0x75e4d6		bb31000000		MOVL $0x31, BX											
  errors.go:26			0x75e4db		31c9			XORL CX, CX											
  errors.go:26			0x75e4dd		31ff			XORL DI, DI											
  errors.go:26			0x75e4df		89fe			MOVL DI, SI											
  errors.go:26			0x75e4e1		e8daf9d7ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75e4e6		4885c0			TESTQ AX, AX											
  errors.go:26			0x75e4e9		7536			JNE 0x75e521											
  errors.go:31			0x75e4eb		90			NOPL												
  errors.go:65			0x75e4ec		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75e4f1		488d1d98073900		LEAQ 0x390798(IP), BX										
  errors.go:65			0x75e4f8		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75e4fd		0f1f00			NOPL 0(AX)											
  errors.go:65			0x75e500		e89b2eccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75e505		48c7400831000000	MOVQ $0x31, 0x8(AX)										
  errors.go:65			0x75e50d		488d159fa50600		LEAQ 0x6a59f(IP), DX										
  errors.go:65			0x75e514		488910			MOVQ DX, 0(AX)											
  members_string.go:4131	0x75e517		4889c3			MOVQ AX, BX											
  members_string.go:4131	0x75e51a		488d051fe53b00		LEAQ 0x3be51f(IP), AX										
  members_string.go:4131	0x75e521		31c9			XORL CX, CX											
  members_string.go:4131	0x75e523		31ff			XORL DI, DI											
  members_string.go:4131	0x75e525		4889c6			MOVQ AX, SI											
  members_string.go:4131	0x75e528		4989d8			MOVQ BX, R8											
  members_string.go:4131	0x75e52b		31c0			XORL AX, AX											
  members_string.go:4131	0x75e52d		31db			XORL BX, BX											
  members_string.go:4131	0x75e52f		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4131	0x75e536		5d			POPQ BP												
  members_string.go:4131	0x75e537		c3			RET												
  members_string.go:4135	0x75e538		4889442458		MOVQ AX, 0x58(SP)										
  members_string.go:4135	0x75e53d		488b9424e8000000	MOVQ 0xe8(SP), DX										
  members_string.go:4135	0x75e545		488b0a			MOVQ 0(DX), CX											
  members_string.go:4135	0x75e548		488b7a08		MOVQ 0x8(DX), DI										
  members_string.go:4135	0x75e54c		488b7210		MOVQ 0x10(DX), SI										
  members_string.go:4135	0x75e550		4c8b4218		MOVQ 0x18(DX), R8										
  members_string.go:4135	0x75e554		488d05d16b0500		LEAQ 0x56bd1(IP), AX										
  members_string.go:4135	0x75e55b		bb0d000000		MOVL $0xd, BX											
  members_string.go:4135	0x75e560		e8fb3afbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4136	0x75e565		4885ff			TESTQ DI, DI											
  members_string.go:4136	0x75e568		0f85e8000000		JNE 0x75e656											
  members_string.go:4135	0x75e56e		884c2447		MOVB CL, 0x47(SP)										
  members_string.go:4135	0x75e572		4889842480000000	MOVQ AX, 0x80(SP)										
  members_string.go:4135	0x75e57a		48895c2450		MOVQ BX, 0x50(SP)										
  members_string.go:4139	0x75e57f		488b442468		MOVQ 0x68(SP), AX										
  members_string.go:4139	0x75e584		488b5c2460		MOVQ 0x60(SP), BX										
  members_string.go:4139	0x75e589		488b8c2488000000	MOVQ 0x88(SP), CX										
  members_string.go:4139	0x75e591		488b7c2470		MOVQ 0x70(SP), DI										
  members_string.go:4139	0x75e596		e885dde4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  members_string.go:4139	0x75e59b		4889442478		MOVQ AX, 0x78(SP)										
  members_string.go:4139	0x75e5a0		48895c2448		MOVQ BX, 0x48(SP)										
  members_string.go:4140	0x75e5a5		4889c1			MOVQ AX, CX											
  members_string.go:4140	0x75e5a8		4889df			MOVQ BX, DI											
  members_string.go:4140	0x75e5ab		488bb42480000000	MOVQ 0x80(SP), SI										
  members_string.go:4140	0x75e5b3		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4140	0x75e5b8		440fb64c2447		MOVZX 0x47(SP), R9										
  members_string.go:4140	0x75e5be		488d05676b0500		LEAQ 0x56b67(IP), AX										
  members_string.go:4140	0x75e5c5		bb0d000000		MOVL $0xd, BX											
  members_string.go:4140	0x75e5ca		e8b151f7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)			
  members_string.go:4140	0x75e5cf		4885c0			TESTQ AX, AX											
  members_string.go:4140	0x75e5d2		756b			JNE 0x75e63f											
  members_string.go:2034	0x75e5d4		488b05655f4000		MOVQ github.com/mgomes/vibescript/internal/runtime.compiledRegexps(SB), AX			
  members_string.go:4143	0x75e5db		90			NOPL												
  members_string.go:2034	0x75e5dc		488d1d496b0500		LEAQ 0x56b49(IP), BX										
  members_string.go:2034	0x75e5e3		b90d000000		MOVL $0xd, CX											
  members_string.go:2034	0x75e5e8		488b7c2478		MOVQ 0x78(SP), DI										
  members_string.go:2034	0x75e5ed		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:2034	0x75e5f2		4c8b842480000000	MOVQ 0x80(SP), R8										
  members_string.go:2034	0x75e5fa		4c8b4c2450		MOVQ 0x50(SP), R9										
  members_string.go:2034	0x75e5ff		4c8b542458		MOVQ 0x58(SP), R10										
  members_string.go:2034	0x75e604		e8d752f7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexMatchFromRuneOffsetWithCache(SB)	
  members_string.go:4144	0x75e609		4885db			TESTQ BX, BX											
  members_string.go:4144	0x75e60c		7417			JE 0x75e625											
  members_string.go:4145	0x75e60e		31c0			XORL AX, AX											
  members_string.go:4145	0x75e610		31ff			XORL DI, DI											
  members_string.go:4145	0x75e612		4889de			MOVQ BX, SI											
  members_string.go:4145	0x75e615		4989c8			MOVQ CX, R8											
  members_string.go:4145	0x75e618		31db			XORL BX, BX											
  members_string.go:4145	0x75e61a		31c9			XORL CX, CX											
  members_string.go:4145	0x75e61c		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4145	0x75e623		5d			POPQ BP												
  members_string.go:4145	0x75e624		c3			RET												
  members_string.go:4147	0x75e625		0fb6f8			MOVZX AL, DI											
  members_string.go:4147	0x75e628		b801000000		MOVL $0x1, AX											
  members_string.go:4147	0x75e62d		31db			XORL BX, BX											
  members_string.go:4147	0x75e62f		31c9			XORL CX, CX											
  members_string.go:4147	0x75e631		89de			MOVL BX, SI											
  members_string.go:4147	0x75e633		4189c8			MOVL CX, R8											
  members_string.go:4147	0x75e636		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4147	0x75e63d		5d			POPQ BP												
  members_string.go:4147	0x75e63e		c3			RET												
  members_string.go:4141	0x75e63f		31c9			XORL CX, CX											
  members_string.go:4141	0x75e641		31ff			XORL DI, DI											
  members_string.go:4141	0x75e643		4889c6			MOVQ AX, SI											
  members_string.go:4141	0x75e646		4989d8			MOVQ BX, R8											
  members_string.go:4141	0x75e649		31c0			XORL AX, AX											
  members_string.go:4141	0x75e64b		31db			XORL BX, BX											
  members_string.go:4141	0x75e64d		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4141	0x75e654		5d			POPQ BP												
  members_string.go:4141	0x75e655		c3			RET												
  members_string.go:4137	0x75e656		31c0			XORL AX, AX											
  members_string.go:4137	0x75e658		31db			XORL BX, BX											
  members_string.go:4137	0x75e65a		31c9			XORL CX, CX											
  members_string.go:4137	0x75e65c		4989f0			MOVQ SI, R8											
  members_string.go:4137	0x75e65f		4889fe			MOVQ DI, SI											
  members_string.go:4137	0x75e662		31ff			XORL DI, DI											
  members_string.go:4137	0x75e664		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4137	0x75e66b		5d			POPQ BP												
  members_string.go:4137	0x75e66c		c3			RET												
  members_string.go:4125	0x75e66d		31c0			XORL AX, AX											
  members_string.go:4125	0x75e66f		31db			XORL BX, BX											
  members_string.go:4125	0x75e671		31c9			XORL CX, CX											
  members_string.go:4125	0x75e673		4989f0			MOVQ SI, R8											
  members_string.go:4125	0x75e676		4889fe			MOVQ DI, SI											
  members_string.go:4125	0x75e679		31ff			XORL DI, DI											
  members_string.go:4125	0x75e67b		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4125	0x75e682		5d			POPQ BP												
  members_string.go:4125	0x75e683		c3			RET												
  errors.go:26			0x75e684		488d05af980600		LEAQ 0x698af(IP), AX										
  errors.go:26			0x75e68b		bb2f000000		MOVL $0x2f, BX											
  errors.go:26			0x75e690		31c9			XORL CX, CX											
  errors.go:26			0x75e692		31ff			XORL DI, DI											
  errors.go:26			0x75e694		89fe			MOVL DI, SI											
  errors.go:26			0x75e696		e825f8d7ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75e69b		0f1f440000		NOPL 0(AX)(AX*1)										
  errors.go:26			0x75e6a0		4885c0			TESTQ AX, AX											
  errors.go:26			0x75e6a3		7533			JNE 0x75e6d8											
  errors.go:31			0x75e6a5		90			NOPL												
  errors.go:65			0x75e6a6		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75e6ab		488d1dde053900		LEAQ 0x3905de(IP), BX										
  errors.go:65			0x75e6b2		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75e6b7		e8e42cccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75e6bc		48c740082f000000	MOVQ $0x2f, 0x8(AX)										
  errors.go:65			0x75e6c4		488d156f980600		LEAQ 0x6986f(IP), DX										
  errors.go:65			0x75e6cb		488910			MOVQ DX, 0(AX)											
  members_string.go:4119	0x75e6ce		4889c3			MOVQ AX, BX											
  members_string.go:4119	0x75e6d1		488d0568e33b00		LEAQ 0x3be368(IP), AX										
  members_string.go:4119	0x75e6d8		31c9			XORL CX, CX											
  members_string.go:4119	0x75e6da		31ff			XORL DI, DI											
  members_string.go:4119	0x75e6dc		4889c6			MOVQ AX, SI											
  members_string.go:4119	0x75e6df		4989d8			MOVQ BX, R8											
  members_string.go:4119	0x75e6e2		31c0			XORL AX, AX											
  members_string.go:4119	0x75e6e4		31db			XORL BX, BX											
  members_string.go:4119	0x75e6e6		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4119	0x75e6ed		5d			POPQ BP												
  members_string.go:4119	0x75e6ee		c3			RET												
  members_string.go:4117	0x75e6ef		4889442428		MOVQ AX, 0x28(SP)										
  members_string.go:4117	0x75e6f4		48895c2430		MOVQ BX, 0x30(SP)										
  members_string.go:4117	0x75e6f9		48894c2438		MOVQ CX, 0x38(SP)										
  members_string.go:4117	0x75e6fe		48897c2440		MOVQ DI, 0x40(SP)										
  members_string.go:4117	0x75e703		4889742448		MOVQ SI, 0x48(SP)										
  members_string.go:4117	0x75e708		4c89442450		MOVQ R8, 0x50(SP)										
  members_string.go:4117	0x75e70d		4c894c2458		MOVQ R9, 0x58(SP)										
  members_string.go:4117	0x75e712		4c89542460		MOVQ R10, 0x60(SP)										
  members_string.go:4117	0x75e717		4c895c2468		MOVQ R11, 0x68(SP)										
  members_string.go:4117	0x75e71c		0f1f4000		NOPL 0(AX)											
  members_string.go:4117	0x75e720		e81bdfd2ff		CALL runtime.morestack_noctxt.abi0(SB)								
  members_string.go:4117	0x75e725		488b442428		MOVQ 0x28(SP), AX										
  members_string.go:4117	0x75e72a		488b5c2430		MOVQ 0x30(SP), BX										
  members_string.go:4117	0x75e72f		488b4c2438		MOVQ 0x38(SP), CX										
  members_string.go:4117	0x75e734		488b7c2440		MOVQ 0x40(SP), DI										
  members_string.go:4117	0x75e739		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:4117	0x75e73e		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4117	0x75e743		4c8b4c2458		MOVQ 0x58(SP), R9										
  members_string.go:4117	0x75e748		4c8b542460		MOVQ 0x60(SP), R10										
  members_string.go:4117	0x75e74d		4c8b5c2468		MOVQ 0x68(SP), R11										
  members_string.go:4117	0x75e752		e929fcffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func24(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func25(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4150	0x75e760		4c8d642490		LEAQ -0x70(SP), R12								
  members_string.go:4150	0x75e765		4d3b6610		CMPQ R12, 0x10(R14)								
  members_string.go:4150	0x75e769		0f86a9030000		JBE 0x75eb18									
  members_string.go:4150	0x75e76f		55			PUSHQ BP									
  members_string.go:4150	0x75e770		4889e5			MOVQ SP, BP									
  members_string.go:4150	0x75e773		4881ece8000000		SUBQ $0xe8, SP									
  members_string.go:4150	0x75e77a		48898c2428010000	MOVQ CX, 0x128(SP)								
  members_string.go:4150	0x75e782		4889bc2430010000	MOVQ DI, 0x130(SP)								
  members_string.go:4150	0x75e78a		4c89842440010000	MOVQ R8, 0x140(SP)								
  members_string.go:4151	0x75e792		4d85db			TESTQ R11, R11									
  members_string.go:4151	0x75e795		7405			JE 0x75e79c									
  members_string.go:4151	0x75e797		498b13			MOVQ 0(R11), DX									
  members_string.go:4151	0x75e79a		eb04			JMP 0x75e7a0									
  members_string.go:4151	0x75e79c		31d2			XORL DX, DX									
  members_string.go:4151	0x75e79e		6690			NOPW										
  members_string.go:4151	0x75e7a0		4885d2			TESTQ DX, DX									
  members_string.go:4151	0x75e7a3		0f8f09030000		JG 0x75eab2									
  members_string.go:4154	0x75e7a9		4983f901		CMPQ R9, $0x1									
  members_string.go:4154	0x75e7ad		7469			JE 0x75e818									
  errors.go:26			0x75e7af		488d05d84b0600		LEAQ 0x64bd8(IP), AX								
  errors.go:26			0x75e7b6		bb27000000		MOVL $0x27, BX									
  errors.go:26			0x75e7bb		31c9			XORL CX, CX									
  errors.go:26			0x75e7bd		31ff			XORL DI, DI									
  errors.go:26			0x75e7bf		89fe			MOVL DI, SI									
  errors.go:26			0x75e7c1		e8faf6d7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75e7c6		4885c0			TESTQ AX, AX									
  errors.go:26			0x75e7c9		7536			JNE 0x75e801									
  errors.go:31			0x75e7cb		90			NOPL										
  errors.go:65			0x75e7cc		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75e7d1		488d1db8043900		LEAQ 0x3904b8(IP), BX								
  errors.go:65			0x75e7d8		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75e7dd		0f1f00			NOPL 0(AX)									
  errors.go:65			0x75e7e0		e8bb2bccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75e7e5		48c7400827000000	MOVQ $0x27, 0x8(AX)								
  errors.go:65			0x75e7ed		488d159a4b0600		LEAQ 0x64b9a(IP), DX								
  errors.go:65			0x75e7f4		488910			MOVQ DX, 0(AX)									
  members_string.go:4155	0x75e7f7		4889c3			MOVQ AX, BX									
  members_string.go:4155	0x75e7fa		488d053fe23b00		LEAQ 0x3be23f(IP), AX								
  members_string.go:4155	0x75e801		31c9			XORL CX, CX									
  members_string.go:4155	0x75e803		31ff			XORL DI, DI									
  members_string.go:4155	0x75e805		4889c6			MOVQ AX, SI									
  members_string.go:4155	0x75e808		4989d8			MOVQ BX, R8									
  members_string.go:4155	0x75e80b		31c0			XORL AX, AX									
  members_string.go:4155	0x75e80d		31db			XORL BX, BX									
  members_string.go:4155	0x75e80f		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4155	0x75e816		5d			POPQ BP										
  members_string.go:4155	0x75e817		c3			RET										
  members_string.go:4151	0x75e818		4889842418010000	MOVQ AX, 0x118(SP)								
  members_string.go:4151	0x75e820		4c899c2458010000	MOVQ R11, 0x158(SP)								
  members_string.go:4151	0x75e828		4c89842440010000	MOVQ R8, 0x140(SP)								
  members_string.go:4151	0x75e830		4889b424b8000000	MOVQ SI, 0xb8(SP)								
  members_string.go:4151	0x75e838		48899c24b0000000	MOVQ BX, 0xb0(SP)								
  members_string.go:4151	0x75e840		4889bc24e0000000	MOVQ DI, 0xe0(SP)								
  members_string.go:4151	0x75e848		48898c24a8000000	MOVQ CX, 0xa8(SP)								
  members_string.go:4151	0x75e850		4c898c2448010000	MOVQ R9, 0x148(SP)								
  members_string.go:4151	0x75e858		4c89942450010000	MOVQ R10, 0x150(SP)								
  members_string.go:4157	0x75e860		498b08			MOVQ 0(R8), CX									
  members_string.go:4157	0x75e863		498b7808		MOVQ 0x8(R8), DI								
  members_string.go:4157	0x75e867		498b7010		MOVQ 0x10(R8), SI								
  members_string.go:4157	0x75e86b		4d8b4018		MOVQ 0x18(R8), R8								
  members_string.go:4157	0x75e86f		488d05b45a0500		LEAQ 0x55ab4(IP), AX								
  members_string.go:4157	0x75e876		bb0b000000		MOVL $0xb, BX									
  members_string.go:4157	0x75e87b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4157	0x75e880		e8db37fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)	
  members_string.go:4158	0x75e885		4885ff			TESTQ DI, DI									
  members_string.go:4158	0x75e888		0f850d020000		JNE 0x75ea9b									
  members_string.go:4157	0x75e88e		888c2497000000		MOVB CL, 0x97(SP)								
  members_string.go:4157	0x75e895		48898424c8000000	MOVQ AX, 0xc8(SP)								
  members_string.go:4157	0x75e89d		48899c24a0000000	MOVQ BX, 0xa0(SP)								
  members_string.go:4161	0x75e8a5		488b8424b0000000	MOVQ 0xb0(SP), AX								
  members_string.go:4161	0x75e8ad		488b9c24a8000000	MOVQ 0xa8(SP), BX								
  members_string.go:4161	0x75e8b5		488b8c24e0000000	MOVQ 0xe0(SP), CX								
  members_string.go:4161	0x75e8bd		488bbc24b8000000	MOVQ 0xb8(SP), DI								
  members_string.go:4161	0x75e8c5		e856dae4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4161	0x75e8ca		48898424c0000000	MOVQ AX, 0xc0(SP)								
  members_string.go:4161	0x75e8d2		48899c2498000000	MOVQ BX, 0x98(SP)								
  members_string.go:4162	0x75e8da		4889c1			MOVQ AX, CX									
  members_string.go:4162	0x75e8dd		4889df			MOVQ BX, DI									
  members_string.go:4162	0x75e8e0		488bb424c8000000	MOVQ 0xc8(SP), SI								
  members_string.go:4162	0x75e8e8		4c8b8424a0000000	MOVQ 0xa0(SP), R8								
  members_string.go:4162	0x75e8f0		440fb68c2497000000	MOVZX 0x97(SP), R9								
  members_string.go:4162	0x75e8f9		488d052a5a0500		LEAQ 0x55a2a(IP), AX								
  members_string.go:4162	0x75e900		bb0b000000		MOVL $0xb, BX									
  members_string.go:4162	0x75e905		e8764ef7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)	
  members_string.go:4162	0x75e90a		4885c0			TESTQ AX, AX									
  members_string.go:4162	0x75e90d		0f8571010000		JNE 0x75ea84									
  members_string.go:4165	0x75e913		488b8424c8000000	MOVQ 0xc8(SP), AX								
  members_string.go:4165	0x75e91b		488b9c24a0000000	MOVQ 0xa0(SP), BX								
  members_string.go:4165	0x75e923		e8f8c6faff		CALL github.com/mgomes/vibescript/internal/runtime.compileCachedRegex(SB)	
  members_string.go:4166	0x75e928		4885db			TESTQ BX, BX									
  members_string.go:4166	0x75e92b		0f848e000000		JE 0x75e9bf									
  members_string.go:4167	0x75e931		440f11bc24d0000000	MOVUPS X15, 0xd0(SP)								
  members_string.go:4167	0x75e93a		7404			JE 0x75e940									
  members_string.go:4167	0x75e93c		488b5b08		MOVQ 0x8(BX), BX								
  members_string.go:4167	0x75e940		48899c24d0000000	MOVQ BX, 0xd0(SP)								
  members_string.go:4167	0x75e948		48898c24d8000000	MOVQ CX, 0xd8(SP)								
  errors.go:26			0x75e950		488d05aadb0500		LEAQ 0x5dbaa(IP), AX								
  errors.go:26			0x75e957		bb1d000000		MOVL $0x1d, BX									
  errors.go:26			0x75e95c		488d8c24d0000000	LEAQ 0xd0(SP), CX								
  errors.go:26			0x75e964		bf01000000		MOVL $0x1, DI									
  errors.go:26			0x75e969		89fe			MOVL DI, SI									
  errors.go:26			0x75e96b		e850f5d7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75e970		4885c0			TESTQ AX, AX									
  errors.go:26			0x75e973		7533			JNE 0x75e9a8									
  errors.go:31			0x75e975		90			NOPL										
  errors.go:65			0x75e976		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75e97b		488d1d0e033900		LEAQ 0x39030e(IP), BX								
  errors.go:65			0x75e982		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75e987		e8142accff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75e98c		48c740081d000000	MOVQ $0x1d, 0x8(AX)								
  errors.go:65			0x75e994		488d1566db0500		LEAQ 0x5db66(IP), DX								
  errors.go:65			0x75e99b		488910			MOVQ DX, 0(AX)									
  members_string.go:4167	0x75e99e		4889c3			MOVQ AX, BX									
  members_string.go:4167	0x75e9a1		488d0598e03b00		LEAQ 0x3be098(IP), AX								
  members_string.go:4167	0x75e9a8		31c9			XORL CX, CX									
  members_string.go:4167	0x75e9aa		31ff			XORL DI, DI									
  members_string.go:4167	0x75e9ac		4889c6			MOVQ AX, SI									
  members_string.go:4167	0x75e9af		4989d8			MOVQ BX, R8									
  members_string.go:4167	0x75e9b2		31c0			XORL AX, AX									
  members_string.go:4167	0x75e9b4		31db			XORL BX, BX									
  members_string.go:4167	0x75e9b6		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4167	0x75e9bd		5d			POPQ BP										
  members_string.go:4167	0x75e9be		c3			RET										
  members_string.go:4169	0x75e9bf		488b9424b0000000	MOVQ 0xb0(SP), DX								
  members_string.go:4169	0x75e9c7		48891424		MOVQ DX, 0(SP)									
  members_string.go:4169	0x75e9cb		488b9424a8000000	MOVQ 0xa8(SP), DX								
  members_string.go:4169	0x75e9d3		4889542408		MOVQ DX, 0x8(SP)								
  members_string.go:4169	0x75e9d8		488b9424e0000000	MOVQ 0xe0(SP), DX								
  members_string.go:4169	0x75e9e0		4889542410		MOVQ DX, 0x10(SP)								
  members_string.go:4169	0x75e9e5		488b9424b8000000	MOVQ 0xb8(SP), DX								
  members_string.go:4169	0x75e9ed		4889542418		MOVQ DX, 0x18(SP)								
  members_string.go:4169	0x75e9f2		488b942458010000	MOVQ 0x158(SP), DX								
  members_string.go:4169	0x75e9fa		4889542420		MOVQ DX, 0x20(SP)								
  members_string.go:4169	0x75e9ff		488b9424f8000000	MOVQ 0xf8(SP), DX								
  members_string.go:4169	0x75ea07		4889542428		MOVQ DX, 0x28(SP)								
  members_string.go:4169	0x75ea0c		488b942400010000	MOVQ 0x100(SP), DX								
  members_string.go:4169	0x75ea14		4889542430		MOVQ DX, 0x30(SP)								
  members_string.go:4169	0x75ea19		488b942408010000	MOVQ 0x108(SP), DX								
  members_string.go:4169	0x75ea21		4889542438		MOVQ DX, 0x38(SP)								
  members_string.go:4169	0x75ea26		488b942410010000	MOVQ 0x110(SP), DX								
  members_string.go:4169	0x75ea2e		4889542440		MOVQ DX, 0x40(SP)								
  members_string.go:4169	0x75ea33		4889c3			MOVQ AX, BX									
  members_string.go:4169	0x75ea36		488b8c24c8000000	MOVQ 0xc8(SP), CX								
  members_string.go:4169	0x75ea3e		488bbc24a0000000	MOVQ 0xa0(SP), DI								
  members_string.go:4169	0x75ea46		488bb424c0000000	MOVQ 0xc0(SP), SI								
  members_string.go:4169	0x75ea4e		4c8b842498000000	MOVQ 0x98(SP), R8								
  members_string.go:4169	0x75ea56		4c8b8c2440010000	MOVQ 0x140(SP), R9								
  members_string.go:4169	0x75ea5e		4c8b942448010000	MOVQ 0x148(SP), R10								
  members_string.go:4169	0x75ea66		4c8b9c2450010000	MOVQ 0x150(SP), R11								
  members_string.go:4169	0x75ea6e		488b842418010000	MOVQ 0x118(SP), AX								
  members_string.go:4169	0x75ea76		e8c507f8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringScan(SB)		
  members_string.go:4169	0x75ea7b		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4169	0x75ea82		5d			POPQ BP										
  members_string.go:4169	0x75ea83		c3			RET										
  members_string.go:4163	0x75ea84		31c9			XORL CX, CX									
  members_string.go:4163	0x75ea86		31ff			XORL DI, DI									
  members_string.go:4163	0x75ea88		4889c6			MOVQ AX, SI									
  members_string.go:4163	0x75ea8b		4989d8			MOVQ BX, R8									
  members_string.go:4163	0x75ea8e		31c0			XORL AX, AX									
  members_string.go:4163	0x75ea90		31db			XORL BX, BX									
  members_string.go:4163	0x75ea92		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4163	0x75ea99		5d			POPQ BP										
  members_string.go:4163	0x75ea9a		c3			RET										
  members_string.go:4159	0x75ea9b		31c0			XORL AX, AX									
  members_string.go:4159	0x75ea9d		31db			XORL BX, BX									
  members_string.go:4159	0x75ea9f		31c9			XORL CX, CX									
  members_string.go:4159	0x75eaa1		4989f0			MOVQ SI, R8									
  members_string.go:4159	0x75eaa4		4889fe			MOVQ DI, SI									
  members_string.go:4159	0x75eaa7		31ff			XORL DI, DI									
  members_string.go:4159	0x75eaa9		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4159	0x75eab0		5d			POPQ BP										
  members_string.go:4159	0x75eab1		c3			RET										
  errors.go:26			0x75eab2		488d05a6840600		LEAQ 0x684a6(IP), AX								
  errors.go:26			0x75eab9		bb2d000000		MOVL $0x2d, BX									
  errors.go:26			0x75eabe		31c9			XORL CX, CX									
  errors.go:26			0x75eac0		31ff			XORL DI, DI									
  errors.go:26			0x75eac2		89fe			MOVL DI, SI									
  errors.go:26			0x75eac4		e8f7f3d7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75eac9		4885c0			TESTQ AX, AX									
  errors.go:26			0x75eacc		7533			JNE 0x75eb01									
  errors.go:31			0x75eace		90			NOPL										
  errors.go:65			0x75eacf		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75ead4		488d1db5013900		LEAQ 0x3901b5(IP), BX								
  errors.go:65			0x75eadb		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75eae0		e8bb28ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75eae5		48c740082d000000	MOVQ $0x2d, 0x8(AX)								
  errors.go:65			0x75eaed		488d156b840600		LEAQ 0x6846b(IP), DX								
  errors.go:65			0x75eaf4		488910			MOVQ DX, 0(AX)									
  members_string.go:4152	0x75eaf7		4889c3			MOVQ AX, BX									
  members_string.go:4152	0x75eafa		488d053fdf3b00		LEAQ 0x3bdf3f(IP), AX								
  members_string.go:4152	0x75eb01		31c9			XORL CX, CX									
  members_string.go:4152	0x75eb03		31ff			XORL DI, DI									
  members_string.go:4152	0x75eb05		4889c6			MOVQ AX, SI									
  members_string.go:4152	0x75eb08		4989d8			MOVQ BX, R8									
  members_string.go:4152	0x75eb0b		31c0			XORL AX, AX									
  members_string.go:4152	0x75eb0d		31db			XORL BX, BX									
  members_string.go:4152	0x75eb0f		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4152	0x75eb16		5d			POPQ BP										
  members_string.go:4152	0x75eb17		c3			RET										
  members_string.go:4150	0x75eb18		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4150	0x75eb1d		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4150	0x75eb22		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4150	0x75eb27		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4150	0x75eb2c		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4150	0x75eb31		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4150	0x75eb36		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4150	0x75eb3b		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4150	0x75eb40		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4150	0x75eb45		e8f6dad2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4150	0x75eb4a		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4150	0x75eb4f		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4150	0x75eb54		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4150	0x75eb59		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4150	0x75eb5e		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4150	0x75eb63		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4150	0x75eb68		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4150	0x75eb6d		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4150	0x75eb72		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4150	0x75eb77		e9e4fbffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func25(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func26(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4172	0x75eb80		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4172	0x75eb84		0f867a010000		JBE 0x75ed04									
  members_string.go:4172	0x75eb8a		55			PUSHQ BP									
  members_string.go:4172	0x75eb8b		4889e5			MOVQ SP, BP									
  members_string.go:4172	0x75eb8e		4883ec70		SUBQ $0x70, SP									
  members_string.go:4172	0x75eb92		48898c24b0000000	MOVQ CX, 0xb0(SP)								
  members_string.go:4172	0x75eb9a		4889bc24b8000000	MOVQ DI, 0xb8(SP)								
  members_string.go:4172	0x75eba2		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4173	0x75ebaa		4d85c9			TESTQ R9, R9									
  members_string.go:4173	0x75ebad		7406			JE 0x75ebb5									
  members_string.go:4173	0x75ebaf		4983f902		CMPQ R9, $0x2									
  members_string.go:4173	0x75ebb3		7e63			JLE 0x75ec18									
  errors.go:26			0x75ebb5		488d050da30600		LEAQ 0x6a30d(IP), AX								
  errors.go:26			0x75ebbc		bb32000000		MOVL $0x32, BX									
  errors.go:26			0x75ebc1		31c9			XORL CX, CX									
  errors.go:26			0x75ebc3		31ff			XORL DI, DI									
  errors.go:26			0x75ebc5		89fe			MOVL DI, SI									
  errors.go:26			0x75ebc7		e8f4f2d7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75ebcc		4885c0			TESTQ AX, AX									
  errors.go:26			0x75ebcf		7533			JNE 0x75ec04									
  errors.go:31			0x75ebd1		90			NOPL										
  errors.go:65			0x75ebd2		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75ebd7		488d1db2003900		LEAQ 0x3900b2(IP), BX								
  errors.go:65			0x75ebde		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75ebe3		e8b827ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75ebe8		48c7400832000000	MOVQ $0x32, 0x8(AX)								
  errors.go:65			0x75ebf0		488d15d2a20600		LEAQ 0x6a2d2(IP), DX								
  errors.go:65			0x75ebf7		488910			MOVQ DX, 0(AX)									
  members_string.go:4174	0x75ebfa		4889c3			MOVQ AX, BX									
  members_string.go:4174	0x75ebfd		488d053cde3b00		LEAQ 0x3bde3c(IP), AX								
  members_string.go:4174	0x75ec04		31c9			XORL CX, CX									
  members_string.go:4174	0x75ec06		31ff			XORL DI, DI									
  members_string.go:4174	0x75ec08		4889c6			MOVQ AX, SI									
  members_string.go:4174	0x75ec0b		4989d8			MOVQ BX, R8									
  members_string.go:4174	0x75ec0e		31c0			XORL AX, AX									
  members_string.go:4174	0x75ec10		31db			XORL BX, BX									
  members_string.go:4174	0x75ec12		4883c470		ADDQ $0x70, SP									
  members_string.go:4174	0x75ec16		5d			POPQ BP										
  members_string.go:4174	0x75ec17		c3			RET										
  members_string.go:4177	0x75ec18		7404			JE 0x75ec1e									
  members_string.go:4177	0x75ec1a		31d2			XORL DX, DX									
  members_string.go:4177	0x75ec1c		eb65			JMP 0x75ec83									
  members_string.go:4173	0x75ec1e		48898424a0000000	MOVQ AX, 0xa0(SP)								
  members_string.go:4173	0x75ec26		48895c2460		MOVQ BX, 0x60(SP)								
  members_string.go:4173	0x75ec2b		4889742458		MOVQ SI, 0x58(SP)								
  members_string.go:4173	0x75ec30		48894c2450		MOVQ CX, 0x50(SP)								
  members_string.go:4173	0x75ec35		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4173	0x75ec3d		48897c2468		MOVQ DI, 0x68(SP)								
  members_string.go:4178	0x75ec42		498b4020		MOVQ 0x20(R8), AX								
  members_string.go:4178	0x75ec46		498b5828		MOVQ 0x28(R8), BX								
  members_string.go:4178	0x75ec4a		498b4830		MOVQ 0x30(R8), CX								
  members_string.go:4178	0x75ec4e		498b7838		MOVQ 0x38(R8), DI								
  members_string.go:4178	0x75ec52		e8696dfdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)		
  members_string.go:4179	0x75ec57		4885db			TESTQ BX, BX									
  members_string.go:4179	0x75ec5a		7545			JNE 0x75eca1									
  members_string.go:4184	0x75ec5c		488b4c2450		MOVQ 0x50(SP), CX								
  members_string.go:4184	0x75ec61		488b5c2460		MOVQ 0x60(SP), BX								
  members_string.go:4184	0x75ec66		488b742458		MOVQ 0x58(SP), SI								
  members_string.go:4184	0x75ec6b		488b7c2468		MOVQ 0x68(SP), DI								
  members_string.go:4184	0x75ec70		4c8b8424c8000000	MOVQ 0xc8(SP), R8								
  members_string.go:4184	0x75ec78		4889c2			MOVQ AX, DX									
  members_string.go:4184	0x75ec7b		488b8424a0000000	MOVQ 0xa0(SP), AX								
  members_string.go:4184	0x75ec83		4d8b4808		MOVQ 0x8(R8), R9								
  members_string.go:4184	0x75ec87		4d8b5010		MOVQ 0x10(R8), R10								
  members_string.go:4184	0x75ec8b		4d8b5818		MOVQ 0x18(R8), R11								
  members_string.go:4184	0x75ec8f		4d8b00			MOVQ 0(R8), R8									
  members_string.go:4184	0x75ec92		48891424		MOVQ DX, 0(SP)									
  members_string.go:4184	0x75ec96		e88501f8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIndexResult(SB)	
  members_string.go:4184	0x75ec9b		4883c470		ADDQ $0x70, SP									
  members_string.go:4184	0x75ec9f		5d			POPQ BP										
  members_string.go:4184	0x75eca0		c3			RET										
  errors.go:26			0x75eca1		488d05c9140600		LEAQ 0x614c9(IP), AX								
  errors.go:26			0x75eca8		bb23000000		MOVL $0x23, BX									
  errors.go:26			0x75ecad		31c9			XORL CX, CX									
  errors.go:26			0x75ecaf		31ff			XORL DI, DI									
  errors.go:26			0x75ecb1		89fe			MOVL DI, SI									
  errors.go:26			0x75ecb3		e808f2d7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75ecb8		4885c0			TESTQ AX, AX									
  errors.go:26			0x75ecbb		7533			JNE 0x75ecf0									
  errors.go:31			0x75ecbd		90			NOPL										
  errors.go:65			0x75ecbe		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75ecc3		488d1dc6ff3800		LEAQ 0x38ffc6(IP), BX								
  errors.go:65			0x75ecca		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75eccf		e8cc26ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75ecd4		48c7400823000000	MOVQ $0x23, 0x8(AX)								
  errors.go:65			0x75ecdc		488d158e140600		LEAQ 0x6148e(IP), DX								
  errors.go:65			0x75ece3		488910			MOVQ DX, 0(AX)									
  members_string.go:4180	0x75ece6		4889c3			MOVQ AX, BX									
  members_string.go:4180	0x75ece9		488d0550dd3b00		LEAQ 0x3bdd50(IP), AX								
  members_string.go:4180	0x75ecf0		31c9			XORL CX, CX									
  members_string.go:4180	0x75ecf2		31ff			XORL DI, DI									
  members_string.go:4180	0x75ecf4		4889c6			MOVQ AX, SI									
  members_string.go:4180	0x75ecf7		4989d8			MOVQ BX, R8									
  members_string.go:4180	0x75ecfa		31c0			XORL AX, AX									
  members_string.go:4180	0x75ecfc		31db			XORL BX, BX									
  members_string.go:4180	0x75ecfe		4883c470		ADDQ $0x70, SP									
  members_string.go:4180	0x75ed02		5d			POPQ BP										
  members_string.go:4180	0x75ed03		c3			RET										
  members_string.go:4172	0x75ed04		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4172	0x75ed09		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4172	0x75ed0e		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4172	0x75ed13		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4172	0x75ed18		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4172	0x75ed1d		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4172	0x75ed22		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4172	0x75ed27		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4172	0x75ed2c		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4172	0x75ed31		e80ad9d2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4172	0x75ed36		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4172	0x75ed3b		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4172	0x75ed40		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4172	0x75ed45		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4172	0x75ed4a		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4172	0x75ed4f		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4172	0x75ed54		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4172	0x75ed59		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4172	0x75ed5e		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4172	0x75ed63		e918feffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func26(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func27(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4187	0x75ed80		4c8d6424e8		LEAQ -0x18(SP), R12								
  members_string.go:4187	0x75ed85		4d3b6610		CMPQ R12, 0x10(R14)								
  members_string.go:4187	0x75ed89		0f8688020000		JBE 0x75f017									
  members_string.go:4187	0x75ed8f		55			PUSHQ BP									
  members_string.go:4187	0x75ed90		4889e5			MOVQ SP, BP									
  members_string.go:4187	0x75ed93		4881ec90000000		SUBQ $0x90, SP									
  members_string.go:4187	0x75ed9a		48898c24d0000000	MOVQ CX, 0xd0(SP)								
  members_string.go:4187	0x75eda2		4889bc24d8000000	MOVQ DI, 0xd8(SP)								
  members_string.go:4187	0x75edaa		4c898424e8000000	MOVQ R8, 0xe8(SP)								
  members_string.go:4188	0x75edb2		4d85c9			TESTQ R9, R9									
  members_string.go:4188	0x75edb5		7406			JE 0x75edbd									
  members_string.go:4188	0x75edb7		4983f902		CMPQ R9, $0x2									
  members_string.go:4188	0x75edbb		7e66			JLE 0x75ee23									
  errors.go:26			0x75edbd		488d0533a40600		LEAQ 0x6a433(IP), AX								
  errors.go:26			0x75edc4		bb33000000		MOVL $0x33, BX									
  errors.go:26			0x75edc9		31c9			XORL CX, CX									
  errors.go:26			0x75edcb		31ff			XORL DI, DI									
  errors.go:26			0x75edcd		89fe			MOVL DI, SI									
  errors.go:26			0x75edcf		e8ecf0d7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75edd4		4885c0			TESTQ AX, AX									
  errors.go:26			0x75edd7		7533			JNE 0x75ee0c									
  errors.go:31			0x75edd9		90			NOPL										
  errors.go:65			0x75edda		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75eddf		488d1daafe3800		LEAQ 0x38feaa(IP), BX								
  errors.go:65			0x75ede6		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75edeb		e8b025ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75edf0		48c7400833000000	MOVQ $0x33, 0x8(AX)								
  errors.go:65			0x75edf8		488d15f8a30600		LEAQ 0x6a3f8(IP), DX								
  errors.go:65			0x75edff		488910			MOVQ DX, 0(AX)									
  members_string.go:4189	0x75ee02		4889c3			MOVQ AX, BX									
  members_string.go:4189	0x75ee05		488d0534dc3b00		LEAQ 0x3bdc34(IP), AX								
  members_string.go:4189	0x75ee0c		31c9			XORL CX, CX									
  members_string.go:4189	0x75ee0e		31ff			XORL DI, DI									
  members_string.go:4189	0x75ee10		4889c6			MOVQ AX, SI									
  members_string.go:4189	0x75ee13		4989d8			MOVQ BX, R8									
  members_string.go:4189	0x75ee16		31c0			XORL AX, AX									
  members_string.go:4189	0x75ee18		31db			XORL BX, BX									
  members_string.go:4189	0x75ee1a		4881c490000000		ADDQ $0x90, SP									
  members_string.go:4189	0x75ee21		5d			POPQ BP										
  members_string.go:4189	0x75ee22		c3			RET										
  members_string.go:4188	0x75ee23		48898424c0000000	MOVQ AX, 0xc0(SP)								
  members_string.go:4188	0x75ee2b		4889742478		MOVQ SI, 0x78(SP)								
  members_string.go:4188	0x75ee30		48895c2470		MOVQ BX, 0x70(SP)								
  members_string.go:4188	0x75ee35		48894c2468		MOVQ CX, 0x68(SP)								
  members_string.go:4188	0x75ee3a		4c898c24f0000000	MOVQ R9, 0xf0(SP)								
  members_string.go:4188	0x75ee42		4c898424e8000000	MOVQ R8, 0xe8(SP)								
  members_string.go:4188	0x75ee4a		4889bc2488000000	MOVQ DI, 0x88(SP)								
  members_string.go:4191	0x75ee52		4889d8			MOVQ BX, AX									
  members_string.go:4191	0x75ee55		4889cb			MOVQ CX, BX									
  members_string.go:4191	0x75ee58		4889f9			MOVQ DI, CX									
  members_string.go:4191	0x75ee5b		4889f7			MOVQ SI, DI									
  members_string.go:4191	0x75ee5e		6690			NOPW										
  members_string.go:4191	0x75ee60		e8bbd4e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4191	0x75ee65		4889842480000000	MOVQ AX, 0x80(SP)								
  members_string.go:4191	0x75ee6d		48895c2458		MOVQ BX, 0x58(SP)								
  ascii_scan_simd_amd64.go:9	0x75ee72		e8c936ebff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIVector(SB)	
  ascii_scan_simd_amd64.go:9	0x75ee77		84c0			TESTL AL, AL									
  members_string.go:1186	0x75ee79		7518			JNE 0x75ee93									
  members_string.go:1189	0x75ee7b		90			NOPL										
  utf8.go:448			0x75ee7c		31d2			XORL DX, DX									
  utf8.go:448			0x75ee7e		4531e4			XORL R12, R12									
  utf8.go:448			0x75ee81		488b5c2458		MOVQ 0x58(SP), BX								
  utf8.go:448			0x75ee86		488b842480000000	MOVQ 0x80(SP), AX								
  utf8.go:448			0x75ee8e		e937010000		JMP 0x75efca									
  members_string.go:4188	0x75ee93		488b9424f0000000	MOVQ 0xf0(SP), DX								
  members_string.go:4188	0x75ee9b		4883fa02		CMPQ DX, $0x2									
  members_string.go:4191	0x75ee9f		488b442458		MOVQ 0x58(SP), AX								
  members_string.go:4192	0x75eea4		0f85bf000000		JNE 0x75ef69									
  members_string.go:4193	0x75eeaa		488b9424e8000000	MOVQ 0xe8(SP), DX								
  members_string.go:4193	0x75eeb2		488b5a28		MOVQ 0x28(DX), BX								
  members_string.go:4193	0x75eeb6		488b4a30		MOVQ 0x30(DX), CX								
  members_string.go:4193	0x75eeba		488b7a38		MOVQ 0x38(DX), DI								
  members_string.go:4193	0x75eebe		488b4220		MOVQ 0x20(DX), AX								
  members_string.go:4193	0x75eec2		e8f96afdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)		
  members_string.go:4194	0x75eec7		4885db			TESTQ BX, BX									
  members_string.go:4194	0x75eeca		746c			JE 0x75ef38									
  errors.go:26			0x75eecc		488d0517200600		LEAQ 0x62017(IP), AX								
  errors.go:26			0x75eed3		bb24000000		MOVL $0x24, BX									
  errors.go:26			0x75eed8		31c9			XORL CX, CX									
  errors.go:26			0x75eeda		31ff			XORL DI, DI									
  errors.go:26			0x75eedc		89fe			MOVL DI, SI									
  errors.go:26			0x75eede		6690			NOPW										
  errors.go:26			0x75eee0		e8dbefd7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75eee5		4885c0			TESTQ AX, AX									
  errors.go:26			0x75eee8		7537			JNE 0x75ef21									
  errors.go:31			0x75eeea		90			NOPL										
  errors.go:65			0x75eeeb		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75eef0		488d1d99fd3800		LEAQ 0x38fd99(IP), BX								
  errors.go:65			0x75eef7		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75eefc		0f1f4000		NOPL 0(AX)									
  errors.go:65			0x75ef00		e89b24ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75ef05		48c7400824000000	MOVQ $0x24, 0x8(AX)								
  errors.go:65			0x75ef0d		488d15d61f0600		LEAQ 0x61fd6(IP), DX								
  errors.go:65			0x75ef14		488910			MOVQ DX, 0(AX)									
  members_string.go:4195	0x75ef17		4889c3			MOVQ AX, BX									
  members_string.go:4195	0x75ef1a		488d051fdb3b00		LEAQ 0x3bdb1f(IP), AX								
  members_string.go:4195	0x75ef21		31c9			XORL CX, CX									
  members_string.go:4195	0x75ef23		31ff			XORL DI, DI									
  members_string.go:4195	0x75ef25		4889c6			MOVQ AX, SI									
  members_string.go:4195	0x75ef28		4989d8			MOVQ BX, R8									
  members_string.go:4195	0x75ef2b		31c0			XORL AX, AX									
  members_string.go:4195	0x75ef2d		31db			XORL BX, BX									
  members_string.go:4195	0x75ef2f		4881c490000000		ADDQ $0x90, SP									
  members_string.go:4195	0x75ef36		5d			POPQ BP										
  members_string.go:4195	0x75ef37		c3			RET										
  members_string.go:4193	0x75ef38		4889442460		MOVQ AX, 0x60(SP)								
  members_string.go:4197	0x75ef3d		488b442470		MOVQ 0x70(SP), AX								
  members_string.go:4197	0x75ef42		488b5c2468		MOVQ 0x68(SP), BX								
  members_string.go:4197	0x75ef47		488b8c2488000000	MOVQ 0x88(SP), CX								
  members_string.go:4197	0x75ef4f		488b7c2478		MOVQ 0x78(SP), DI								
  members_string.go:4197	0x75ef54		e8c7d3e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4197	0x75ef59		488b4c2460		MOVQ 0x60(SP), CX								
  members_string.go:4197	0x75ef5e		6690			NOPW										
  members_string.go:4197	0x75ef60		e8bb0af7ff		CALL github.com/mgomes/vibescript/internal/runtime.stringEffectiveOffset(SB)	
  members_string.go:4197	0x75ef65		84db			TESTL BL, BL									
  members_string.go:4198	0x75ef67		7448			JE 0x75efb1									
  members_string.go:4203	0x75ef69		488b9424e8000000	MOVQ 0xe8(SP), DX								
  members_string.go:4203	0x75ef71		4c8b02			MOVQ 0(DX), R8									
  members_string.go:4203	0x75ef74		4c8b4a08		MOVQ 0x8(DX), R9								
  members_string.go:4203	0x75ef78		4c8b5210		MOVQ 0x10(DX), R10								
  members_string.go:4203	0x75ef7c		4c8b5a18		MOVQ 0x18(DX), R11								
  members_string.go:4203	0x75ef80		48890424		MOVQ AX, 0(SP)									
  members_string.go:4203	0x75ef84		488b8424c0000000	MOVQ 0xc0(SP), AX								
  members_string.go:4203	0x75ef8c		488b5c2470		MOVQ 0x70(SP), BX								
  members_string.go:4203	0x75ef91		488b4c2468		MOVQ 0x68(SP), CX								
  members_string.go:4203	0x75ef96		488bbc2488000000	MOVQ 0x88(SP), DI								
  members_string.go:4203	0x75ef9e		488b742478		MOVQ 0x78(SP), SI								
  members_string.go:4203	0x75efa3		e8d800f8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringRIndexResult(SB)	
  members_string.go:4203	0x75efa8		4881c490000000		ADDQ $0x90, SP									
  members_string.go:4203	0x75efaf		5d			POPQ BP										
  members_string.go:4203	0x75efb0		c3			RET										
  members_string.go:4199	0x75efb1		31c0			XORL AX, AX									
  members_string.go:4199	0x75efb3		31db			XORL BX, BX									
  members_string.go:4199	0x75efb5		31c9			XORL CX, CX									
  members_string.go:4199	0x75efb7		31ff			XORL DI, DI									
  members_string.go:4199	0x75efb9		89de			MOVL BX, SI									
  members_string.go:4199	0x75efbb		4189c8			MOVL CX, R8									
  members_string.go:4199	0x75efbe		4881c490000000		ADDQ $0x90, SP									
  members_string.go:4199	0x75efc5		5d			POPQ BP										
  members_string.go:4199	0x75efc6		c3			RET										
  utf8.go:449			0x75efc7		48ffc2			INCQ DX										
  utf8.go:448			0x75efca		4c39e3			CMPQ BX, R12									
  utf8.go:448			0x75efcd		7e34			JLE 0x75f003									
  utf8.go:448			0x75efcf		460fb62c20		MOVZX 0(AX)(R12*1), R13								
  utf8.go:448			0x75efd4		4183fd7f		CMPL R13, $0x7f									
  utf8.go:448			0x75efd8		7f05			JG 0x75efdf									
  utf8.go:448			0x75efda		49ffc4			INCQ R12									
  utf8.go:448			0x75efdd		ebe8			JMP 0x75efc7									
  utf8.go:448			0x75efdf		4889542450		MOVQ DX, 0x50(SP)								
  utf8.go:448			0x75efe4		4c89e1			MOVQ R12, CX									
  utf8.go:448			0x75efe7		e814e2d1ff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x75efec		488b842480000000	MOVQ 0x80(SP), AX								
  utf8.go:449			0x75eff4		488b542450		MOVQ 0x50(SP), DX								
  utf8.go:449			0x75eff9		4989dc			MOVQ BX, R12									
  utf8.go:448			0x75effc		488b5c2458		MOVQ 0x58(SP), BX								
  utf8.go:448			0x75f001		ebc4			JMP 0x75efc7									
  members_string.go:4188	0x75f003		4c8ba424f0000000	MOVQ 0xf0(SP), R12								
  members_string.go:4188	0x75f00b		4983fc02		CMPQ R12, $0x2									
  members_string.go:4191	0x75f00f		4889d0			MOVQ DX, AX									
  members_string.go:4191	0x75f012		e98dfeffff		JMP 0x75eea4									
  members_string.go:4187	0x75f017		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4187	0x75f01c		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4187	0x75f021		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4187	0x75f026		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4187	0x75f02b		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4187	0x75f030		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4187	0x75f035		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4187	0x75f03a		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4187	0x75f03f		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4187	0x75f044		e8f7d5d2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4187	0x75f049		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4187	0x75f04e		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4187	0x75f053		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4187	0x75f058		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4187	0x75f05d		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4187	0x75f062		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4187	0x75f067		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4187	0x75f06c		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4187	0x75f071		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4187	0x75f076		e905fdffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func27(SB)	

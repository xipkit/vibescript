TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB) /home/runner/work/vibescript/vibescript/base/vibes/value/value_methods.go
  value_methods.go:605		0x5aeca0		4c8da42488feffff	LEAQ 0xfffffe88(SP), R12									
  value_methods.go:605		0x5aeca8		4d3b6610		CMPQ R12, 0x10(R14)										
  value_methods.go:605		0x5aecac		0f86c9060000		JBE 0x5af37b											
  value_methods.go:605		0x5aecb2		55			PUSHQ BP											
  value_methods.go:605		0x5aecb3		4889e5			MOVQ SP, BP											
  value_methods.go:605		0x5aecb6		4881ecf0010000		SUBQ $0x1f0, SP											
  value_methods.go:605		0x5aecbd		48899c2408020000	MOVQ BX, 0x208(SP)										
  value_methods.go:605		0x5aecc5		48898c2410020000	MOVQ CX, 0x210(SP)										
  value_methods.go:607		0x5aeccd		4889b42420020000	MOVQ SI, 0x220(SP)										
  value_methods.go:605		0x5aecd5		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  value_methods.go:605		0x5aecde		6690			NOPW												
  value_methods.go:607		0x5aece0		4883f805		CMPQ AX, $0x5											
  value_methods.go:607		0x5aece4		0f8493020000		JE 0x5aef7d											
  value_methods.go:627		0x5aecea		4883f806		CMPQ AX, $0x6											
  value_methods.go:627		0x5aecee		0f84d5000000		JE 0x5aedc9											
  value_methods.go:647		0x5aecf4		4883f814		CMPQ AX, $0x14											
  value_methods.go:647		0x5aecf8		0f8488000000		JE 0x5aed86											
  value_methods.go:652		0x5aecfe		488b157b055b00		MOVQ github.com/mgomes/vibescript/vibes/value.RuntimeStringRuneLen(SB), DX			
  value_methods.go:652		0x5aed05		4885d2			TESTQ DX, DX											
  value_methods.go:652		0x5aed08		7449			JE 0x5aed53											
  value_methods.go:607		0x5aed0a		4889bc2418010000	MOVQ DI, 0x118(SP)										
  value_methods.go:607		0x5aed12		48898c24e8010000	MOVQ CX, 0x1e8(SP)										
  value_methods.go:607		0x5aed1a		48899c2410010000	MOVQ BX, 0x110(SP)										
  value_methods.go:607		0x5aed22		4889842408010000	MOVQ AX, 0x108(SP)										
  value_methods.go:653		0x5aed2a		488b32			MOVQ 0(DX), SI											
  value_methods.go:653		0x5aed2d		ffd6			CALL SI												
  value_methods.go:653		0x5aed2f		84db			TESTL BL, BL											
  value_methods.go:653		0x5aed31		753b			JNE 0x5aed6e											
  value_methods.go:657		0x5aed33		488b842408010000	MOVQ 0x108(SP), AX										
  value_methods.go:657		0x5aed3b		488b8c24e8010000	MOVQ 0x1e8(SP), CX										
  value_methods.go:657		0x5aed43		488b9c2410010000	MOVQ 0x110(SP), BX										
  value_methods.go:657		0x5aed4b		488bbc2418010000	MOVQ 0x118(SP), DI										
  value_methods.go:657		0x5aed53		e868d5ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  value_methods.go:657		0x5aed58		4889842428010000	MOVQ AX, 0x128(SP)										
  value_methods.go:657		0x5aed60		48895c2458		MOVQ BX, 0x58(SP)										
  utf8.go:448			0x5aed65		31d2			XORL DX, DX											
  utf8.go:448			0x5aed67		31f6			XORL SI, SI											
  utf8.go:448			0x5aed69		e9bd050000		JMP 0x5af32b											
  value_methods.go:654		0x5aed6e		4889442440		MOVQ AX, 0x40(SP)										
  value_methods.go:659		0x5aed73		e868d0e9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:654		0x5aed78		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aed7d		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aed84		5d			POPQ BP												
  value_methods.go:659		0x5aed85		c3			RET												
  value_methods.go:650		0x5aed86		488d15bb7b5500		LEAQ 0x557bbb(IP), DX										
  value_methods.go:650		0x5aed8d		4839d3			CMPQ BX, DX											
  value_methods.go:650		0x5aed90		0f857b050000		JNE 0x5af311											
  value_methods.go:650		0x5aed96		488b01			MOVQ 0(CX), AX											
  value_methods.go:650		0x5aed99		488b5908		MOVQ 0x8(CX), BX										
  value_methods.go:650		0x5aed9d		488b5110		MOVQ 0x10(CX), DX										
  value_methods.go:650		0x5aeda1		488b7918		MOVQ 0x18(CX), DI										
  value_methods.go:650		0x5aeda5		488b7120		MOVQ 0x20(CX), SI										
  value_methods.go:650		0x5aeda9		4889d1			MOVQ DX, CX											
  value_methods.go:650		0x5aedac		e86f69ffff		CALL github.com/mgomes/vibescript/vibes/value.Regex.StringRuneLen(SB)				
  value_methods.go:650		0x5aedb1		4889442440		MOVQ AX, 0x40(SP)										
  value_methods.go:659		0x5aedb6		e825d0e9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:650		0x5aedbb		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aedc0		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aedc7		5d			POPQ BP												
  value_methods.go:659		0x5aedc8		c3			RET												
  value_methods.go:628		0x5aedc9		90			NOPL												
  value_accessors.go:113	0x5aedca		488d151fc65000		LEAQ 0x50c61f(IP), DX										
  value_accessors.go:113	0x5aedd1		4839d3			CMPQ BX, DX											
  value_accessors.go:113	0x5aedd4		0f8525050000		JNE 0x5af2ff											
  value_accessors.go:113	0x5aedda		488b19			MOVQ 0(CX), BX											
  value_accessors.go:113	0x5aeddd		0f1f00			NOPL 0(AX)											
  value_methods.go:629		0x5aede0		4885db			TESTQ BX, BX											
  value_methods.go:629		0x5aede3		7405			JE 0x5aedea											
  value_methods.go:629		0x5aede5		488b13			MOVQ 0(BX), DX											
  value_methods.go:629		0x5aede8		eb02			JMP 0x5aedec											
  value_methods.go:629		0x5aedea		31d2			XORL DX, DX											
  value_methods.go:629		0x5aedec		4885d2			TESTQ DX, DX											
  value_methods.go:629		0x5aedef		0f846c010000		JE 0x5aef61											
  value_accessors.go:113	0x5aedf5		48899c24e0010000	MOVQ BX, 0x1e0(SP)										
  type.go:208			0x5aedfd		0fb615907a5100		MOVZX 0x517a90(IP), DX										
  value.go:165			0x5aee04		90			NOPL												
  type.go:208			0x5aee05		f6c220			TESTL $0x20, DL											
  value.go:3164			0x5aee08		b995000000		MOVL $0x95, CX											
  value.go:3164			0x5aee0d		ba15000000		MOVL $0x15, DX											
  value.go:3164			0x5aee12		480f45ca		CMOVNE DX, CX											
  value_methods.go:632		0x5aee16		488d05637a5100		LEAQ 0x517a63(IP), AX										
  value_methods.go:632		0x5aee1d		0f1f00			NOPL 0(AX)											
  value_methods.go:632		0x5aee20		e8fb7ff1ff		CALL reflect.Value.Pointer(SB)									
  value_methods.go:633		0x5aee25		4885c0			TESTQ AX, AX											
  value_methods.go:633		0x5aee28		7510			JNE 0x5aee3a											
  value_methods.go:629		0x5aee2a		488b9c24e0010000	MOVQ 0x1e0(SP), BX										
  value_methods.go:629		0x5aee32		4885db			TESTQ BX, BX											
  value_methods.go:633		0x5aee35		e9a9000000		JMP 0x5aeee3											
  value_methods.go:632		0x5aee3a		4889442460		MOVQ AX, 0x60(SP)										
  value_methods.go:634		0x5aee3f		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:634		0x5aee47		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:634		0x5aee4b		4889c1			MOVQ AX, CX											
  value_methods.go:634		0x5aee4e		488d056b7e5100		LEAQ 0x517e6b(IP), AX										
  value_methods.go:634		0x5aee55		e82699e5ff		CALL runtime.mapaccess2_fast64(SB)								
  value_methods.go:634		0x5aee5a		660f1f440000		NOPW 0(AX)(AX*1)										
  value_methods.go:634		0x5aee60		84db			TESTL BL, BL											
  value_methods.go:634		0x5aee62		0f85dd000000		JNE 0x5aef45											
  value_methods.go:637		0x5aee68		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:637		0x5aee70		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:637		0x5aee74		488d05457e5100		LEAQ 0x517e45(IP), AX										
  value_methods.go:637		0x5aee7b		488b4c2460		MOVQ 0x60(SP), CX										
  value_methods.go:637		0x5aee80		e85b9be5ff		CALL runtime.mapassign_fast64(SB)								
  value_methods.go:637		0x5aee85		8400			TESTB AL, 0(AX)											
  value_methods.go:638		0x5aee87		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:638		0x5aee8f		488b5208		MOVQ 0x8(DX), DX										
  value_methods.go:638		0x5aee93		488d35065c0000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB), SI	
  value_methods.go:638		0x5aee9a		4889b42438010000	MOVQ SI, 0x138(SP)										
  value_methods.go:638		0x5aeea2		4889942440010000	MOVQ DX, 0x140(SP)										
  value_methods.go:638		0x5aeeaa		488b542460		MOVQ 0x60(SP), DX										
  value_methods.go:638		0x5aeeaf		4889942448010000	MOVQ DX, 0x148(SP)										
  value_methods.go:638		0x5aeeb7		488d942438010000	LEAQ 0x138(SP), DX										
  value_methods.go:638		0x5aeebf		48899424a0000000	MOVQ DX, 0xa0(SP)										
  value_methods.go:638		0x5aeec7		488d842488000000	LEAQ 0x88(SP), AX										
  value_methods.go:638		0x5aeecf		e8ecc9e9ff		CALL runtime.deferprocStack(SB)									
  value_methods.go:629		0x5aeed4		488b9c24e0010000	MOVQ 0x1e0(SP), BX										
  value_methods.go:629		0x5aeedc		0f1f4000		NOPL 0(AX)											
  value_methods.go:629		0x5aeee0		4885db			TESTQ BX, BX											
  value_methods.go:641		0x5aeee3		7405			JE 0x5aeeea											
  value_methods.go:641		0x5aeee5		488b13			MOVQ 0(BX), DX											
  value_methods.go:641		0x5aeee8		eb02			JMP 0x5aeeec											
  value_methods.go:641		0x5aeeea		31d2			XORL DX, DX											
  value_methods.go:1031		0x5aeeec		4883fa02		CMPQ DX, $0x2											
  value_methods.go:1031		0x5aeef0		7d04			JGE 0x5aeef6											
  value_methods.go:1031		0x5aeef2		31d2			XORL DX, DX											
  value_methods.go:641		0x5aeef4		eb08			JMP 0x5aeefe											
  value_methods.go:1034		0x5aeef6		488d1412		LEAQ 0(DX)(DX*1), DX										
  value_methods.go:1034		0x5aeefa		488d52fe		LEAQ -0x2(DX), DX										
  value_methods.go:641		0x5aeefe		4889542438		MOVQ DX, 0x38(SP)										
  value_methods.go:642		0x5aef03		488d8c2478010000	LEAQ 0x178(SP), CX										
  value_methods.go:642		0x5aef0b		440f1139		MOVUPS X15, 0(CX)										
  value_methods.go:642		0x5aef0f		440f117910		MOVUPS X15, 0x10(CX)										
  value_methods.go:642		0x5aef14		440f117920		MOVUPS X15, 0x20(CX)										
  value_methods.go:642		0x5aef19		440f117930		MOVUPS X15, 0x30(CX)										
  value_methods.go:642		0x5aef1e		440f117940		MOVUPS X15, 0x40(CX)										
  value_methods.go:642		0x5aef23		440f117950		MOVUPS X15, 0x50(CX)										
  value_methods.go:642		0x5aef28		488d0551795100		LEAQ 0x517951(IP), AX										
  value_methods.go:642		0x5aef2f		e88c59e7ff		CALL runtime.mapIterStart(SB)									
  value_methods.go:641		0x5aef34		488b542438		MOVQ 0x38(SP), DX										
  value_methods.go:641		0x5aef39		4883c202		ADDQ $0x2, DX											
  value_methods.go:641		0x5aef3d		0f1f00			NOPL 0(AX)											
  value_methods.go:642		0x5aef40		e9d4020000		JMP 0x5af219											
  value_methods.go:635		0x5aef45		48c744244007000000	MOVQ $0x7, 0x40(SP)										
  value_methods.go:659		0x5aef4e		e88dcee9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:635		0x5aef53		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aef58		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aef5f		5d			POPQ BP												
  value_methods.go:659		0x5aef60		c3			RET												
  value_methods.go:630		0x5aef61		48c744244002000000	MOVQ $0x2, 0x40(SP)										
  value_methods.go:659		0x5aef6a		e871cee9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:630		0x5aef6f		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aef74		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aef7b		5d			POPQ BP												
  value_methods.go:659		0x5aef7c		c3			RET												
  value_methods.go:608		0x5aef7d		90			NOPL												
  value_accessors.go:86		0x5aef7e		488d15c3c35000		LEAQ 0x50c3c3(IP), DX										
  value_accessors.go:86		0x5aef85		4839d3			CMPQ BX, DX											
  value_accessors.go:86		0x5aef88		0f8534020000		JNE 0x5af1c2											
  value_accessors.go:86		0x5aef8e		488b5908		MOVQ 0x8(CX), BX										
  value_accessors.go:86		0x5aef92		48895c2428		MOVQ BX, 0x28(SP)										
  value_accessors.go:86		0x5aef97		488b5110		MOVQ 0x10(CX), DX										
  value_accessors.go:86		0x5aef9b		4889542430		MOVQ DX, 0x30(SP)										
  value_accessors.go:86		0x5aefa0		488b01			MOVQ 0(CX), AX											
  value_accessors.go:86		0x5aefa3		4889842420010000	MOVQ AX, 0x120(SP)										
  value_methods.go:610		0x5aefab		4889d1			MOVQ DX, CX											
  value_methods.go:610		0x5aefae		e86d6bedff		CALL runtime.convTslice(SB)									
  type.go:208			0x5aefb3		0fb615721b5100		MOVZX 0x511b72(IP), DX										
  value.go:165			0x5aefba		90			NOPL												
  type.go:208			0x5aefbb		f6c220			TESTL $0x20, DL											
  value.go:3164			0x5aefbe		b997000000		MOVL $0x97, CX											
  value.go:3164			0x5aefc3		ba17000000		MOVL $0x17, DX											
  value.go:3164			0x5aefc8		480f45ca		CMOVNE DX, CX											
  value_methods.go:610		0x5aefcc		4889c3			MOVQ AX, BX											
  value_methods.go:610		0x5aefcf		488d05421b5100		LEAQ 0x511b42(IP), AX										
  value_methods.go:610		0x5aefd6		e8457ef1ff		CALL reflect.Value.Pointer(SB)									
  value_methods.go:610		0x5aefdb		0f1f440000		NOPL 0(AX)(AX*1)										
  value_methods.go:614		0x5aefe0		4885c0			TESTQ AX, AX											
  value_methods.go:614		0x5aefe3		0f8407010000		JE 0x5af0f0											
  value_methods.go:610		0x5aefe9		4889842480000000	MOVQ AX, 0x80(SP)										
  value_methods.go:615		0x5aeff1		48898424e8000000	MOVQ AX, 0xe8(SP)										
  value_methods.go:615		0x5aeff9		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:615		0x5aeffe		48899424f0000000	MOVQ DX, 0xf0(SP)										
  value_methods.go:615		0x5af006		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:615		0x5af00b		48899424f8000000	MOVQ DX, 0xf8(SP)										
  value_methods.go:615		0x5af013		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:615		0x5af01b		488b1a			MOVQ 0(DX), BX											
  value_methods.go:615		0x5af01e		488d05bb7e5100		LEAQ 0x517ebb(IP), AX										
  value_methods.go:615		0x5af025		488d8c24e8000000	LEAQ 0xe8(SP), CX										
  value_methods.go:615		0x5af02d		e8ee87e5ff		CALL runtime.mapaccess2(SB)									
  value_methods.go:615		0x5af032		84db			TESTL BL, BL											
  value_methods.go:615		0x5af034		0f85f9000000		JNE 0x5af133											
  value_methods.go:618		0x5af03a		488b942480000000	MOVQ 0x80(SP), DX										
  value_methods.go:618		0x5af042		48899424e8000000	MOVQ DX, 0xe8(SP)										
  value_methods.go:618		0x5af04a		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:618		0x5af04f		48899424f0000000	MOVQ DX, 0xf0(SP)										
  value_methods.go:618		0x5af057		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:618		0x5af05c		48899424f8000000	MOVQ DX, 0xf8(SP)										
  value_methods.go:618		0x5af064		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:618		0x5af06c		488b1a			MOVQ 0(DX), BX											
  value_methods.go:618		0x5af06f		488d056a7e5100		LEAQ 0x517e6a(IP), AX										
  value_methods.go:618		0x5af076		488d8c24e8000000	LEAQ 0xe8(SP), CX										
  value_methods.go:618		0x5af07e		6690			NOPW												
  value_methods.go:618		0x5af080		e87b8ae5ff		CALL runtime.mapassign(SB)									
  value_methods.go:618		0x5af085		8400			TESTB AL, 0(AX)											
  value_methods.go:619		0x5af087		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:619		0x5af08f		488b12			MOVQ 0(DX), DX											
  value_methods.go:619		0x5af092		488d35475a0000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB), SI	
  value_methods.go:619		0x5af099		4889b42450010000	MOVQ SI, 0x150(SP)										
  value_methods.go:619		0x5af0a1		4889942458010000	MOVQ DX, 0x158(SP)										
  value_methods.go:619		0x5af0a9		488b942480000000	MOVQ 0x80(SP), DX										
  value_methods.go:619		0x5af0b1		4889942460010000	MOVQ DX, 0x160(SP)										
  value_methods.go:619		0x5af0b9		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:619		0x5af0be		4889942468010000	MOVQ DX, 0x168(SP)										
  value_methods.go:619		0x5af0c6		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:619		0x5af0cb		4889942470010000	MOVQ DX, 0x170(SP)										
  value_methods.go:619		0x5af0d3		488d942450010000	LEAQ 0x150(SP), DX										
  value_methods.go:619		0x5af0db		48899424d0000000	MOVQ DX, 0xd0(SP)										
  value_methods.go:619		0x5af0e3		488d8424b8000000	LEAQ 0xb8(SP), AX										
  value_methods.go:619		0x5af0eb		e8d0c7e9ff		CALL runtime.deferprocStack(SB)									
  value_methods.go:1031		0x5af0f0		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:1031		0x5af0f5		4883fa02		CMPQ DX, $0x2											
  value_methods.go:1031		0x5af0f9		7d07			JGE 0x5af102											
  value_methods.go:1031		0x5af0fb		4531c0			XORL R8, R8											
  value_methods.go:1031		0x5af0fe		6690			NOPW												
  value_methods.go:622		0x5af100		eb08			JMP 0x5af10a											
  value_methods.go:1034		0x5af102		4c8d0412		LEAQ 0(DX)(DX*1), R8										
  value_methods.go:1034		0x5af106		4d8d40fe		LEAQ -0x2(R8), R8										
  value_methods.go:622		0x5af10a		4983c002		ADDQ $0x2, R8											
  value_methods.go:623		0x5af10e		4c8b8c2420010000	MOVQ 0x120(SP), R9										
  value_methods.go:623		0x5af116		e98a000000		JMP 0x5af1a5											
  value_methods.go:659		0x5af11b		0f1f440000		NOPL 0(AX)(AX*1)										
  value_methods.go:659		0x5af120		e8bbcce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:619		0x5af125		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af12a		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af131		5d			POPQ BP												
  value_methods.go:659		0x5af132		c3			RET												
  value_methods.go:616		0x5af133		48c744244007000000	MOVQ $0x7, 0x40(SP)										
  value_methods.go:616		0x5af13c		0f1f4000		NOPL 0(AX)											
  value_methods.go:659		0x5af140		e89bcce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:616		0x5af145		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af14a		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af151		5d			POPQ BP												
  value_methods.go:659		0x5af152		c3			RET												
  value_methods.go:623		0x5af153		4889942400010000	MOVQ DX, 0x100(SP)										
  value_methods.go:623		0x5af15b		4c89442450		MOVQ R8, 0x50(SP)										
  value_methods.go:623		0x5af160		4c898c24d8010000	MOVQ R9, 0x1d8(SP)										
  value_methods.go:623		0x5af168		498b01			MOVQ 0(R9), AX											
  value_methods.go:623		0x5af16b		498b4910		MOVQ 0x10(R9), CX										
  value_methods.go:623		0x5af16f		498b7918		MOVQ 0x18(R9), DI										
  value_methods.go:623		0x5af173		498b5908		MOVQ 0x8(R9), BX										
  value_methods.go:624		0x5af177		488bb42420020000	MOVQ 0x220(SP), SI										
  value_methods.go:624		0x5af17f		90			NOPL												
  value_methods.go:624		0x5af180		e81bfbffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			
  value_methods.go:623		0x5af185		4c8b8c24d8010000	MOVQ 0x1d8(SP), R9										
  value_methods.go:623		0x5af18d		4983c120		ADDQ $0x20, R9											
  value_methods.go:624		0x5af191		488b542450		MOVQ 0x50(SP), DX										
  value_methods.go:624		0x5af196		4c8d0402		LEAQ 0(DX)(AX*1), R8										
  value_methods.go:623		0x5af19a		488b942400010000	MOVQ 0x100(SP), DX										
  value_methods.go:623		0x5af1a2		48ffca			DECQ DX												
  value_methods.go:623		0x5af1a5		4885d2			TESTQ DX, DX											
  value_methods.go:623		0x5af1a8		7fa9			JG 0x5af153											
  value_methods.go:626		0x5af1aa		4c89442440		MOVQ R8, 0x40(SP)										
  value_methods.go:659		0x5af1af		e82ccce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:626		0x5af1b4		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af1b9		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af1c0		5d			POPQ BP												
  value_methods.go:659		0x5af1c1		c3			RET												
  value_accessors.go:86		0x5af1c2		4889d8			MOVQ BX, AX											
  value_accessors.go:86		0x5af1c5		4889d3			MOVQ DX, BX											
  value_accessors.go:86		0x5af1c8		488d0d31735300		LEAQ 0x537331(IP), CX										
  value_accessors.go:86		0x5af1cf		e82cdce6ff		CALL runtime.panicdottypeE(SB)									
  value_methods.go:644		0x5af1d4		4c89c0			MOVQ R8, AX											
  value_methods.go:644		0x5af1d7		4c89d3			MOVQ R10, BX											
  value_methods.go:644		0x5af1da		488bb42420020000	MOVQ 0x220(SP), SI										
  value_methods.go:644		0x5af1e2		e8b9faffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			
  value_methods.go:644		0x5af1e7		4889842400010000	MOVQ AX, 0x100(SP)										
  value_methods.go:642		0x5af1ef		488d842478010000	LEAQ 0x178(SP), AX										
  value_methods.go:642		0x5af1f7		e82457e7ff		CALL runtime.mapIterNext(SB)									
  value_methods.go:643		0x5af1fc		488b542470		MOVQ 0x70(SP), DX										
  value_methods.go:643		0x5af201		4c8b442448		MOVQ 0x48(SP), R8										
  value_methods.go:643		0x5af206		4c01c2			ADDQ R8, DX											
  value_methods.go:644		0x5af209		4c8b842400010000	MOVQ 0x100(SP), R8										
  value_methods.go:644		0x5af211		4a8d1402		LEAQ 0(DX)(R8*1), DX										
  value_methods.go:644		0x5af215		488d5202		LEAQ 0x2(DX), DX										
  value_methods.go:642		0x5af219		4c8b842478010000	MOVQ 0x178(SP), R8										
  value_methods.go:642		0x5af221		4d85c0			TESTQ R8, R8											
  value_methods.go:642		0x5af224		0f84bd000000		JE 0x5af2e7											
  value_methods.go:642		0x5af22a		4889542448		MOVQ DX, 0x48(SP)										
  value_methods.go:642		0x5af22f		4c8b8c2480010000	MOVQ 0x180(SP), R9										
  value_methods.go:642		0x5af237		498b00			MOVQ 0(R8), AX											
  value_methods.go:642		0x5af23a		4889842430010000	MOVQ AX, 0x130(SP)										
  value_methods.go:642		0x5af242		498b5808		MOVQ 0x8(R8), BX										
  value_methods.go:642		0x5af246		48895c2478		MOVQ BX, 0x78(SP)										
  value_methods.go:642		0x5af24b		4d8b01			MOVQ 0(R9), R8											
  value_methods.go:642		0x5af24e		4c89842408010000	MOVQ R8, 0x108(SP)										
  value_methods.go:642		0x5af256		4d8b5108		MOVQ 0x8(R9), R10										
  value_methods.go:642		0x5af25a		4c89942410010000	MOVQ R10, 0x110(SP)										
  value_methods.go:642		0x5af262		498b4910		MOVQ 0x10(R9), CX										
  value_methods.go:642		0x5af266		48898c24e8010000	MOVQ CX, 0x1e8(SP)										
  value_methods.go:642		0x5af26e		498b7918		MOVQ 0x18(R9), DI										
  value_methods.go:642		0x5af272		4889bc2418010000	MOVQ DI, 0x118(SP)										
  utf8.go:448			0x5af27a		4531c9			XORL R9, R9											
  utf8.go:448			0x5af27d		4531db			XORL R11, R11											
  utf8.go:448			0x5af280		eb03			JMP 0x5af285											
  utf8.go:449			0x5af282		49ffc1			INCQ R9												
  utf8.go:448			0x5af285		4c894c2470		MOVQ R9, 0x70(SP)										
  utf8.go:448			0x5af28a		4939db			CMPQ R11, BX											
  utf8.go:448			0x5af28d		0f8d41ffffff		JGE 0x5af1d4											
  utf8.go:448			0x5af293		450fb62403		MOVZX 0(R11)(AX*1), R12										
  utf8.go:448			0x5af298		4183fc7f		CMPL R12, $0x7f											
  utf8.go:448			0x5af29c		7f05			JG 0x5af2a3											
  utf8.go:448			0x5af29e		49ffc3			INCQ R11											
  utf8.go:448			0x5af2a1		ebdf			JMP 0x5af282											
  utf8.go:448			0x5af2a3		4c89d9			MOVQ R11, CX											
  utf8.go:448			0x5af2a6		e815dfecff		CALL runtime.decoderune(SB)									
  utf8.go:448			0x5af2ab		488b842430010000	MOVQ 0x130(SP), AX										
  value_methods.go:644		0x5af2b3		488b8c24e8010000	MOVQ 0x1e8(SP), CX										
  value_methods.go:643		0x5af2bb		488b542448		MOVQ 0x48(SP), DX										
  value_methods.go:644		0x5af2c0		488bbc2418010000	MOVQ 0x118(SP), DI										
  value_methods.go:644		0x5af2c8		4c8b842408010000	MOVQ 0x108(SP), R8										
  utf8.go:449			0x5af2d0		4c8b4c2470		MOVQ 0x70(SP), R9										
  value_methods.go:644		0x5af2d5		4c8b942410010000	MOVQ 0x110(SP), R10										
  utf8.go:449			0x5af2dd		4989db			MOVQ BX, R11											
  utf8.go:448			0x5af2e0		488b5c2478		MOVQ 0x78(SP), BX										
  utf8.go:448			0x5af2e5		eb9b			JMP 0x5af282											
  value_methods.go:646		0x5af2e7		4889542440		MOVQ DX, 0x40(SP)										
  value_methods.go:659		0x5af2ec		e8efcae9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:646		0x5af2f1		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af2f6		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af2fd		5d			POPQ BP												
  value_methods.go:659		0x5af2fe		c3			RET												
  value_accessors.go:113	0x5af2ff		4889d8			MOVQ BX, AX											
  value_accessors.go:113	0x5af302		4889d3			MOVQ DX, BX											
  value_accessors.go:113	0x5af305		488d0df4715300		LEAQ 0x5371f4(IP), CX										
  value_accessors.go:113	0x5af30c		e8efdae6ff		CALL runtime.panicdottypeE(SB)									
  value_methods.go:650		0x5af311		4889d8			MOVQ BX, AX											
  value_methods.go:650		0x5af314		4889d3			MOVQ DX, BX											
  value_methods.go:650		0x5af317		488d0de2715300		LEAQ 0x5371e2(IP), CX										
  value_methods.go:650		0x5af31e		6690			NOPW												
  value_methods.go:650		0x5af320		e8dbdae6ff		CALL runtime.panicdottypeE(SB)									
  utf8.go:449			0x5af325		48ffc6			INCQ SI												
  utf8.go:448			0x5af328		4889ca			MOVQ CX, DX											
  utf8.go:448			0x5af32b		4839d3			CMPQ BX, DX											
  utf8.go:448			0x5af32e		7e33			JLE 0x5af363											
  utf8.go:448			0x5af330		0fb63c10		MOVZX 0(AX)(DX*1), DI										
  utf8.go:448			0x5af334		83ff7f			CMPL DI, $0x7f											
  utf8.go:448			0x5af337		7f06			JG 0x5af33f											
  utf8.go:448			0x5af339		488d4a01		LEAQ 0x1(DX), CX										
  utf8.go:448			0x5af33d		ebe6			JMP 0x5af325											
  utf8.go:448			0x5af33f		4889742468		MOVQ SI, 0x68(SP)										
  utf8.go:448			0x5af344		4889d1			MOVQ DX, CX											
  utf8.go:448			0x5af347		e874deecff		CALL runtime.decoderune(SB)									
  utf8.go:448			0x5af34c		488b842428010000	MOVQ 0x128(SP), AX										
  utf8.go:449			0x5af354		488b742468		MOVQ 0x68(SP), SI										
  utf8.go:449			0x5af359		4889d9			MOVQ BX, CX											
  utf8.go:448			0x5af35c		488b5c2458		MOVQ 0x58(SP), BX										
  utf8.go:448			0x5af361		ebc2			JMP 0x5af325											
  value_methods.go:657		0x5af363		4889742440		MOVQ SI, 0x40(SP)										
  value_methods.go:659		0x5af368		e873cae9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:657		0x5af36d		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af372		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af379		5d			POPQ BP												
  value_methods.go:659		0x5af37a		c3			RET												
  value_methods.go:605		0x5af37b		4889442408		MOVQ AX, 0x8(SP)										
  value_methods.go:605		0x5af380		48895c2410		MOVQ BX, 0x10(SP)										
  value_methods.go:605		0x5af385		48894c2418		MOVQ CX, 0x18(SP)										
  value_methods.go:605		0x5af38a		48897c2420		MOVQ DI, 0x20(SP)										
  value_methods.go:605		0x5af38f		4889742428		MOVQ SI, 0x28(SP)										
  value_methods.go:605		0x5af394		e867d2edff		CALL runtime.morestack_noctxt.abi0(SB)								
  value_methods.go:605		0x5af399		488b442408		MOVQ 0x8(SP), AX										
  value_methods.go:605		0x5af39e		488b5c2410		MOVQ 0x10(SP), BX										
  value_methods.go:605		0x5af3a3		488b4c2418		MOVQ 0x18(SP), CX										
  value_methods.go:605		0x5af3a8		488b7c2420		MOVQ 0x20(SP), DI										
  value_methods.go:605		0x5af3ad		488b742428		MOVQ 0x28(SP), SI										
  value_methods.go:605		0x5af3b2		e9e9f8ffff		JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB) /home/runner/work/vibescript/vibescript/base/vibes/value/value_methods.go
  value_methods.go:844		0x5b0720		4c8da42468feffff	LEAQ 0xfffffe68(SP), R12										
  value_methods.go:844		0x5b0728		4d3b6610		CMPQ R12, 0x10(R14)											
  value_methods.go:844		0x5b072c		0f86210a0000		JBE 0x5b1153												
  value_methods.go:844		0x5b0732		55			PUSHQ BP												
  value_methods.go:844		0x5b0733		4889e5			MOVQ SP, BP												
  value_methods.go:844		0x5b0736		4881ec10020000		SUBQ $0x210, SP												
  value_methods.go:844		0x5b073d		48899c2428020000	MOVQ BX, 0x228(SP)											
  value_methods.go:844		0x5b0745		48898c2430020000	MOVQ CX, 0x230(SP)											
  value_methods.go:845		0x5b074d		4889b42440020000	MOVQ SI, 0x240(SP)											
  value_methods.go:845		0x5b0755		4c89842448020000	MOVQ R8, 0x248(SP)											
  value_methods.go:845		0x5b075d		48898c24f0010000	MOVQ CX, 0x1f0(SP)											
  value_methods.go:845		0x5b0765		48899c24c8000000	MOVQ BX, 0xc8(SP)											
  value_methods.go:845		0x5b076d		48898424c0000000	MOVQ AX, 0xc0(SP)											
  value_methods.go:845		0x5b0775		4889bc24b8000000	MOVQ DI, 0xb8(SP)											
  value_methods.go:844		0x5b077d		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:844		0x5b0786		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:845		0x5b078f		498b00			MOVQ 0(R8), AX												
  value_methods.go:845		0x5b0792		4c89c2			MOVQ R8, DX												
  value_methods.go:845		0x5b0795		ffd0			CALL AX													
  value_methods.go:845		0x5b0797		660f1f840000000000	NOPW 0(AX)(AX*1)											
  value_methods.go:845		0x5b07a0		4885c0			TESTQ AX, AX												
  value_methods.go:845		0x5b07a3		0f854d050000		JNE 0x5b0cf6												
  value_methods.go:849		0x5b07a9		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:849		0x5b07b1		4883f805		CMPQ AX, $0x5												
  value_methods.go:849		0x5b07b5		0f85e5010000		JNE 0x5b09a0												
  value_methods.go:850		0x5b07bb		90			NOPL													
  value_accessors.go:86		0x5b07bc		488b8424c8000000	MOVQ 0xc8(SP), AX											
  value_accessors.go:86		0x5b07c4		488d1d7dab5000		LEAQ 0x50ab7d(IP), BX											
  value_accessors.go:86		0x5b07cb		4839d8			CMPQ AX, BX												
  value_accessors.go:86		0x5b07ce		0f8572090000		JNE 0x5b1146												
  value_accessors.go:86		0x5b07d4		488b9424f0010000	MOVQ 0x1f0(SP), DX											
  value_accessors.go:86		0x5b07dc		488b5a08		MOVQ 0x8(DX), BX											
  value_accessors.go:86		0x5b07e0		48895c2430		MOVQ BX, 0x30(SP)											
  value_accessors.go:86		0x5b07e5		488b4a10		MOVQ 0x10(DX), CX											
  value_accessors.go:86		0x5b07e9		48894c2438		MOVQ CX, 0x38(SP)											
  value_accessors.go:86		0x5b07ee		488b02			MOVQ 0(DX), AX												
  value_accessors.go:86		0x5b07f1		4889842440010000	MOVQ AX, 0x140(SP)											
  value_methods.go:852		0x5b07f9		e82253edff		CALL runtime.convTslice(SB)										
  type.go:208			0x5b07fe		0fb61527035100		MOVZX 0x510327(IP), DX											
  value.go:165			0x5b0805		90			NOPL													
  type.go:208			0x5b0806		f6c220			TESTL $0x20, DL												
  value.go:3164			0x5b0809		b997000000		MOVL $0x97, CX												
  value.go:3164			0x5b080e		ba17000000		MOVL $0x17, DX												
  value.go:3164			0x5b0813		480f45ca		CMOVNE DX, CX												
  value_methods.go:852		0x5b0817		4889c3			MOVQ AX, BX												
  value_methods.go:852		0x5b081a		488d05f7025100		LEAQ 0x5102f7(IP), AX											
  value_methods.go:852		0x5b0821		e8fa65f1ff		CALL reflect.Value.Pointer(SB)										
  value_methods.go:856		0x5b0826		4885c0			TESTQ AX, AX												
  value_methods.go:856		0x5b0829		0f840d010000		JE 0x5b093c												
  value_methods.go:852		0x5b082f		4889842490000000	MOVQ AX, 0x90(SP)											
  value_methods.go:857		0x5b0837		4889842498000000	MOVQ AX, 0x98(SP)											
  value_methods.go:857		0x5b083f		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:857		0x5b0844		48899424a0000000	MOVQ DX, 0xa0(SP)											
  value_methods.go:857		0x5b084c		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:857		0x5b0851		48899424a8000000	MOVQ DX, 0xa8(SP)											
  value_methods.go:857		0x5b0859		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:857		0x5b0861		488b1a			MOVQ 0(DX), BX												
  value_methods.go:857		0x5b0864		488d0575665100		LEAQ 0x516675(IP), AX											
  value_methods.go:857		0x5b086b		488d8c2498000000	LEAQ 0x98(SP), CX											
  value_methods.go:857		0x5b0873		e8a86fe5ff		CALL runtime.mapaccess2(SB)										
  value_methods.go:857		0x5b0878		0f1f840000000000	NOPL 0(AX)(AX*1)											
  value_methods.go:857		0x5b0880		84db			TESTL BL, BL												
  value_methods.go:857		0x5b0882		0f85dd000000		JNE 0x5b0965												
  value_methods.go:860		0x5b0888		488b942490000000	MOVQ 0x90(SP), DX											
  value_methods.go:860		0x5b0890		4889942498000000	MOVQ DX, 0x98(SP)											
  value_methods.go:860		0x5b0898		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:860		0x5b089d		48899424a0000000	MOVQ DX, 0xa0(SP)											
  value_methods.go:860		0x5b08a5		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:860		0x5b08aa		48899424a8000000	MOVQ DX, 0xa8(SP)											
  value_methods.go:860		0x5b08b2		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:860		0x5b08ba		488b1a			MOVQ 0(DX), BX												
  value_methods.go:860		0x5b08bd		488d051c665100		LEAQ 0x51661c(IP), AX											
  value_methods.go:860		0x5b08c4		488d8c2498000000	LEAQ 0x98(SP), CX											
  value_methods.go:860		0x5b08cc		e82f72e5ff		CALL runtime.mapassign(SB)										
  value_methods.go:860		0x5b08d1		8400			TESTB AL, 0(AX)												
  value_methods.go:861		0x5b08d3		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:861		0x5b08db		488b12			MOVQ 0(DX), DX												
  value_methods.go:861		0x5b08de		488d35fb420000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB), SI	
  value_methods.go:861		0x5b08e5		4889b42460010000	MOVQ SI, 0x160(SP)											
  value_methods.go:861		0x5b08ed		4889942468010000	MOVQ DX, 0x168(SP)											
  value_methods.go:861		0x5b08f5		488b942490000000	MOVQ 0x90(SP), DX											
  value_methods.go:861		0x5b08fd		4889942470010000	MOVQ DX, 0x170(SP)											
  value_methods.go:861		0x5b0905		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:861		0x5b090a		4889942478010000	MOVQ DX, 0x178(SP)											
  value_methods.go:861		0x5b0912		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:861		0x5b0917		4889942480010000	MOVQ DX, 0x180(SP)											
  value_methods.go:861		0x5b091f		488d942460010000	LEAQ 0x160(SP), DX											
  value_methods.go:861		0x5b0927		4889942418010000	MOVQ DX, 0x118(SP)											
  value_methods.go:861		0x5b092f		488d842400010000	LEAQ 0x100(SP), AX											
  value_methods.go:861		0x5b0937		e884afe9ff		CALL runtime.deferprocStack(SB)										
  value_methods.go:1031		0x5b093c		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:1031		0x5b0941		4883fa02		CMPQ DX, $0x2												
  value_methods.go:1031		0x5b0945		7d05			JGE 0x5b094c												
  value_methods.go:1031		0x5b0947		4531c9			XORL R9, R9												
  value_methods.go:864		0x5b094a		eb08			JMP 0x5b0954												
  value_methods.go:1034		0x5b094c		4c8d0c12		LEAQ 0(DX)(DX*1), R9											
  value_methods.go:1034		0x5b0950		4d8d49fe		LEAQ -0x2(R9), R9											
  value_methods.go:864		0x5b0954		4983c102		ADDQ $0x2, R9												
  value_methods.go:865		0x5b0958		4c8b942440010000	MOVQ 0x140(SP), R10											
  value_methods.go:865		0x5b0960		e931070000		JMP 0x5b1096												
  value_methods.go:858		0x5b0965		48c744244807000000	MOVQ $0x7, 0x48(SP)											
  value_methods.go:858		0x5b096e		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0977		e864b4e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:858		0x5b097c		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:858		0x5b0984		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:858		0x5b098c		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0991		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0998		5d			POPQ BP													
  value_methods.go:918		0x5b0999		c3			RET													
  value_methods.go:918		0x5b099a		660f1f440000		NOPW 0(AX)(AX*1)											
  value_methods.go:873		0x5b09a0		4883f806		CMPQ AX, $0x6												
  value_methods.go:873		0x5b09a4		0f850e020000		JNE 0x5b0bb8												
  value_methods.go:874		0x5b09aa		90			NOPL													
  value_accessors.go:113	0x5b09ab		488b8424c8000000	MOVQ 0xc8(SP), AX											
  value_accessors.go:113	0x5b09b3		488d1d36aa5000		LEAQ 0x50aa36(IP), BX											
  value_accessors.go:113	0x5b09ba		660f1f440000		NOPW 0(AX)(AX*1)											
  value_accessors.go:113	0x5b09c0		4839d8			CMPQ AX, BX												
  value_accessors.go:113	0x5b09c3		0f85a1060000		JNE 0x5b106a												
  value_accessors.go:113	0x5b09c9		488b9424f0010000	MOVQ 0x1f0(SP), DX											
  value_accessors.go:113	0x5b09d1		488b1a			MOVQ 0(DX), BX												
  value_methods.go:875		0x5b09d4		4885db			TESTQ BX, BX												
  value_methods.go:875		0x5b09d7		7405			JE 0x5b09de												
  value_methods.go:875		0x5b09d9		488b13			MOVQ 0(BX), DX												
  value_methods.go:875		0x5b09dc		eb02			JMP 0x5b09e0												
  value_methods.go:875		0x5b09de		31d2			XORL DX, DX												
  value_methods.go:875		0x5b09e0		4885d2			TESTQ DX, DX												
  value_methods.go:875		0x5b09e3		0f849a010000		JE 0x5b0b83												
  value_accessors.go:113	0x5b09e9		48899c2448010000	MOVQ BX, 0x148(SP)											
  type.go:208			0x5b09f1		0fb6159c5e5100		MOVZX 0x515e9c(IP), DX											
  value.go:165			0x5b09f8		90			NOPL													
  type.go:208			0x5b09f9		f6c220			TESTL $0x20, DL												
  value.go:3164			0x5b09fc		b995000000		MOVL $0x95, CX												
  value.go:3164			0x5b0a01		ba15000000		MOVL $0x15, DX												
  value.go:3164			0x5b0a06		480f45ca		CMOVNE DX, CX												
  value_methods.go:878		0x5b0a0a		488d056f5e5100		LEAQ 0x515e6f(IP), AX											
  value_methods.go:878		0x5b0a11		e80a64f1ff		CALL reflect.Value.Pointer(SB)										
  value_methods.go:879		0x5b0a16		4885c0			TESTQ AX, AX												
  value_methods.go:879		0x5b0a19		7510			JNE 0x5b0a2b												
  value_methods.go:875		0x5b0a1b		488b9c2448010000	MOVQ 0x148(SP), BX											
  value_methods.go:875		0x5b0a23		4885db			TESTQ BX, BX												
  value_methods.go:879		0x5b0a26		e99f000000		JMP 0x5b0aca												
  value_methods.go:878		0x5b0a2b		4889442468		MOVQ AX, 0x68(SP)											
  value_methods.go:880		0x5b0a30		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:880		0x5b0a38		488b5a08		MOVQ 0x8(DX), BX											
  value_methods.go:880		0x5b0a3c		4889c1			MOVQ AX, CX												
  value_methods.go:880		0x5b0a3f		488d057a625100		LEAQ 0x51627a(IP), AX											
  value_methods.go:880		0x5b0a46		e8357de5ff		CALL runtime.mapaccess2_fast64(SB)									
  value_methods.go:880		0x5b0a4b		84db			TESTL BL, BL												
  value_methods.go:880		0x5b0a4d		0f85f9000000		JNE 0x5b0b4c												
  value_methods.go:883		0x5b0a53		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:883		0x5b0a5b		488b5a08		MOVQ 0x8(DX), BX											
  value_methods.go:883		0x5b0a5f		488d055a625100		LEAQ 0x51625a(IP), AX											
  value_methods.go:883		0x5b0a66		488b4c2468		MOVQ 0x68(SP), CX											
  value_methods.go:883		0x5b0a6b		e8707fe5ff		CALL runtime.mapassign_fast64(SB)									
  value_methods.go:883		0x5b0a70		8400			TESTB AL, 0(AX)												
  value_methods.go:884		0x5b0a72		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:884		0x5b0a7a		488b5208		MOVQ 0x8(DX), DX											
  value_methods.go:884		0x5b0a7e		488d351b410000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB), SI	
  value_methods.go:884		0x5b0a85		4889b424f8010000	MOVQ SI, 0x1f8(SP)											
  value_methods.go:884		0x5b0a8d		4889942400020000	MOVQ DX, 0x200(SP)											
  value_methods.go:884		0x5b0a95		488b542468		MOVQ 0x68(SP), DX											
  value_methods.go:884		0x5b0a9a		4889942408020000	MOVQ DX, 0x208(SP)											
  value_methods.go:884		0x5b0aa2		488d9424f8010000	LEAQ 0x1f8(SP), DX											
  value_methods.go:884		0x5b0aaa		48899424e8000000	MOVQ DX, 0xe8(SP)											
  value_methods.go:884		0x5b0ab2		488d8424d0000000	LEAQ 0xd0(SP), AX											
  value_methods.go:884		0x5b0aba		e801aee9ff		CALL runtime.deferprocStack(SB)										
  value_methods.go:875		0x5b0abf		488b9c2448010000	MOVQ 0x148(SP), BX											
  value_methods.go:875		0x5b0ac7		4885db			TESTQ BX, BX												
  value_methods.go:887		0x5b0aca		7405			JE 0x5b0ad1												
  value_methods.go:887		0x5b0acc		488b13			MOVQ 0(BX), DX												
  value_methods.go:887		0x5b0acf		eb02			JMP 0x5b0ad3												
  value_methods.go:887		0x5b0ad1		31d2			XORL DX, DX												
  value_methods.go:1031		0x5b0ad3		4883fa02		CMPQ DX, $0x2												
  value_methods.go:1031		0x5b0ad7		7d04			JGE 0x5b0add												
  value_methods.go:1031		0x5b0ad9		31d2			XORL DX, DX												
  value_methods.go:887		0x5b0adb		eb08			JMP 0x5b0ae5												
  value_methods.go:1034		0x5b0add		488d1412		LEAQ 0(DX)(DX*1), DX											
  value_methods.go:1034		0x5b0ae1		488d52fe		LEAQ -0x2(DX), DX											
  value_methods.go:887		0x5b0ae5		4889542440		MOVQ DX, 0x40(SP)											
  value_methods.go:888		0x5b0aea		488d8c2488010000	LEAQ 0x188(SP), CX											
  value_methods.go:888		0x5b0af2		440f1139		MOVUPS X15, 0(CX)											
  value_methods.go:888		0x5b0af6		440f117910		MOVUPS X15, 0x10(CX)											
  value_methods.go:888		0x5b0afb		440f117920		MOVUPS X15, 0x20(CX)											
  value_methods.go:888		0x5b0b00		440f117930		MOVUPS X15, 0x30(CX)											
  value_methods.go:888		0x5b0b05		440f117940		MOVUPS X15, 0x40(CX)											
  value_methods.go:888		0x5b0b0a		440f117950		MOVUPS X15, 0x50(CX)											
  value_methods.go:888		0x5b0b0f		488d056a5d5100		LEAQ 0x515d6a(IP), AX											
  value_methods.go:888		0x5b0b16		e8a53de7ff		CALL runtime.mapIterStart(SB)										
  value_methods.go:887		0x5b0b1b		488b542440		MOVQ 0x40(SP), DX											
  value_methods.go:887		0x5b0b20		4883c202		ADDQ $0x2, DX												
  value_methods.go:888		0x5b0b24		e9c7030000		JMP 0x5b0ef0												
  value_methods.go:918		0x5b0b29		e8b2b2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:861		0x5b0b2e		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:861		0x5b0b36		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:861		0x5b0b3e		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0b43		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0b4a		5d			POPQ BP													
  value_methods.go:918		0x5b0b4b		c3			RET													
  value_methods.go:881		0x5b0b4c		48c744244807000000	MOVQ $0x7, 0x48(SP)											
  value_methods.go:881		0x5b0b55		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:881		0x5b0b5e		6690			NOPW													
  value_methods.go:918		0x5b0b60		e87bb2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:881		0x5b0b65		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:881		0x5b0b6d		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:881		0x5b0b75		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0b7a		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0b81		5d			POPQ BP													
  value_methods.go:918		0x5b0b82		c3			RET													
  value_methods.go:876		0x5b0b83		48c744244802000000	MOVQ $0x2, 0x48(SP)											
  value_methods.go:876		0x5b0b8c		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0b95		e846b2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:876		0x5b0b9a		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:876		0x5b0ba2		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:876		0x5b0baa		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0baf		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0bb6		5d			POPQ BP													
  value_methods.go:918		0x5b0bb7		c3			RET													
  value_methods.go:897		0x5b0bb8		4883f814		CMPQ AX, $0x14												
  value_methods.go:897		0x5b0bbc		752d			JNE 0x5b0beb												
  regex.go:180			0x5b0bbe		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0bc6		488d1d7b5d5500		LEAQ 0x555d7b(IP), BX											
  regex.go:180			0x5b0bcd		4839d8			CMPQ AX, BX												
  regex.go:180			0x5b0bd0		0f85d9020000		JNE 0x5b0eaf												
  regex.go:180			0x5b0bd6		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  regex.go:180			0x5b0bde		4d8b4808		MOVQ 0x8(R8), R9											
  regex.go:180			0x5b0be2		49c1e906		SHRQ $0x6, R9												
  regex.go:180			0x5b0be6		e9da010000		JMP 0x5b0dc5												
  value_methods.go:908		0x5b0beb		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:908		0x5b0bf3		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:908		0x5b0bfb		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:908		0x5b0c03		488bb42448020000	MOVQ 0x248(SP), SI											
  value_methods.go:908		0x5b0c0b		e850ebfeff		CALL github.com/mgomes/vibescript/vibes/value.chargeBigIntRenderSteps(SB)				
  value_methods.go:908		0x5b0c10		4885c0			TESTQ AX, AX												
  value_methods.go:908		0x5b0c13		0f85a1000000		JNE 0x5b0cba												
  value_methods.go:911		0x5b0c19		488b1560e65a00		MOVQ github.com/mgomes/vibescript/vibes/value.RuntimeStringRuneLen(SB), DX				
  value_methods.go:911		0x5b0c20		4885d2			TESTQ DX, DX												
  value_methods.go:911		0x5b0c23		7429			JE 0x5b0c4e												
  value_methods.go:912		0x5b0c25		488b32			MOVQ 0(DX), SI												
  value_methods.go:912		0x5b0c28		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:912		0x5b0c30		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:912		0x5b0c38		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:912		0x5b0c40		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:912		0x5b0c48		ffd6			CALL SI													
  value_methods.go:912		0x5b0c4a		84db			TESTL BL, BL												
  value_methods.go:912		0x5b0c4c		753b			JNE 0x5b0c89												
  value_methods.go:916		0x5b0c4e		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:916		0x5b0c56		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:916		0x5b0c5e		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:916		0x5b0c66		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:916		0x5b0c6e		e84db6ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)						
  value_methods.go:916		0x5b0c73		4889842450010000	MOVQ AX, 0x150(SP)											
  value_methods.go:916		0x5b0c7b		48895c2460		MOVQ BX, 0x60(SP)											
  utf8.go:448			0x5b0c80		31d2			XORL DX, DX												
  utf8.go:448			0x5b0c82		31f6			XORL SI, SI												
  utf8.go:448			0x5b0c84		e9af000000		JMP 0x5b0d38												
  value_methods.go:913		0x5b0c89		4889442448		MOVQ AX, 0x48(SP)											
  value_methods.go:913		0x5b0c8e		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0c97		e844b1e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:913		0x5b0c9c		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:913		0x5b0ca4		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:913		0x5b0cac		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0cb1		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0cb8		5d			POPQ BP													
  value_methods.go:918		0x5b0cb9		c3			RET													
  value_methods.go:909		0x5b0cba		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:909		0x5b0cc3		4889842430010000	MOVQ AX, 0x130(SP)											
  value_methods.go:909		0x5b0ccb		48899c2438010000	MOVQ BX, 0x138(SP)											
  value_methods.go:918		0x5b0cd3		e808b1e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:909		0x5b0cd8		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:909		0x5b0ce0		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:909		0x5b0ce8		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0ced		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0cf4		5d			POPQ BP													
  value_methods.go:918		0x5b0cf5		c3			RET													
  value_methods.go:846		0x5b0cf6		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:846		0x5b0cff		4889842430010000	MOVQ AX, 0x130(SP)											
  value_methods.go:846		0x5b0d07		48899c2438010000	MOVQ BX, 0x138(SP)											
  value_methods.go:918		0x5b0d0f		e8ccb0e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:846		0x5b0d14		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:846		0x5b0d1c		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:846		0x5b0d24		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0d29		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0d30		5d			POPQ BP													
  value_methods.go:918		0x5b0d31		c3			RET													
  utf8.go:449			0x5b0d32		48ffc6			INCQ SI													
  utf8.go:448			0x5b0d35		4889ca			MOVQ CX, DX												
  utf8.go:448			0x5b0d38		4839d3			CMPQ BX, DX												
  utf8.go:448			0x5b0d3b		7e33			JLE 0x5b0d70												
  utf8.go:448			0x5b0d3d		0fb63c02		MOVZX 0(DX)(AX*1), DI											
  utf8.go:448			0x5b0d41		83ff7f			CMPL DI, $0x7f												
  utf8.go:448			0x5b0d44		7f06			JG 0x5b0d4c												
  utf8.go:448			0x5b0d46		488d4a01		LEAQ 0x1(DX), CX											
  utf8.go:448			0x5b0d4a		ebe6			JMP 0x5b0d32												
  utf8.go:448			0x5b0d4c		4889742470		MOVQ SI, 0x70(SP)											
  utf8.go:448			0x5b0d51		4889d1			MOVQ DX, CX												
  utf8.go:448			0x5b0d54		e867c4ecff		CALL runtime.decoderune(SB)										
  utf8.go:448			0x5b0d59		488b842450010000	MOVQ 0x150(SP), AX											
  utf8.go:449			0x5b0d61		488b742470		MOVQ 0x70(SP), SI											
  utf8.go:449			0x5b0d66		4889d9			MOVQ BX, CX												
  utf8.go:448			0x5b0d69		488b5c2460		MOVQ 0x60(SP), BX											
  utf8.go:448			0x5b0d6e		ebc2			JMP 0x5b0d32												
  value_methods.go:916		0x5b0d70		4889742448		MOVQ SI, 0x48(SP)											
  value_methods.go:916		0x5b0d75		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0d7e		6690			NOPW													
  value_methods.go:918		0x5b0d80		e85bb0e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:916		0x5b0d85		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:916		0x5b0d8d		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:916		0x5b0d95		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0d9a		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0da1		5d			POPQ BP													
  value_methods.go:918		0x5b0da2		c3			RET													
  regex.go:180			0x5b0da3		4c8b8c24b0000000	MOVQ 0xb0(SP), R9											
  regex.go:180			0x5b0dab		49ffc9			DECQ R9													
  regex.go:180			0x5b0dae		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0db6		488d1d8b5b5500		LEAQ 0x555b8b(IP), BX											
  value_methods.go:906		0x5b0dbd		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  regex.go:180			0x5b0dc5		4d85c9			TESTQ R9, R9												
  regex.go:180			0x5b0dc8		7e3a			JLE 0x5b0e04												
  regex.go:180			0x5b0dca		4c898c24b0000000	MOVQ R9, 0xb0(SP)											
  regex.go:181			0x5b0dd2		488b942448020000	MOVQ 0x248(SP), DX											
  regex.go:181			0x5b0dda		488b02			MOVQ 0(DX), AX												
  regex.go:181			0x5b0ddd		ffd0			CALL AX													
  regex.go:181			0x5b0ddf		90			NOPL													
  regex.go:181			0x5b0de0		4885c0			TESTQ AX, AX												
  regex.go:181			0x5b0de3		74be			JE 0x5b0da3												
  value_methods.go:906		0x5b0de5		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  value_methods.go:903		0x5b0ded		4889c1			MOVQ AX, CX												
  value_methods.go:903		0x5b0df0		4889da			MOVQ BX, DX												
  regex.go:180			0x5b0df3		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0dfb		488d1d465b5500		LEAQ 0x555b46(IP), BX											
  value_methods.go:903		0x5b0e02		eb04			JMP 0x5b0e08												
  value_methods.go:903		0x5b0e04		31c9			XORL CX, CX												
  value_methods.go:903		0x5b0e06		31d2			XORL DX, DX												
  value_methods.go:903		0x5b0e08		4885c9			TESTQ CX, CX												
  value_methods.go:903		0x5b0e0b		7556			JNE 0x5b0e63												
  regex.go:180			0x5b0e0d		4839d8			CMPQ AX, BX												
  value_methods.go:906		0x5b0e10		0f858d000000		JNE 0x5b0ea3												
  value_methods.go:906		0x5b0e16		498b00			MOVQ 0(R8), AX												
  value_methods.go:906		0x5b0e19		498b5808		MOVQ 0x8(R8), BX											
  value_methods.go:906		0x5b0e1d		498b4810		MOVQ 0x10(R8), CX											
  value_methods.go:906		0x5b0e21		498b7818		MOVQ 0x18(R8), DI											
  value_methods.go:906		0x5b0e25		498b7020		MOVQ 0x20(R8), SI											
  value_methods.go:906		0x5b0e29		e8f248ffff		CALL github.com/mgomes/vibescript/vibes/value.Regex.StringRuneLen(SB)					
  value_methods.go:906		0x5b0e2e		4889442448		MOVQ AX, 0x48(SP)											
  value_methods.go:906		0x5b0e33		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:906		0x5b0e3c		0f1f4000		NOPL 0(AX)												
  value_methods.go:918		0x5b0e40		e89bafe9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:906		0x5b0e45		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:906		0x5b0e4d		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:906		0x5b0e55		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0e5a		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0e61		5d			POPQ BP													
  value_methods.go:918		0x5b0e62		c3			RET													
  value_methods.go:904		0x5b0e63		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:904		0x5b0e6c		48898c2430010000	MOVQ CX, 0x130(SP)											
  value_methods.go:904		0x5b0e74		4889942438010000	MOVQ DX, 0x138(SP)											
  value_methods.go:904		0x5b0e7c		0f1f4000		NOPL 0(AX)												
  value_methods.go:918		0x5b0e80		e85bafe9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:904		0x5b0e85		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:904		0x5b0e8d		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:904		0x5b0e95		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0e9a		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0ea1		5d			POPQ BP													
  value_methods.go:918		0x5b0ea2		c3			RET													
  value_methods.go:906		0x5b0ea3		488d0d56565300		LEAQ 0x535656(IP), CX											
  value_methods.go:906		0x5b0eaa		e851bfe6ff		CALL runtime.panicdottypeE(SB)										
  regex.go:180			0x5b0eaf		488d0d4a565300		LEAQ 0x53564a(IP), CX											
  regex.go:180			0x5b0eb6		e845bfe6ff		CALL runtime.panicdottypeE(SB)										
  value_methods.go:890		0x5b0ebb		4889842480000000	MOVQ AX, 0x80(SP)											
  value_methods.go:889		0x5b0ec3		48899424b0000000	MOVQ DX, 0xb0(SP)											
  value_methods.go:888		0x5b0ecb		488d842488010000	LEAQ 0x188(SP), AX											
  value_methods.go:888		0x5b0ed3		e8483ae7ff		CALL runtime.mapIterNext(SB)										
  value_methods.go:894		0x5b0ed8		488b8c2480000000	MOVQ 0x80(SP), CX											
  value_methods.go:894		0x5b0ee0		488b9424b0000000	MOVQ 0xb0(SP), DX											
  value_methods.go:894		0x5b0ee8		488d140a		LEAQ 0(DX)(CX*1), DX											
  value_methods.go:894		0x5b0eec		488d5202		LEAQ 0x2(DX), DX											
  value_methods.go:888		0x5b0ef0		4c8b8c2488010000	MOVQ 0x188(SP), R9											
  value_methods.go:888		0x5b0ef8		0f1f840000000000	NOPL 0(AX)(AX*1)											
  value_methods.go:888		0x5b0f00		4d85c9			TESTQ R9, R9												
  value_methods.go:888		0x5b0f03		0f84f4000000		JE 0x5b0ffd												
  value_methods.go:888		0x5b0f09		4889542450		MOVQ DX, 0x50(SP)											
  value_methods.go:888		0x5b0f0e		4c8b942490010000	MOVQ 0x190(SP), R10											
  value_methods.go:888		0x5b0f16		498b01			MOVQ 0(R9), AX												
  value_methods.go:888		0x5b0f19		4889842458010000	MOVQ AX, 0x158(SP)											
  value_methods.go:888		0x5b0f21		498b5908		MOVQ 0x8(R9), BX											
  value_methods.go:888		0x5b0f25		48899c2488000000	MOVQ BX, 0x88(SP)											
  value_methods.go:888		0x5b0f2d		4d8b0a			MOVQ 0(R10), R9												
  value_methods.go:888		0x5b0f30		4c898c24c0000000	MOVQ R9, 0xc0(SP)											
  value_methods.go:888		0x5b0f38		4d8b5a08		MOVQ 0x8(R10), R11											
  value_methods.go:888		0x5b0f3c		4c899c24c8000000	MOVQ R11, 0xc8(SP)											
  value_methods.go:888		0x5b0f44		498b4a10		MOVQ 0x10(R10), CX											
  value_methods.go:888		0x5b0f48		48898c24f0010000	MOVQ CX, 0x1f0(SP)											
  value_methods.go:888		0x5b0f50		498b7a18		MOVQ 0x18(R10), DI											
  value_methods.go:888		0x5b0f54		4889bc24b8000000	MOVQ DI, 0xb8(SP)											
  utf8.go:448			0x5b0f5c		4531d2			XORL R10, R10												
  utf8.go:448			0x5b0f5f		4531e4			XORL R12, R12												
  utf8.go:448			0x5b0f62		eb03			JMP 0x5b0f67												
  utf8.go:449			0x5b0f64		49ffc2			INCQ R10												
  utf8.go:448			0x5b0f67		4c89542478		MOVQ R10, 0x78(SP)											
  utf8.go:448			0x5b0f6c		4939dc			CMPQ R12, BX												
  utf8.go:448			0x5b0f6f		7d58			JGE 0x5b0fc9												
  utf8.go:448			0x5b0f71		450fb62c04		MOVZX 0(R12)(AX*1), R13											
  utf8.go:448			0x5b0f76		4183fd7f		CMPL R13, $0x7f												
  utf8.go:448			0x5b0f7a		7f06			JG 0x5b0f82												
  utf8.go:448			0x5b0f7c		49ffc4			INCQ R12												
  utf8.go:448			0x5b0f7f		90			NOPL													
  utf8.go:448			0x5b0f80		ebe2			JMP 0x5b0f64												
  utf8.go:448			0x5b0f82		4c89e1			MOVQ R12, CX												
  utf8.go:448			0x5b0f85		e836c2ecff		CALL runtime.decoderune(SB)										
  utf8.go:448			0x5b0f8a		488b842458010000	MOVQ 0x158(SP), AX											
  value_methods.go:890		0x5b0f92		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:889		0x5b0f9a		488b542450		MOVQ 0x50(SP), DX											
  value_methods.go:890		0x5b0f9f		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:890		0x5b0fa7		4c8b8c24c0000000	MOVQ 0xc0(SP), R9											
  utf8.go:449			0x5b0faf		4c8b542478		MOVQ 0x78(SP), R10											
  value_methods.go:890		0x5b0fb4		4c8b9c24c8000000	MOVQ 0xc8(SP), R11											
  utf8.go:449			0x5b0fbc		4989dc			MOVQ BX, R12												
  utf8.go:448			0x5b0fbf		488b9c2488000000	MOVQ 0x88(SP), BX											
  utf8.go:448			0x5b0fc7		eb9b			JMP 0x5b0f64												
  value_methods.go:890		0x5b0fc9		4c89c8			MOVQ R9, AX												
  value_methods.go:890		0x5b0fcc		4c89db			MOVQ R11, BX												
  value_methods.go:890		0x5b0fcf		488bb42440020000	MOVQ 0x240(SP), SI											
  value_methods.go:890		0x5b0fd7		4c8b842448020000	MOVQ 0x248(SP), R8											
  value_methods.go:890		0x5b0fdf		90			NOPL													
  value_methods.go:890		0x5b0fe0		e83bf7ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			
  value_methods.go:889		0x5b0fe5		488b542478		MOVQ 0x78(SP), DX											
  value_methods.go:889		0x5b0fea		4c8b4c2450		MOVQ 0x50(SP), R9											
  value_methods.go:889		0x5b0fef		4c01ca			ADDQ R9, DX												
  value_methods.go:891		0x5b0ff2		4885db			TESTQ BX, BX												
  value_methods.go:891		0x5b0ff5		0f84c0feffff		JE 0x5b0ebb												
  value_methods.go:891		0x5b0ffb		eb31			JMP 0x5b102e												
  value_methods.go:896		0x5b0ffd		4889542448		MOVQ DX, 0x48(SP)											
  value_methods.go:896		0x5b1002		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b100b		e8d0ade9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:896		0x5b1010		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:896		0x5b1018		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:896		0x5b1020		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b1025		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b102c		5d			POPQ BP													
  value_methods.go:918		0x5b102d		c3			RET													
  value_methods.go:892		0x5b102e		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:892		0x5b1037		48899c2430010000	MOVQ BX, 0x130(SP)											
  value_methods.go:892		0x5b103f		48898c2438010000	MOVQ CX, 0x138(SP)											
  value_methods.go:918		0x5b1047		e894ade9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:892		0x5b104c		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:892		0x5b1054		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:892		0x5b105c		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b1061		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b1068		5d			POPQ BP													
  value_methods.go:918		0x5b1069		c3			RET													
  value_accessors.go:113	0x5b106a		488d0d8f545300		LEAQ 0x53548f(IP), CX											
  value_accessors.go:113	0x5b1071		e88abde6ff		CALL runtime.panicdottypeE(SB)										
  value_methods.go:865		0x5b1076		4c8b9424e8010000	MOVQ 0x1e8(SP), R10											
  value_methods.go:865		0x5b107e		4983c220		ADDQ $0x20, R10												
  value_methods.go:870		0x5b1082		4c8b5c2458		MOVQ 0x58(SP), R11											
  value_methods.go:870		0x5b1087		4d8d0c03		LEAQ 0(R11)(AX*1), R9											
  value_methods.go:865		0x5b108b		488b9424b0000000	MOVQ 0xb0(SP), DX											
  value_methods.go:865		0x5b1093		48ffca			DECQ DX													
  value_methods.go:865		0x5b1096		4885d2			TESTQ DX, DX												
  value_methods.go:865		0x5b1099		7e7a			JLE 0x5b1115												
  value_methods.go:865		0x5b109b		48899424b0000000	MOVQ DX, 0xb0(SP)											
  value_methods.go:865		0x5b10a3		4c894c2458		MOVQ R9, 0x58(SP)											
  value_methods.go:865		0x5b10a8		4c899424e8010000	MOVQ R10, 0x1e8(SP)											
  value_methods.go:865		0x5b10b0		498b02			MOVQ 0(R10), AX												
  value_methods.go:865		0x5b10b3		498b5a08		MOVQ 0x8(R10), BX											
  value_methods.go:865		0x5b10b7		498b4a10		MOVQ 0x10(R10), CX											
  value_methods.go:865		0x5b10bb		498b7a18		MOVQ 0x18(R10), DI											
  value_methods.go:866		0x5b10bf		488bb42440020000	MOVQ 0x240(SP), SI											
  value_methods.go:866		0x5b10c7		4c8b842448020000	MOVQ 0x248(SP), R8											
  value_methods.go:866		0x5b10cf		e84cf6ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			
  value_methods.go:867		0x5b10d4		4885db			TESTQ BX, BX												
  value_methods.go:867		0x5b10d7		749d			JE 0x5b1076												
  value_methods.go:868		0x5b10d9		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:868		0x5b10e2		48899c2430010000	MOVQ BX, 0x130(SP)											
  value_methods.go:868		0x5b10ea		48898c2438010000	MOVQ CX, 0x138(SP)											
  value_methods.go:918		0x5b10f2		e8e9ace9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:868		0x5b10f7		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:868		0x5b10ff		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:868		0x5b1107		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b110c		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b1113		5d			POPQ BP													
  value_methods.go:918		0x5b1114		c3			RET													
  value_methods.go:872		0x5b1115		4c894c2448		MOVQ R9, 0x48(SP)											
  value_methods.go:872		0x5b111a		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b1123		e8b8ace9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:872		0x5b1128		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:872		0x5b1130		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:872		0x5b1138		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b113d		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b1144		5d			POPQ BP													
  value_methods.go:918		0x5b1145		c3			RET													
  value_accessors.go:86		0x5b1146		488d0db3535300		LEAQ 0x5353b3(IP), CX											
  value_accessors.go:86		0x5b114d		e8aebce6ff		CALL runtime.panicdottypeE(SB)										
  value_accessors.go:86		0x5b1152		90			NOPL													
  value_methods.go:844		0x5b1153		4889442408		MOVQ AX, 0x8(SP)											
  value_methods.go:844		0x5b1158		48895c2410		MOVQ BX, 0x10(SP)											
  value_methods.go:844		0x5b115d		48894c2418		MOVQ CX, 0x18(SP)											
  value_methods.go:844		0x5b1162		48897c2420		MOVQ DI, 0x20(SP)											
  value_methods.go:844		0x5b1167		4889742428		MOVQ SI, 0x28(SP)											
  value_methods.go:844		0x5b116c		4c89442430		MOVQ R8, 0x30(SP)											
  value_methods.go:844		0x5b1171		e88ab4edff		CALL runtime.morestack_noctxt.abi0(SB)									
  value_methods.go:844		0x5b1176		488b442408		MOVQ 0x8(SP), AX											
  value_methods.go:844		0x5b117b		488b5c2410		MOVQ 0x10(SP), BX											
  value_methods.go:844		0x5b1180		488b4c2418		MOVQ 0x18(SP), CX											
  value_methods.go:844		0x5b1185		488b7c2420		MOVQ 0x20(SP), DI											
  value_methods.go:844		0x5b118a		488b742428		MOVQ 0x28(SP), SI											
  value_methods.go:844		0x5b118f		4c8b442430		MOVQ 0x30(SP), R8											
  value_methods.go:844		0x5b1194		e987f5ffff		JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB) /home/runner/work/vibescript/vibescript/base/vibes/value/value_methods.go
  value_methods.go:638	0x5b4aa0		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:638	0x5b4aa4		7625			JBE 0x5b4acb											
  value_methods.go:638	0x5b4aa6		55			PUSHQ BP											
  value_methods.go:638	0x5b4aa7		4889e5			MOVQ SP, BP											
  value_methods.go:638	0x5b4aaa		4883ec18		SUBQ $0x18, SP											
  value_methods.go:638	0x5b4aae		488b4a10		MOVQ 0x10(DX), CX										
  value_methods.go:638	0x5b4ab2		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:638	0x5b4ab6		488d0503225100		LEAQ 0x512203(IP), AX										
  value_methods.go:638	0x5b4abd		0f1f00			NOPL 0(AX)											
  value_methods.go:638	0x5b4ac0		e8fb46e5ff		CALL runtime.mapdelete_fast64(SB)								
  value_methods.go:638	0x5b4ac5		4883c418		ADDQ $0x18, SP											
  value_methods.go:638	0x5b4ac9		5d			POPQ BP												
  value_methods.go:638	0x5b4aca		c3			RET												
  value_methods.go:638	0x5b4acb		e8907aedff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:638	0x5b4ad0		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB) /home/runner/work/vibescript/vibescript/base/vibes/value/value_methods.go
  value_methods.go:619	0x5b4ae0		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:619	0x5b4ae4		7625			JBE 0x5b4b0b											
  value_methods.go:619	0x5b4ae6		55			PUSHQ BP											
  value_methods.go:619	0x5b4ae7		4889e5			MOVQ SP, BP											
  value_methods.go:619	0x5b4aea		4883ec18		SUBQ $0x18, SP											
  value_methods.go:619	0x5b4aee		488d4a10		LEAQ 0x10(DX), CX										
  value_methods.go:619	0x5b4af2		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:619	0x5b4af6		488d05e3235100		LEAQ 0x5123e3(IP), AX										
  value_methods.go:619	0x5b4afd		0f1f00			NOPL 0(AX)											
  value_methods.go:619	0x5b4b00		e85b17edff		CALL runtime.mapdelete(SB)									
  value_methods.go:619	0x5b4b05		4883c418		ADDQ $0x18, SP											
  value_methods.go:619	0x5b4b09		5d			POPQ BP												
  value_methods.go:619	0x5b4b0a		c3			RET												
  value_methods.go:619	0x5b4b0b		e8507aedff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:619	0x5b4b10		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB) /home/runner/work/vibescript/vibescript/base/vibes/value/value_methods.go
  value_methods.go:884	0x5b4ba0		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:884	0x5b4ba4		7625			JBE 0x5b4bcb											
  value_methods.go:884	0x5b4ba6		55			PUSHQ BP											
  value_methods.go:884	0x5b4ba7		4889e5			MOVQ SP, BP											
  value_methods.go:884	0x5b4baa		4883ec18		SUBQ $0x18, SP											
  value_methods.go:884	0x5b4bae		488b4a10		MOVQ 0x10(DX), CX										
  value_methods.go:884	0x5b4bb2		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:884	0x5b4bb6		488d0503215100		LEAQ 0x512103(IP), AX										
  value_methods.go:884	0x5b4bbd		0f1f00			NOPL 0(AX)											
  value_methods.go:884	0x5b4bc0		e8fb45e5ff		CALL runtime.mapdelete_fast64(SB)								
  value_methods.go:884	0x5b4bc5		4883c418		ADDQ $0x18, SP											
  value_methods.go:884	0x5b4bc9		5d			POPQ BP												
  value_methods.go:884	0x5b4bca		c3			RET												
  value_methods.go:884	0x5b4bcb		e89079edff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:884	0x5b4bd0		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB) /home/runner/work/vibescript/vibescript/base/vibes/value/value_methods.go
  value_methods.go:861	0x5b4be0		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:861	0x5b4be4		7625			JBE 0x5b4c0b											
  value_methods.go:861	0x5b4be6		55			PUSHQ BP											
  value_methods.go:861	0x5b4be7		4889e5			MOVQ SP, BP											
  value_methods.go:861	0x5b4bea		4883ec18		SUBQ $0x18, SP											
  value_methods.go:861	0x5b4bee		488d4a10		LEAQ 0x10(DX), CX										
  value_methods.go:861	0x5b4bf2		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:861	0x5b4bf6		488d05e3225100		LEAQ 0x5122e3(IP), AX										
  value_methods.go:861	0x5b4bfd		0f1f00			NOPL 0(AX)											
  value_methods.go:861	0x5b4c00		e85b16edff		CALL runtime.mapdelete(SB)									
  value_methods.go:861	0x5b4c05		4883c418		ADDQ $0x18, SP											
  value_methods.go:861	0x5b4c09		5d			POPQ BP												
  value_methods.go:861	0x5b4c0a		c3			RET												
  value_methods.go:861	0x5b4c0b		e85079edff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:861	0x5b4c10		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneIndex(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:1223	0x6cdf40		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:1223	0x6cdf44		0f86bc030000		JBE 0x6ce306									
  members_string.go:1223	0x6cdf4a		55			PUSHQ BP									
  members_string.go:1223	0x6cdf4b		4889e5			MOVQ SP, BP									
  members_string.go:1223	0x6cdf4e		4883ec60		SUBQ $0x60, SP									
  members_string.go:1223	0x6cdf52		48895c2478		MOVQ BX, 0x78(SP)								
  members_string.go:1223	0x6cdf57		4889bc2488000000	MOVQ DI, 0x88(SP)								
  members_string.go:1223	0x6cdf5f		90			NOPL										
  members_string.go:1224	0x6cdf60		4d85c0			TESTQ R8, R8									
  members_string.go:1224	0x6cdf63		7c7e			JL 0x6cdfe3									
  members_string.go:5204	0x6cdf65		4885c9			TESTQ CX, CX									
  members_string.go:5204	0x6cdf68		7504			JNE 0x6cdf6e									
  members_string.go:5204	0x6cdf6a		31d2			XORL DX, DX									
  members_string.go:1240	0x6cdf6c		eb3d			JMP 0x6cdfab									
  members_string.go:1224	0x6cdf6e		4889c2			MOVQ AX, DX									
  members_string.go:5207	0x6cdf71		48b8ffffffffffffff7f	MOVQ $0x7fffffffffffffff, AX							
  members_string.go:1224	0x6cdf7b		4989d1			MOVQ DX, R9									
  members_string.go:5207	0x6cdf7e		31d2			XORL DX, DX									
  members_string.go:5207	0x6cdf80		48f7f1			DIVQ CX										
  members_string.go:5207	0x6cdf83		4883f804		CMPQ AX, $0x4									
  members_string.go:5207	0x6cdf87		7d0f			JGE 0x6cdf98									
  members_string.go:1257	0x6cdf89		4c89c8			MOVQ R9, AX									
  members_string.go:1257	0x6cdf8c		48baffffffffffffff7f	MOVQ $0x7fffffffffffffff, DX							
  members_string.go:1240	0x6cdf96		eb13			JMP 0x6cdfab									
  members_string.go:5210	0x6cdf98		4889ca			MOVQ CX, DX									
  members_string.go:5210	0x6cdf9b		48c1e102		SHLQ $0x2, CX									
  members_string.go:1257	0x6cdf9f		4c89c8			MOVQ R9, AX									
  members_string.go:1100	0x6cdfa2		4989ca			MOVQ CX, R10									
  members_string.go:1100	0x6cdfa5		4889d1			MOVQ DX, CX									
  members_string.go:1240	0x6cdfa8		4c89d2			MOVQ R10, DX									
  members_string.go:1240	0x6cdfab		4839d6			CMPQ SI, DX									
  members_string.go:1240	0x6cdfae		7f22			JG 0x6cdfd2									
  members_string.go:1224	0x6cdfb0		4889442470		MOVQ AX, 0x70(SP)								
  members_string.go:1224	0x6cdfb5		4c89842498000000	MOVQ R8, 0x98(SP)								
  members_string.go:1224	0x6cdfbd		4889b42490000000	MOVQ SI, 0x90(SP)								
  members_string.go:1224	0x6cdfc5		4889bc2488000000	MOVQ DI, 0x88(SP)								
  members_string.go:1243	0x6cdfcd		90			NOPL										
  members_string.go:1100	0x6cdfce		31d2			XORL DX, DX									
  members_string.go:1100	0x6cdfd0		eb25			JMP 0x6cdff7									
  members_string.go:1241	0x6cdfd2		48c7c0ffffffff		MOVQ $-0x1, AX									
  members_string.go:1241	0x6cdfd9		31db			XORL BX, BX									
  members_string.go:1241	0x6cdfdb		31c9			XORL CX, CX									
  members_string.go:1241	0x6cdfdd		4883c460		ADDQ $0x60, SP									
  members_string.go:1241	0x6cdfe1		5d			POPQ BP										
  members_string.go:1241	0x6cdfe2		c3			RET										
  members_string.go:1225	0x6cdfe3		48c7c0ffffffff		MOVQ $-0x1, AX									
  members_string.go:1225	0x6cdfea		31db			XORL BX, BX									
  members_string.go:1225	0x6cdfec		31c9			XORL CX, CX									
  members_string.go:1225	0x6cdfee		4883c460		ADDQ $0x60, SP									
  members_string.go:1225	0x6cdff2		5d			POPQ BP										
  members_string.go:1225	0x6cdff3		c3			RET										
  members_string.go:1100	0x6cdff4		48ffc2			INCQ DX										
  members_string.go:1100	0x6cdff7		4839d1			CMPQ CX, DX									
  members_string.go:1100	0x6cdffa		7e0d			JLE 0x6ce009									
  members_string.go:1101	0x6cdffc		440fb60c1a		MOVZX 0(DX)(BX*1), R9								
  members_string.go:1101	0x6ce001		4180f980		CMPL R9, $0x80									
  members_string.go:1101	0x6ce005		72ed			JB 0x6cdff4									
  members_string.go:1101	0x6ce007		eb1d			JMP 0x6ce026									
  members_string.go:1243	0x6ce009		90			NOPL										
  members_string.go:1100	0x6ce00a		31d2			XORL DX, DX									
  members_string.go:1100	0x6ce00c		eb03			JMP 0x6ce011									
  members_string.go:1100	0x6ce00e		48ffc2			INCQ DX										
  members_string.go:1100	0x6ce011		4839d6			CMPQ SI, DX									
  members_string.go:1100	0x6ce014		0f8e91000000		JLE 0x6ce0ab									
  members_string.go:1101	0x6ce01a		440fb60c17		MOVZX 0(DI)(DX*1), R9								
  members_string.go:1101	0x6ce01f		90			NOPL										
  members_string.go:1101	0x6ce020		4180f980		CMPL R9, $0x80									
  members_string.go:1101	0x6ce024		72e8			JB 0x6ce00e									
  members_string.go:1224	0x6ce026		48895c2478		MOVQ BX, 0x78(SP)								
  members_string.go:1224	0x6ce02b		48898c2480000000	MOVQ CX, 0x80(SP)								
  members_string.go:1256	0x6ce033		4889d8			MOVQ BX, AX									
  members_string.go:1256	0x6ce036		4889cb			MOVQ CX, BX									
  members_string.go:1256	0x6ce039		e8c20edeff		CALL unicode/utf8.ValidString(SB)						
  members_string.go:1256	0x6ce03e		6690			NOPW										
  members_string.go:1256	0x6ce040		84c0			TESTL AL, AL									
  members_string.go:1256	0x6ce042		742e			JE 0x6ce072									
  members_string.go:1256	0x6ce044		488b842488000000	MOVQ 0x88(SP), AX								
  members_string.go:1256	0x6ce04c		488b9c2490000000	MOVQ 0x90(SP), BX								
  members_string.go:1256	0x6ce054		e8a70edeff		CALL unicode/utf8.ValidString(SB)						
  members_string.go:1256	0x6ce059		84c0			TESTL AL, AL									
  members_string.go:1256	0x6ce05b		7415			JE 0x6ce072									
  members_string.go:1188	0x6ce05d		90			NOPL										
  members_string.go:1100	0x6ce05e		31d2			XORL DX, DX									
  members_string.go:1100	0x6ce060		488b9c2480000000	MOVQ 0x80(SP), BX								
  members_string.go:1100	0x6ce068		488b442478		MOVQ 0x78(SP), AX								
  members_string.go:1100	0x6ce06d		e9b2000000		JMP 0x6ce124									
  members_string.go:1257	0x6ce072		488b442470		MOVQ 0x70(SP), AX								
  members_string.go:1257	0x6ce077		488b5c2478		MOVQ 0x78(SP), BX								
  members_string.go:1257	0x6ce07c		488b8c2480000000	MOVQ 0x80(SP), CX								
  members_string.go:1257	0x6ce084		488bbc2488000000	MOVQ 0x88(SP), DI								
  members_string.go:1257	0x6ce08c		488bb42490000000	MOVQ 0x90(SP), SI								
  members_string.go:1257	0x6ce094		4c8b842498000000	MOVQ 0x98(SP), R8								
  members_string.go:1257	0x6ce09c		0f1f4000		NOPL 0(AX)									
  members_string.go:1257	0x6ce0a0		e8fb030000		CALL github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB)	
  members_string.go:1257	0x6ce0a5		4883c460		ADDQ $0x60, SP									
  members_string.go:1257	0x6ce0a9		5d			POPQ BP										
  members_string.go:1257	0x6ce0aa		c3			RET										
  members_string.go:1244	0x6ce0ab		4c39c1			CMPQ CX, R8									
  members_string.go:1244	0x6ce0ae		7c5f			JL 0x6ce10f									
  members_string.go:1247	0x6ce0b0		4885f6			TESTQ SI, SI									
  members_string.go:1247	0x6ce0b3		744d			JE 0x6ce102									
  members_string.go:1250	0x6ce0b5		4c29c1			SUBQ R8, CX									
  members_string.go:1250	0x6ce0b8		4889ca			MOVQ CX, DX									
  members_string.go:1250	0x6ce0bb		48f7d9			NEGQ CX										
  members_string.go:1250	0x6ce0be		48c1f93f		SARQ $0x3f, CX									
  members_string.go:1250	0x6ce0c2		4c21c1			ANDQ R8, CX									
  members_string.go:1250	0x6ce0c5		488d0419		LEAQ 0(CX)(BX*1), AX								
  strings.go:1264		0x6ce0c9		4889d3			MOVQ DX, BX									
  strings.go:1264		0x6ce0cc		4889f9			MOVQ DI, CX									
  strings.go:1264		0x6ce0cf		4889f7			MOVQ SI, DI									
  strings.go:1264		0x6ce0d2		e8896fd4ff		CALL internal/stringslite.Index(SB)						
  members_string.go:1251	0x6ce0d7		4885c0			TESTQ AX, AX									
  members_string.go:1251	0x6ce0da		7d11			JGE 0x6ce0ed									
  members_string.go:1252	0x6ce0dc		48c7c0ffffffff		MOVQ $-0x1, AX									
  members_string.go:1252	0x6ce0e3		31db			XORL BX, BX									
  members_string.go:1252	0x6ce0e5		31c9			XORL CX, CX									
  members_string.go:1252	0x6ce0e7		4883c460		ADDQ $0x60, SP									
  members_string.go:1252	0x6ce0eb		5d			POPQ BP										
  members_string.go:1252	0x6ce0ec		c3			RET										
  members_string.go:1254	0x6ce0ed		488b942498000000	MOVQ 0x98(SP), DX								
  members_string.go:1254	0x6ce0f5		4801d0			ADDQ DX, AX									
  members_string.go:1254	0x6ce0f8		31db			XORL BX, BX									
  members_string.go:1254	0x6ce0fa		31c9			XORL CX, CX									
  members_string.go:1254	0x6ce0fc		4883c460		ADDQ $0x60, SP									
  members_string.go:1254	0x6ce100		5d			POPQ BP										
  members_string.go:1254	0x6ce101		c3			RET										
  members_string.go:1248	0x6ce102		4c89c0			MOVQ R8, AX									
  members_string.go:1248	0x6ce105		31db			XORL BX, BX									
  members_string.go:1248	0x6ce107		31c9			XORL CX, CX									
  members_string.go:1248	0x6ce109		4883c460		ADDQ $0x60, SP									
  members_string.go:1248	0x6ce10d		5d			POPQ BP										
  members_string.go:1248	0x6ce10e		c3			RET										
  members_string.go:1245	0x6ce10f		48c7c0ffffffff		MOVQ $-0x1, AX									
  members_string.go:1245	0x6ce116		31db			XORL BX, BX									
  members_string.go:1245	0x6ce118		31c9			XORL CX, CX									
  members_string.go:1245	0x6ce11a		4883c460		ADDQ $0x60, SP									
  members_string.go:1245	0x6ce11e		5d			POPQ BP										
  members_string.go:1245	0x6ce11f		90			NOPL										
  members_string.go:1245	0x6ce120		c3			RET										
  members_string.go:1100	0x6ce121		48ffc2			INCQ DX										
  members_string.go:1100	0x6ce124		4839d3			CMPQ BX, DX									
  members_string.go:1100	0x6ce127		7e1c			JLE 0x6ce145									
  members_string.go:1101	0x6ce129		0fb63402		MOVZX 0(DX)(AX*1), SI								
  members_string.go:1101	0x6ce12d		4080fe80		CMPL SI, $0x80									
  members_string.go:1101	0x6ce131		72ee			JB 0x6ce121									
  members_string.go:1195	0x6ce133		31d2			XORL DX, DX									
  members_string.go:1195	0x6ce135		31f6			XORL SI, SI									
  members_string.go:1195	0x6ce137		4c8b842498000000	MOVQ 0x98(SP), R8								
  members_string.go:1195	0x6ce13f		90			NOPL										
  members_string.go:1195	0x6ce140		e93c010000		JMP 0x6ce281									
  members_string.go:1189	0x6ce145		488b942498000000	MOVQ 0x98(SP), DX								
  members_string.go:1189	0x6ce14d		4839d3			CMPQ BX, DX									
  members_string.go:1189	0x6ce150		7d06			JGE 0x6ce158									
  members_string.go:1189	0x6ce152		31c9			XORL CX, CX									
  members_string.go:1189	0x6ce154		31f6			XORL SI, SI									
  members_string.go:1259	0x6ce156		eb08			JMP 0x6ce160									
  members_string.go:1259	0x6ce158		b901000000		MOVL $0x1, CX									
  members_string.go:1259	0x6ce15d		4889d6			MOVQ DX, SI									
  members_string.go:1259	0x6ce160		84c9			TESTL CL, CL									
  members_string.go:1260	0x6ce162		0f84ab000000		JE 0x6ce213									
  members_string.go:1263	0x6ce168		488bbc2490000000	MOVQ 0x90(SP), DI								
  members_string.go:1263	0x6ce170		4885ff			TESTQ DI, DI									
  members_string.go:1263	0x6ce173		0f848d000000		JE 0x6ce206									
  members_string.go:1263	0x6ce179		0f1f8000000000		NOPL 0(AX)									
  members_string.go:1266	0x6ce180		4839f3			CMPQ BX, SI									
  members_string.go:1266	0x6ce183		0f82ed000000		JB 0x6ce276									
  members_string.go:1259	0x6ce189		4889742430		MOVQ SI, 0x30(SP)								
  members_string.go:1266	0x6ce18e		4889da			MOVQ BX, DX									
  members_string.go:1266	0x6ce191		4829f2			SUBQ SI, DX									
  members_string.go:1266	0x6ce194		4889d3			MOVQ DX, BX									
  members_string.go:1266	0x6ce197		48f7da			NEGQ DX										
  members_string.go:1266	0x6ce19a		48c1fa3f		SARQ $0x3f, DX									
  members_string.go:1266	0x6ce19e		4821f2			ANDQ SI, DX									
  members_string.go:1266	0x6ce1a1		4801d0			ADDQ DX, AX									
  strings.go:1264		0x6ce1a4		488b8c2488000000	MOVQ 0x88(SP), CX								
  strings.go:1264		0x6ce1ac		e8af6ed4ff		CALL internal/stringslite.Index(SB)						
  members_string.go:1267	0x6ce1b1		4885c0			TESTQ AX, AX									
  members_string.go:1267	0x6ce1b4		7c3f			JL 0x6ce1f5									
  members_string.go:1270	0x6ce1b6		488b542430		MOVQ 0x30(SP), DX								
  members_string.go:1270	0x6ce1bb		488d3402		LEAQ 0(DX)(AX*1), SI								
  members_string.go:1270	0x6ce1bf		488bbc2480000000	MOVQ 0x80(SP), DI								
  members_string.go:1270	0x6ce1c7		4839f7			CMPQ DI, SI									
  members_string.go:1270	0x6ce1ca		0f82a1000000		JB 0x6ce271									
  strings.go:1264		0x6ce1d0		4889442448		MOVQ AX, 0x48(SP)								
  members_string.go:1270	0x6ce1d5		4889c3			MOVQ AX, BX									
  members_string.go:1270	0x6ce1d8		48f7d8			NEGQ AX										
  members_string.go:1270	0x6ce1db		48c1f83f		SARQ $0x3f, AX									
  members_string.go:1270	0x6ce1df		4821d0			ANDQ DX, AX									
  members_string.go:1270	0x6ce1e2		488b542478		MOVQ 0x78(SP), DX								
  members_string.go:1270	0x6ce1e7		4801d0			ADDQ DX, AX									
  members_string.go:1270	0x6ce1ea		4889442458		MOVQ AX, 0x58(SP)								
  utf8.go:448			0x6ce1ef		31d2			XORL DX, DX									
  utf8.go:448			0x6ce1f1		31f6			XORL SI, SI									
  utf8.go:448			0x6ce1f3		eb32			JMP 0x6ce227									
  members_string.go:1268	0x6ce1f5		48c7c0ffffffff		MOVQ $-0x1, AX									
  members_string.go:1268	0x6ce1fc		31db			XORL BX, BX									
  members_string.go:1268	0x6ce1fe		31c9			XORL CX, CX									
  members_string.go:1268	0x6ce200		4883c460		ADDQ $0x60, SP									
  members_string.go:1268	0x6ce204		5d			POPQ BP										
  members_string.go:1268	0x6ce205		c3			RET										
  members_string.go:1264	0x6ce206		4889d0			MOVQ DX, AX									
  members_string.go:1264	0x6ce209		31db			XORL BX, BX									
  members_string.go:1264	0x6ce20b		31c9			XORL CX, CX									
  members_string.go:1264	0x6ce20d		4883c460		ADDQ $0x60, SP									
  members_string.go:1264	0x6ce211		5d			POPQ BP										
  members_string.go:1264	0x6ce212		c3			RET										
  members_string.go:1261	0x6ce213		48c7c0ffffffff		MOVQ $-0x1, AX									
  members_string.go:1261	0x6ce21a		31db			XORL BX, BX									
  members_string.go:1261	0x6ce21c		31c9			XORL CX, CX									
  members_string.go:1261	0x6ce21e		4883c460		ADDQ $0x60, SP									
  members_string.go:1261	0x6ce222		5d			POPQ BP										
  members_string.go:1261	0x6ce223		c3			RET										
  utf8.go:449			0x6ce224		48ffc6			INCQ SI										
  utf8.go:448			0x6ce227		4839d3			CMPQ BX, DX									
  utf8.go:448			0x6ce22a		7e2f			JLE 0x6ce25b									
  utf8.go:448			0x6ce22c		0fb63c02		MOVZX 0(DX)(AX*1), DI								
  utf8.go:448			0x6ce230		83ff7f			CMPL DI, $0x7f									
  utf8.go:448			0x6ce233		7f05			JG 0x6ce23a									
  utf8.go:448			0x6ce235		48ffc2			INCQ DX										
  utf8.go:448			0x6ce238		ebea			JMP 0x6ce224									
  utf8.go:448			0x6ce23a		4889742440		MOVQ SI, 0x40(SP)								
  utf8.go:448			0x6ce23f		4889d1			MOVQ DX, CX									
  utf8.go:448			0x6ce242		e879efdaff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x6ce247		488b442458		MOVQ 0x58(SP), AX								
  utf8.go:449			0x6ce24c		488b742440		MOVQ 0x40(SP), SI								
  utf8.go:449			0x6ce251		4889da			MOVQ BX, DX									
  utf8.go:448			0x6ce254		488b5c2448		MOVQ 0x48(SP), BX								
  utf8.go:448			0x6ce259		ebc9			JMP 0x6ce224									
  members_string.go:1270	0x6ce25b		488b942498000000	MOVQ 0x98(SP), DX								
  members_string.go:1270	0x6ce263		488d0432		LEAQ 0(DX)(SI*1), AX								
  members_string.go:1270	0x6ce267		31db			XORL BX, BX									
  members_string.go:1270	0x6ce269		31c9			XORL CX, CX									
  members_string.go:1270	0x6ce26b		4883c460		ADDQ $0x60, SP									
  members_string.go:1270	0x6ce26f		5d			POPQ BP										
  members_string.go:1270	0x6ce270		c3			RET										
  members_string.go:1270	0x6ce271		e8caffdbff		CALL runtime.panicBounds(SB)							
  members_string.go:1266	0x6ce276		e8c5ffdbff		CALL runtime.panicBounds(SB)							
  members_string.go:1199	0x6ce27b		48ffc6			INCQ SI										
  members_string.go:1195	0x6ce27e		4c89ca			MOVQ R9, DX									
  members_string.go:1195	0x6ce281		4839d3			CMPQ BX, DX									
  members_string.go:1195	0x6ce284		7e5f			JLE 0x6ce2e5									
  members_string.go:1195	0x6ce286		440fb60c02		MOVZX 0(DX)(AX*1), R9								
  members_string.go:1195	0x6ce28b		4183f97f		CMPL R9, $0x7f									
  members_string.go:1195	0x6ce28f		7f06			JG 0x6ce297									
  members_string.go:1195	0x6ce291		4c8d4a01		LEAQ 0x1(DX), R9								
  members_string.go:1195	0x6ce295		eb34			JMP 0x6ce2cb									
  members_string.go:1195	0x6ce297		4889542450		MOVQ DX, 0x50(SP)								
  members_string.go:1195	0x6ce29c		4889742438		MOVQ SI, 0x38(SP)								
  members_string.go:1195	0x6ce2a1		4889d1			MOVQ DX, CX									
  members_string.go:1195	0x6ce2a4		e817efdaff		CALL runtime.decoderune(SB)							
  members_string.go:1195	0x6ce2a9		488b442478		MOVQ 0x78(SP), AX								
  members_string.go:1259	0x6ce2ae		488b542450		MOVQ 0x50(SP), DX								
  members_string.go:1196	0x6ce2b3		488b742438		MOVQ 0x38(SP), SI								
  members_string.go:1196	0x6ce2b8		4c8b842498000000	MOVQ 0x98(SP), R8								
  members_string.go:1195	0x6ce2c0		4989d9			MOVQ BX, R9									
  members_string.go:1195	0x6ce2c3		488b9c2480000000	MOVQ 0x80(SP), BX								
  members_string.go:1196	0x6ce2cb		4939f0			CMPQ R8, SI									
  members_string.go:1196	0x6ce2ce		75ab			JNE 0x6ce27b									
  members_string.go:1196	0x6ce2d0		b901000000		MOVL $0x1, CX									
  members_string.go:1259	0x6ce2d5		4889d6			MOVQ DX, SI									
  members_string.go:1264	0x6ce2d8		4c89c2			MOVQ R8, DX									
  members_string.go:1264	0x6ce2db		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:1259	0x6ce2e0		e97bfeffff		JMP 0x6ce160									
  members_string.go:1201	0x6ce2e5		4939f0			CMPQ R8, SI									
  members_string.go:1201	0x6ce2e8		7510			JNE 0x6ce2fa									
  members_string.go:1264	0x6ce2ea		4c89c2			MOVQ R8, DX									
  members_string.go:1264	0x6ce2ed		b901000000		MOVL $0x1, CX									
  members_string.go:1259	0x6ce2f2		4889de			MOVQ BX, SI									
  members_string.go:1259	0x6ce2f5		e966feffff		JMP 0x6ce160									
  members_string.go:1264	0x6ce2fa		4c89c2			MOVQ R8, DX									
  members_string.go:1264	0x6ce2fd		31c9			XORL CX, CX									
  members_string.go:1264	0x6ce2ff		31f6			XORL SI, SI									
  members_string.go:1259	0x6ce301		e95afeffff		JMP 0x6ce160									
  members_string.go:1223	0x6ce306		4889442408		MOVQ AX, 0x8(SP)								
  members_string.go:1223	0x6ce30b		48895c2410		MOVQ BX, 0x10(SP)								
  members_string.go:1223	0x6ce310		48894c2418		MOVQ CX, 0x18(SP)								
  members_string.go:1223	0x6ce315		48897c2420		MOVQ DI, 0x20(SP)								
  members_string.go:1223	0x6ce31a		4889742428		MOVQ SI, 0x28(SP)								
  members_string.go:1223	0x6ce31f		4c89442430		MOVQ R8, 0x30(SP)								
  members_string.go:1223	0x6ce324		e8d7e2dbff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:1223	0x6ce329		488b442408		MOVQ 0x8(SP), AX								
  members_string.go:1223	0x6ce32e		488b5c2410		MOVQ 0x10(SP), BX								
  members_string.go:1223	0x6ce333		488b4c2418		MOVQ 0x18(SP), CX								
  members_string.go:1223	0x6ce338		488b7c2420		MOVQ 0x20(SP), DI								
  members_string.go:1223	0x6ce33d		488b742428		MOVQ 0x28(SP), SI								
  members_string.go:1223	0x6ce342		4c8b442430		MOVQ 0x30(SP), R8								
  members_string.go:1223	0x6ce347		e9f4fbffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneIndex(SB)		

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:1297	0x6ce4a0		4c8da424c0feffff	LEAQ 0xfffffec0(SP), R12								
  members_string.go:1297	0x6ce4a8		4d3b6610		CMPQ R12, 0x10(R14)									
  members_string.go:1297	0x6ce4ac		0f865f020000		JBE 0x6ce711										
  members_string.go:1297	0x6ce4b2		55			PUSHQ BP										
  members_string.go:1297	0x6ce4b3		4889e5			MOVQ SP, BP										
  members_string.go:1297	0x6ce4b6		4881ecb8010000		SUBQ $0x1b8, SP										
  members_string.go:1298	0x6ce4bd		4c898424f0010000	MOVQ R8, 0x1f0(SP)									
  members_string.go:1298	0x6ce4c5		48898c24d8010000	MOVQ CX, 0x1d8(SP)									
  members_string.go:1298	0x6ce4cd		48899c24d0010000	MOVQ BX, 0x1d0(SP)									
  members_string.go:1298	0x6ce4d5		4889b424e8010000	MOVQ SI, 0x1e8(SP)									
  members_string.go:1298	0x6ce4dd		4889bc24e0010000	MOVQ DI, 0x1e0(SP)									
  members_string.go:1298	0x6ce4e5		e876feffff		CALL github.com/mgomes/vibescript/internal/runtime.reserveFallbackSearchScratch(SB)	
  members_string.go:1298	0x6ce4ea		4885c0			TESTQ AX, AX										
  members_string.go:1298	0x6ce4ed		0f859b010000		JNE 0x6ce68e										
  members_string.go:1301	0x6ce4f3		488d8424e8000000	LEAQ 0xe8(SP), AX									
  members_string.go:1301	0x6ce4fb		488b9c24d0010000	MOVQ 0x1d0(SP), BX									
  members_string.go:1301	0x6ce503		488b8c24d8010000	MOVQ 0x1d8(SP), CX									
  members_string.go:1301	0x6ce50b		e830c8d9ff		CALL runtime.stringtoslicerune(SB)							
  members_string.go:1301	0x6ce510		48899c2488010000	MOVQ BX, 0x188(SP)									
  members_string.go:1301	0x6ce518		48898424a8010000	MOVQ AX, 0x1a8(SP)									
  members_string.go:1301	0x6ce520		48898c2490010000	MOVQ CX, 0x190(SP)									
  members_string.go:1302	0x6ce528		488d442468		LEAQ 0x68(SP), AX									
  members_string.go:1302	0x6ce52d		488b9c24e0010000	MOVQ 0x1e0(SP), BX									
  members_string.go:1302	0x6ce535		488b8c24e8010000	MOVQ 0x1e8(SP), CX									
  members_string.go:1302	0x6ce53d		0f1f00			NOPL 0(AX)										
  members_string.go:1302	0x6ce540		e8fbc7d9ff		CALL runtime.stringtoslicerune(SB)							
  members_string.go:1303	0x6ce545		488b942488010000	MOVQ 0x188(SP), DX									
  members_string.go:1303	0x6ce54d		488bb424f0010000	MOVQ 0x1f0(SP), SI									
  members_string.go:1303	0x6ce555		4839f2			CMPQ DX, SI										
  members_string.go:1303	0x6ce558		0f8c1c010000		JL 0x6ce67a										
  members_string.go:1303	0x6ce55e		6690			NOPW											
  members_string.go:1306	0x6ce560		4885db			TESTQ BX, BX										
  members_string.go:1306	0x6ce563		0f8401010000		JE 0x6ce66a										
  members_string.go:1309	0x6ce569		4989d0			MOVQ DX, R8										
  members_string.go:1309	0x6ce56c		4829da			SUBQ BX, DX										
  members_string.go:1310	0x6ce56f		4839d6			CMPQ SI, DX										
  members_string.go:1310	0x6ce572		0f8fde000000		JG 0x6ce656										
  members_string.go:1310	0x6ce578		0f1f840000000000	NOPL 0(AX)(AX*1)									
  members_string.go:1303	0x6ce580		4939f0			CMPQ R8, SI										
  members_string.go:1320	0x6ce583		0f8282010000		JB 0x6ce70b										
  members_string.go:1302	0x6ce589		48899c2470010000	MOVQ BX, 0x170(SP)									
  members_string.go:1302	0x6ce591		48898424a0010000	MOVQ AX, 0x1a0(SP)									
  members_string.go:1302	0x6ce599		48898c2478010000	MOVQ CX, 0x178(SP)									
  members_string.go:1320	0x6ce5a1		4929f0			SUBQ SI, R8										
  members_string.go:1320	0x6ce5a4		488bbc2490010000	MOVQ 0x190(SP), DI									
  members_string.go:1320	0x6ce5ac		4829f7			SUBQ SI, DI										
  members_string.go:1320	0x6ce5af		488b9424a8010000	MOVQ 0x1a8(SP), DX									
  members_string.go:1320	0x6ce5b7		488d1cb2		LEAQ 0(DX)(SI*4), BX									
  members_string.go:1320	0x6ce5bb		488d442448		LEAQ 0x48(SP), AX									
  members_string.go:1320	0x6ce5c0		4c89c1			MOVQ R8, CX										
  members_string.go:1320	0x6ce5c3		e8f8c8d9ff		CALL runtime.slicerunetostring(SB)							
  members_string.go:1320	0x6ce5c8		48898424b0010000	MOVQ AX, 0x1b0(SP)									
  members_string.go:1320	0x6ce5d0		48899c2498010000	MOVQ BX, 0x198(SP)									
  members_string.go:1321	0x6ce5d8		488d442428		LEAQ 0x28(SP), AX									
  members_string.go:1321	0x6ce5dd		488b9c24a0010000	MOVQ 0x1a0(SP), BX									
  members_string.go:1321	0x6ce5e5		488b8c2470010000	MOVQ 0x170(SP), CX									
  members_string.go:1321	0x6ce5ed		488bbc2478010000	MOVQ 0x178(SP), DI									
  members_string.go:1321	0x6ce5f5		e8c6c8d9ff		CALL runtime.slicerunetostring(SB)							
  strings.go:1264		0x6ce5fa		4889c1			MOVQ AX, CX										
  strings.go:1264		0x6ce5fd		4889df			MOVQ BX, DI										
  strings.go:1264		0x6ce600		488b8424b0010000	MOVQ 0x1b0(SP), AX									
  strings.go:1264		0x6ce608		488b9c2498010000	MOVQ 0x198(SP), BX									
  strings.go:1264		0x6ce610		e84b6ad4ff		CALL internal/stringslite.Index(SB)							
  members_string.go:1322	0x6ce615		4885c0			TESTQ AX, AX										
  members_string.go:1322	0x6ce618		7c28			JL 0x6ce642										
  members_string.go:1325	0x6ce61a		488b942498010000	MOVQ 0x198(SP), DX									
  members_string.go:1325	0x6ce622		4839d0			CMPQ AX, DX										
  members_string.go:1325	0x6ce625		0f87db000000		JA 0x6ce706										
  strings.go:1264		0x6ce62b		4889842468010000	MOVQ AX, 0x168(SP)									
  utf8.go:448			0x6ce633		31d2			XORL DX, DX										
  utf8.go:448			0x6ce635		488bb424b0010000	MOVQ 0x1b0(SP), SI									
  utf8.go:448			0x6ce63d		31c9			XORL CX, CX										
  utf8.go:448			0x6ce63f		90			NOPL											
  utf8.go:448			0x6ce640		eb65			JMP 0x6ce6a7										
  members_string.go:1323	0x6ce642		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1323	0x6ce649		31db			XORL BX, BX										
  members_string.go:1323	0x6ce64b		31c9			XORL CX, CX										
  members_string.go:1323	0x6ce64d		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1323	0x6ce654		5d			POPQ BP											
  members_string.go:1323	0x6ce655		c3			RET											
  members_string.go:1311	0x6ce656		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1311	0x6ce65d		31db			XORL BX, BX										
  members_string.go:1311	0x6ce65f		31c9			XORL CX, CX										
  members_string.go:1311	0x6ce661		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1311	0x6ce668		5d			POPQ BP											
  members_string.go:1311	0x6ce669		c3			RET											
  members_string.go:1307	0x6ce66a		4889f0			MOVQ SI, AX										
  members_string.go:1307	0x6ce66d		31db			XORL BX, BX										
  members_string.go:1307	0x6ce66f		31c9			XORL CX, CX										
  members_string.go:1307	0x6ce671		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1307	0x6ce678		5d			POPQ BP											
  members_string.go:1307	0x6ce679		c3			RET											
  members_string.go:1304	0x6ce67a		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1304	0x6ce681		31db			XORL BX, BX										
  members_string.go:1304	0x6ce683		31c9			XORL CX, CX										
  members_string.go:1304	0x6ce685		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1304	0x6ce68c		5d			POPQ BP											
  members_string.go:1304	0x6ce68d		c3			RET											
  members_string.go:1299	0x6ce68e		4889d9			MOVQ BX, CX										
  members_string.go:1299	0x6ce691		4889c3			MOVQ AX, BX										
  members_string.go:1299	0x6ce694		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1299	0x6ce69b		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1299	0x6ce6a2		5d			POPQ BP											
  members_string.go:1299	0x6ce6a3		c3			RET											
  utf8.go:449			0x6ce6a4		48ffc1			INCQ CX											
  utf8.go:448			0x6ce6a7		4839d0			CMPQ AX, DX										
  utf8.go:448			0x6ce6aa		7e41			JLE 0x6ce6ed										
  utf8.go:448			0x6ce6ac		0fb63c16		MOVZX 0(SI)(DX*1), DI									
  utf8.go:448			0x6ce6b0		83ff7f			CMPL DI, $0x7f										
  utf8.go:448			0x6ce6b3		7f05			JG 0x6ce6ba										
  utf8.go:448			0x6ce6b5		48ffc2			INCQ DX											
  utf8.go:448			0x6ce6b8		ebea			JMP 0x6ce6a4										
  utf8.go:448			0x6ce6ba		48898c2480010000	MOVQ CX, 0x180(SP)									
  utf8.go:448			0x6ce6c2		4889c3			MOVQ AX, BX										
  utf8.go:448			0x6ce6c5		4889d1			MOVQ DX, CX										
  utf8.go:448			0x6ce6c8		4889f0			MOVQ SI, AX										
  utf8.go:448			0x6ce6cb		e8f0eadaff		CALL runtime.decoderune(SB)								
  utf8.go:448			0x6ce6d0		488b842468010000	MOVQ 0x168(SP), AX									
  utf8.go:449			0x6ce6d8		488b8c2480010000	MOVQ 0x180(SP), CX									
  utf8.go:448			0x6ce6e0		488bb424b0010000	MOVQ 0x1b0(SP), SI									
  utf8.go:449			0x6ce6e8		4889da			MOVQ BX, DX										
  utf8.go:448			0x6ce6eb		ebb7			JMP 0x6ce6a4										
  members_string.go:1325	0x6ce6ed		488b9424f0010000	MOVQ 0x1f0(SP), DX									
  members_string.go:1325	0x6ce6f5		488d040a		LEAQ 0(DX)(CX*1), AX									
  members_string.go:1325	0x6ce6f9		31db			XORL BX, BX										
  members_string.go:1325	0x6ce6fb		31c9			XORL CX, CX										
  members_string.go:1325	0x6ce6fd		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1325	0x6ce704		5d			POPQ BP											
  members_string.go:1325	0x6ce705		c3			RET											
  members_string.go:1325	0x6ce706		e835fbdbff		CALL runtime.panicBounds(SB)								
  members_string.go:1320	0x6ce70b		e830fbdbff		CALL runtime.panicBounds(SB)								
  members_string.go:1320	0x6ce710		90			NOPL											
  members_string.go:1297	0x6ce711		4889442408		MOVQ AX, 0x8(SP)									
  members_string.go:1297	0x6ce716		48895c2410		MOVQ BX, 0x10(SP)									
  members_string.go:1297	0x6ce71b		48894c2418		MOVQ CX, 0x18(SP)									
  members_string.go:1297	0x6ce720		48897c2420		MOVQ DI, 0x20(SP)									
  members_string.go:1297	0x6ce725		4889742428		MOVQ SI, 0x28(SP)									
  members_string.go:1297	0x6ce72a		4c89442430		MOVQ R8, 0x30(SP)									
  members_string.go:1297	0x6ce72f		e8ccdedbff		CALL runtime.morestack_noctxt.abi0(SB)							
  members_string.go:1297	0x6ce734		488b442408		MOVQ 0x8(SP), AX									
  members_string.go:1297	0x6ce739		488b5c2410		MOVQ 0x10(SP), BX									
  members_string.go:1297	0x6ce73e		488b4c2418		MOVQ 0x18(SP), CX									
  members_string.go:1297	0x6ce743		488b7c2420		MOVQ 0x20(SP), DI									
  members_string.go:1297	0x6ce748		488b742428		MOVQ 0x28(SP), SI									
  members_string.go:1297	0x6ce74d		4c8b442430		MOVQ 0x30(SP), R8									
  members_string.go:1297	0x6ce752		e949fdffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB)		

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneSlice(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:1446	0x6cef40		4c8d642488		LEAQ -0x78(SP), R12							
  members_string.go:1446	0x6cef45		4d3b6610		CMPQ R12, 0x10(R14)							
  members_string.go:1446	0x6cef49		0f8629030000		JBE 0x6cf278								
  members_string.go:1446	0x6cef4f		55			PUSHQ BP								
  members_string.go:1446	0x6cef50		4889e5			MOVQ SP, BP								
  members_string.go:1446	0x6cef53		4881ecf0000000		SUBQ $0xf0, SP								
  members_string.go:1446	0x6cef5a		4889842400010000	MOVQ AX, 0x100(SP)							
  members_string.go:1447	0x6cef62		4885ff			TESTQ DI, DI								
  members_string.go:1447	0x6cef65		7c26			JL 0x6cef8d								
  members_string.go:1447	0x6cef67		4889bc2418010000	MOVQ DI, 0x118(SP)							
  members_string.go:1447	0x6cef6f		48899c2408010000	MOVQ BX, 0x108(SP)							
  members_string.go:1447	0x6cef77		4889842400010000	MOVQ AX, 0x100(SP)							
  members_string.go:1447	0x6cef7f		90			NOPL									
  members_string.go:1450	0x6cef80		4885c9			TESTQ CX, CX								
  members_string.go:1450	0x6cef83		7d19			JGE 0x6cef9e								
  members_string.go:1178	0x6cef85		90			NOPL									
  members_string.go:1100	0x6cef86		31d2			XORL DX, DX								
  members_string.go:1100	0x6cef88		e93b020000		JMP 0x6cf1c8								
  members_string.go:1448	0x6cef8d		31c0			XORL AX, AX								
  members_string.go:1448	0x6cef8f		31db			XORL BX, BX								
  members_string.go:1448	0x6cef91		31c9			XORL CX, CX								
  members_string.go:1448	0x6cef93		89cf			MOVL CX, DI								
  members_string.go:1448	0x6cef95		4881c4f0000000		ADDQ $0xf0, SP								
  members_string.go:1448	0x6cef9c		5d			POPQ BP									
  members_string.go:1448	0x6cef9d		c3			RET									
  members_string.go:1448	0x6cef9e		6690			NOPW									
  members_string.go:1185	0x6cefa0		4885c9			TESTQ CX, CX								
  members_string.go:1185	0x6cefa3		7d06			JGE 0x6cefab								
  members_string.go:1185	0x6cefa5		31c9			XORL CX, CX								
  members_string.go:1185	0x6cefa7		31d2			XORL DX, DX								
  members_string.go:1456	0x6cefa9		eb3f			JMP 0x6cefea								
  members_string.go:1188	0x6cefab		90			NOPL									
  members_string.go:1100	0x6cefac		31d2			XORL DX, DX								
  members_string.go:1100	0x6cefae		eb03			JMP 0x6cefb3								
  members_string.go:1100	0x6cefb0		48ffc2			INCQ DX									
  members_string.go:1100	0x6cefb3		4839d3			CMPQ BX, DX								
  members_string.go:1100	0x6cefb6		7e1f			JLE 0x6cefd7								
  members_string.go:1101	0x6cefb8		0fb63410		MOVZX 0(AX)(DX*1), SI							
  members_string.go:1101	0x6cefbc		0f1f4000		NOPL 0(AX)								
  members_string.go:1101	0x6cefc0		4080fe80		CMPL SI, $0x80								
  members_string.go:1101	0x6cefc4		72ea			JB 0x6cefb0								
  members_string.go:1456	0x6cefc6		48898c24d0000000	MOVQ CX, 0xd0(SP)							
  members_string.go:1195	0x6cefce		31d2			XORL DX, DX								
  members_string.go:1195	0x6cefd0		31f6			XORL SI, SI								
  members_string.go:1195	0x6cefd2		e95e010000		JMP 0x6cf135								
  members_string.go:1189	0x6cefd7		4839cb			CMPQ BX, CX								
  members_string.go:1189	0x6cefda		7d06			JGE 0x6cefe2								
  members_string.go:1189	0x6cefdc		31c9			XORL CX, CX								
  members_string.go:1189	0x6cefde		31d2			XORL DX, DX								
  members_string.go:1456	0x6cefe0		eb08			JMP 0x6cefea								
  members_string.go:1456	0x6cefe2		4889ca			MOVQ CX, DX								
  members_string.go:1456	0x6cefe5		b901000000		MOVL $0x1, CX								
  members_string.go:1456	0x6cefea		84c9			TESTL CL, CL								
  members_string.go:1457	0x6cefec		740d			JE 0x6ceffb								
  members_string.go:1456	0x6cefee		48899424c0000000	MOVQ DX, 0xc0(SP)							
  members_string.go:1456	0x6ceff6		4889d1			MOVQ DX, CX								
  members_string.go:1461	0x6ceff9		eb17			JMP 0x6cf012								
  members_string.go:1458	0x6ceffb		31c0			XORL AX, AX								
  members_string.go:1458	0x6ceffd		31db			XORL BX, BX								
  members_string.go:1458	0x6cefff		31c9			XORL CX, CX								
  members_string.go:1458	0x6cf001		89cf			MOVL CX, DI								
  members_string.go:1458	0x6cf003		4881c4f0000000		ADDQ $0xf0, SP								
  members_string.go:1458	0x6cf00a		5d			POPQ BP									
  members_string.go:1458	0x6cf00b		c3			RET									
  members_string.go:1466	0x6cf00c		4801f2			ADDQ SI, DX								
  members_string.go:1461	0x6cf00f		48ffcf			DECQ DI									
  members_string.go:1461	0x6cf012		4885ff			TESTQ DI, DI								
  members_string.go:1461	0x6cf015		7e73			JLE 0x6cf08a								
  members_string.go:1462	0x6cf017		4839d3			CMPQ BX, DX								
  members_string.go:1462	0x6cf01a		746e			JE 0x6cf08a								
  members_string.go:1462	0x6cf01c		0f1f4000		NOPL 0(AX)								
  members_string.go:1465	0x6cf020		0f8204010000		JB 0x6cf12a								
  utf8.go:223			0x6cf026		0fb63402		MOVZX 0(DX)(AX*1), SI							
  members_string.go:1465	0x6cf02a		4989d8			MOVQ BX, R8								
  members_string.go:1465	0x6cf02d		4929d0			SUBQ DX, R8								
  members_string.go:1465	0x6cf030		4c8d0c02		LEAQ 0(DX)(AX*1), R9							
  utf8.go:223			0x6cf034		4080fe80		CMPL SI, $0x80								
  utf8.go:223			0x6cf038		7308			JAE 0x6cf042								
  utf8.go:223			0x6cf03a		be01000000		MOVL $0x1, SI								
  utf8.go:223			0x6cf03f		90			NOPL									
  members_string.go:1465	0x6cf040		ebca			JMP 0x6cf00c								
  members_string.go:1461	0x6cf042		4889bc24e0000000	MOVQ DI, 0xe0(SP)							
  members_string.go:1461	0x6cf04a		48899424d8000000	MOVQ DX, 0xd8(SP)							
  utf8.go:226			0x6cf052		4c89c8			MOVQ R9, AX								
  utf8.go:226			0x6cf055		4c89c3			MOVQ R8, BX								
  utf8.go:226			0x6cf058		e843f8ddff		CALL unicode/utf8.decodeRuneInStringSlow(SB)				
  utf8.go:223			0x6cf05d		488b842400010000	MOVQ 0x100(SP), AX							
  members_string.go:1468	0x6cf065		488b8c24c0000000	MOVQ 0xc0(SP), CX							
  members_string.go:1466	0x6cf06d		488b9424d8000000	MOVQ 0xd8(SP), DX							
  members_string.go:1461	0x6cf075		488bbc24e0000000	MOVQ 0xe0(SP), DI							
  members_string.go:1465	0x6cf07d		4889de			MOVQ BX, SI								
  members_string.go:1462	0x6cf080		488b9c2408010000	MOVQ 0x108(SP), BX							
  members_string.go:1465	0x6cf088		eb82			JMP 0x6cf00c								
  members_string.go:1468	0x6cf08a		4839d3			CMPQ BX, DX								
  members_string.go:1468	0x6cf08d		0f8292000000		JB 0x6cf125								
  members_string.go:1468	0x6cf093		4839ca			CMPQ DX, CX								
  members_string.go:1468	0x6cf096		0f8283000000		JB 0x6cf11f								
  members_string.go:1468	0x6cf09c		4829ca			SUBQ CX, DX								
  members_string.go:1468	0x6cf09f		48899424b8000000	MOVQ DX, 0xb8(SP)							
  members_string.go:1468	0x6cf0a7		4889d3			MOVQ DX, BX								
  members_string.go:1468	0x6cf0aa		48f7da			NEGQ DX									
  members_string.go:1468	0x6cf0ad		48c1fa3f		SARQ $0x3f, DX								
  members_string.go:1468	0x6cf0b1		4821d1			ANDQ DX, CX								
  members_string.go:1468	0x6cf0b4		4801c8			ADDQ CX, AX								
  members_string.go:1468	0x6cf0b7		48898424e8000000	MOVQ AX, 0xe8(SP)							
  members_string.go:1433	0x6cf0bf		90			NOPL									
  members_string.go:1433	0x6cf0c0		e83bfeddff		CALL unicode/utf8.ValidString(SB)					
  members_string.go:1433	0x6cf0c5		88442427		MOVB AL, 0x27(SP)							
  members_string.go:1433	0x6cf0c9		84c0			TESTL AL, AL								
  members_string.go:1433	0x6cf0cb		7412			JE 0x6cf0df								
  members_string.go:1468	0x6cf0cd		488b9c24b8000000	MOVQ 0xb8(SP), BX							
  members_string.go:1468	0x6cf0d5		488b8424e8000000	MOVQ 0xe8(SP), AX							
  members_string.go:1468	0x6cf0dd		eb2a			JMP 0x6cf109								
  members_string.go:1436	0x6cf0df		488d442428		LEAQ 0x28(SP), AX							
  members_string.go:1436	0x6cf0e4		488b9c24e8000000	MOVQ 0xe8(SP), BX							
  members_string.go:1436	0x6cf0ec		488b8c24b8000000	MOVQ 0xb8(SP), CX							
  members_string.go:1436	0x6cf0f4		e847bcd9ff		CALL runtime.stringtoslicerune(SB)					
  members_string.go:1436	0x6cf0f9		4889cf			MOVQ CX, DI								
  members_string.go:1436	0x6cf0fc		4889d9			MOVQ BX, CX								
  members_string.go:1436	0x6cf0ff		4889c3			MOVQ AX, BX								
  members_string.go:1436	0x6cf102		31c0			XORL AX, AX								
  members_string.go:1436	0x6cf104		e8b7bdd9ff		CALL runtime.slicerunetostring(SB)					
  members_string.go:1468	0x6cf109		0fb64c2427		MOVZX 0x27(SP), CX							
  members_string.go:1468	0x6cf10e		83f101			XORL $0x1, CX								
  members_string.go:1468	0x6cf111		bf01000000		MOVL $0x1, DI								
  members_string.go:1468	0x6cf116		4881c4f0000000		ADDQ $0xf0, SP								
  members_string.go:1468	0x6cf11d		5d			POPQ BP									
  members_string.go:1468	0x6cf11e		c3			RET									
  members_string.go:1468	0x6cf11f		90			NOPL									
  members_string.go:1468	0x6cf120		e81bf1dbff		CALL runtime.panicBounds(SB)						
  members_string.go:1468	0x6cf125		e816f1dbff		CALL runtime.panicBounds(SB)						
  members_string.go:1465	0x6cf12a		e811f1dbff		CALL runtime.panicBounds(SB)						
  members_string.go:1199	0x6cf12f		48ffc6			INCQ SI									
  members_string.go:1195	0x6cf132		4c89c2			MOVQ R8, DX								
  members_string.go:1195	0x6cf135		4839d3			CMPQ BX, DX								
  members_string.go:1195	0x6cf138		7e6d			JLE 0x6cf1a7								
  members_string.go:1195	0x6cf13a		440fb60410		MOVZX 0(AX)(DX*1), R8							
  members_string.go:1195	0x6cf13f		90			NOPL									
  members_string.go:1195	0x6cf140		4183f87f		CMPL R8, $0x7f								
  members_string.go:1195	0x6cf144		7f06			JG 0x6cf14c								
  members_string.go:1195	0x6cf146		4c8d4201		LEAQ 0x1(DX), R8							
  members_string.go:1195	0x6cf14a		eb4c			JMP 0x6cf198								
  members_string.go:1195	0x6cf14c		48899424a8000000	MOVQ DX, 0xa8(SP)							
  members_string.go:1195	0x6cf154		4889b424c8000000	MOVQ SI, 0xc8(SP)							
  members_string.go:1195	0x6cf15c		4889d1			MOVQ DX, CX								
  members_string.go:1195	0x6cf15f		90			NOPL									
  members_string.go:1195	0x6cf160		e85be0daff		CALL runtime.decoderune(SB)						
  members_string.go:1195	0x6cf165		488b842400010000	MOVQ 0x100(SP), AX							
  members_string.go:1196	0x6cf16d		488b8c24d0000000	MOVQ 0xd0(SP), CX							
  members_string.go:1456	0x6cf175		488b9424a8000000	MOVQ 0xa8(SP), DX							
  members_string.go:1196	0x6cf17d		488bb424c8000000	MOVQ 0xc8(SP), SI							
  members_string.go:1461	0x6cf185		488bbc2418010000	MOVQ 0x118(SP), DI							
  members_string.go:1195	0x6cf18d		4989d8			MOVQ BX, R8								
  members_string.go:1195	0x6cf190		488b9c2408010000	MOVQ 0x108(SP), BX							
  members_string.go:1196	0x6cf198		4839ce			CMPQ SI, CX								
  members_string.go:1196	0x6cf19b		7592			JNE 0x6cf12f								
  members_string.go:1196	0x6cf19d		b901000000		MOVL $0x1, CX								
  members_string.go:1456	0x6cf1a2		e943feffff		JMP 0x6cefea								
  members_string.go:1201	0x6cf1a7		4839ce			CMPQ SI, CX								
  members_string.go:1201	0x6cf1aa		750d			JNE 0x6cf1b9								
  members_string.go:1201	0x6cf1ac		b901000000		MOVL $0x1, CX								
  members_string.go:1456	0x6cf1b1		4889da			MOVQ BX, DX								
  members_string.go:1456	0x6cf1b4		e931feffff		JMP 0x6cefea								
  members_string.go:1456	0x6cf1b9		31c9			XORL CX, CX								
  members_string.go:1456	0x6cf1bb		31d2			XORL DX, DX								
  members_string.go:1456	0x6cf1bd		0f1f00			NOPL 0(AX)								
  members_string.go:1456	0x6cf1c0		e925feffff		JMP 0x6cefea								
  members_string.go:1100	0x6cf1c5		48ffc2			INCQ DX									
  members_string.go:1100	0x6cf1c8		4839d3			CMPQ BX, DX								
  members_string.go:1100	0x6cf1cb		7e19			JLE 0x6cf1e6								
  members_string.go:1101	0x6cf1cd		0fb63410		MOVZX 0(AX)(DX*1), SI							
  members_string.go:1101	0x6cf1d1		4080fe80		CMPL SI, $0x80								
  members_string.go:1101	0x6cf1d5		72ee			JB 0x6cf1c5								
  members_string.go:1447	0x6cf1d7		48898c2410010000	MOVQ CX, 0x110(SP)							
  members_string.go:1181	0x6cf1df		90			NOPL									
  utf8.go:448			0x6cf1e0		31d2			XORL DX, DX								
  utf8.go:448			0x6cf1e2		31f6			XORL SI, SI								
  utf8.go:448			0x6cf1e4		eb2a			JMP 0x6cf210								
  members_string.go:1447	0x6cf1e6		4889da			MOVQ BX, DX								
  members_string.go:1451	0x6cf1e9		4801cb			ADDQ CX, BX								
  members_string.go:1452	0x6cf1ec		4885db			TESTQ BX, BX								
  members_string.go:1452	0x6cf1ef		7c0b			JL 0x6cf1fc								
  members_string.go:1456	0x6cf1f1		4889d9			MOVQ BX, CX								
  members_string.go:1100	0x6cf1f4		4889d3			MOVQ DX, BX								
  members_string.go:1452	0x6cf1f7		e9a2fdffff		JMP 0x6cef9e								
  members_string.go:1453	0x6cf1fc		31c0			XORL AX, AX								
  members_string.go:1453	0x6cf1fe		31db			XORL BX, BX								
  members_string.go:1453	0x6cf200		31c9			XORL CX, CX								
  members_string.go:1453	0x6cf202		89cf			MOVL CX, DI								
  members_string.go:1453	0x6cf204		4881c4f0000000		ADDQ $0xf0, SP								
  members_string.go:1453	0x6cf20b		5d			POPQ BP									
  members_string.go:1453	0x6cf20c		c3			RET									
  utf8.go:449			0x6cf20d		48ffc2			INCQ DX									
  utf8.go:448			0x6cf210		4839f3			CMPQ BX, SI								
  utf8.go:448			0x6cf213		7e53			JLE 0x6cf268								
  utf8.go:448			0x6cf215		440fb60430		MOVZX 0(AX)(SI*1), R8							
  utf8.go:448			0x6cf21a		660f1f440000		NOPW 0(AX)(AX*1)							
  utf8.go:448			0x6cf220		4183f87f		CMPL R8, $0x7f								
  utf8.go:448			0x6cf224		7f05			JG 0x6cf22b								
  utf8.go:448			0x6cf226		48ffc6			INCQ SI									
  utf8.go:448			0x6cf229		ebe2			JMP 0x6cf20d								
  utf8.go:448			0x6cf22b		48899424b0000000	MOVQ DX, 0xb0(SP)							
  utf8.go:448			0x6cf233		4889f1			MOVQ SI, CX								
  utf8.go:448			0x6cf236		e885dfdaff		CALL runtime.decoderune(SB)						
  utf8.go:448			0x6cf23b		488b842400010000	MOVQ 0x100(SP), AX							
  members_string.go:1451	0x6cf243		488b8c2410010000	MOVQ 0x110(SP), CX							
  utf8.go:449			0x6cf24b		488b9424b0000000	MOVQ 0xb0(SP), DX							
  members_string.go:1461	0x6cf253		488bbc2418010000	MOVQ 0x118(SP), DI							
  utf8.go:449			0x6cf25b		4889de			MOVQ BX, SI								
  utf8.go:448			0x6cf25e		488b9c2408010000	MOVQ 0x108(SP), BX							
  utf8.go:448			0x6cf266		eba5			JMP 0x6cf20d								
  members_string.go:1451	0x6cf268		4889d3			MOVQ DX, BX								
  members_string.go:1100	0x6cf26b		488b942408010000	MOVQ 0x108(SP), DX							
  members_string.go:1451	0x6cf273		e971ffffff		JMP 0x6cf1e9								
  members_string.go:1446	0x6cf278		4889442408		MOVQ AX, 0x8(SP)							
  members_string.go:1446	0x6cf27d		48895c2410		MOVQ BX, 0x10(SP)							
  members_string.go:1446	0x6cf282		48894c2418		MOVQ CX, 0x18(SP)							
  members_string.go:1446	0x6cf287		48897c2420		MOVQ DI, 0x20(SP)							
  members_string.go:1446	0x6cf28c		e86fd3dbff		CALL runtime.morestack_noctxt.abi0(SB)					
  members_string.go:1446	0x6cf291		488b442408		MOVQ 0x8(SP), AX							
  members_string.go:1446	0x6cf296		488b5c2410		MOVQ 0x10(SP), BX							
  members_string.go:1446	0x6cf29b		488b4c2418		MOVQ 0x18(SP), CX							
  members_string.go:1446	0x6cf2a0		488b7c2420		MOVQ 0x20(SP), DI							
  members_string.go:1446	0x6cf2a5		e996fcffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneSlice(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func2(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:3804	0x7588e0		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:3804	0x7588e4		0f8626010000		JBE 0x758a10									
  members_string.go:3804	0x7588ea		55			PUSHQ BP									
  members_string.go:3804	0x7588eb		4889e5			MOVQ SP, BP									
  members_string.go:3804	0x7588ee		4883ec40		SUBQ $0x40, SP									
  members_string.go:3804	0x7588f2		48898c2480000000	MOVQ CX, 0x80(SP)								
  members_string.go:3804	0x7588fa		4889bc2488000000	MOVQ DI, 0x88(SP)								
  members_string.go:3804	0x758902		4c89842498000000	MOVQ R8, 0x98(SP)								
  members_string.go:3805	0x75890a		4d85c9			TESTQ R9, R9									
  members_string.go:3805	0x75890d		751b			JNE 0x75892a									
  members_string.go:3808	0x75890f		4889d8			MOVQ BX, AX									
  members_string.go:3808	0x758912		4889cb			MOVQ CX, BX									
  members_string.go:3808	0x758915		4889f9			MOVQ DI, CX									
  members_string.go:3808	0x758918		4889f7			MOVQ SI, DI									
  members_string.go:3808	0x75891b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:3808	0x758920		e89b39e5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:1178	0x758925		90			NOPL										
  members_string.go:1100	0x758926		31d2			XORL DX, DX									
  members_string.go:1100	0x758928		eb6e			JMP 0x758998									
  errors.go:26			0x75892a		488d05b9740600		LEAQ 0x674b9(IP), AX								
  errors.go:26			0x758931		bb25000000		MOVL $0x25, BX									
  errors.go:26			0x758936		31c9			XORL CX, CX									
  errors.go:26			0x758938		31ff			XORL DI, DI									
  errors.go:26			0x75893a		89fe			MOVL DI, SI									
  errors.go:26			0x75893c		0f1f4000		NOPL 0(AX)									
  errors.go:26			0x758940		e81b55d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x758945		4885c0			TESTQ AX, AX									
  errors.go:26			0x758948		7537			JNE 0x758981									
  errors.go:31			0x75894a		90			NOPL										
  errors.go:65			0x75894b		b810000000		MOVL $0x10, AX									
  errors.go:65			0x758950		488d1d991d3900		LEAQ 0x391d99(IP), BX								
  errors.go:65			0x758957		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75895c		0f1f4000		NOPL 0(AX)									
  errors.go:65			0x758960		e8fb89ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x758965		48c7400825000000	MOVQ $0x25, 0x8(AX)								
  errors.go:65			0x75896d		488d1576740600		LEAQ 0x67476(IP), DX								
  errors.go:65			0x758974		488910			MOVQ DX, 0(AX)									
  members_string.go:3806	0x758977		4889c3			MOVQ AX, BX									
  members_string.go:3806	0x75897a		488d051ffb3b00		LEAQ 0x3bfb1f(IP), AX								
  members_string.go:3806	0x758981		31c9			XORL CX, CX									
  members_string.go:3806	0x758983		31ff			XORL DI, DI									
  members_string.go:3806	0x758985		4889c6			MOVQ AX, SI									
  members_string.go:3806	0x758988		4989d8			MOVQ BX, R8									
  members_string.go:3806	0x75898b		31c0			XORL AX, AX									
  members_string.go:3806	0x75898d		31db			XORL BX, BX									
  members_string.go:3806	0x75898f		4883c440		ADDQ $0x40, SP									
  members_string.go:3806	0x758993		5d			POPQ BP										
  members_string.go:3806	0x758994		c3			RET										
  members_string.go:1100	0x758995		48ffc2			INCQ DX										
  members_string.go:1100	0x758998		4839d3			CMPQ BX, DX									
  members_string.go:1100	0x75899b		7e1d			JLE 0x7589ba									
  members_string.go:1101	0x75899d		440fb60c10		MOVZX 0(AX)(DX*1), R9								
  members_string.go:1101	0x7589a2		4180f980		CMPL R9, $0x80									
  members_string.go:1101	0x7589a6		72ed			JB 0x758995									
  members_string.go:3808	0x7589a8		48895c2428		MOVQ BX, 0x28(SP)								
  members_string.go:3808	0x7589ad		4889442438		MOVQ AX, 0x38(SP)								
  members_string.go:1181	0x7589b2		90			NOPL										
  utf8.go:448			0x7589b3		31d2			XORL DX, DX									
  utf8.go:448			0x7589b5		4531c9			XORL R9, R9									
  utf8.go:448			0x7589b8		eb1a			JMP 0x7589d4									
  members_string.go:3808	0x7589ba		b802000000		MOVL $0x2, AX									
  members_string.go:3808	0x7589bf		31c9			XORL CX, CX									
  members_string.go:3808	0x7589c1		4889df			MOVQ BX, DI									
  members_string.go:3808	0x7589c4		31f6			XORL SI, SI									
  members_string.go:3808	0x7589c6		4189c8			MOVL CX, R8									
  members_string.go:3808	0x7589c9		89f3			MOVL SI, BX									
  members_string.go:3808	0x7589cb		4883c440		ADDQ $0x40, SP									
  members_string.go:3808	0x7589cf		5d			POPQ BP										
  members_string.go:3808	0x7589d0		c3			RET										
  utf8.go:449			0x7589d1		49ffc1			INCQ R9										
  utf8.go:448			0x7589d4		4839d3			CMPQ BX, DX									
  utf8.go:448			0x7589d7		7e32			JLE 0x758a0b									
  utf8.go:448			0x7589d9		0fb63c10		MOVZX 0(AX)(DX*1), DI								
  utf8.go:448			0x7589dd		0f1f00			NOPL 0(AX)									
  utf8.go:448			0x7589e0		83ff7f			CMPL DI, $0x7f									
  utf8.go:448			0x7589e3		7f05			JG 0x7589ea									
  utf8.go:448			0x7589e5		48ffc2			INCQ DX										
  utf8.go:448			0x7589e8		ebe7			JMP 0x7589d1									
  utf8.go:448			0x7589ea		4c894c2430		MOVQ R9, 0x30(SP)								
  utf8.go:448			0x7589ef		4889d1			MOVQ DX, CX									
  utf8.go:448			0x7589f2		e8c947d2ff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x7589f7		488b442438		MOVQ 0x38(SP), AX								
  utf8.go:449			0x7589fc		4c8b4c2430		MOVQ 0x30(SP), R9								
  utf8.go:449			0x758a01		4889da			MOVQ BX, DX									
  utf8.go:448			0x758a04		488b5c2428		MOVQ 0x28(SP), BX								
  utf8.go:448			0x758a09		ebc6			JMP 0x7589d1									
  members_string.go:3808	0x758a0b		4c89cb			MOVQ R9, BX									
  members_string.go:3808	0x758a0e		ebaa			JMP 0x7589ba									
  members_string.go:3804	0x758a10		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:3804	0x758a15		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:3804	0x758a1a		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:3804	0x758a1f		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:3804	0x758a24		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:3804	0x758a29		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:3804	0x758a2e		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:3804	0x758a33		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:3804	0x758a38		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:3804	0x758a3d		0f1f00			NOPL 0(AX)									
  members_string.go:3804	0x758a40		e8bb3bd3ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:3804	0x758a45		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:3804	0x758a4a		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:3804	0x758a4f		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:3804	0x758a54		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:3804	0x758a59		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:3804	0x758a5e		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:3804	0x758a63		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:3804	0x758a68		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:3804	0x758a6d		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:3804	0x758a72		e969feffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func2(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func20(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4045	0x75b500		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4045	0x75b504		0f8615010000		JBE 0x75b61f									
  members_string.go:4045	0x75b50a		55			PUSHQ BP									
  members_string.go:4045	0x75b50b		4889e5			MOVQ SP, BP									
  members_string.go:4045	0x75b50e		4883ec38		SUBQ $0x38, SP									
  members_string.go:4045	0x75b512		48894c2478		MOVQ CX, 0x78(SP)								
  members_string.go:4045	0x75b517		4889bc2480000000	MOVQ DI, 0x80(SP)								
  members_string.go:4045	0x75b51f		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4046	0x75b527		4983f901		CMPQ R9, $0x1									
  members_string.go:4046	0x75b52b		0f858b000000		JNE 0x75b5bc									
  members_string.go:4049	0x75b531		49833804		CMPQ 0(R8), $0x4								
  members_string.go:4049	0x75b535		7413			JE 0x75b54a									
  members_string.go:4050	0x75b537		31c0			XORL AX, AX									
  members_string.go:4050	0x75b539		31db			XORL BX, BX									
  members_string.go:4050	0x75b53b		31c9			XORL CX, CX									
  members_string.go:4050	0x75b53d		31ff			XORL DI, DI									
  members_string.go:4050	0x75b53f		89de			MOVL BX, SI									
  members_string.go:4050	0x75b541		4189c8			MOVL CX, R8									
  members_string.go:4050	0x75b544		4883c438		ADDQ $0x38, SP									
  members_string.go:4050	0x75b548		5d			POPQ BP										
  members_string.go:4050	0x75b549		c3			RET										
  members_string.go:4046	0x75b54a		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4052	0x75b552		4889d8			MOVQ BX, AX									
  members_string.go:4052	0x75b555		4889cb			MOVQ CX, BX									
  members_string.go:4052	0x75b558		4889f9			MOVQ DI, CX									
  members_string.go:4052	0x75b55b		4889f7			MOVQ SI, DI									
  members_string.go:4052	0x75b55e		6690			NOPW										
  members_string.go:4052	0x75b560		e85b0de5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4052	0x75b565		4889442430		MOVQ AX, 0x30(SP)								
  members_string.go:4052	0x75b56a		48895c2428		MOVQ BX, 0x28(SP)								
  members_string.go:4052	0x75b56f		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4052	0x75b577		488b02			MOVQ 0(DX), AX									
  members_string.go:4052	0x75b57a		488b4a10		MOVQ 0x10(DX), CX								
  members_string.go:4052	0x75b57e		488b7a18		MOVQ 0x18(DX), DI								
  members_string.go:4052	0x75b582		488b5a08		MOVQ 0x8(DX), BX								
  members_string.go:4052	0x75b586		e8350de5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4052	0x75b58b		4889c1			MOVQ AX, CX									
  members_string.go:4052	0x75b58e		4889df			MOVQ BX, DI									
  members_string.go:4052	0x75b591		488b442430		MOVQ 0x30(SP), AX								
  members_string.go:4052	0x75b596		488b5c2428		MOVQ 0x28(SP), BX								
  members_string.go:4052	0x75b59b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4052	0x75b5a0		e8fb27f7ff		CALL github.com/mgomes/vibescript/internal/runtime.asciiCaseCompare(SB)		
  members_string.go:4052	0x75b5a5		31db			XORL BX, BX									
  members_string.go:4052	0x75b5a7		31c9			XORL CX, CX									
  members_string.go:4052	0x75b5a9		4889c7			MOVQ AX, DI									
  members_string.go:4052	0x75b5ac		89de			MOVL BX, SI									
  members_string.go:4052	0x75b5ae		4189c8			MOVL CX, R8									
  members_string.go:4052	0x75b5b1		b802000000		MOVL $0x2, AX									
  members_string.go:4052	0x75b5b6		4883c438		ADDQ $0x38, SP									
  members_string.go:4052	0x75b5ba		5d			POPQ BP										
  members_string.go:4052	0x75b5bb		c3			RET										
  errors.go:26			0x75b5bc		488d05ae720600		LEAQ 0x672ae(IP), AX								
  errors.go:26			0x75b5c3		bb29000000		MOVL $0x29, BX									
  errors.go:26			0x75b5c8		31c9			XORL CX, CX									
  errors.go:26			0x75b5ca		31ff			XORL DI, DI									
  errors.go:26			0x75b5cc		89fe			MOVL DI, SI									
  errors.go:26			0x75b5ce		e88d28d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75b5d3		4885c0			TESTQ AX, AX									
  errors.go:26			0x75b5d6		7533			JNE 0x75b60b									
  errors.go:31			0x75b5d8		90			NOPL										
  errors.go:65			0x75b5d9		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75b5de		488d1d0bf13800		LEAQ 0x38f10b(IP), BX								
  errors.go:65			0x75b5e5		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75b5ea		e8715dccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75b5ef		48c7400829000000	MOVQ $0x29, 0x8(AX)								
  errors.go:65			0x75b5f7		488d1573720600		LEAQ 0x67273(IP), DX								
  errors.go:65			0x75b5fe		488910			MOVQ DX, 0(AX)									
  members_string.go:4047	0x75b601		4889c3			MOVQ AX, BX									
  members_string.go:4047	0x75b604		488d0595ce3b00		LEAQ 0x3bce95(IP), AX								
  members_string.go:4047	0x75b60b		31c9			XORL CX, CX									
  members_string.go:4047	0x75b60d		31ff			XORL DI, DI									
  members_string.go:4047	0x75b60f		4889c6			MOVQ AX, SI									
  members_string.go:4047	0x75b612		4989d8			MOVQ BX, R8									
  members_string.go:4047	0x75b615		31c0			XORL AX, AX									
  members_string.go:4047	0x75b617		31db			XORL BX, BX									
  members_string.go:4047	0x75b619		4883c438		ADDQ $0x38, SP									
  members_string.go:4047	0x75b61d		5d			POPQ BP										
  members_string.go:4047	0x75b61e		c3			RET										
  members_string.go:4045	0x75b61f		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4045	0x75b624		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4045	0x75b629		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4045	0x75b62e		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4045	0x75b633		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4045	0x75b638		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4045	0x75b63d		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4045	0x75b642		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4045	0x75b647		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4045	0x75b64c		e8af0fd3ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4045	0x75b651		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4045	0x75b656		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4045	0x75b65b		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4045	0x75b660		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4045	0x75b665		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4045	0x75b66a		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4045	0x75b66f		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4045	0x75b674		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4045	0x75b679		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4045	0x75b67e		6690			NOPW										
  members_string.go:4045	0x75b680		e97bfeffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func20(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func21(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4055	0x75b6a0		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4055	0x75b6a4		0f8615010000		JBE 0x75b7bf									
  members_string.go:4055	0x75b6aa		55			PUSHQ BP									
  members_string.go:4055	0x75b6ab		4889e5			MOVQ SP, BP									
  members_string.go:4055	0x75b6ae		4883ec38		SUBQ $0x38, SP									
  members_string.go:4055	0x75b6b2		48894c2478		MOVQ CX, 0x78(SP)								
  members_string.go:4055	0x75b6b7		4889bc2480000000	MOVQ DI, 0x80(SP)								
  members_string.go:4055	0x75b6bf		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4056	0x75b6c7		4983f901		CMPQ R9, $0x1									
  members_string.go:4056	0x75b6cb		0f858b000000		JNE 0x75b75c									
  members_string.go:4059	0x75b6d1		49833804		CMPQ 0(R8), $0x4								
  members_string.go:4059	0x75b6d5		7413			JE 0x75b6ea									
  members_string.go:4060	0x75b6d7		31c0			XORL AX, AX									
  members_string.go:4060	0x75b6d9		31db			XORL BX, BX									
  members_string.go:4060	0x75b6db		31c9			XORL CX, CX									
  members_string.go:4060	0x75b6dd		31ff			XORL DI, DI									
  members_string.go:4060	0x75b6df		89de			MOVL BX, SI									
  members_string.go:4060	0x75b6e1		4189c8			MOVL CX, R8									
  members_string.go:4060	0x75b6e4		4883c438		ADDQ $0x38, SP									
  members_string.go:4060	0x75b6e8		5d			POPQ BP										
  members_string.go:4060	0x75b6e9		c3			RET										
  members_string.go:4056	0x75b6ea		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4062	0x75b6f2		4889d8			MOVQ BX, AX									
  members_string.go:4062	0x75b6f5		4889cb			MOVQ CX, BX									
  members_string.go:4062	0x75b6f8		4889f9			MOVQ DI, CX									
  members_string.go:4062	0x75b6fb		4889f7			MOVQ SI, DI									
  members_string.go:4062	0x75b6fe		6690			NOPW										
  members_string.go:4062	0x75b700		e8bb0be5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4062	0x75b705		4889442430		MOVQ AX, 0x30(SP)								
  members_string.go:4062	0x75b70a		48895c2428		MOVQ BX, 0x28(SP)								
  members_string.go:4062	0x75b70f		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4062	0x75b717		488b02			MOVQ 0(DX), AX									
  members_string.go:4062	0x75b71a		488b5a08		MOVQ 0x8(DX), BX								
  members_string.go:4062	0x75b71e		488b4a10		MOVQ 0x10(DX), CX								
  members_string.go:4062	0x75b722		488b7a18		MOVQ 0x18(DX), DI								
  members_string.go:4062	0x75b726		e8950be5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4062	0x75b72b		4889c1			MOVQ AX, CX									
  members_string.go:4062	0x75b72e		4889df			MOVQ BX, DI									
  members_string.go:4062	0x75b731		488b442430		MOVQ 0x30(SP), AX								
  members_string.go:4062	0x75b736		488b5c2428		MOVQ 0x28(SP), BX								
  members_string.go:4062	0x75b73b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4062	0x75b740		e8db26f7ff		CALL github.com/mgomes/vibescript/internal/runtime.caseInsensitiveEqual(SB)	
  members_string.go:4062	0x75b745		0fb6f8			MOVZX AL, DI									
  members_string.go:4062	0x75b748		b801000000		MOVL $0x1, AX									
  members_string.go:4062	0x75b74d		31db			XORL BX, BX									
  members_string.go:4062	0x75b74f		31c9			XORL CX, CX									
  members_string.go:4062	0x75b751		89de			MOVL BX, SI									
  members_string.go:4062	0x75b753		4189c8			MOVL CX, R8									
  members_string.go:4062	0x75b756		4883c438		ADDQ $0x38, SP									
  members_string.go:4062	0x75b75a		5d			POPQ BP										
  members_string.go:4062	0x75b75b		c3			RET										
  errors.go:26			0x75b75c		488d05837b0600		LEAQ 0x67b83(IP), AX								
  errors.go:26			0x75b763		bb2a000000		MOVL $0x2a, BX									
  errors.go:26			0x75b768		31c9			XORL CX, CX									
  errors.go:26			0x75b76a		31ff			XORL DI, DI									
  errors.go:26			0x75b76c		89fe			MOVL DI, SI									
  errors.go:26			0x75b76e		e8ed26d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75b773		4885c0			TESTQ AX, AX									
  errors.go:26			0x75b776		7533			JNE 0x75b7ab									
  errors.go:31			0x75b778		90			NOPL										
  errors.go:65			0x75b779		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75b77e		488d1d6bef3800		LEAQ 0x38ef6b(IP), BX								
  errors.go:65			0x75b785		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75b78a		e8d15bccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75b78f		48c740082a000000	MOVQ $0x2a, 0x8(AX)								
  errors.go:65			0x75b797		488d15487b0600		LEAQ 0x67b48(IP), DX								
  errors.go:65			0x75b79e		488910			MOVQ DX, 0(AX)									
  members_string.go:4057	0x75b7a1		4889c3			MOVQ AX, BX									
  members_string.go:4057	0x75b7a4		488d05f5cc3b00		LEAQ 0x3bccf5(IP), AX								
  members_string.go:4057	0x75b7ab		31c9			XORL CX, CX									
  members_string.go:4057	0x75b7ad		31ff			XORL DI, DI									
  members_string.go:4057	0x75b7af		4889c6			MOVQ AX, SI									
  members_string.go:4057	0x75b7b2		4989d8			MOVQ BX, R8									
  members_string.go:4057	0x75b7b5		31c0			XORL AX, AX									
  members_string.go:4057	0x75b7b7		31db			XORL BX, BX									
  members_string.go:4057	0x75b7b9		4883c438		ADDQ $0x38, SP									
  members_string.go:4057	0x75b7bd		5d			POPQ BP										
  members_string.go:4057	0x75b7be		c3			RET										
  members_string.go:4055	0x75b7bf		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4055	0x75b7c4		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4055	0x75b7c9		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4055	0x75b7ce		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4055	0x75b7d3		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4055	0x75b7d8		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4055	0x75b7dd		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4055	0x75b7e2		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4055	0x75b7e7		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4055	0x75b7ec		e80f0ed3ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4055	0x75b7f1		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4055	0x75b7f6		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4055	0x75b7fb		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4055	0x75b800		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4055	0x75b805		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4055	0x75b80a		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4055	0x75b80f		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4055	0x75b814		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4055	0x75b819		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4055	0x75b81e		6690			NOPW										
  members_string.go:4055	0x75b820		e97bfeffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func21(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func22(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4065	0x75b840		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4065	0x75b844		0f8684000000		JBE 0x75b8ce									
  members_string.go:4065	0x75b84a		55			PUSHQ BP									
  members_string.go:4065	0x75b84b		4889e5			MOVQ SP, BP									
  members_string.go:4065	0x75b84e		4883ec70		SUBQ $0x70, SP									
  members_string.go:4065	0x75b852		48898c24b0000000	MOVQ CX, 0xb0(SP)								
  members_string.go:4065	0x75b85a		4889bc24b8000000	MOVQ DI, 0xb8(SP)								
  members_string.go:4065	0x75b862		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4066	0x75b86a		4c891c24		MOVQ R11, 0(SP)									
  members_string.go:4066	0x75b86e		488b942480000000	MOVQ 0x80(SP), DX								
  members_string.go:4066	0x75b876		4889542408		MOVQ DX, 0x8(SP)								
  members_string.go:4066	0x75b87b		488b942488000000	MOVQ 0x88(SP), DX								
  members_string.go:4066	0x75b883		4889542410		MOVQ DX, 0x10(SP)								
  members_string.go:4066	0x75b888		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4066	0x75b890		4889542418		MOVQ DX, 0x18(SP)								
  members_string.go:4066	0x75b895		488b942498000000	MOVQ 0x98(SP), DX								
  members_string.go:4066	0x75b89d		4889542420		MOVQ DX, 0x20(SP)								
  members_string.go:4066	0x75b8a2		488d053c860500		LEAQ 0x5863c(IP), AX								
  members_string.go:4066	0x75b8a9		4d89d3			MOVQ R10, R11									
  members_string.go:4066	0x75b8ac		4d89ca			MOVQ R9, R10									
  members_string.go:4066	0x75b8af		4d89c1			MOVQ R8, R9									
  members_string.go:4066	0x75b8b2		4989f0			MOVQ SI, R8									
  members_string.go:4066	0x75b8b5		4889fe			MOVQ DI, SI									
  members_string.go:4066	0x75b8b8		4889cf			MOVQ CX, DI									
  members_string.go:4066	0x75b8bb		4889d9			MOVQ BX, CX									
  members_string.go:4066	0x75b8be		bb0f000000		MOVL $0xf, BX									
  members_string.go:4066	0x75b8c3		e818f0fdff		CALL github.com/mgomes/vibescript/internal/runtime.comparableBetween(SB)	
  members_string.go:4066	0x75b8c8		4883c470		ADDQ $0x70, SP									
  members_string.go:4066	0x75b8cc		5d			POPQ BP										
  members_string.go:4066	0x75b8cd		c3			RET										
  members_string.go:4065	0x75b8ce		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4065	0x75b8d3		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4065	0x75b8d8		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4065	0x75b8dd		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4065	0x75b8e2		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4065	0x75b8e7		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4065	0x75b8ec		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4065	0x75b8f1		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4065	0x75b8f6		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4065	0x75b8fb		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4065	0x75b900		e8fb0cd3ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4065	0x75b905		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4065	0x75b90a		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4065	0x75b90f		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4065	0x75b914		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4065	0x75b919		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4065	0x75b91e		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4065	0x75b923		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4065	0x75b928		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4065	0x75b92d		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4065	0x75b932		e909ffffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func22(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func23(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4069	0x75b940		4c8da42400ffffff	LEAQ 0xffffff00(SP), R12									
  members_string.go:4069	0x75b948		4d3b6610		CMPQ R12, 0x10(R14)										
  members_string.go:4069	0x75b94c		0f86f3080000		JBE 0x75c245											
  members_string.go:4069	0x75b952		55			PUSHQ BP											
  members_string.go:4069	0x75b953		4889e5			MOVQ SP, BP											
  members_string.go:4069	0x75b956		4881ec78010000		SUBQ $0x178, SP											
  members_string.go:4069	0x75b95d		48898c24b8010000	MOVQ CX, 0x1b8(SP)										
  members_string.go:4069	0x75b965		4889bc24c0010000	MOVQ DI, 0x1c0(SP)										
  members_string.go:4069	0x75b96d		4c898424d0010000	MOVQ R8, 0x1d0(SP)										
  members_string.go:4070	0x75b975		4d85db			TESTQ R11, R11											
  members_string.go:4070	0x75b978		7405			JE 0x75b97f											
  members_string.go:4070	0x75b97a		498b13			MOVQ 0(R11), DX											
  members_string.go:4070	0x75b97d		eb02			JMP 0x75b981											
  members_string.go:4070	0x75b97f		31d2			XORL DX, DX											
  members_string.go:4070	0x75b981		4885d2			TESTQ DX, DX											
  members_string.go:4070	0x75b984		0f8f89020000		JG 0x75bc13											
  members_string.go:4073	0x75b98a		4d85c9			TESTQ R9, R9											
  members_string.go:4073	0x75b98d		7406			JE 0x75b995											
  members_string.go:4073	0x75b98f		4983f902		CMPQ R9, $0x2											
  members_string.go:4073	0x75b993		7e66			JLE 0x75b9fb											
  errors.go:26			0x75b995		488d05fbb40600		LEAQ 0x6b4fb(IP), AX										
  errors.go:26			0x75b99c		bb32000000		MOVL $0x32, BX											
  errors.go:26			0x75b9a1		31c9			XORL CX, CX											
  errors.go:26			0x75b9a3		31ff			XORL DI, DI											
  errors.go:26			0x75b9a5		89fe			MOVL DI, SI											
  errors.go:26			0x75b9a7		e8b424d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75b9ac		4885c0			TESTQ AX, AX											
  errors.go:26			0x75b9af		7533			JNE 0x75b9e4											
  errors.go:31			0x75b9b1		90			NOPL												
  errors.go:65			0x75b9b2		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75b9b7		488d1d32ed3800		LEAQ 0x38ed32(IP), BX										
  errors.go:65			0x75b9be		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75b9c3		e89859ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75b9c8		48c7400832000000	MOVQ $0x32, 0x8(AX)										
  errors.go:65			0x75b9d0		488d15c0b40600		LEAQ 0x6b4c0(IP), DX										
  errors.go:65			0x75b9d7		488910			MOVQ DX, 0(AX)											
  members_string.go:4074	0x75b9da		4889c3			MOVQ AX, BX											
  members_string.go:4074	0x75b9dd		488d05bcca3b00		LEAQ 0x3bcabc(IP), AX										
  members_string.go:4074	0x75b9e4		31c9			XORL CX, CX											
  members_string.go:4074	0x75b9e6		31ff			XORL DI, DI											
  members_string.go:4074	0x75b9e8		4889c6			MOVQ AX, SI											
  members_string.go:4074	0x75b9eb		4989d8			MOVQ BX, R8											
  members_string.go:4074	0x75b9ee		31c0			XORL AX, AX											
  members_string.go:4074	0x75b9f0		31db			XORL BX, BX											
  members_string.go:4074	0x75b9f2		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4074	0x75b9f9		5d			POPQ BP												
  members_string.go:4074	0x75b9fa		c3			RET												
  members_string.go:4070	0x75b9fb		48898424a8010000	MOVQ AX, 0x1a8(SP)										
  members_string.go:4070	0x75ba03		4c899c24e8010000	MOVQ R11, 0x1e8(SP)										
  members_string.go:4070	0x75ba0b		48899c2418010000	MOVQ BX, 0x118(SP)										
  members_string.go:4070	0x75ba13		4c898424d0010000	MOVQ R8, 0x1d0(SP)										
  members_string.go:4070	0x75ba1b		4c898c24d8010000	MOVQ R9, 0x1d8(SP)										
  members_string.go:4070	0x75ba23		4c899424e0010000	MOVQ R10, 0x1e0(SP)										
  members_string.go:4070	0x75ba2b		4889b42410010000	MOVQ SI, 0x110(SP)										
  members_string.go:4070	0x75ba33		4889bc2440010000	MOVQ DI, 0x140(SP)										
  members_string.go:4070	0x75ba3b		48898c2408010000	MOVQ CX, 0x108(SP)										
  members_string.go:4076	0x75ba43		498b7808		MOVQ 0x8(R8), DI										
  members_string.go:4076	0x75ba47		498b7010		MOVQ 0x10(R8), SI										
  members_string.go:4076	0x75ba4b		498b5018		MOVQ 0x18(R8), DX										
  members_string.go:4076	0x75ba4f		498b08			MOVQ 0(R8), CX											
  members_string.go:4076	0x75ba52		488d05ef6f0500		LEAQ 0x56fef(IP), AX										
  members_string.go:4076	0x75ba59		bb0c000000		MOVL $0xc, BX											
  members_string.go:4076	0x75ba5e		4989d0			MOVQ DX, R8											
  members_string.go:4076	0x75ba61		e81a50fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4077	0x75ba66		4885ff			TESTQ DI, DI											
  members_string.go:4077	0x75ba69		0f858d010000		JNE 0x75bbfc											
  members_string.go:4076	0x75ba6f		888c24af000000		MOVB CL, 0xaf(SP)										
  members_string.go:4076	0x75ba76		48899c24e8000000	MOVQ BX, 0xe8(SP)										
  members_string.go:4076	0x75ba7e		4889842430010000	MOVQ AX, 0x130(SP)										
  members_string.go:4080	0x75ba86		488b842418010000	MOVQ 0x118(SP), AX										
  members_string.go:4080	0x75ba8e		488b9c2408010000	MOVQ 0x108(SP), BX										
  members_string.go:4080	0x75ba96		488b8c2440010000	MOVQ 0x140(SP), CX										
  members_string.go:4080	0x75ba9e		488bbc2410010000	MOVQ 0x110(SP), DI										
  members_string.go:4080	0x75baa6		e81508e5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  members_string.go:4080	0x75baab		4889842428010000	MOVQ AX, 0x128(SP)										
  members_string.go:4080	0x75bab3		48899c24d8000000	MOVQ BX, 0xd8(SP)										
  members_string.go:4081	0x75babb		4889c1			MOVQ AX, CX											
  members_string.go:4081	0x75babe		4889df			MOVQ BX, DI											
  members_string.go:4081	0x75bac1		488bb42430010000	MOVQ 0x130(SP), SI										
  members_string.go:4081	0x75bac9		4c8b8424e8000000	MOVQ 0xe8(SP), R8										
  members_string.go:4081	0x75bad1		440fb68c24af000000	MOVZX 0xaf(SP), R9										
  members_string.go:4081	0x75bada		488d05676f0500		LEAQ 0x56f67(IP), AX										
  members_string.go:4081	0x75bae1		bb0c000000		MOVL $0xc, BX											
  members_string.go:4081	0x75bae6		e8f565f7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)			
  members_string.go:4081	0x75baeb		4885c0			TESTQ AX, AX											
  members_string.go:4081	0x75baee		0f85f1000000		JNE 0x75bbe5											
  members_string.go:4073	0x75baf4		488b9424d8010000	MOVQ 0x1d8(SP), DX										
  members_string.go:4073	0x75bafc		0f1f4000		NOPL 0(AX)											
  members_string.go:4073	0x75bb00		4883fa02		CMPQ DX, $0x2											
  members_string.go:4096	0x75bb04		7418			JE 0x75bb1e											
  members_string.go:2136	0x75bb06		488b8424d8000000	MOVQ 0xd8(SP), AX										
  members_string.go:2136	0x75bb0e		488bbc2428010000	MOVQ 0x128(SP), DI										
  members_string.go:2136	0x75bb16		4531d2			XORL R10, R10											
  members_string.go:4096	0x75bb19		e9a5020000		JMP 0x75bdc3											
  members_string.go:4097	0x75bb1e		488b9424d0010000	MOVQ 0x1d0(SP), DX										
  members_string.go:4097	0x75bb26		488b4220		MOVQ 0x20(DX), AX										
  members_string.go:4097	0x75bb2a		488b5a28		MOVQ 0x28(DX), BX										
  members_string.go:4097	0x75bb2e		488b4a30		MOVQ 0x30(DX), CX										
  members_string.go:4097	0x75bb32		488b7a38		MOVQ 0x38(DX), DI										
  members_string.go:4097	0x75bb36		e86581fdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)				
  members_string.go:4097	0x75bb3b		0f1f440000		NOPL 0(AX)(AX*1)										
  members_string.go:4098	0x75bb40		4885db			TESTQ BX, BX											
  members_string.go:4098	0x75bb43		753a			JNE 0x75bb7f											
  members_string.go:1213	0x75bb45		4885c0			TESTQ AX, AX											
  members_string.go:1213	0x75bb48		7c1d			JL 0x75bb67											
  members_string.go:1100	0x75bb4a		488b8c24d8000000	MOVQ 0xd8(SP), CX										
  members_string.go:1101	0x75bb52		488bbc2428010000	MOVQ 0x128(SP), DI										
  members_string.go:4101	0x75bb5a		4989c2			MOVQ AX, R10											
  members_string.go:4101	0x75bb5d		b801000000		MOVL $0x1, AX											
  members_string.go:4101	0x75bb62		e959010000		JMP 0x75bcc0											
  members_string.go:1178	0x75bb67		90			NOPL												
  members_string.go:1100	0x75bb68		31d2			XORL DX, DX											
  members_string.go:1100	0x75bb6a		488bb424d8000000	MOVQ 0xd8(SP), SI										
  members_string.go:1100	0x75bb72		488bbc2428010000	MOVQ 0x128(SP), DI										
  members_string.go:1100	0x75bb7a		e901010000		JMP 0x75bc80											
  errors.go:26			0x75bb7f		488d05ca280600		LEAQ 0x628ca(IP), AX										
  errors.go:26			0x75bb86		bb23000000		MOVL $0x23, BX											
  errors.go:26			0x75bb8b		31c9			XORL CX, CX											
  errors.go:26			0x75bb8d		31ff			XORL DI, DI											
  errors.go:26			0x75bb8f		89fe			MOVL DI, SI											
  errors.go:26			0x75bb91		e8ca22d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75bb96		4885c0			TESTQ AX, AX											
  errors.go:26			0x75bb99		7533			JNE 0x75bbce											
  errors.go:31			0x75bb9b		90			NOPL												
  errors.go:65			0x75bb9c		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75bba1		488d1d48eb3800		LEAQ 0x38eb48(IP), BX										
  errors.go:65			0x75bba8		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75bbad		e8ae57ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75bbb2		48c7400823000000	MOVQ $0x23, 0x8(AX)										
  errors.go:65			0x75bbba		488d158f280600		LEAQ 0x6288f(IP), DX										
  errors.go:65			0x75bbc1		488910			MOVQ DX, 0(AX)											
  members_string.go:4099	0x75bbc4		4889c3			MOVQ AX, BX											
  members_string.go:4099	0x75bbc7		488d05d2c83b00		LEAQ 0x3bc8d2(IP), AX										
  members_string.go:4099	0x75bbce		31c9			XORL CX, CX											
  members_string.go:4099	0x75bbd0		31ff			XORL DI, DI											
  members_string.go:4099	0x75bbd2		4889c6			MOVQ AX, SI											
  members_string.go:4099	0x75bbd5		4989d8			MOVQ BX, R8											
  members_string.go:4099	0x75bbd8		31c0			XORL AX, AX											
  members_string.go:4099	0x75bbda		31db			XORL BX, BX											
  members_string.go:4099	0x75bbdc		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4099	0x75bbe3		5d			POPQ BP												
  members_string.go:4099	0x75bbe4		c3			RET												
  members_string.go:4082	0x75bbe5		31c9			XORL CX, CX											
  members_string.go:4082	0x75bbe7		31ff			XORL DI, DI											
  members_string.go:4082	0x75bbe9		4889c6			MOVQ AX, SI											
  members_string.go:4082	0x75bbec		4989d8			MOVQ BX, R8											
  members_string.go:4082	0x75bbef		31c0			XORL AX, AX											
  members_string.go:4082	0x75bbf1		31db			XORL BX, BX											
  members_string.go:4082	0x75bbf3		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4082	0x75bbfa		5d			POPQ BP												
  members_string.go:4082	0x75bbfb		c3			RET												
  members_string.go:4078	0x75bbfc		31c0			XORL AX, AX											
  members_string.go:4078	0x75bbfe		31db			XORL BX, BX											
  members_string.go:4078	0x75bc00		31c9			XORL CX, CX											
  members_string.go:4078	0x75bc02		4989f0			MOVQ SI, R8											
  members_string.go:4078	0x75bc05		4889fe			MOVQ DI, SI											
  members_string.go:4078	0x75bc08		31ff			XORL DI, DI											
  members_string.go:4078	0x75bc0a		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4078	0x75bc11		5d			POPQ BP												
  members_string.go:4078	0x75bc12		c3			RET												
  errors.go:26			0x75bc13		488d05039c0600		LEAQ 0x69c03(IP), AX										
  errors.go:26			0x75bc1a		bb2e000000		MOVL $0x2e, BX											
  errors.go:26			0x75bc1f		31c9			XORL CX, CX											
  errors.go:26			0x75bc21		31ff			XORL DI, DI											
  errors.go:26			0x75bc23		89fe			MOVL DI, SI											
  errors.go:26			0x75bc25		e83622d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75bc2a		4885c0			TESTQ AX, AX											
  errors.go:26			0x75bc2d		7533			JNE 0x75bc62											
  errors.go:31			0x75bc2f		90			NOPL												
  errors.go:65			0x75bc30		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75bc35		488d1db4ea3800		LEAQ 0x38eab4(IP), BX										
  errors.go:65			0x75bc3c		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75bc41		e81a57ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75bc46		48c740082e000000	MOVQ $0x2e, 0x8(AX)										
  errors.go:65			0x75bc4e		488d15c89b0600		LEAQ 0x69bc8(IP), DX										
  errors.go:65			0x75bc55		488910			MOVQ DX, 0(AX)											
  members_string.go:4071	0x75bc58		4889c3			MOVQ AX, BX											
  members_string.go:4071	0x75bc5b		488d053ec83b00		LEAQ 0x3bc83e(IP), AX										
  members_string.go:4071	0x75bc62		31c9			XORL CX, CX											
  members_string.go:4071	0x75bc64		31ff			XORL DI, DI											
  members_string.go:4071	0x75bc66		4889c6			MOVQ AX, SI											
  members_string.go:4071	0x75bc69		4989d8			MOVQ BX, R8											
  members_string.go:4071	0x75bc6c		31c0			XORL AX, AX											
  members_string.go:4071	0x75bc6e		31db			XORL BX, BX											
  members_string.go:4071	0x75bc70		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4071	0x75bc77		5d			POPQ BP												
  members_string.go:4071	0x75bc78		c3			RET												
  members_string.go:1100	0x75bc79		48ffc2			INCQ DX												
  members_string.go:1100	0x75bc7c		0f1f4000		NOPL 0(AX)											
  members_string.go:1100	0x75bc80		4839d6			CMPQ SI, DX											
  members_string.go:1100	0x75bc83		7e20			JLE 0x75bca5											
  members_string.go:1101	0x75bc85		440fb61c3a		MOVZX 0(DX)(DI*1), R11										
  members_string.go:1101	0x75bc8a		4180fb80		CMPL R11, $0x80											
  members_string.go:1101	0x75bc8e		72e9			JB 0x75bc79											
  members_string.go:4097	0x75bc90		48898424e0000000	MOVQ AX, 0xe0(SP)										
  members_string.go:1181	0x75bc98		90			NOPL												
  utf8.go:448			0x75bc99		31d2			XORL DX, DX											
  utf8.go:448			0x75bc9b		4531db			XORL R11, R11											
  utf8.go:448			0x75bc9e		6690			NOPW												
  utf8.go:448			0x75bca0		e943050000		JMP 0x75c1e8											
  members_string.go:4080	0x75bca5		4889f1			MOVQ SI, CX											
  members_string.go:1216	0x75bca8		4c8d1406		LEAQ 0(SI)(AX*1), R10										
  members_string.go:1217	0x75bcac		4d85d2			TESTQ R10, R10											
  members_string.go:1217	0x75bcaf		7d07			JGE 0x75bcb8											
  members_string.go:1217	0x75bcb1		31c0			XORL AX, AX											
  members_string.go:1217	0x75bcb3		4531d2			XORL R10, R10											
  members_string.go:4101	0x75bcb6		eb08			JMP 0x75bcc0											
  members_string.go:4101	0x75bcb8		b801000000		MOVL $0x1, AX											
  members_string.go:4101	0x75bcbd		0f1f00			NOPL 0(AX)											
  members_string.go:4101	0x75bcc0		84c0			TESTL AL, AL											
  members_string.go:4102	0x75bcc2		7408			JE 0x75bccc											
  members_string.go:1178	0x75bcc4		90			NOPL												
  members_string.go:1100	0x75bcc5		31d2			XORL DX, DX											
  members_string.go:1100	0x75bcc7		e9c9000000		JMP 0x75bd95											
  members_string.go:4103	0x75bccc		488b842430010000	MOVQ 0x130(SP), AX										
  members_string.go:4103	0x75bcd4		488b9c24e8000000	MOVQ 0xe8(SP), BX										
  members_string.go:4103	0x75bcdc		0f1f4000		NOPL 0(AX)											
  members_string.go:4103	0x75bce0		e85bddfaff		CALL github.com/mgomes/vibescript/internal/runtime.compileCachedRegex(SB)			
  members_string.go:4103	0x75bce5		4885db			TESTQ BX, BX											
  members_string.go:4103	0x75bce8		0f848e000000		JE 0x75bd7c											
  members_string.go:4104	0x75bcee		440f11bc2468010000	MOVUPS X15, 0x168(SP)										
  members_string.go:4104	0x75bcf7		7404			JE 0x75bcfd											
  members_string.go:4104	0x75bcf9		488b5b08		MOVQ 0x8(BX), BX										
  members_string.go:4104	0x75bcfd		48899c2468010000	MOVQ BX, 0x168(SP)										
  members_string.go:4104	0x75bd05		48898c2470010000	MOVQ CX, 0x170(SP)										
  errors.go:26			0x75bd0d		488d05a6f00500		LEAQ 0x5f0a6(IP), AX										
  errors.go:26			0x75bd14		bb1e000000		MOVL $0x1e, BX											
  errors.go:26			0x75bd19		488d8c2468010000	LEAQ 0x168(SP), CX										
  errors.go:26			0x75bd21		bf01000000		MOVL $0x1, DI											
  errors.go:26			0x75bd26		89fe			MOVL DI, SI											
  errors.go:26			0x75bd28		e83321d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75bd2d		4885c0			TESTQ AX, AX											
  errors.go:26			0x75bd30		7533			JNE 0x75bd65											
  errors.go:31			0x75bd32		90			NOPL												
  errors.go:65			0x75bd33		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75bd38		488d1db1e93800		LEAQ 0x38e9b1(IP), BX										
  errors.go:65			0x75bd3f		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75bd44		e81756ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75bd49		48c740081e000000	MOVQ $0x1e, 0x8(AX)										
  errors.go:65			0x75bd51		488d1562f00500		LEAQ 0x5f062(IP), DX										
  errors.go:65			0x75bd58		488910			MOVQ DX, 0(AX)											
  members_string.go:4104	0x75bd5b		4889c3			MOVQ AX, BX											
  members_string.go:4104	0x75bd5e		488d053bc73b00		LEAQ 0x3bc73b(IP), AX										
  members_string.go:4104	0x75bd65		31c9			XORL CX, CX											
  members_string.go:4104	0x75bd67		31ff			XORL DI, DI											
  members_string.go:4104	0x75bd69		4889c6			MOVQ AX, SI											
  members_string.go:4104	0x75bd6c		4989d8			MOVQ BX, R8											
  members_string.go:4104	0x75bd6f		31c0			XORL AX, AX											
  members_string.go:4104	0x75bd71		31db			XORL BX, BX											
  members_string.go:4104	0x75bd73		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4104	0x75bd7a		5d			POPQ BP												
  members_string.go:4104	0x75bd7b		c3			RET												
  members_string.go:4106	0x75bd7c		31c0			XORL AX, AX											
  members_string.go:4106	0x75bd7e		31db			XORL BX, BX											
  members_string.go:4106	0x75bd80		31c9			XORL CX, CX											
  members_string.go:4106	0x75bd82		31ff			XORL DI, DI											
  members_string.go:4106	0x75bd84		89de			MOVL BX, SI											
  members_string.go:4106	0x75bd86		4189c8			MOVL CX, R8											
  members_string.go:4106	0x75bd89		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4106	0x75bd90		5d			POPQ BP												
  members_string.go:4106	0x75bd91		c3			RET												
  members_string.go:1100	0x75bd92		48ffc2			INCQ DX												
  members_string.go:1100	0x75bd95		4839d1			CMPQ CX, DX											
  members_string.go:1100	0x75bd98		7e1f			JLE 0x75bdb9											
  members_string.go:1101	0x75bd9a		440fb61c3a		MOVZX 0(DX)(DI*1), R11										
  members_string.go:1101	0x75bd9f		90			NOPL												
  members_string.go:1101	0x75bda0		4180fb80		CMPL R11, $0x80											
  members_string.go:1101	0x75bda4		72ec			JB 0x75bd92											
  members_string.go:4101	0x75bda6		4c899424d0000000	MOVQ R10, 0xd0(SP)										
  members_string.go:1181	0x75bdae		90			NOPL												
  utf8.go:448			0x75bdaf		31d2			XORL DX, DX											
  utf8.go:448			0x75bdb1		4531db			XORL R11, R11											
  utf8.go:448			0x75bdb4		e9cf030000		JMP 0x75c188											
  members_string.go:4080	0x75bdb9		4889c8			MOVQ CX, AX											
  members_string.go:4108	0x75bdbc		4c39d1			CMPQ CX, R10											
  members_string.go:4111	0x75bdbf		4c0f4cd1		CMOVL CX, R10											
  members_string.go:2136	0x75bdc3		488b1576374000		MOVQ github.com/mgomes/vibescript/internal/runtime.compiledRegexps(SB), DX			
  members_string.go:4113	0x75bdca		90			NOPL												
  members_string.go:2136	0x75bdcb		488d1d766c0500		LEAQ 0x56c76(IP), BX										
  members_string.go:2136	0x75bdd2		b90c000000		MOVL $0xc, CX											
  members_string.go:2136	0x75bdd7		4889c6			MOVQ AX, SI											
  members_string.go:2136	0x75bdda		4c8b842430010000	MOVQ 0x130(SP), R8										
  members_string.go:2136	0x75bde2		4c8b8c24e8000000	MOVQ 0xe8(SP), R9										
  members_string.go:2136	0x75bdea		4889d0			MOVQ DX, AX											
  members_string.go:2136	0x75bded		e8ce69f7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexSubmatchFromRuneOffsetWithCache(SB)	
  members_string.go:4114	0x75bdf2		4885ff			TESTQ DI, DI											
  members_string.go:4114	0x75bdf5		0f85a2010000		JNE 0x75bf9d											
  members_string.go:4114	0x75bdfb		0f1f440000		NOPL 0(AX)(AX*1)										
  members_string.go:4117	0x75be00		4885c0			TESTQ AX, AX											
  members_string.go:4117	0x75be03		0f847e010000		JE 0x75bf87											
  members_string.go:2136	0x75be09		48898c24b8000000	MOVQ CX, 0xb8(SP)										
  members_string.go:2136	0x75be11		48899c24b0000000	MOVQ BX, 0xb0(SP)										
  members_string.go:2136	0x75be19		4889842420010000	MOVQ AX, 0x120(SP)										
  members_string.go:4122	0x75be21		488b842430010000	MOVQ 0x130(SP), AX										
  members_string.go:4122	0x75be29		488b9c24e8000000	MOVQ 0xe8(SP), BX										
  members_string.go:4122	0x75be31		e80a69f7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexSubexpNames(SB)				
  members_string.go:4122	0x75be36		488b942418010000	MOVQ 0x118(SP), DX										
  members_string.go:4122	0x75be3e		48891424		MOVQ DX, 0(SP)											
  members_string.go:4122	0x75be42		488b942408010000	MOVQ 0x108(SP), DX										
  members_string.go:4122	0x75be4a		4889542408		MOVQ DX, 0x8(SP)										
  members_string.go:4122	0x75be4f		488b942440010000	MOVQ 0x140(SP), DX										
  members_string.go:4122	0x75be57		4889542410		MOVQ DX, 0x10(SP)										
  members_string.go:4122	0x75be5c		488b942410010000	MOVQ 0x110(SP), DX										
  members_string.go:4122	0x75be64		4889542418		MOVQ DX, 0x18(SP)										
  members_string.go:4122	0x75be69		488b9424d0010000	MOVQ 0x1d0(SP), DX										
  members_string.go:4122	0x75be71		4889542420		MOVQ DX, 0x20(SP)										
  members_string.go:4122	0x75be76		488b9424d8010000	MOVQ 0x1d8(SP), DX										
  members_string.go:4122	0x75be7e		4889542428		MOVQ DX, 0x28(SP)										
  members_string.go:4122	0x75be83		488b9424e0010000	MOVQ 0x1e0(SP), DX										
  members_string.go:4122	0x75be8b		4889542430		MOVQ DX, 0x30(SP)										
  members_string.go:4122	0x75be90		488b9424e8010000	MOVQ 0x1e8(SP), DX										
  members_string.go:4122	0x75be98		4889542438		MOVQ DX, 0x38(SP)										
  members_string.go:4122	0x75be9d		488b942488010000	MOVQ 0x188(SP), DX										
  members_string.go:4122	0x75bea5		4889542440		MOVQ DX, 0x40(SP)										
  members_string.go:4122	0x75beaa		488b942490010000	MOVQ 0x190(SP), DX										
  members_string.go:4122	0x75beb2		4889542448		MOVQ DX, 0x48(SP)										
  members_string.go:4122	0x75beb7		488b942498010000	MOVQ 0x198(SP), DX										
  members_string.go:4122	0x75bebf		4889542450		MOVQ DX, 0x50(SP)										
  members_string.go:4122	0x75bec4		488b9424a0010000	MOVQ 0x1a0(SP), DX										
  members_string.go:4122	0x75becc		4889542458		MOVQ DX, 0x58(SP)										
  members_string.go:4122	0x75bed1		488bbc2420010000	MOVQ 0x120(SP), DI										
  members_string.go:4122	0x75bed9		488bb424b0000000	MOVQ 0xb0(SP), SI										
  members_string.go:4122	0x75bee1		4c8b8424b8000000	MOVQ 0xb8(SP), R8										
  members_string.go:4122	0x75bee9		4989c1			MOVQ AX, R9											
  members_string.go:4122	0x75beec		4989da			MOVQ BX, R10											
  members_string.go:4122	0x75beef		4989cb			MOVQ CX, R11											
  members_string.go:4122	0x75bef2		488b8424a8010000	MOVQ 0x1a8(SP), AX										
  members_string.go:4122	0x75befa		488b9c2428010000	MOVQ 0x128(SP), BX										
  members_string.go:4122	0x75bf02		488b8c24d8000000	MOVQ 0xd8(SP), CX										
  members_string.go:4122	0x75bf0a		e83198f3ff		CALL github.com/mgomes/vibescript/internal/runtime.newMatchData(SB)				
  members_string.go:4123	0x75bf0f		4885f6			TESTQ SI, SI											
  members_string.go:4123	0x75bf12		7562			JNE 0x75bf76											
  members_string.go:4122	0x75bf14		4889842400010000	MOVQ AX, 0x100(SP)										
  members_string.go:4122	0x75bf1c		4889bc24f8000000	MOVQ DI, 0xf8(SP)										
  members_string.go:4122	0x75bf24		48898c2438010000	MOVQ CX, 0x138(SP)										
  members_string.go:4122	0x75bf2c		48899c24f0000000	MOVQ BX, 0xf0(SP)										
  aliases.go:1400		0x75bf34		90			NOPL												
  value_accessors.go:180	0x75bf35		488b942488010000	MOVQ 0x188(SP), DX										
  value_accessors.go:180	0x75bf3d		0f1f00			NOPL 0(AX)											
  value_accessors.go:180	0x75bf40		4883fa0f		CMPQ DX, $0xf											
  value_accessors.go:180	0x75bf44		7529			JNE 0x75bf6f											
  value_accessors.go:183	0x75bf46		4c8b9c2490010000	MOVQ 0x190(SP), R11										
  value_accessors.go:183	0x75bf4e		4d85db			TESTQ R11, R11											
  value_accessors.go:183	0x75bf51		7414			JE 0x75bf67											
  value_accessors.go:183	0x75bf53		4c8b2586263f00		MOVQ github.com/mgomes/vibescript/internal/runtime..typeAssert.357(SB), R12			
  value_accessors.go:183	0x75bf5a		4d8b2c24		MOVQ 0(R12), R13										
  value_accessors.go:183	0x75bf5e		458b7b10		MOVL 0x10(R11), R15										
  value_accessors.go:183	0x75bf62		e9a5010000		JMP 0x75c10c											
  members_string.go:4069	0x75bf67		4c89de			MOVQ R11, SI											
  value_accessors.go:183	0x75bf6a		e98d010000		JMP 0x75c0fc											
  value_accessors.go:183	0x75bf6f		31f6			XORL SI, SI											
  value_accessors.go:183	0x75bf71		4531c0			XORL R8, R8											
  aliases.go:1367		0x75bf74		eb3e			JMP 0x75bfb4											
  members_string.go:4124	0x75bf76		31c0			XORL AX, AX											
  members_string.go:4124	0x75bf78		31db			XORL BX, BX											
  members_string.go:4124	0x75bf7a		31c9			XORL CX, CX											
  members_string.go:4124	0x75bf7c		31ff			XORL DI, DI											
  members_string.go:4124	0x75bf7e		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4124	0x75bf85		5d			POPQ BP												
  members_string.go:4124	0x75bf86		c3			RET												
  members_string.go:4120	0x75bf87		31c0			XORL AX, AX											
  members_string.go:4120	0x75bf89		31db			XORL BX, BX											
  members_string.go:4120	0x75bf8b		31c9			XORL CX, CX											
  members_string.go:4120	0x75bf8d		31ff			XORL DI, DI											
  members_string.go:4120	0x75bf8f		89de			MOVL BX, SI											
  members_string.go:4120	0x75bf91		4189c8			MOVL CX, R8											
  members_string.go:4120	0x75bf94		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4120	0x75bf9b		5d			POPQ BP												
  members_string.go:4120	0x75bf9c		c3			RET												
  members_string.go:4115	0x75bf9d		31c0			XORL AX, AX											
  members_string.go:4115	0x75bf9f		31db			XORL BX, BX											
  members_string.go:4115	0x75bfa1		31c9			XORL CX, CX											
  members_string.go:4115	0x75bfa3		4989f0			MOVQ SI, R8											
  members_string.go:4115	0x75bfa6		4889fe			MOVQ DI, SI											
  members_string.go:4115	0x75bfa9		31ff			XORL DI, DI											
  members_string.go:4115	0x75bfab		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4115	0x75bfb2		5d			POPQ BP												
  members_string.go:4115	0x75bfb3		c3			RET												
  aliases.go:1367		0x75bfb4		4c8d1d45cd3b00		LEAQ 0x3bcd45(IP), R11										
  aliases.go:1367		0x75bfbb		0f1f440000		NOPL 0(AX)(AX*1)										
  aliases.go:1367		0x75bfc0		4c39de			CMPQ SI, R11											
  aliases.go:1367		0x75bfc3		7403			JE 0x75bfc8											
  aliases.go:1367		0x75bfc5		4531c0			XORL R8, R8											
  members_string.go:4126	0x75bfc8		4d85c0			TESTQ R8, R8											
  members_string.go:4126	0x75bfcb		0f841d010000		JE 0x75c0ee											
  members_string.go:4130	0x75bfd1		4c8b9c2418010000	MOVQ 0x118(SP), R11										
  members_string.go:4130	0x75bfd9		4c891c24		MOVQ R11, 0(SP)											
  members_string.go:4130	0x75bfdd		4c8b9c2408010000	MOVQ 0x108(SP), R11										
  members_string.go:4130	0x75bfe5		4c895c2408		MOVQ R11, 0x8(SP)										
  members_string.go:4130	0x75bfea		4c8b9c2440010000	MOVQ 0x140(SP), R11										
  members_string.go:4130	0x75bff2		4c895c2410		MOVQ R11, 0x10(SP)										
  members_string.go:4130	0x75bff7		4c8b9c2410010000	MOVQ 0x110(SP), R11										
  members_string.go:4130	0x75bfff		4c895c2418		MOVQ R11, 0x18(SP)										
  members_string.go:4130	0x75c004		4c8b9c24d0010000	MOVQ 0x1d0(SP), R11										
  members_string.go:4130	0x75c00c		4c895c2420		MOVQ R11, 0x20(SP)										
  members_string.go:4130	0x75c011		4c8b9c24d8010000	MOVQ 0x1d8(SP), R11										
  members_string.go:4130	0x75c019		4c895c2428		MOVQ R11, 0x28(SP)										
  members_string.go:4130	0x75c01e		4c8b9c24e0010000	MOVQ 0x1e0(SP), R11										
  members_string.go:4130	0x75c026		4c895c2430		MOVQ R11, 0x30(SP)										
  members_string.go:4130	0x75c02b		488b8424a8010000	MOVQ 0x1a8(SP), AX										
  members_string.go:4130	0x75c033		4889d3			MOVQ DX, BX											
  members_string.go:4130	0x75c036		488b8c2490010000	MOVQ 0x190(SP), CX										
  members_string.go:4130	0x75c03e		488bbc2498010000	MOVQ 0x198(SP), DI										
  members_string.go:4130	0x75c046		488bb424a0010000	MOVQ 0x1a0(SP), SI										
  members_string.go:4130	0x75c04e		4c8d05f3690500		LEAQ 0x569f3(IP), R8										
  members_string.go:4130	0x75c055		41b90c000000		MOVL $0xc, R9											
  members_string.go:4130	0x75c05b		4c8b9424e8010000	MOVQ 0x1e8(SP), R10										
  members_string.go:4130	0x75c063		e8d85df1ff		CALL github.com/mgomes/vibescript/internal/runtime.newBlockCallRunner(SB)			
  members_string.go:4131	0x75c068		4885db			TESTQ BX, BX											
  members_string.go:4131	0x75c06b		7417			JE 0x75c084											
  members_string.go:4132	0x75c06d		31c0			XORL AX, AX											
  members_string.go:4132	0x75c06f		31ff			XORL DI, DI											
  members_string.go:4132	0x75c071		4889de			MOVQ BX, SI											
  members_string.go:4132	0x75c074		4989c8			MOVQ CX, R8											
  members_string.go:4132	0x75c077		31db			XORL BX, BX											
  members_string.go:4132	0x75c079		31c9			XORL CX, CX											
  members_string.go:4132	0x75c07b		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4132	0x75c082		5d			POPQ BP												
  members_string.go:4132	0x75c083		c3			RET												
  members_string.go:4134	0x75c084		488b942400010000	MOVQ 0x100(SP), DX										
  members_string.go:4134	0x75c08c		4889942448010000	MOVQ DX, 0x148(SP)										
  members_string.go:4134	0x75c094		488b9424f0000000	MOVQ 0xf0(SP), DX										
  members_string.go:4134	0x75c09c		4889942450010000	MOVQ DX, 0x150(SP)										
  members_string.go:4134	0x75c0a4		488b9424f8000000	MOVQ 0xf8(SP), DX										
  members_string.go:4134	0x75c0ac		4889942460010000	MOVQ DX, 0x160(SP)										
  members_string.go:4134	0x75c0b4		488b942438010000	MOVQ 0x138(SP), DX										
  members_string.go:4134	0x75c0bc		4889942458010000	MOVQ DX, 0x158(SP)										
  eval.go:1785			0x75c0c4		488d9c2448010000	LEAQ 0x148(SP), BX										
  eval.go:1785			0x75c0cc		b901000000		MOVL $0x1, CX											
  eval.go:1785			0x75c0d1		89cf			MOVL CX, DI											
  eval.go:1785			0x75c0d3		31f6			XORL SI, SI											
  eval.go:1785			0x75c0d5		4531c0			XORL R8, R8											
  eval.go:1785			0x75c0d8		4589c1			MOVL R8, R9											
  eval.go:1785			0x75c0db		0f1f440000		NOPL 0(AX)(AX*1)										
  eval.go:1785			0x75c0e0		e89b62f1ff		CALL github.com/mgomes/vibescript/internal/runtime.(*blockCallRunner).callWithChargedRoots(SB)	
  members_string.go:4134	0x75c0e5		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4134	0x75c0ec		5d			POPQ BP												
  members_string.go:4134	0x75c0ed		c3			RET												
  members_string.go:4136	0x75c0ee		31f6			XORL SI, SI											
  members_string.go:4136	0x75c0f0		4531c0			XORL R8, R8											
  members_string.go:4136	0x75c0f3		4881c478010000		ADDQ $0x178, SP											
  members_string.go:4136	0x75c0fa		5d			POPQ BP												
  members_string.go:4136	0x75c0fb		c3			RET												
  aliases.go:1367		0x75c0fc		4c89de			MOVQ R11, SI											
  aliases.go:1367		0x75c0ff		4c8b842498010000	MOVQ 0x198(SP), R8										
  aliases.go:1367		0x75c107		e9a8feffff		JMP 0x75bfb4											
  value_accessors.go:183	0x75c10c		4c89fe			MOVQ R15, SI											
  value_accessors.go:183	0x75c10f		4d21ef			ANDQ R13, R15											
  value_accessors.go:183	0x75c112		49c1e704		SHLQ $0x4, R15											
  value_accessors.go:183	0x75c116		4f8b442708		MOVQ 0x8(R15)(R12*1), R8									
  value_accessors.go:183	0x75c11b		0f1f440000		NOPL 0(AX)(AX*1)										
  value_accessors.go:183	0x75c120		4d39c3			CMPQ R11, R8											
  value_accessors.go:183	0x75c123		744d			JE 0x75c172											
  value_accessors.go:183	0x75c125		4c8d7e01		LEAQ 0x1(SI), R15										
  value_accessors.go:183	0x75c129		4d85c0			TESTQ R8, R8											
  value_accessors.go:183	0x75c12c		75de			JNE 0x75c10c											
  value_accessors.go:183	0x75c12e		488d05ab243f00		LEAQ github.com/mgomes/vibescript/internal/runtime..typeAssert.357(SB), AX			
  value_accessors.go:183	0x75c135		4c89db			MOVQ R11, BX											
  value_accessors.go:183	0x75c138		e88310ccff		CALL runtime.typeAssert(SB)									
  members_string.go:4136	0x75c13d		488b8c2438010000	MOVQ 0x138(SP), CX										
  members_string.go:4130	0x75c145		488b942488010000	MOVQ 0x188(SP), DX										
  members_string.go:4136	0x75c14d		488b9c24f0000000	MOVQ 0xf0(SP), BX										
  members_string.go:4130	0x75c155		488bb42490010000	MOVQ 0x190(SP), SI										
  members_string.go:4136	0x75c15d		488bbc24f8000000	MOVQ 0xf8(SP), DI										
  value_accessors.go:183	0x75c165		4989c3			MOVQ AX, R11											
  members_string.go:4136	0x75c168		488b842400010000	MOVQ 0x100(SP), AX										
  value_accessors.go:183	0x75c170		eb8a			JMP 0x75c0fc											
  value_accessors.go:183	0x75c172		4f8b642710		MOVQ 0x10(R15)(R12*1), R12									
  members_string.go:4130	0x75c177		4c89de			MOVQ R11, SI											
  value_accessors.go:183	0x75c17a		4d89e3			MOVQ R12, R11											
  value_accessors.go:183	0x75c17d		0f1f00			NOPL 0(AX)											
  value_accessors.go:183	0x75c180		e977ffffff		JMP 0x75c0fc											
  utf8.go:449			0x75c185		48ffc2			INCQ DX												
  utf8.go:448			0x75c188		4c39d9			CMPQ CX, R11											
  utf8.go:448			0x75c18b		7e4b			JLE 0x75c1d8											
  utf8.go:448			0x75c18d		450fb6243b		MOVZX 0(R11)(DI*1), R12										
  utf8.go:448			0x75c192		4183fc7f		CMPL R12, $0x7f											
  utf8.go:448			0x75c196		7f05			JG 0x75c19d											
  utf8.go:448			0x75c198		49ffc3			INCQ R11											
  utf8.go:448			0x75c19b		ebe8			JMP 0x75c185											
  utf8.go:448			0x75c19d		48899424c8000000	MOVQ DX, 0xc8(SP)										
  utf8.go:448			0x75c1a5		4889f8			MOVQ DI, AX											
  utf8.go:448			0x75c1a8		4889cb			MOVQ CX, BX											
  utf8.go:448			0x75c1ab		4c89d9			MOVQ R11, CX											
  utf8.go:448			0x75c1ae		e80d10d2ff		CALL runtime.decoderune(SB)									
  utf8.go:448			0x75c1b3		488b8c24d8000000	MOVQ 0xd8(SP), CX										
  utf8.go:449			0x75c1bb		488b9424c8000000	MOVQ 0xc8(SP), DX										
  utf8.go:448			0x75c1c3		488bbc2428010000	MOVQ 0x128(SP), DI										
  members_string.go:4108	0x75c1cb		4c8b9424d0000000	MOVQ 0xd0(SP), R10										
  utf8.go:449			0x75c1d3		4989db			MOVQ BX, R11											
  utf8.go:448			0x75c1d6		ebad			JMP 0x75c185											
  members_string.go:2136	0x75c1d8		4889c8			MOVQ CX, AX											
  members_string.go:4108	0x75c1db		4889d1			MOVQ DX, CX											
  members_string.go:4108	0x75c1de		6690			NOPW												
  members_string.go:4108	0x75c1e0		e9d7fbffff		JMP 0x75bdbc											
  utf8.go:449			0x75c1e5		48ffc2			INCQ DX												
  utf8.go:448			0x75c1e8		4c39de			CMPQ SI, R11											
  utf8.go:448			0x75c1eb		7e4b			JLE 0x75c238											
  utf8.go:448			0x75c1ed		450fb6243b		MOVZX 0(R11)(DI*1), R12										
  utf8.go:448			0x75c1f2		4183fc7f		CMPL R12, $0x7f											
  utf8.go:448			0x75c1f6		7f05			JG 0x75c1fd											
  utf8.go:448			0x75c1f8		49ffc3			INCQ R11											
  utf8.go:448			0x75c1fb		ebe8			JMP 0x75c1e5											
  utf8.go:448			0x75c1fd		48899424c0000000	MOVQ DX, 0xc0(SP)										
  utf8.go:448			0x75c205		4889f8			MOVQ DI, AX											
  utf8.go:448			0x75c208		4889f3			MOVQ SI, BX											
  utf8.go:448			0x75c20b		4c89d9			MOVQ R11, CX											
  utf8.go:448			0x75c20e		e8ad0fd2ff		CALL runtime.decoderune(SB)									
  members_string.go:1216	0x75c213		488b8424e0000000	MOVQ 0xe0(SP), AX										
  utf8.go:449			0x75c21b		488b9424c0000000	MOVQ 0xc0(SP), DX										
  utf8.go:448			0x75c223		488bb424d8000000	MOVQ 0xd8(SP), SI										
  utf8.go:448			0x75c22b		488bbc2428010000	MOVQ 0x128(SP), DI										
  utf8.go:449			0x75c233		4989db			MOVQ BX, R11											
  utf8.go:448			0x75c236		ebad			JMP 0x75c1e5											
  members_string.go:1100	0x75c238		4889f1			MOVQ SI, CX											
  members_string.go:1216	0x75c23b		4889d6			MOVQ DX, SI											
  members_string.go:1216	0x75c23e		6690			NOPW												
  members_string.go:1216	0x75c240		e963faffff		JMP 0x75bca8											
  members_string.go:4069	0x75c245		4889442428		MOVQ AX, 0x28(SP)										
  members_string.go:4069	0x75c24a		48895c2430		MOVQ BX, 0x30(SP)										
  members_string.go:4069	0x75c24f		48894c2438		MOVQ CX, 0x38(SP)										
  members_string.go:4069	0x75c254		48897c2440		MOVQ DI, 0x40(SP)										
  members_string.go:4069	0x75c259		4889742448		MOVQ SI, 0x48(SP)										
  members_string.go:4069	0x75c25e		4c89442450		MOVQ R8, 0x50(SP)										
  members_string.go:4069	0x75c263		4c894c2458		MOVQ R9, 0x58(SP)										
  members_string.go:4069	0x75c268		4c89542460		MOVQ R10, 0x60(SP)										
  members_string.go:4069	0x75c26d		4c895c2468		MOVQ R11, 0x68(SP)										
  members_string.go:4069	0x75c272		e88903d3ff		CALL runtime.morestack_noctxt.abi0(SB)								
  members_string.go:4069	0x75c277		488b442428		MOVQ 0x28(SP), AX										
  members_string.go:4069	0x75c27c		488b5c2430		MOVQ 0x30(SP), BX										
  members_string.go:4069	0x75c281		488b4c2438		MOVQ 0x38(SP), CX										
  members_string.go:4069	0x75c286		488b7c2440		MOVQ 0x40(SP), DI										
  members_string.go:4069	0x75c28b		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:4069	0x75c290		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4069	0x75c295		4c8b4c2458		MOVQ 0x58(SP), R9										
  members_string.go:4069	0x75c29a		4c8b542460		MOVQ 0x60(SP), R10										
  members_string.go:4069	0x75c29f		4c8b5c2468		MOVQ 0x68(SP), R11										
  members_string.go:4069	0x75c2a4		e997f6ffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func23(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func24(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4139	0x75c2c0		4c8d6424e8		LEAQ -0x18(SP), R12										
  members_string.go:4139	0x75c2c5		4d3b6610		CMPQ R12, 0x10(R14)										
  members_string.go:4139	0x75c2c9		0f8660030000		JBE 0x75c62f											
  members_string.go:4139	0x75c2cf		55			PUSHQ BP											
  members_string.go:4139	0x75c2d0		4889e5			MOVQ SP, BP											
  members_string.go:4139	0x75c2d3		4881ec90000000		SUBQ $0x90, SP											
  members_string.go:4139	0x75c2da		48898c24d0000000	MOVQ CX, 0xd0(SP)										
  members_string.go:4139	0x75c2e2		4889bc24d8000000	MOVQ DI, 0xd8(SP)										
  members_string.go:4139	0x75c2ea		4c898424e8000000	MOVQ R8, 0xe8(SP)										
  members_string.go:4140	0x75c2f2		4d85db			TESTQ R11, R11											
  members_string.go:4140	0x75c2f5		7405			JE 0x75c2fc											
  members_string.go:4140	0x75c2f7		498b13			MOVQ 0(R11), DX											
  members_string.go:4140	0x75c2fa		eb04			JMP 0x75c300											
  members_string.go:4140	0x75c2fc		31d2			XORL DX, DX											
  members_string.go:4140	0x75c2fe		6690			NOPW												
  members_string.go:4140	0x75c300		4885d2			TESTQ DX, DX											
  members_string.go:4140	0x75c303		0f8fbb020000		JG 0x75c5c4											
  members_string.go:4143	0x75c309		4d85c9			TESTQ R9, R9											
  members_string.go:4143	0x75c30c		7406			JE 0x75c314											
  members_string.go:4143	0x75c30e		4983f902		CMPQ R9, $0x2											
  members_string.go:4143	0x75c312		7e66			JLE 0x75c37a											
  errors.go:26			0x75c314		488d05a9ae0600		LEAQ 0x6aea9(IP), AX										
  errors.go:26			0x75c31b		bb33000000		MOVL $0x33, BX											
  errors.go:26			0x75c320		31c9			XORL CX, CX											
  errors.go:26			0x75c322		31ff			XORL DI, DI											
  errors.go:26			0x75c324		89fe			MOVL DI, SI											
  errors.go:26			0x75c326		e8351bd8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75c32b		4885c0			TESTQ AX, AX											
  errors.go:26			0x75c32e		7533			JNE 0x75c363											
  errors.go:31			0x75c330		90			NOPL												
  errors.go:65			0x75c331		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75c336		488d1db3e33800		LEAQ 0x38e3b3(IP), BX										
  errors.go:65			0x75c33d		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75c342		e81950ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75c347		48c7400833000000	MOVQ $0x33, 0x8(AX)										
  errors.go:65			0x75c34f		488d156eae0600		LEAQ 0x6ae6e(IP), DX										
  errors.go:65			0x75c356		488910			MOVQ DX, 0(AX)											
  members_string.go:4144	0x75c359		4889c3			MOVQ AX, BX											
  members_string.go:4144	0x75c35c		488d053dc13b00		LEAQ 0x3bc13d(IP), AX										
  members_string.go:4144	0x75c363		31c9			XORL CX, CX											
  members_string.go:4144	0x75c365		31ff			XORL DI, DI											
  members_string.go:4144	0x75c367		4889c6			MOVQ AX, SI											
  members_string.go:4144	0x75c36a		4989d8			MOVQ BX, R8											
  members_string.go:4144	0x75c36d		31c0			XORL AX, AX											
  members_string.go:4144	0x75c36f		31db			XORL BX, BX											
  members_string.go:4144	0x75c371		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4144	0x75c378		5d			POPQ BP												
  members_string.go:4144	0x75c379		c3			RET												
  members_string.go:4140	0x75c37a		4889742470		MOVQ SI, 0x70(SP)										
  members_string.go:4140	0x75c37f		4889bc2488000000	MOVQ DI, 0x88(SP)										
  members_string.go:4140	0x75c387		4c898c24f0000000	MOVQ R9, 0xf0(SP)										
  members_string.go:4140	0x75c38f		4c898424e8000000	MOVQ R8, 0xe8(SP)										
  members_string.go:4140	0x75c397		48895c2468		MOVQ BX, 0x68(SP)										
  members_string.go:4140	0x75c39c		48894c2460		MOVQ CX, 0x60(SP)										
  members_string.go:4146	0x75c3a1		498b7808		MOVQ 0x8(R8), DI										
  members_string.go:4146	0x75c3a5		498b7010		MOVQ 0x10(R8), SI										
  members_string.go:4146	0x75c3a9		498b5018		MOVQ 0x18(R8), DX										
  members_string.go:4146	0x75c3ad		498b08			MOVQ 0(R8), CX											
  members_string.go:4146	0x75c3b0		488d05756d0500		LEAQ 0x56d75(IP), AX										
  members_string.go:4146	0x75c3b7		bb0d000000		MOVL $0xd, BX											
  members_string.go:4146	0x75c3bc		4989d0			MOVQ DX, R8											
  members_string.go:4146	0x75c3bf		90			NOPL												
  members_string.go:4146	0x75c3c0		e8bb46fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4146	0x75c3c5		4885ff			TESTQ DI, DI											
  members_string.go:4146	0x75c3c8		0f85df010000		JNE 0x75c5ad											
  members_string.go:4143	0x75c3ce		488b9424f0000000	MOVQ 0xf0(SP), DX										
  members_string.go:4143	0x75c3d6		4883fa02		CMPQ DX, $0x2											
  members_string.go:4150	0x75c3da		7409			JE 0x75c3e5											
  members_string.go:4150	0x75c3dc		31c0			XORL AX, AX											
  members_string.go:4150	0x75c3de		6690			NOPW												
  members_string.go:4150	0x75c3e0		e993000000		JMP 0x75c478											
  members_string.go:4151	0x75c3e5		488b9424e8000000	MOVQ 0xe8(SP), DX										
  members_string.go:4151	0x75c3ed		488b4220		MOVQ 0x20(DX), AX										
  members_string.go:4151	0x75c3f1		488b5a28		MOVQ 0x28(DX), BX										
  members_string.go:4151	0x75c3f5		488b4a30		MOVQ 0x30(DX), CX										
  members_string.go:4151	0x75c3f9		488b7a38		MOVQ 0x38(DX), DI										
  members_string.go:4151	0x75c3fd		0f1f00			NOPL 0(AX)											
  members_string.go:4151	0x75c400		e89b78fdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)				
  members_string.go:4152	0x75c405		4885db			TESTQ BX, BX											
  members_string.go:4152	0x75c408		7505			JNE 0x75c40f											
  members_string.go:4152	0x75c40a		4885c0			TESTQ AX, AX											
  members_string.go:4152	0x75c40d		7d69			JGE 0x75c478											
  errors.go:26			0x75c40f		488d059da60600		LEAQ 0x6a69d(IP), AX										
  errors.go:26			0x75c416		bb31000000		MOVL $0x31, BX											
  errors.go:26			0x75c41b		31c9			XORL CX, CX											
  errors.go:26			0x75c41d		31ff			XORL DI, DI											
  errors.go:26			0x75c41f		89fe			MOVL DI, SI											
  errors.go:26			0x75c421		e83a1ad8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75c426		4885c0			TESTQ AX, AX											
  errors.go:26			0x75c429		7536			JNE 0x75c461											
  errors.go:31			0x75c42b		90			NOPL												
  errors.go:65			0x75c42c		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75c431		488d1db8e23800		LEAQ 0x38e2b8(IP), BX										
  errors.go:65			0x75c438		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75c43d		0f1f00			NOPL 0(AX)											
  errors.go:65			0x75c440		e81b4fccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75c445		48c7400831000000	MOVQ $0x31, 0x8(AX)										
  errors.go:65			0x75c44d		488d155fa60600		LEAQ 0x6a65f(IP), DX										
  errors.go:65			0x75c454		488910			MOVQ DX, 0(AX)											
  members_string.go:4153	0x75c457		4889c3			MOVQ AX, BX											
  members_string.go:4153	0x75c45a		488d053fc03b00		LEAQ 0x3bc03f(IP), AX										
  members_string.go:4153	0x75c461		31c9			XORL CX, CX											
  members_string.go:4153	0x75c463		31ff			XORL DI, DI											
  members_string.go:4153	0x75c465		4889c6			MOVQ AX, SI											
  members_string.go:4153	0x75c468		4989d8			MOVQ BX, R8											
  members_string.go:4153	0x75c46b		31c0			XORL AX, AX											
  members_string.go:4153	0x75c46d		31db			XORL BX, BX											
  members_string.go:4153	0x75c46f		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4153	0x75c476		5d			POPQ BP												
  members_string.go:4153	0x75c477		c3			RET												
  members_string.go:4157	0x75c478		4889442458		MOVQ AX, 0x58(SP)										
  members_string.go:4157	0x75c47d		488b9424e8000000	MOVQ 0xe8(SP), DX										
  members_string.go:4157	0x75c485		488b0a			MOVQ 0(DX), CX											
  members_string.go:4157	0x75c488		488b7a08		MOVQ 0x8(DX), DI										
  members_string.go:4157	0x75c48c		488b7210		MOVQ 0x10(DX), SI										
  members_string.go:4157	0x75c490		4c8b4218		MOVQ 0x18(DX), R8										
  members_string.go:4157	0x75c494		488d05916c0500		LEAQ 0x56c91(IP), AX										
  members_string.go:4157	0x75c49b		bb0d000000		MOVL $0xd, BX											
  members_string.go:4157	0x75c4a0		e8db45fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4158	0x75c4a5		4885ff			TESTQ DI, DI											
  members_string.go:4158	0x75c4a8		0f85e8000000		JNE 0x75c596											
  members_string.go:4157	0x75c4ae		884c2447		MOVB CL, 0x47(SP)										
  members_string.go:4157	0x75c4b2		4889842480000000	MOVQ AX, 0x80(SP)										
  members_string.go:4157	0x75c4ba		48895c2450		MOVQ BX, 0x50(SP)										
  members_string.go:4161	0x75c4bf		488b442468		MOVQ 0x68(SP), AX										
  members_string.go:4161	0x75c4c4		488b5c2460		MOVQ 0x60(SP), BX										
  members_string.go:4161	0x75c4c9		488b8c2488000000	MOVQ 0x88(SP), CX										
  members_string.go:4161	0x75c4d1		488b7c2470		MOVQ 0x70(SP), DI										
  members_string.go:4161	0x75c4d6		e8e5fde4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  members_string.go:4161	0x75c4db		4889442478		MOVQ AX, 0x78(SP)										
  members_string.go:4161	0x75c4e0		48895c2448		MOVQ BX, 0x48(SP)										
  members_string.go:4162	0x75c4e5		4889c1			MOVQ AX, CX											
  members_string.go:4162	0x75c4e8		4889df			MOVQ BX, DI											
  members_string.go:4162	0x75c4eb		488bb42480000000	MOVQ 0x80(SP), SI										
  members_string.go:4162	0x75c4f3		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4162	0x75c4f8		440fb64c2447		MOVZX 0x47(SP), R9										
  members_string.go:4162	0x75c4fe		488d05276c0500		LEAQ 0x56c27(IP), AX										
  members_string.go:4162	0x75c505		bb0d000000		MOVL $0xd, BX											
  members_string.go:4162	0x75c50a		e8d15bf7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)			
  members_string.go:4162	0x75c50f		4885c0			TESTQ AX, AX											
  members_string.go:4162	0x75c512		756b			JNE 0x75c57f											
  members_string.go:2070	0x75c514		488b0525304000		MOVQ github.com/mgomes/vibescript/internal/runtime.compiledRegexps(SB), AX			
  members_string.go:4165	0x75c51b		90			NOPL												
  members_string.go:2070	0x75c51c		488d1d096c0500		LEAQ 0x56c09(IP), BX										
  members_string.go:2070	0x75c523		b90d000000		MOVL $0xd, CX											
  members_string.go:2070	0x75c528		488b7c2478		MOVQ 0x78(SP), DI										
  members_string.go:2070	0x75c52d		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:2070	0x75c532		4c8b842480000000	MOVQ 0x80(SP), R8										
  members_string.go:2070	0x75c53a		4c8b4c2450		MOVQ 0x50(SP), R9										
  members_string.go:2070	0x75c53f		4c8b542458		MOVQ 0x58(SP), R10										
  members_string.go:2070	0x75c544		e8f75cf7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexMatchFromRuneOffsetWithCache(SB)	
  members_string.go:4166	0x75c549		4885db			TESTQ BX, BX											
  members_string.go:4166	0x75c54c		7417			JE 0x75c565											
  members_string.go:4167	0x75c54e		31c0			XORL AX, AX											
  members_string.go:4167	0x75c550		31ff			XORL DI, DI											
  members_string.go:4167	0x75c552		4889de			MOVQ BX, SI											
  members_string.go:4167	0x75c555		4989c8			MOVQ CX, R8											
  members_string.go:4167	0x75c558		31db			XORL BX, BX											
  members_string.go:4167	0x75c55a		31c9			XORL CX, CX											
  members_string.go:4167	0x75c55c		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4167	0x75c563		5d			POPQ BP												
  members_string.go:4167	0x75c564		c3			RET												
  members_string.go:4169	0x75c565		0fb6f8			MOVZX AL, DI											
  members_string.go:4169	0x75c568		b801000000		MOVL $0x1, AX											
  members_string.go:4169	0x75c56d		31db			XORL BX, BX											
  members_string.go:4169	0x75c56f		31c9			XORL CX, CX											
  members_string.go:4169	0x75c571		89de			MOVL BX, SI											
  members_string.go:4169	0x75c573		4189c8			MOVL CX, R8											
  members_string.go:4169	0x75c576		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4169	0x75c57d		5d			POPQ BP												
  members_string.go:4169	0x75c57e		c3			RET												
  members_string.go:4163	0x75c57f		31c9			XORL CX, CX											
  members_string.go:4163	0x75c581		31ff			XORL DI, DI											
  members_string.go:4163	0x75c583		4889c6			MOVQ AX, SI											
  members_string.go:4163	0x75c586		4989d8			MOVQ BX, R8											
  members_string.go:4163	0x75c589		31c0			XORL AX, AX											
  members_string.go:4163	0x75c58b		31db			XORL BX, BX											
  members_string.go:4163	0x75c58d		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4163	0x75c594		5d			POPQ BP												
  members_string.go:4163	0x75c595		c3			RET												
  members_string.go:4159	0x75c596		31c0			XORL AX, AX											
  members_string.go:4159	0x75c598		31db			XORL BX, BX											
  members_string.go:4159	0x75c59a		31c9			XORL CX, CX											
  members_string.go:4159	0x75c59c		4989f0			MOVQ SI, R8											
  members_string.go:4159	0x75c59f		4889fe			MOVQ DI, SI											
  members_string.go:4159	0x75c5a2		31ff			XORL DI, DI											
  members_string.go:4159	0x75c5a4		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4159	0x75c5ab		5d			POPQ BP												
  members_string.go:4159	0x75c5ac		c3			RET												
  members_string.go:4147	0x75c5ad		31c0			XORL AX, AX											
  members_string.go:4147	0x75c5af		31db			XORL BX, BX											
  members_string.go:4147	0x75c5b1		31c9			XORL CX, CX											
  members_string.go:4147	0x75c5b3		4989f0			MOVQ SI, R8											
  members_string.go:4147	0x75c5b6		4889fe			MOVQ DI, SI											
  members_string.go:4147	0x75c5b9		31ff			XORL DI, DI											
  members_string.go:4147	0x75c5bb		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4147	0x75c5c2		5d			POPQ BP												
  members_string.go:4147	0x75c5c3		c3			RET												
  errors.go:26			0x75c5c4		488d056f990600		LEAQ 0x6996f(IP), AX										
  errors.go:26			0x75c5cb		bb2f000000		MOVL $0x2f, BX											
  errors.go:26			0x75c5d0		31c9			XORL CX, CX											
  errors.go:26			0x75c5d2		31ff			XORL DI, DI											
  errors.go:26			0x75c5d4		89fe			MOVL DI, SI											
  errors.go:26			0x75c5d6		e88518d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75c5db		0f1f440000		NOPL 0(AX)(AX*1)										
  errors.go:26			0x75c5e0		4885c0			TESTQ AX, AX											
  errors.go:26			0x75c5e3		7533			JNE 0x75c618											
  errors.go:31			0x75c5e5		90			NOPL												
  errors.go:65			0x75c5e6		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75c5eb		488d1dfee03800		LEAQ 0x38e0fe(IP), BX										
  errors.go:65			0x75c5f2		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75c5f7		e8644dccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75c5fc		48c740082f000000	MOVQ $0x2f, 0x8(AX)										
  errors.go:65			0x75c604		488d152f990600		LEAQ 0x6992f(IP), DX										
  errors.go:65			0x75c60b		488910			MOVQ DX, 0(AX)											
  members_string.go:4141	0x75c60e		4889c3			MOVQ AX, BX											
  members_string.go:4141	0x75c611		488d0588be3b00		LEAQ 0x3bbe88(IP), AX										
  members_string.go:4141	0x75c618		31c9			XORL CX, CX											
  members_string.go:4141	0x75c61a		31ff			XORL DI, DI											
  members_string.go:4141	0x75c61c		4889c6			MOVQ AX, SI											
  members_string.go:4141	0x75c61f		4989d8			MOVQ BX, R8											
  members_string.go:4141	0x75c622		31c0			XORL AX, AX											
  members_string.go:4141	0x75c624		31db			XORL BX, BX											
  members_string.go:4141	0x75c626		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4141	0x75c62d		5d			POPQ BP												
  members_string.go:4141	0x75c62e		c3			RET												
  members_string.go:4139	0x75c62f		4889442428		MOVQ AX, 0x28(SP)										
  members_string.go:4139	0x75c634		48895c2430		MOVQ BX, 0x30(SP)										
  members_string.go:4139	0x75c639		48894c2438		MOVQ CX, 0x38(SP)										
  members_string.go:4139	0x75c63e		48897c2440		MOVQ DI, 0x40(SP)										
  members_string.go:4139	0x75c643		4889742448		MOVQ SI, 0x48(SP)										
  members_string.go:4139	0x75c648		4c89442450		MOVQ R8, 0x50(SP)										
  members_string.go:4139	0x75c64d		4c894c2458		MOVQ R9, 0x58(SP)										
  members_string.go:4139	0x75c652		4c89542460		MOVQ R10, 0x60(SP)										
  members_string.go:4139	0x75c657		4c895c2468		MOVQ R11, 0x68(SP)										
  members_string.go:4139	0x75c65c		0f1f4000		NOPL 0(AX)											
  members_string.go:4139	0x75c660		e89bffd2ff		CALL runtime.morestack_noctxt.abi0(SB)								
  members_string.go:4139	0x75c665		488b442428		MOVQ 0x28(SP), AX										
  members_string.go:4139	0x75c66a		488b5c2430		MOVQ 0x30(SP), BX										
  members_string.go:4139	0x75c66f		488b4c2438		MOVQ 0x38(SP), CX										
  members_string.go:4139	0x75c674		488b7c2440		MOVQ 0x40(SP), DI										
  members_string.go:4139	0x75c679		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:4139	0x75c67e		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4139	0x75c683		4c8b4c2458		MOVQ 0x58(SP), R9										
  members_string.go:4139	0x75c688		4c8b542460		MOVQ 0x60(SP), R10										
  members_string.go:4139	0x75c68d		4c8b5c2468		MOVQ 0x68(SP), R11										
  members_string.go:4139	0x75c692		e929fcffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func24(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func25(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4172	0x75c6a0		4c8d642490		LEAQ -0x70(SP), R12								
  members_string.go:4172	0x75c6a5		4d3b6610		CMPQ R12, 0x10(R14)								
  members_string.go:4172	0x75c6a9		0f86a9030000		JBE 0x75ca58									
  members_string.go:4172	0x75c6af		55			PUSHQ BP									
  members_string.go:4172	0x75c6b0		4889e5			MOVQ SP, BP									
  members_string.go:4172	0x75c6b3		4881ece8000000		SUBQ $0xe8, SP									
  members_string.go:4172	0x75c6ba		48898c2428010000	MOVQ CX, 0x128(SP)								
  members_string.go:4172	0x75c6c2		4889bc2430010000	MOVQ DI, 0x130(SP)								
  members_string.go:4172	0x75c6ca		4c89842440010000	MOVQ R8, 0x140(SP)								
  members_string.go:4173	0x75c6d2		4d85db			TESTQ R11, R11									
  members_string.go:4173	0x75c6d5		7405			JE 0x75c6dc									
  members_string.go:4173	0x75c6d7		498b13			MOVQ 0(R11), DX									
  members_string.go:4173	0x75c6da		eb04			JMP 0x75c6e0									
  members_string.go:4173	0x75c6dc		31d2			XORL DX, DX									
  members_string.go:4173	0x75c6de		6690			NOPW										
  members_string.go:4173	0x75c6e0		4885d2			TESTQ DX, DX									
  members_string.go:4173	0x75c6e3		0f8f09030000		JG 0x75c9f2									
  members_string.go:4176	0x75c6e9		4983f901		CMPQ R9, $0x1									
  members_string.go:4176	0x75c6ed		7469			JE 0x75c758									
  errors.go:26			0x75c6ef		488d05984c0600		LEAQ 0x64c98(IP), AX								
  errors.go:26			0x75c6f6		bb27000000		MOVL $0x27, BX									
  errors.go:26			0x75c6fb		31c9			XORL CX, CX									
  errors.go:26			0x75c6fd		31ff			XORL DI, DI									
  errors.go:26			0x75c6ff		89fe			MOVL DI, SI									
  errors.go:26			0x75c701		e85a17d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75c706		4885c0			TESTQ AX, AX									
  errors.go:26			0x75c709		7536			JNE 0x75c741									
  errors.go:31			0x75c70b		90			NOPL										
  errors.go:65			0x75c70c		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75c711		488d1dd8df3800		LEAQ 0x38dfd8(IP), BX								
  errors.go:65			0x75c718		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75c71d		0f1f00			NOPL 0(AX)									
  errors.go:65			0x75c720		e83b4cccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75c725		48c7400827000000	MOVQ $0x27, 0x8(AX)								
  errors.go:65			0x75c72d		488d155a4c0600		LEAQ 0x64c5a(IP), DX								
  errors.go:65			0x75c734		488910			MOVQ DX, 0(AX)									
  members_string.go:4177	0x75c737		4889c3			MOVQ AX, BX									
  members_string.go:4177	0x75c73a		488d055fbd3b00		LEAQ 0x3bbd5f(IP), AX								
  members_string.go:4177	0x75c741		31c9			XORL CX, CX									
  members_string.go:4177	0x75c743		31ff			XORL DI, DI									
  members_string.go:4177	0x75c745		4889c6			MOVQ AX, SI									
  members_string.go:4177	0x75c748		4989d8			MOVQ BX, R8									
  members_string.go:4177	0x75c74b		31c0			XORL AX, AX									
  members_string.go:4177	0x75c74d		31db			XORL BX, BX									
  members_string.go:4177	0x75c74f		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4177	0x75c756		5d			POPQ BP										
  members_string.go:4177	0x75c757		c3			RET										
  members_string.go:4173	0x75c758		4889842418010000	MOVQ AX, 0x118(SP)								
  members_string.go:4173	0x75c760		4c899c2458010000	MOVQ R11, 0x158(SP)								
  members_string.go:4173	0x75c768		4c89842440010000	MOVQ R8, 0x140(SP)								
  members_string.go:4173	0x75c770		4889b424b8000000	MOVQ SI, 0xb8(SP)								
  members_string.go:4173	0x75c778		48899c24b0000000	MOVQ BX, 0xb0(SP)								
  members_string.go:4173	0x75c780		4889bc24e0000000	MOVQ DI, 0xe0(SP)								
  members_string.go:4173	0x75c788		48898c24a8000000	MOVQ CX, 0xa8(SP)								
  members_string.go:4173	0x75c790		4c898c2448010000	MOVQ R9, 0x148(SP)								
  members_string.go:4173	0x75c798		4c89942450010000	MOVQ R10, 0x150(SP)								
  members_string.go:4179	0x75c7a0		498b08			MOVQ 0(R8), CX									
  members_string.go:4179	0x75c7a3		498b7808		MOVQ 0x8(R8), DI								
  members_string.go:4179	0x75c7a7		498b7010		MOVQ 0x10(R8), SI								
  members_string.go:4179	0x75c7ab		4d8b4018		MOVQ 0x18(R8), R8								
  members_string.go:4179	0x75c7af		488d05745b0500		LEAQ 0x55b74(IP), AX								
  members_string.go:4179	0x75c7b6		bb0b000000		MOVL $0xb, BX									
  members_string.go:4179	0x75c7bb		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4179	0x75c7c0		e8bb42fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)	
  members_string.go:4180	0x75c7c5		4885ff			TESTQ DI, DI									
  members_string.go:4180	0x75c7c8		0f850d020000		JNE 0x75c9db									
  members_string.go:4179	0x75c7ce		888c2497000000		MOVB CL, 0x97(SP)								
  members_string.go:4179	0x75c7d5		48898424c8000000	MOVQ AX, 0xc8(SP)								
  members_string.go:4179	0x75c7dd		48899c24a0000000	MOVQ BX, 0xa0(SP)								
  members_string.go:4183	0x75c7e5		488b8424b0000000	MOVQ 0xb0(SP), AX								
  members_string.go:4183	0x75c7ed		488b9c24a8000000	MOVQ 0xa8(SP), BX								
  members_string.go:4183	0x75c7f5		488b8c24e0000000	MOVQ 0xe0(SP), CX								
  members_string.go:4183	0x75c7fd		488bbc24b8000000	MOVQ 0xb8(SP), DI								
  members_string.go:4183	0x75c805		e8b6fae4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4183	0x75c80a		48898424c0000000	MOVQ AX, 0xc0(SP)								
  members_string.go:4183	0x75c812		48899c2498000000	MOVQ BX, 0x98(SP)								
  members_string.go:4184	0x75c81a		4889c1			MOVQ AX, CX									
  members_string.go:4184	0x75c81d		4889df			MOVQ BX, DI									
  members_string.go:4184	0x75c820		488bb424c8000000	MOVQ 0xc8(SP), SI								
  members_string.go:4184	0x75c828		4c8b8424a0000000	MOVQ 0xa0(SP), R8								
  members_string.go:4184	0x75c830		440fb68c2497000000	MOVZX 0x97(SP), R9								
  members_string.go:4184	0x75c839		488d05ea5a0500		LEAQ 0x55aea(IP), AX								
  members_string.go:4184	0x75c840		bb0b000000		MOVL $0xb, BX									
  members_string.go:4184	0x75c845		e89658f7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)	
  members_string.go:4184	0x75c84a		4885c0			TESTQ AX, AX									
  members_string.go:4184	0x75c84d		0f8571010000		JNE 0x75c9c4									
  members_string.go:4187	0x75c853		488b8424c8000000	MOVQ 0xc8(SP), AX								
  members_string.go:4187	0x75c85b		488b9c24a0000000	MOVQ 0xa0(SP), BX								
  members_string.go:4187	0x75c863		e8d8d1faff		CALL github.com/mgomes/vibescript/internal/runtime.compileCachedRegex(SB)	
  members_string.go:4188	0x75c868		4885db			TESTQ BX, BX									
  members_string.go:4188	0x75c86b		0f848e000000		JE 0x75c8ff									
  members_string.go:4189	0x75c871		440f11bc24d0000000	MOVUPS X15, 0xd0(SP)								
  members_string.go:4189	0x75c87a		7404			JE 0x75c880									
  members_string.go:4189	0x75c87c		488b5b08		MOVQ 0x8(BX), BX								
  members_string.go:4189	0x75c880		48899c24d0000000	MOVQ BX, 0xd0(SP)								
  members_string.go:4189	0x75c888		48898c24d8000000	MOVQ CX, 0xd8(SP)								
  errors.go:26			0x75c890		488d056adc0500		LEAQ 0x5dc6a(IP), AX								
  errors.go:26			0x75c897		bb1d000000		MOVL $0x1d, BX									
  errors.go:26			0x75c89c		488d8c24d0000000	LEAQ 0xd0(SP), CX								
  errors.go:26			0x75c8a4		bf01000000		MOVL $0x1, DI									
  errors.go:26			0x75c8a9		89fe			MOVL DI, SI									
  errors.go:26			0x75c8ab		e8b015d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75c8b0		4885c0			TESTQ AX, AX									
  errors.go:26			0x75c8b3		7533			JNE 0x75c8e8									
  errors.go:31			0x75c8b5		90			NOPL										
  errors.go:65			0x75c8b6		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75c8bb		488d1d2ede3800		LEAQ 0x38de2e(IP), BX								
  errors.go:65			0x75c8c2		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75c8c7		e8944accff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75c8cc		48c740081d000000	MOVQ $0x1d, 0x8(AX)								
  errors.go:65			0x75c8d4		488d1526dc0500		LEAQ 0x5dc26(IP), DX								
  errors.go:65			0x75c8db		488910			MOVQ DX, 0(AX)									
  members_string.go:4189	0x75c8de		4889c3			MOVQ AX, BX									
  members_string.go:4189	0x75c8e1		488d05b8bb3b00		LEAQ 0x3bbbb8(IP), AX								
  members_string.go:4189	0x75c8e8		31c9			XORL CX, CX									
  members_string.go:4189	0x75c8ea		31ff			XORL DI, DI									
  members_string.go:4189	0x75c8ec		4889c6			MOVQ AX, SI									
  members_string.go:4189	0x75c8ef		4989d8			MOVQ BX, R8									
  members_string.go:4189	0x75c8f2		31c0			XORL AX, AX									
  members_string.go:4189	0x75c8f4		31db			XORL BX, BX									
  members_string.go:4189	0x75c8f6		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4189	0x75c8fd		5d			POPQ BP										
  members_string.go:4189	0x75c8fe		c3			RET										
  members_string.go:4191	0x75c8ff		488b9424b0000000	MOVQ 0xb0(SP), DX								
  members_string.go:4191	0x75c907		48891424		MOVQ DX, 0(SP)									
  members_string.go:4191	0x75c90b		488b9424a8000000	MOVQ 0xa8(SP), DX								
  members_string.go:4191	0x75c913		4889542408		MOVQ DX, 0x8(SP)								
  members_string.go:4191	0x75c918		488b9424e0000000	MOVQ 0xe0(SP), DX								
  members_string.go:4191	0x75c920		4889542410		MOVQ DX, 0x10(SP)								
  members_string.go:4191	0x75c925		488b9424b8000000	MOVQ 0xb8(SP), DX								
  members_string.go:4191	0x75c92d		4889542418		MOVQ DX, 0x18(SP)								
  members_string.go:4191	0x75c932		488b942458010000	MOVQ 0x158(SP), DX								
  members_string.go:4191	0x75c93a		4889542420		MOVQ DX, 0x20(SP)								
  members_string.go:4191	0x75c93f		488b9424f8000000	MOVQ 0xf8(SP), DX								
  members_string.go:4191	0x75c947		4889542428		MOVQ DX, 0x28(SP)								
  members_string.go:4191	0x75c94c		488b942400010000	MOVQ 0x100(SP), DX								
  members_string.go:4191	0x75c954		4889542430		MOVQ DX, 0x30(SP)								
  members_string.go:4191	0x75c959		488b942408010000	MOVQ 0x108(SP), DX								
  members_string.go:4191	0x75c961		4889542438		MOVQ DX, 0x38(SP)								
  members_string.go:4191	0x75c966		488b942410010000	MOVQ 0x110(SP), DX								
  members_string.go:4191	0x75c96e		4889542440		MOVQ DX, 0x40(SP)								
  members_string.go:4191	0x75c973		4889c3			MOVQ AX, BX									
  members_string.go:4191	0x75c976		488b8c24c8000000	MOVQ 0xc8(SP), CX								
  members_string.go:4191	0x75c97e		488bbc24a0000000	MOVQ 0xa0(SP), DI								
  members_string.go:4191	0x75c986		488bb424c0000000	MOVQ 0xc0(SP), SI								
  members_string.go:4191	0x75c98e		4c8b842498000000	MOVQ 0x98(SP), R8								
  members_string.go:4191	0x75c996		4c8b8c2440010000	MOVQ 0x140(SP), R9								
  members_string.go:4191	0x75c99e		4c8b942448010000	MOVQ 0x148(SP), R10								
  members_string.go:4191	0x75c9a6		4c8b9c2450010000	MOVQ 0x150(SP), R11								
  members_string.go:4191	0x75c9ae		488b842418010000	MOVQ 0x118(SP), AX								
  members_string.go:4191	0x75c9b6		e88512f8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringScan(SB)		
  members_string.go:4191	0x75c9bb		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4191	0x75c9c2		5d			POPQ BP										
  members_string.go:4191	0x75c9c3		c3			RET										
  members_string.go:4185	0x75c9c4		31c9			XORL CX, CX									
  members_string.go:4185	0x75c9c6		31ff			XORL DI, DI									
  members_string.go:4185	0x75c9c8		4889c6			MOVQ AX, SI									
  members_string.go:4185	0x75c9cb		4989d8			MOVQ BX, R8									
  members_string.go:4185	0x75c9ce		31c0			XORL AX, AX									
  members_string.go:4185	0x75c9d0		31db			XORL BX, BX									
  members_string.go:4185	0x75c9d2		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4185	0x75c9d9		5d			POPQ BP										
  members_string.go:4185	0x75c9da		c3			RET										
  members_string.go:4181	0x75c9db		31c0			XORL AX, AX									
  members_string.go:4181	0x75c9dd		31db			XORL BX, BX									
  members_string.go:4181	0x75c9df		31c9			XORL CX, CX									
  members_string.go:4181	0x75c9e1		4989f0			MOVQ SI, R8									
  members_string.go:4181	0x75c9e4		4889fe			MOVQ DI, SI									
  members_string.go:4181	0x75c9e7		31ff			XORL DI, DI									
  members_string.go:4181	0x75c9e9		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4181	0x75c9f0		5d			POPQ BP										
  members_string.go:4181	0x75c9f1		c3			RET										
  errors.go:26			0x75c9f2		488d0566850600		LEAQ 0x68566(IP), AX								
  errors.go:26			0x75c9f9		bb2d000000		MOVL $0x2d, BX									
  errors.go:26			0x75c9fe		31c9			XORL CX, CX									
  errors.go:26			0x75ca00		31ff			XORL DI, DI									
  errors.go:26			0x75ca02		89fe			MOVL DI, SI									
  errors.go:26			0x75ca04		e85714d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75ca09		4885c0			TESTQ AX, AX									
  errors.go:26			0x75ca0c		7533			JNE 0x75ca41									
  errors.go:31			0x75ca0e		90			NOPL										
  errors.go:65			0x75ca0f		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75ca14		488d1dd5dc3800		LEAQ 0x38dcd5(IP), BX								
  errors.go:65			0x75ca1b		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75ca20		e83b49ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75ca25		48c740082d000000	MOVQ $0x2d, 0x8(AX)								
  errors.go:65			0x75ca2d		488d152b850600		LEAQ 0x6852b(IP), DX								
  errors.go:65			0x75ca34		488910			MOVQ DX, 0(AX)									
  members_string.go:4174	0x75ca37		4889c3			MOVQ AX, BX									
  members_string.go:4174	0x75ca3a		488d055fba3b00		LEAQ 0x3bba5f(IP), AX								
  members_string.go:4174	0x75ca41		31c9			XORL CX, CX									
  members_string.go:4174	0x75ca43		31ff			XORL DI, DI									
  members_string.go:4174	0x75ca45		4889c6			MOVQ AX, SI									
  members_string.go:4174	0x75ca48		4989d8			MOVQ BX, R8									
  members_string.go:4174	0x75ca4b		31c0			XORL AX, AX									
  members_string.go:4174	0x75ca4d		31db			XORL BX, BX									
  members_string.go:4174	0x75ca4f		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4174	0x75ca56		5d			POPQ BP										
  members_string.go:4174	0x75ca57		c3			RET										
  members_string.go:4172	0x75ca58		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4172	0x75ca5d		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4172	0x75ca62		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4172	0x75ca67		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4172	0x75ca6c		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4172	0x75ca71		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4172	0x75ca76		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4172	0x75ca7b		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4172	0x75ca80		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4172	0x75ca85		e876fbd2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4172	0x75ca8a		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4172	0x75ca8f		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4172	0x75ca94		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4172	0x75ca99		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4172	0x75ca9e		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4172	0x75caa3		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4172	0x75caa8		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4172	0x75caad		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4172	0x75cab2		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4172	0x75cab7		e9e4fbffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func25(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func26(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4194	0x75cac0		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4194	0x75cac4		0f867a010000		JBE 0x75cc44									
  members_string.go:4194	0x75caca		55			PUSHQ BP									
  members_string.go:4194	0x75cacb		4889e5			MOVQ SP, BP									
  members_string.go:4194	0x75cace		4883ec70		SUBQ $0x70, SP									
  members_string.go:4194	0x75cad2		48898c24b0000000	MOVQ CX, 0xb0(SP)								
  members_string.go:4194	0x75cada		4889bc24b8000000	MOVQ DI, 0xb8(SP)								
  members_string.go:4194	0x75cae2		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4195	0x75caea		4d85c9			TESTQ R9, R9									
  members_string.go:4195	0x75caed		7406			JE 0x75caf5									
  members_string.go:4195	0x75caef		4983f902		CMPQ R9, $0x2									
  members_string.go:4195	0x75caf3		7e63			JLE 0x75cb58									
  errors.go:26			0x75caf5		488d05cda30600		LEAQ 0x6a3cd(IP), AX								
  errors.go:26			0x75cafc		bb32000000		MOVL $0x32, BX									
  errors.go:26			0x75cb01		31c9			XORL CX, CX									
  errors.go:26			0x75cb03		31ff			XORL DI, DI									
  errors.go:26			0x75cb05		89fe			MOVL DI, SI									
  errors.go:26			0x75cb07		e85413d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75cb0c		4885c0			TESTQ AX, AX									
  errors.go:26			0x75cb0f		7533			JNE 0x75cb44									
  errors.go:31			0x75cb11		90			NOPL										
  errors.go:65			0x75cb12		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75cb17		488d1dd2db3800		LEAQ 0x38dbd2(IP), BX								
  errors.go:65			0x75cb1e		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75cb23		e83848ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75cb28		48c7400832000000	MOVQ $0x32, 0x8(AX)								
  errors.go:65			0x75cb30		488d1592a30600		LEAQ 0x6a392(IP), DX								
  errors.go:65			0x75cb37		488910			MOVQ DX, 0(AX)									
  members_string.go:4196	0x75cb3a		4889c3			MOVQ AX, BX									
  members_string.go:4196	0x75cb3d		488d055cb93b00		LEAQ 0x3bb95c(IP), AX								
  members_string.go:4196	0x75cb44		31c9			XORL CX, CX									
  members_string.go:4196	0x75cb46		31ff			XORL DI, DI									
  members_string.go:4196	0x75cb48		4889c6			MOVQ AX, SI									
  members_string.go:4196	0x75cb4b		4989d8			MOVQ BX, R8									
  members_string.go:4196	0x75cb4e		31c0			XORL AX, AX									
  members_string.go:4196	0x75cb50		31db			XORL BX, BX									
  members_string.go:4196	0x75cb52		4883c470		ADDQ $0x70, SP									
  members_string.go:4196	0x75cb56		5d			POPQ BP										
  members_string.go:4196	0x75cb57		c3			RET										
  members_string.go:4199	0x75cb58		7404			JE 0x75cb5e									
  members_string.go:4199	0x75cb5a		31d2			XORL DX, DX									
  members_string.go:4199	0x75cb5c		eb65			JMP 0x75cbc3									
  members_string.go:4195	0x75cb5e		48898424a0000000	MOVQ AX, 0xa0(SP)								
  members_string.go:4195	0x75cb66		48895c2460		MOVQ BX, 0x60(SP)								
  members_string.go:4195	0x75cb6b		4889742458		MOVQ SI, 0x58(SP)								
  members_string.go:4195	0x75cb70		48894c2450		MOVQ CX, 0x50(SP)								
  members_string.go:4195	0x75cb75		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4195	0x75cb7d		48897c2468		MOVQ DI, 0x68(SP)								
  members_string.go:4200	0x75cb82		498b4020		MOVQ 0x20(R8), AX								
  members_string.go:4200	0x75cb86		498b5828		MOVQ 0x28(R8), BX								
  members_string.go:4200	0x75cb8a		498b4830		MOVQ 0x30(R8), CX								
  members_string.go:4200	0x75cb8e		498b7838		MOVQ 0x38(R8), DI								
  members_string.go:4200	0x75cb92		e80971fdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)		
  members_string.go:4201	0x75cb97		4885db			TESTQ BX, BX									
  members_string.go:4201	0x75cb9a		7545			JNE 0x75cbe1									
  members_string.go:4206	0x75cb9c		488b4c2450		MOVQ 0x50(SP), CX								
  members_string.go:4206	0x75cba1		488b5c2460		MOVQ 0x60(SP), BX								
  members_string.go:4206	0x75cba6		488b742458		MOVQ 0x58(SP), SI								
  members_string.go:4206	0x75cbab		488b7c2468		MOVQ 0x68(SP), DI								
  members_string.go:4206	0x75cbb0		4c8b8424c8000000	MOVQ 0xc8(SP), R8								
  members_string.go:4206	0x75cbb8		4889c2			MOVQ AX, DX									
  members_string.go:4206	0x75cbbb		488b8424a0000000	MOVQ 0xa0(SP), AX								
  members_string.go:4206	0x75cbc3		4d8b4808		MOVQ 0x8(R8), R9								
  members_string.go:4206	0x75cbc7		4d8b5010		MOVQ 0x10(R8), R10								
  members_string.go:4206	0x75cbcb		4d8b5818		MOVQ 0x18(R8), R11								
  members_string.go:4206	0x75cbcf		4d8b00			MOVQ 0(R8), R8									
  members_string.go:4206	0x75cbd2		48891424		MOVQ DX, 0(SP)									
  members_string.go:4206	0x75cbd6		e8a50bf8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIndexResult(SB)	
  members_string.go:4206	0x75cbdb		4883c470		ADDQ $0x70, SP									
  members_string.go:4206	0x75cbdf		5d			POPQ BP										
  members_string.go:4206	0x75cbe0		c3			RET										
  errors.go:26			0x75cbe1		488d0589150600		LEAQ 0x61589(IP), AX								
  errors.go:26			0x75cbe8		bb23000000		MOVL $0x23, BX									
  errors.go:26			0x75cbed		31c9			XORL CX, CX									
  errors.go:26			0x75cbef		31ff			XORL DI, DI									
  errors.go:26			0x75cbf1		89fe			MOVL DI, SI									
  errors.go:26			0x75cbf3		e86812d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75cbf8		4885c0			TESTQ AX, AX									
  errors.go:26			0x75cbfb		7533			JNE 0x75cc30									
  errors.go:31			0x75cbfd		90			NOPL										
  errors.go:65			0x75cbfe		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75cc03		488d1de6da3800		LEAQ 0x38dae6(IP), BX								
  errors.go:65			0x75cc0a		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75cc0f		e84c47ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75cc14		48c7400823000000	MOVQ $0x23, 0x8(AX)								
  errors.go:65			0x75cc1c		488d154e150600		LEAQ 0x6154e(IP), DX								
  errors.go:65			0x75cc23		488910			MOVQ DX, 0(AX)									
  members_string.go:4202	0x75cc26		4889c3			MOVQ AX, BX									
  members_string.go:4202	0x75cc29		488d0570b83b00		LEAQ 0x3bb870(IP), AX								
  members_string.go:4202	0x75cc30		31c9			XORL CX, CX									
  members_string.go:4202	0x75cc32		31ff			XORL DI, DI									
  members_string.go:4202	0x75cc34		4889c6			MOVQ AX, SI									
  members_string.go:4202	0x75cc37		4989d8			MOVQ BX, R8									
  members_string.go:4202	0x75cc3a		31c0			XORL AX, AX									
  members_string.go:4202	0x75cc3c		31db			XORL BX, BX									
  members_string.go:4202	0x75cc3e		4883c470		ADDQ $0x70, SP									
  members_string.go:4202	0x75cc42		5d			POPQ BP										
  members_string.go:4202	0x75cc43		c3			RET										
  members_string.go:4194	0x75cc44		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4194	0x75cc49		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4194	0x75cc4e		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4194	0x75cc53		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4194	0x75cc58		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4194	0x75cc5d		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4194	0x75cc62		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4194	0x75cc67		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4194	0x75cc6c		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4194	0x75cc71		e88af9d2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4194	0x75cc76		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4194	0x75cc7b		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4194	0x75cc80		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4194	0x75cc85		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4194	0x75cc8a		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4194	0x75cc8f		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4194	0x75cc94		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4194	0x75cc99		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4194	0x75cc9e		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4194	0x75cca3		e918feffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func26(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func27(SB) /home/runner/work/vibescript/vibescript/base/internal/runtime/members_string.go
  members_string.go:4209	0x75ccc0		4c8d6424d0		LEAQ -0x30(SP), R12								
  members_string.go:4209	0x75ccc5		4d3b6610		CMPQ R12, 0x10(R14)								
  members_string.go:4209	0x75ccc9		0f8641030000		JBE 0x75d010									
  members_string.go:4209	0x75cccf		55			PUSHQ BP									
  members_string.go:4209	0x75ccd0		4889e5			MOVQ SP, BP									
  members_string.go:4209	0x75ccd3		4881eca8000000		SUBQ $0xa8, SP									
  members_string.go:4209	0x75ccda		48898c24e8000000	MOVQ CX, 0xe8(SP)								
  members_string.go:4209	0x75cce2		4889bc24f0000000	MOVQ DI, 0xf0(SP)								
  members_string.go:4209	0x75ccea		4c89842400010000	MOVQ R8, 0x100(SP)								
  members_string.go:4210	0x75ccf2		4d85c9			TESTQ R9, R9									
  members_string.go:4210	0x75ccf5		7453			JE 0x75cd4a									
  members_string.go:4210	0x75ccf7		4983f902		CMPQ R9, $0x2									
  members_string.go:4210	0x75ccfb		7f4d			JG 0x75cd4a									
  members_string.go:4210	0x75ccfd		48898424d8000000	MOVQ AX, 0xd8(SP)								
  members_string.go:4210	0x75cd05		48899c2488000000	MOVQ BX, 0x88(SP)								
  members_string.go:4210	0x75cd0d		4c898c2408010000	MOVQ R9, 0x108(SP)								
  members_string.go:4210	0x75cd15		4889b42480000000	MOVQ SI, 0x80(SP)								
  members_string.go:4210	0x75cd1d		4889bc24a0000000	MOVQ DI, 0xa0(SP)								
  members_string.go:4210	0x75cd25		48894c2478		MOVQ CX, 0x78(SP)								
  members_string.go:4210	0x75cd2a		4c89842400010000	MOVQ R8, 0x100(SP)								
  members_string.go:4213	0x75cd32		4889d8			MOVQ BX, AX									
  members_string.go:4213	0x75cd35		4889cb			MOVQ CX, BX									
  members_string.go:4213	0x75cd38		4889f9			MOVQ DI, CX									
  members_string.go:4213	0x75cd3b		4889f7			MOVQ SI, DI									
  members_string.go:4213	0x75cd3e		6690			NOPW										
  members_string.go:4213	0x75cd40		e87bf5e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:1178	0x75cd45		90			NOPL										
  members_string.go:1100	0x75cd46		31d2			XORL DX, DX									
  members_string.go:1100	0x75cd48		eb76			JMP 0x75cdc0									
  errors.go:26			0x75cd4a		488d05a6a40600		LEAQ 0x6a4a6(IP), AX								
  errors.go:26			0x75cd51		bb33000000		MOVL $0x33, BX									
  errors.go:26			0x75cd56		31c9			XORL CX, CX									
  errors.go:26			0x75cd58		31ff			XORL DI, DI									
  errors.go:26			0x75cd5a		89fe			MOVL DI, SI									
  errors.go:26			0x75cd5c		0f1f4000		NOPL 0(AX)									
  errors.go:26			0x75cd60		e8fb10d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75cd65		4885c0			TESTQ AX, AX									
  errors.go:26			0x75cd68		7537			JNE 0x75cda1									
  errors.go:31			0x75cd6a		90			NOPL										
  errors.go:65			0x75cd6b		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75cd70		488d1d79d93800		LEAQ 0x38d979(IP), BX								
  errors.go:65			0x75cd77		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75cd7c		0f1f4000		NOPL 0(AX)									
  errors.go:65			0x75cd80		e8db45ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75cd85		48c7400833000000	MOVQ $0x33, 0x8(AX)								
  errors.go:65			0x75cd8d		488d1563a40600		LEAQ 0x6a463(IP), DX								
  errors.go:65			0x75cd94		488910			MOVQ DX, 0(AX)									
  members_string.go:4211	0x75cd97		4889c3			MOVQ AX, BX									
  members_string.go:4211	0x75cd9a		488d05ffb63b00		LEAQ 0x3bb6ff(IP), AX								
  members_string.go:4211	0x75cda1		31c9			XORL CX, CX									
  members_string.go:4211	0x75cda3		31ff			XORL DI, DI									
  members_string.go:4211	0x75cda5		4889c6			MOVQ AX, SI									
  members_string.go:4211	0x75cda8		4989d8			MOVQ BX, R8									
  members_string.go:4211	0x75cdab		31c0			XORL AX, AX									
  members_string.go:4211	0x75cdad		31db			XORL BX, BX									
  members_string.go:4211	0x75cdaf		4881c4a8000000		ADDQ $0xa8, SP									
  members_string.go:4211	0x75cdb6		5d			POPQ BP										
  members_string.go:4211	0x75cdb7		c3			RET										
  members_string.go:1100	0x75cdb8		48ffc2			INCQ DX										
  members_string.go:1100	0x75cdbb		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:1100	0x75cdc0		4839d3			CMPQ BX, DX									
  members_string.go:1100	0x75cdc3		7e23			JLE 0x75cde8									
  members_string.go:1101	0x75cdc5		440fb62410		MOVZX 0(AX)(DX*1), R12								
  members_string.go:1101	0x75cdca		4180fc80		CMPL R12, $0x80									
  members_string.go:1101	0x75cdce		72e8			JB 0x75cdb8									
  members_string.go:4213	0x75cdd0		48895c2468		MOVQ BX, 0x68(SP)								
  members_string.go:4213	0x75cdd5		4889842498000000	MOVQ AX, 0x98(SP)								
  members_string.go:1181	0x75cddd		90			NOPL										
  utf8.go:448			0x75cdde		31d2			XORL DX, DX									
  utf8.go:448			0x75cde0		4531e4			XORL R12, R12									
  utf8.go:448			0x75cde3		e9d8010000		JMP 0x75cfc0									
  members_string.go:4210	0x75cde8		488b942408010000	MOVQ 0x108(SP), DX								
  members_string.go:4210	0x75cdf0		4883fa02		CMPQ DX, $0x2									
  members_string.go:4214	0x75cdf4		0f85cd000000		JNE 0x75cec7									
  members_string.go:4215	0x75cdfa		488b942400010000	MOVQ 0x100(SP), DX								
  members_string.go:4215	0x75ce02		488b5a28		MOVQ 0x28(DX), BX								
  members_string.go:4215	0x75ce06		488b4a30		MOVQ 0x30(DX), CX								
  members_string.go:4215	0x75ce0a		488b7a38		MOVQ 0x38(DX), DI								
  members_string.go:4215	0x75ce0e		488b4220		MOVQ 0x20(DX), AX								
  members_string.go:4215	0x75ce12		e8896efdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)		
  members_string.go:4216	0x75ce17		4885db			TESTQ BX, BX									
  members_string.go:4216	0x75ce1a		7466			JE 0x75ce82									
  errors.go:26			0x75ce1c		488d05c7200600		LEAQ 0x620c7(IP), AX								
  errors.go:26			0x75ce23		bb24000000		MOVL $0x24, BX									
  errors.go:26			0x75ce28		31c9			XORL CX, CX									
  errors.go:26			0x75ce2a		31ff			XORL DI, DI									
  errors.go:26			0x75ce2c		89fe			MOVL DI, SI									
  errors.go:26			0x75ce2e		e82d10d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75ce33		4885c0			TESTQ AX, AX									
  errors.go:26			0x75ce36		7533			JNE 0x75ce6b									
  errors.go:31			0x75ce38		90			NOPL										
  errors.go:65			0x75ce39		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75ce3e		488d1dabd83800		LEAQ 0x38d8ab(IP), BX								
  errors.go:65			0x75ce45		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75ce4a		e81145ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75ce4f		48c7400824000000	MOVQ $0x24, 0x8(AX)								
  errors.go:65			0x75ce57		488d158c200600		LEAQ 0x6208c(IP), DX								
  errors.go:65			0x75ce5e		488910			MOVQ DX, 0(AX)									
  members_string.go:4217	0x75ce61		4889c3			MOVQ AX, BX									
  members_string.go:4217	0x75ce64		488d0535b63b00		LEAQ 0x3bb635(IP), AX								
  members_string.go:4217	0x75ce6b		31c9			XORL CX, CX									
  members_string.go:4217	0x75ce6d		31ff			XORL DI, DI									
  members_string.go:4217	0x75ce6f		4889c6			MOVQ AX, SI									
  members_string.go:4217	0x75ce72		4989d8			MOVQ BX, R8									
  members_string.go:4217	0x75ce75		31c0			XORL AX, AX									
  members_string.go:4217	0x75ce77		31db			XORL BX, BX									
  members_string.go:4217	0x75ce79		4881c4a8000000		ADDQ $0xa8, SP									
  members_string.go:4217	0x75ce80		5d			POPQ BP										
  members_string.go:4217	0x75ce81		c3			RET										
  members_string.go:4215	0x75ce82		4889442470		MOVQ AX, 0x70(SP)								
  members_string.go:4219	0x75ce87		488b842488000000	MOVQ 0x88(SP), AX								
  members_string.go:4219	0x75ce8f		488b5c2478		MOVQ 0x78(SP), BX								
  members_string.go:4219	0x75ce94		488b8c24a0000000	MOVQ 0xa0(SP), CX								
  members_string.go:4219	0x75ce9c		488bbc2480000000	MOVQ 0x80(SP), DI								
  members_string.go:4219	0x75cea4		e817f4e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:1213	0x75cea9		488b542470		MOVQ 0x70(SP), DX								
  members_string.go:1213	0x75ceae		4885d2			TESTQ DX, DX									
  members_string.go:1213	0x75ceb1		7d06			JGE 0x75ceb9									
  members_string.go:1178	0x75ceb3		90			NOPL										
  members_string.go:1100	0x75ceb4		4531e4			XORL R12, R12									
  members_string.go:1100	0x75ceb7		eb75			JMP 0x75cf2e									
  members_string.go:1100	0x75ceb9		b801000000		MOVL $0x1, AX									
  members_string.go:1100	0x75cebe		6690			NOPW										
  members_string.go:4219	0x75cec0		84c0			TESTL AL, AL									
  members_string.go:4220	0x75cec2		7451			JE 0x75cf15									
  members_string.go:4225	0x75cec4		4889d3			MOVQ DX, BX									
  members_string.go:4225	0x75cec7		488b942400010000	MOVQ 0x100(SP), DX								
  members_string.go:4225	0x75cecf		4c8b4a08		MOVQ 0x8(DX), R9								
  members_string.go:4225	0x75ced3		4c8b5210		MOVQ 0x10(DX), R10								
  members_string.go:4225	0x75ced7		4c8b5a18		MOVQ 0x18(DX), R11								
  members_string.go:4225	0x75cedb		4c8b02			MOVQ 0(DX), R8									
  members_string.go:4225	0x75cede		48891c24		MOVQ BX, 0(SP)									
  members_string.go:4225	0x75cee2		488b8424d8000000	MOVQ 0xd8(SP), AX								
  members_string.go:4225	0x75ceea		488b9c2488000000	MOVQ 0x88(SP), BX								
  members_string.go:4225	0x75cef2		488b4c2478		MOVQ 0x78(SP), CX								
  members_string.go:4225	0x75cef7		488bbc24a0000000	MOVQ 0xa0(SP), DI								
  members_string.go:4225	0x75ceff		488bb42480000000	MOVQ 0x80(SP), SI								
  members_string.go:4225	0x75cf07		e8740bf8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringRIndexResult(SB)	
  members_string.go:4225	0x75cf0c		4881c4a8000000		ADDQ $0xa8, SP									
  members_string.go:4225	0x75cf13		5d			POPQ BP										
  members_string.go:4225	0x75cf14		c3			RET										
  members_string.go:4221	0x75cf15		31c0			XORL AX, AX									
  members_string.go:4221	0x75cf17		31db			XORL BX, BX									
  members_string.go:4221	0x75cf19		31c9			XORL CX, CX									
  members_string.go:4221	0x75cf1b		31ff			XORL DI, DI									
  members_string.go:4221	0x75cf1d		89de			MOVL BX, SI									
  members_string.go:4221	0x75cf1f		4189c8			MOVL CX, R8									
  members_string.go:4221	0x75cf22		4881c4a8000000		ADDQ $0xa8, SP									
  members_string.go:4221	0x75cf29		5d			POPQ BP										
  members_string.go:4221	0x75cf2a		c3			RET										
  members_string.go:1100	0x75cf2b		49ffc4			INCQ R12									
  members_string.go:1100	0x75cf2e		4c39e3			CMPQ BX, R12									
  members_string.go:1100	0x75cf31		7e21			JLE 0x75cf54									
  members_string.go:1101	0x75cf33		450fb62c04		MOVZX 0(R12)(AX*1), R13								
  members_string.go:1101	0x75cf38		4180fd80		CMPL R13, $0x80									
  members_string.go:1101	0x75cf3c		72ed			JB 0x75cf2b									
  members_string.go:4219	0x75cf3e		4889842490000000	MOVQ AX, 0x90(SP)								
  members_string.go:4219	0x75cf46		48895c2460		MOVQ BX, 0x60(SP)								
  members_string.go:1181	0x75cf4b		90			NOPL										
  utf8.go:448			0x75cf4c		4531e4			XORL R12, R12									
  utf8.go:448			0x75cf4f		4531ed			XORL R13, R13									
  utf8.go:448			0x75cf52		eb1e			JMP 0x75cf72									
  members_string.go:1216	0x75cf54		4801da			ADDQ BX, DX									
  members_string.go:1217	0x75cf57		4885d2			TESTQ DX, DX									
  members_string.go:1217	0x75cf5a		7d09			JGE 0x75cf65									
  members_string.go:1217	0x75cf5c		31c0			XORL AX, AX									
  members_string.go:1217	0x75cf5e		31d2			XORL DX, DX									
  members_string.go:4219	0x75cf60		e95bffffff		JMP 0x75cec0									
  members_string.go:4219	0x75cf65		b801000000		MOVL $0x1, AX									
  members_string.go:4219	0x75cf6a		e951ffffff		JMP 0x75cec0									
  utf8.go:449			0x75cf6f		49ffc4			INCQ R12									
  utf8.go:448			0x75cf72		4c39eb			CMPQ BX, R13									
  utf8.go:448			0x75cf75		7e3d			JLE 0x75cfb4									
  utf8.go:448			0x75cf77		450fb67c0500		MOVZX 0(R13)(AX*1), R15								
  utf8.go:448			0x75cf7d		0f1f00			NOPL 0(AX)									
  utf8.go:448			0x75cf80		4183ff7f		CMPL R15, $0x7f									
  utf8.go:448			0x75cf84		7f05			JG 0x75cf8b									
  utf8.go:448			0x75cf86		49ffc5			INCQ R13									
  utf8.go:448			0x75cf89		ebe4			JMP 0x75cf6f									
  utf8.go:448			0x75cf8b		4c89642450		MOVQ R12, 0x50(SP)								
  utf8.go:448			0x75cf90		4c89e9			MOVQ R13, CX									
  utf8.go:448			0x75cf93		e82802d2ff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x75cf98		488b842490000000	MOVQ 0x90(SP), AX								
  members_string.go:1216	0x75cfa0		488b542470		MOVQ 0x70(SP), DX								
  utf8.go:449			0x75cfa5		4c8b642450		MOVQ 0x50(SP), R12								
  utf8.go:449			0x75cfaa		4989dd			MOVQ BX, R13									
  utf8.go:448			0x75cfad		488b5c2460		MOVQ 0x60(SP), BX								
  utf8.go:448			0x75cfb2		ebbb			JMP 0x75cf6f									
  members_string.go:1216	0x75cfb4		4c89e3			MOVQ R12, BX									
  members_string.go:1216	0x75cfb7		eb9b			JMP 0x75cf54									
  utf8.go:449			0x75cfb9		48ffc2			INCQ DX										
  utf8.go:449			0x75cfbc		0f1f4000		NOPL 0(AX)									
  utf8.go:448			0x75cfc0		4c39e3			CMPQ BX, R12									
  utf8.go:448			0x75cfc3		7e37			JLE 0x75cffc									
  utf8.go:448			0x75cfc5		460fb62c20		MOVZX 0(AX)(R12*1), R13								
  utf8.go:448			0x75cfca		4183fd7f		CMPL R13, $0x7f									
  utf8.go:448			0x75cfce		7f05			JG 0x75cfd5									
  utf8.go:448			0x75cfd0		49ffc4			INCQ R12									
  utf8.go:448			0x75cfd3		ebe4			JMP 0x75cfb9									
  utf8.go:448			0x75cfd5		4889542458		MOVQ DX, 0x58(SP)								
  utf8.go:448			0x75cfda		4c89e1			MOVQ R12, CX									
  utf8.go:448			0x75cfdd		0f1f00			NOPL 0(AX)									
  utf8.go:448			0x75cfe0		e8db01d2ff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x75cfe5		488b842498000000	MOVQ 0x98(SP), AX								
  utf8.go:449			0x75cfed		488b542458		MOVQ 0x58(SP), DX								
  utf8.go:449			0x75cff2		4989dc			MOVQ BX, R12									
  utf8.go:448			0x75cff5		488b5c2468		MOVQ 0x68(SP), BX								
  utf8.go:448			0x75cffa		ebbd			JMP 0x75cfb9									
  members_string.go:4210	0x75cffc		4c8ba42408010000	MOVQ 0x108(SP), R12								
  members_string.go:4210	0x75d004		4983fc02		CMPQ R12, $0x2									
  members_string.go:4213	0x75d008		4889d3			MOVQ DX, BX									
  members_string.go:4213	0x75d00b		e9e4fdffff		JMP 0x75cdf4									
  members_string.go:4209	0x75d010		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4209	0x75d015		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4209	0x75d01a		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4209	0x75d01f		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4209	0x75d024		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4209	0x75d029		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4209	0x75d02e		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4209	0x75d033		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4209	0x75d038		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4209	0x75d03d		0f1f00			NOPL 0(AX)									
  members_string.go:4209	0x75d040		e8bbf5d2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4209	0x75d045		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4209	0x75d04a		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4209	0x75d04f		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4209	0x75d054		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4209	0x75d059		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4209	0x75d05e		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4209	0x75d063		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4209	0x75d068		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4209	0x75d06d		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4209	0x75d072		e949fcffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func27(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB) /home/runner/work/vibescript/vibescript/head/vibes/value/value_methods.go
  value_methods.go:605		0x5aed00		4c8da42488feffff	LEAQ 0xfffffe88(SP), R12									
  value_methods.go:605		0x5aed08		4d3b6610		CMPQ R12, 0x10(R14)										
  value_methods.go:605		0x5aed0c		0f86c9060000		JBE 0x5af3db											
  value_methods.go:605		0x5aed12		55			PUSHQ BP											
  value_methods.go:605		0x5aed13		4889e5			MOVQ SP, BP											
  value_methods.go:605		0x5aed16		4881ecf0010000		SUBQ $0x1f0, SP											
  value_methods.go:605		0x5aed1d		48899c2408020000	MOVQ BX, 0x208(SP)										
  value_methods.go:605		0x5aed25		48898c2410020000	MOVQ CX, 0x210(SP)										
  value_methods.go:607		0x5aed2d		4889b42420020000	MOVQ SI, 0x220(SP)										
  value_methods.go:605		0x5aed35		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  value_methods.go:605		0x5aed3e		6690			NOPW												
  value_methods.go:607		0x5aed40		4883f805		CMPQ AX, $0x5											
  value_methods.go:607		0x5aed44		0f8493020000		JE 0x5aefdd											
  value_methods.go:627		0x5aed4a		4883f806		CMPQ AX, $0x6											
  value_methods.go:627		0x5aed4e		0f84d5000000		JE 0x5aee29											
  value_methods.go:647		0x5aed54		4883f814		CMPQ AX, $0x14											
  value_methods.go:647		0x5aed58		0f8488000000		JE 0x5aede6											
  value_methods.go:652		0x5aed5e		488b151b555b00		MOVQ github.com/mgomes/vibescript/vibes/value.RuntimeStringRuneLen(SB), DX			
  value_methods.go:652		0x5aed65		4885d2			TESTQ DX, DX											
  value_methods.go:652		0x5aed68		7449			JE 0x5aedb3											
  value_methods.go:607		0x5aed6a		4889bc2418010000	MOVQ DI, 0x118(SP)										
  value_methods.go:607		0x5aed72		48898c24e8010000	MOVQ CX, 0x1e8(SP)										
  value_methods.go:607		0x5aed7a		48899c2410010000	MOVQ BX, 0x110(SP)										
  value_methods.go:607		0x5aed82		4889842408010000	MOVQ AX, 0x108(SP)										
  value_methods.go:653		0x5aed8a		488b32			MOVQ 0(DX), SI											
  value_methods.go:653		0x5aed8d		ffd6			CALL SI												
  value_methods.go:653		0x5aed8f		84db			TESTL BL, BL											
  value_methods.go:653		0x5aed91		753b			JNE 0x5aedce											
  value_methods.go:657		0x5aed93		488b842408010000	MOVQ 0x108(SP), AX										
  value_methods.go:657		0x5aed9b		488b8c24e8010000	MOVQ 0x1e8(SP), CX										
  value_methods.go:657		0x5aeda3		488b9c2410010000	MOVQ 0x110(SP), BX										
  value_methods.go:657		0x5aedab		488bbc2418010000	MOVQ 0x118(SP), DI										
  value_methods.go:657		0x5aedb3		e868d5ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  value_methods.go:657		0x5aedb8		4889842428010000	MOVQ AX, 0x128(SP)										
  value_methods.go:657		0x5aedc0		48895c2458		MOVQ BX, 0x58(SP)										
  utf8.go:448			0x5aedc5		31d2			XORL DX, DX											
  utf8.go:448			0x5aedc7		31f6			XORL SI, SI											
  utf8.go:448			0x5aedc9		e9bd050000		JMP 0x5af38b											
  value_methods.go:654		0x5aedce		4889442440		MOVQ AX, 0x40(SP)										
  value_methods.go:659		0x5aedd3		e848d0e9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:654		0x5aedd8		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aeddd		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aede4		5d			POPQ BP												
  value_methods.go:659		0x5aede5		c3			RET												
  value_methods.go:650		0x5aede6		488d150bc25500		LEAQ 0x55c20b(IP), DX										
  value_methods.go:650		0x5aeded		4839d3			CMPQ BX, DX											
  value_methods.go:650		0x5aedf0		0f857b050000		JNE 0x5af371											
  value_methods.go:650		0x5aedf6		488b01			MOVQ 0(CX), AX											
  value_methods.go:650		0x5aedf9		488b5908		MOVQ 0x8(CX), BX										
  value_methods.go:650		0x5aedfd		488b5110		MOVQ 0x10(CX), DX										
  value_methods.go:650		0x5aee01		488b7918		MOVQ 0x18(CX), DI										
  value_methods.go:650		0x5aee05		488b7120		MOVQ 0x20(CX), SI										
  value_methods.go:650		0x5aee09		4889d1			MOVQ DX, CX											
  value_methods.go:650		0x5aee0c		e86f69ffff		CALL github.com/mgomes/vibescript/vibes/value.Regex.StringRuneLen(SB)				
  value_methods.go:650		0x5aee11		4889442440		MOVQ AX, 0x40(SP)										
  value_methods.go:659		0x5aee16		e805d0e9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:650		0x5aee1b		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aee20		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aee27		5d			POPQ BP												
  value_methods.go:659		0x5aee28		c3			RET												
  value_methods.go:628		0x5aee29		90			NOPL												
  value_accessors.go:113	0x5aee2a		488d156f0c5100		LEAQ 0x510c6f(IP), DX										
  value_accessors.go:113	0x5aee31		4839d3			CMPQ BX, DX											
  value_accessors.go:113	0x5aee34		0f8525050000		JNE 0x5af35f											
  value_accessors.go:113	0x5aee3a		488b19			MOVQ 0(CX), BX											
  value_accessors.go:113	0x5aee3d		0f1f00			NOPL 0(AX)											
  value_methods.go:629		0x5aee40		4885db			TESTQ BX, BX											
  value_methods.go:629		0x5aee43		7405			JE 0x5aee4a											
  value_methods.go:629		0x5aee45		488b13			MOVQ 0(BX), DX											
  value_methods.go:629		0x5aee48		eb02			JMP 0x5aee4c											
  value_methods.go:629		0x5aee4a		31d2			XORL DX, DX											
  value_methods.go:629		0x5aee4c		4885d2			TESTQ DX, DX											
  value_methods.go:629		0x5aee4f		0f846c010000		JE 0x5aefc1											
  value_accessors.go:113	0x5aee55		48899c24e0010000	MOVQ BX, 0x1e0(SP)										
  type.go:208			0x5aee5d		0fb615e0c05100		MOVZX 0x51c0e0(IP), DX										
  value.go:165			0x5aee64		90			NOPL												
  type.go:208			0x5aee65		f6c220			TESTL $0x20, DL											
  value.go:3164			0x5aee68		b995000000		MOVL $0x95, CX											
  value.go:3164			0x5aee6d		ba15000000		MOVL $0x15, DX											
  value.go:3164			0x5aee72		480f45ca		CMOVNE DX, CX											
  value_methods.go:632		0x5aee76		488d05b3c05100		LEAQ 0x51c0b3(IP), AX										
  value_methods.go:632		0x5aee7d		0f1f00			NOPL 0(AX)											
  value_methods.go:632		0x5aee80		e8fb7ff1ff		CALL reflect.Value.Pointer(SB)									
  value_methods.go:633		0x5aee85		4885c0			TESTQ AX, AX											
  value_methods.go:633		0x5aee88		7510			JNE 0x5aee9a											
  value_methods.go:629		0x5aee8a		488b9c24e0010000	MOVQ 0x1e0(SP), BX										
  value_methods.go:629		0x5aee92		4885db			TESTQ BX, BX											
  value_methods.go:633		0x5aee95		e9a9000000		JMP 0x5aef43											
  value_methods.go:632		0x5aee9a		4889442460		MOVQ AX, 0x60(SP)										
  value_methods.go:634		0x5aee9f		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:634		0x5aeea7		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:634		0x5aeeab		4889c1			MOVQ AX, CX											
  value_methods.go:634		0x5aeeae		488d05bbc45100		LEAQ 0x51c4bb(IP), AX										
  value_methods.go:634		0x5aeeb5		e806fce5ff		CALL runtime.mapaccess2_fast64(SB)								
  value_methods.go:634		0x5aeeba		660f1f440000		NOPW 0(AX)(AX*1)										
  value_methods.go:634		0x5aeec0		84db			TESTL BL, BL											
  value_methods.go:634		0x5aeec2		0f85dd000000		JNE 0x5aefa5											
  value_methods.go:637		0x5aeec8		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:637		0x5aeed0		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:637		0x5aeed4		488d0595c45100		LEAQ 0x51c495(IP), AX										
  value_methods.go:637		0x5aeedb		488b4c2460		MOVQ 0x60(SP), CX										
  value_methods.go:637		0x5aeee0		e85bfee5ff		CALL runtime.mapassign_fast64(SB)								
  value_methods.go:637		0x5aeee5		8400			TESTB AL, 0(AX)											
  value_methods.go:638		0x5aeee7		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:638		0x5aeeef		488b5208		MOVQ 0x8(DX), DX										
  value_methods.go:638		0x5aeef3		488d35065c0000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB), SI	
  value_methods.go:638		0x5aeefa		4889b42438010000	MOVQ SI, 0x138(SP)										
  value_methods.go:638		0x5aef02		4889942440010000	MOVQ DX, 0x140(SP)										
  value_methods.go:638		0x5aef0a		488b542460		MOVQ 0x60(SP), DX										
  value_methods.go:638		0x5aef0f		4889942448010000	MOVQ DX, 0x148(SP)										
  value_methods.go:638		0x5aef17		488d942438010000	LEAQ 0x138(SP), DX										
  value_methods.go:638		0x5aef1f		48899424a0000000	MOVQ DX, 0xa0(SP)										
  value_methods.go:638		0x5aef27		488d842488000000	LEAQ 0x88(SP), AX										
  value_methods.go:638		0x5aef2f		e8ccc9e9ff		CALL runtime.deferprocStack(SB)									
  value_methods.go:629		0x5aef34		488b9c24e0010000	MOVQ 0x1e0(SP), BX										
  value_methods.go:629		0x5aef3c		0f1f4000		NOPL 0(AX)											
  value_methods.go:629		0x5aef40		4885db			TESTQ BX, BX											
  value_methods.go:641		0x5aef43		7405			JE 0x5aef4a											
  value_methods.go:641		0x5aef45		488b13			MOVQ 0(BX), DX											
  value_methods.go:641		0x5aef48		eb02			JMP 0x5aef4c											
  value_methods.go:641		0x5aef4a		31d2			XORL DX, DX											
  value_methods.go:1031		0x5aef4c		4883fa02		CMPQ DX, $0x2											
  value_methods.go:1031		0x5aef50		7d04			JGE 0x5aef56											
  value_methods.go:1031		0x5aef52		31d2			XORL DX, DX											
  value_methods.go:641		0x5aef54		eb08			JMP 0x5aef5e											
  value_methods.go:1034		0x5aef56		488d1412		LEAQ 0(DX)(DX*1), DX										
  value_methods.go:1034		0x5aef5a		488d52fe		LEAQ -0x2(DX), DX										
  value_methods.go:641		0x5aef5e		4889542438		MOVQ DX, 0x38(SP)										
  value_methods.go:642		0x5aef63		488d8c2478010000	LEAQ 0x178(SP), CX										
  value_methods.go:642		0x5aef6b		440f1139		MOVUPS X15, 0(CX)										
  value_methods.go:642		0x5aef6f		440f117910		MOVUPS X15, 0x10(CX)										
  value_methods.go:642		0x5aef74		440f117920		MOVUPS X15, 0x20(CX)										
  value_methods.go:642		0x5aef79		440f117930		MOVUPS X15, 0x30(CX)										
  value_methods.go:642		0x5aef7e		440f117940		MOVUPS X15, 0x40(CX)										
  value_methods.go:642		0x5aef83		440f117950		MOVUPS X15, 0x50(CX)										
  value_methods.go:642		0x5aef88		488d05a1bf5100		LEAQ 0x51bfa1(IP), AX										
  value_methods.go:642		0x5aef8f		e86c59e7ff		CALL runtime.mapIterStart(SB)									
  value_methods.go:641		0x5aef94		488b542438		MOVQ 0x38(SP), DX										
  value_methods.go:641		0x5aef99		4883c202		ADDQ $0x2, DX											
  value_methods.go:641		0x5aef9d		0f1f00			NOPL 0(AX)											
  value_methods.go:642		0x5aefa0		e9d4020000		JMP 0x5af279											
  value_methods.go:635		0x5aefa5		48c744244007000000	MOVQ $0x7, 0x40(SP)										
  value_methods.go:659		0x5aefae		e86dcee9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:635		0x5aefb3		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aefb8		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aefbf		5d			POPQ BP												
  value_methods.go:659		0x5aefc0		c3			RET												
  value_methods.go:630		0x5aefc1		48c744244002000000	MOVQ $0x2, 0x40(SP)										
  value_methods.go:659		0x5aefca		e851cee9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:630		0x5aefcf		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aefd4		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aefdb		5d			POPQ BP												
  value_methods.go:659		0x5aefdc		c3			RET												
  value_methods.go:608		0x5aefdd		90			NOPL												
  value_accessors.go:86		0x5aefde		488d15130a5100		LEAQ 0x510a13(IP), DX										
  value_accessors.go:86		0x5aefe5		4839d3			CMPQ BX, DX											
  value_accessors.go:86		0x5aefe8		0f8534020000		JNE 0x5af222											
  value_accessors.go:86		0x5aefee		488b5908		MOVQ 0x8(CX), BX										
  value_accessors.go:86		0x5aeff2		48895c2428		MOVQ BX, 0x28(SP)										
  value_accessors.go:86		0x5aeff7		488b5110		MOVQ 0x10(CX), DX										
  value_accessors.go:86		0x5aeffb		4889542430		MOVQ DX, 0x30(SP)										
  value_accessors.go:86		0x5af000		488b01			MOVQ 0(CX), AX											
  value_accessors.go:86		0x5af003		4889842420010000	MOVQ AX, 0x120(SP)										
  value_methods.go:610		0x5af00b		4889d1			MOVQ DX, CX											
  value_methods.go:610		0x5af00e		e84d6bedff		CALL runtime.convTslice(SB)									
  type.go:208			0x5af013		0fb615c2615100		MOVZX 0x5161c2(IP), DX										
  value.go:165			0x5af01a		90			NOPL												
  type.go:208			0x5af01b		f6c220			TESTL $0x20, DL											
  value.go:3164			0x5af01e		b997000000		MOVL $0x97, CX											
  value.go:3164			0x5af023		ba17000000		MOVL $0x17, DX											
  value.go:3164			0x5af028		480f45ca		CMOVNE DX, CX											
  value_methods.go:610		0x5af02c		4889c3			MOVQ AX, BX											
  value_methods.go:610		0x5af02f		488d0592615100		LEAQ 0x516192(IP), AX										
  value_methods.go:610		0x5af036		e8457ef1ff		CALL reflect.Value.Pointer(SB)									
  value_methods.go:610		0x5af03b		0f1f440000		NOPL 0(AX)(AX*1)										
  value_methods.go:614		0x5af040		4885c0			TESTQ AX, AX											
  value_methods.go:614		0x5af043		0f8407010000		JE 0x5af150											
  value_methods.go:610		0x5af049		4889842480000000	MOVQ AX, 0x80(SP)										
  value_methods.go:615		0x5af051		48898424e8000000	MOVQ AX, 0xe8(SP)										
  value_methods.go:615		0x5af059		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:615		0x5af05e		48899424f0000000	MOVQ DX, 0xf0(SP)										
  value_methods.go:615		0x5af066		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:615		0x5af06b		48899424f8000000	MOVQ DX, 0xf8(SP)										
  value_methods.go:615		0x5af073		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:615		0x5af07b		488b1a			MOVQ 0(DX), BX											
  value_methods.go:615		0x5af07e		488d050bc55100		LEAQ 0x51c50b(IP), AX										
  value_methods.go:615		0x5af085		488d8c24e8000000	LEAQ 0xe8(SP), CX										
  value_methods.go:615		0x5af08d		e88eeae5ff		CALL runtime.mapaccess2(SB)									
  value_methods.go:615		0x5af092		84db			TESTL BL, BL											
  value_methods.go:615		0x5af094		0f85f9000000		JNE 0x5af193											
  value_methods.go:618		0x5af09a		488b942480000000	MOVQ 0x80(SP), DX										
  value_methods.go:618		0x5af0a2		48899424e8000000	MOVQ DX, 0xe8(SP)										
  value_methods.go:618		0x5af0aa		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:618		0x5af0af		48899424f0000000	MOVQ DX, 0xf0(SP)										
  value_methods.go:618		0x5af0b7		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:618		0x5af0bc		48899424f8000000	MOVQ DX, 0xf8(SP)										
  value_methods.go:618		0x5af0c4		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:618		0x5af0cc		488b1a			MOVQ 0(DX), BX											
  value_methods.go:618		0x5af0cf		488d05bac45100		LEAQ 0x51c4ba(IP), AX										
  value_methods.go:618		0x5af0d6		488d8c24e8000000	LEAQ 0xe8(SP), CX										
  value_methods.go:618		0x5af0de		6690			NOPW												
  value_methods.go:618		0x5af0e0		e81bede5ff		CALL runtime.mapassign(SB)									
  value_methods.go:618		0x5af0e5		8400			TESTB AL, 0(AX)											
  value_methods.go:619		0x5af0e7		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:619		0x5af0ef		488b12			MOVQ 0(DX), DX											
  value_methods.go:619		0x5af0f2		488d35475a0000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB), SI	
  value_methods.go:619		0x5af0f9		4889b42450010000	MOVQ SI, 0x150(SP)										
  value_methods.go:619		0x5af101		4889942458010000	MOVQ DX, 0x158(SP)										
  value_methods.go:619		0x5af109		488b942480000000	MOVQ 0x80(SP), DX										
  value_methods.go:619		0x5af111		4889942460010000	MOVQ DX, 0x160(SP)										
  value_methods.go:619		0x5af119		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:619		0x5af11e		4889942468010000	MOVQ DX, 0x168(SP)										
  value_methods.go:619		0x5af126		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:619		0x5af12b		4889942470010000	MOVQ DX, 0x170(SP)										
  value_methods.go:619		0x5af133		488d942450010000	LEAQ 0x150(SP), DX										
  value_methods.go:619		0x5af13b		48899424d0000000	MOVQ DX, 0xd0(SP)										
  value_methods.go:619		0x5af143		488d8424b8000000	LEAQ 0xb8(SP), AX										
  value_methods.go:619		0x5af14b		e8b0c7e9ff		CALL runtime.deferprocStack(SB)									
  value_methods.go:1031		0x5af150		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:1031		0x5af155		4883fa02		CMPQ DX, $0x2											
  value_methods.go:1031		0x5af159		7d07			JGE 0x5af162											
  value_methods.go:1031		0x5af15b		4531c0			XORL R8, R8											
  value_methods.go:1031		0x5af15e		6690			NOPW												
  value_methods.go:622		0x5af160		eb08			JMP 0x5af16a											
  value_methods.go:1034		0x5af162		4c8d0412		LEAQ 0(DX)(DX*1), R8										
  value_methods.go:1034		0x5af166		4d8d40fe		LEAQ -0x2(R8), R8										
  value_methods.go:622		0x5af16a		4983c002		ADDQ $0x2, R8											
  value_methods.go:623		0x5af16e		4c8b8c2420010000	MOVQ 0x120(SP), R9										
  value_methods.go:623		0x5af176		e98a000000		JMP 0x5af205											
  value_methods.go:659		0x5af17b		0f1f440000		NOPL 0(AX)(AX*1)										
  value_methods.go:659		0x5af180		e89bcce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:619		0x5af185		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af18a		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af191		5d			POPQ BP												
  value_methods.go:659		0x5af192		c3			RET												
  value_methods.go:616		0x5af193		48c744244007000000	MOVQ $0x7, 0x40(SP)										
  value_methods.go:616		0x5af19c		0f1f4000		NOPL 0(AX)											
  value_methods.go:659		0x5af1a0		e87bcce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:616		0x5af1a5		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af1aa		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af1b1		5d			POPQ BP												
  value_methods.go:659		0x5af1b2		c3			RET												
  value_methods.go:623		0x5af1b3		4889942400010000	MOVQ DX, 0x100(SP)										
  value_methods.go:623		0x5af1bb		4c89442450		MOVQ R8, 0x50(SP)										
  value_methods.go:623		0x5af1c0		4c898c24d8010000	MOVQ R9, 0x1d8(SP)										
  value_methods.go:623		0x5af1c8		498b01			MOVQ 0(R9), AX											
  value_methods.go:623		0x5af1cb		498b4910		MOVQ 0x10(R9), CX										
  value_methods.go:623		0x5af1cf		498b7918		MOVQ 0x18(R9), DI										
  value_methods.go:623		0x5af1d3		498b5908		MOVQ 0x8(R9), BX										
  value_methods.go:624		0x5af1d7		488bb42420020000	MOVQ 0x220(SP), SI										
  value_methods.go:624		0x5af1df		90			NOPL												
  value_methods.go:624		0x5af1e0		e81bfbffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			
  value_methods.go:623		0x5af1e5		4c8b8c24d8010000	MOVQ 0x1d8(SP), R9										
  value_methods.go:623		0x5af1ed		4983c120		ADDQ $0x20, R9											
  value_methods.go:624		0x5af1f1		488b542450		MOVQ 0x50(SP), DX										
  value_methods.go:624		0x5af1f6		4c8d0402		LEAQ 0(DX)(AX*1), R8										
  value_methods.go:623		0x5af1fa		488b942400010000	MOVQ 0x100(SP), DX										
  value_methods.go:623		0x5af202		48ffca			DECQ DX												
  value_methods.go:623		0x5af205		4885d2			TESTQ DX, DX											
  value_methods.go:623		0x5af208		7fa9			JG 0x5af1b3											
  value_methods.go:626		0x5af20a		4c89442440		MOVQ R8, 0x40(SP)										
  value_methods.go:659		0x5af20f		e80ccce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:626		0x5af214		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af219		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af220		5d			POPQ BP												
  value_methods.go:659		0x5af221		c3			RET												
  value_accessors.go:86		0x5af222		4889d8			MOVQ BX, AX											
  value_accessors.go:86		0x5af225		4889d3			MOVQ DX, BX											
  value_accessors.go:86		0x5af228		488d0d81b95300		LEAQ 0x53b981(IP), CX										
  value_accessors.go:86		0x5af22f		e80cdce6ff		CALL runtime.panicdottypeE(SB)									
  value_methods.go:644		0x5af234		4c89c0			MOVQ R8, AX											
  value_methods.go:644		0x5af237		4c89d3			MOVQ R10, BX											
  value_methods.go:644		0x5af23a		488bb42420020000	MOVQ 0x220(SP), SI										
  value_methods.go:644		0x5af242		e8b9faffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			
  value_methods.go:644		0x5af247		4889842400010000	MOVQ AX, 0x100(SP)										
  value_methods.go:642		0x5af24f		488d842478010000	LEAQ 0x178(SP), AX										
  value_methods.go:642		0x5af257		e80457e7ff		CALL runtime.mapIterNext(SB)									
  value_methods.go:643		0x5af25c		488b542470		MOVQ 0x70(SP), DX										
  value_methods.go:643		0x5af261		4c8b442448		MOVQ 0x48(SP), R8										
  value_methods.go:643		0x5af266		4c01c2			ADDQ R8, DX											
  value_methods.go:644		0x5af269		4c8b842400010000	MOVQ 0x100(SP), R8										
  value_methods.go:644		0x5af271		4a8d1402		LEAQ 0(DX)(R8*1), DX										
  value_methods.go:644		0x5af275		488d5202		LEAQ 0x2(DX), DX										
  value_methods.go:642		0x5af279		4c8b842478010000	MOVQ 0x178(SP), R8										
  value_methods.go:642		0x5af281		4d85c0			TESTQ R8, R8											
  value_methods.go:642		0x5af284		0f84bd000000		JE 0x5af347											
  value_methods.go:642		0x5af28a		4889542448		MOVQ DX, 0x48(SP)										
  value_methods.go:642		0x5af28f		4c8b8c2480010000	MOVQ 0x180(SP), R9										
  value_methods.go:642		0x5af297		498b00			MOVQ 0(R8), AX											
  value_methods.go:642		0x5af29a		4889842430010000	MOVQ AX, 0x130(SP)										
  value_methods.go:642		0x5af2a2		498b5808		MOVQ 0x8(R8), BX										
  value_methods.go:642		0x5af2a6		48895c2478		MOVQ BX, 0x78(SP)										
  value_methods.go:642		0x5af2ab		4d8b01			MOVQ 0(R9), R8											
  value_methods.go:642		0x5af2ae		4c89842408010000	MOVQ R8, 0x108(SP)										
  value_methods.go:642		0x5af2b6		4d8b5108		MOVQ 0x8(R9), R10										
  value_methods.go:642		0x5af2ba		4c89942410010000	MOVQ R10, 0x110(SP)										
  value_methods.go:642		0x5af2c2		498b4910		MOVQ 0x10(R9), CX										
  value_methods.go:642		0x5af2c6		48898c24e8010000	MOVQ CX, 0x1e8(SP)										
  value_methods.go:642		0x5af2ce		498b7918		MOVQ 0x18(R9), DI										
  value_methods.go:642		0x5af2d2		4889bc2418010000	MOVQ DI, 0x118(SP)										
  utf8.go:448			0x5af2da		4531c9			XORL R9, R9											
  utf8.go:448			0x5af2dd		4531db			XORL R11, R11											
  utf8.go:448			0x5af2e0		eb03			JMP 0x5af2e5											
  utf8.go:449			0x5af2e2		49ffc1			INCQ R9												
  utf8.go:448			0x5af2e5		4c894c2470		MOVQ R9, 0x70(SP)										
  utf8.go:448			0x5af2ea		4939db			CMPQ R11, BX											
  utf8.go:448			0x5af2ed		0f8d41ffffff		JGE 0x5af234											
  utf8.go:448			0x5af2f3		450fb62403		MOVZX 0(R11)(AX*1), R12										
  utf8.go:448			0x5af2f8		4183fc7f		CMPL R12, $0x7f											
  utf8.go:448			0x5af2fc		7f05			JG 0x5af303											
  utf8.go:448			0x5af2fe		49ffc3			INCQ R11											
  utf8.go:448			0x5af301		ebdf			JMP 0x5af2e2											
  utf8.go:448			0x5af303		4c89d9			MOVQ R11, CX											
  utf8.go:448			0x5af306		e8f5deecff		CALL runtime.decoderune(SB)									
  utf8.go:448			0x5af30b		488b842430010000	MOVQ 0x130(SP), AX										
  value_methods.go:644		0x5af313		488b8c24e8010000	MOVQ 0x1e8(SP), CX										
  value_methods.go:643		0x5af31b		488b542448		MOVQ 0x48(SP), DX										
  value_methods.go:644		0x5af320		488bbc2418010000	MOVQ 0x118(SP), DI										
  value_methods.go:644		0x5af328		4c8b842408010000	MOVQ 0x108(SP), R8										
  utf8.go:449			0x5af330		4c8b4c2470		MOVQ 0x70(SP), R9										
  value_methods.go:644		0x5af335		4c8b942410010000	MOVQ 0x110(SP), R10										
  utf8.go:449			0x5af33d		4989db			MOVQ BX, R11											
  utf8.go:448			0x5af340		488b5c2478		MOVQ 0x78(SP), BX										
  utf8.go:448			0x5af345		eb9b			JMP 0x5af2e2											
  value_methods.go:646		0x5af347		4889542440		MOVQ DX, 0x40(SP)										
  value_methods.go:659		0x5af34c		e8cfcae9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:646		0x5af351		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af356		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af35d		5d			POPQ BP												
  value_methods.go:659		0x5af35e		c3			RET												
  value_accessors.go:113	0x5af35f		4889d8			MOVQ BX, AX											
  value_accessors.go:113	0x5af362		4889d3			MOVQ DX, BX											
  value_accessors.go:113	0x5af365		488d0d44b85300		LEAQ 0x53b844(IP), CX										
  value_accessors.go:113	0x5af36c		e8cfdae6ff		CALL runtime.panicdottypeE(SB)									
  value_methods.go:650		0x5af371		4889d8			MOVQ BX, AX											
  value_methods.go:650		0x5af374		4889d3			MOVQ DX, BX											
  value_methods.go:650		0x5af377		488d0d32b85300		LEAQ 0x53b832(IP), CX										
  value_methods.go:650		0x5af37e		6690			NOPW												
  value_methods.go:650		0x5af380		e8bbdae6ff		CALL runtime.panicdottypeE(SB)									
  utf8.go:449			0x5af385		48ffc6			INCQ SI												
  utf8.go:448			0x5af388		4889ca			MOVQ CX, DX											
  utf8.go:448			0x5af38b		4839d3			CMPQ BX, DX											
  utf8.go:448			0x5af38e		7e33			JLE 0x5af3c3											
  utf8.go:448			0x5af390		0fb63c10		MOVZX 0(AX)(DX*1), DI										
  utf8.go:448			0x5af394		83ff7f			CMPL DI, $0x7f											
  utf8.go:448			0x5af397		7f06			JG 0x5af39f											
  utf8.go:448			0x5af399		488d4a01		LEAQ 0x1(DX), CX										
  utf8.go:448			0x5af39d		ebe6			JMP 0x5af385											
  utf8.go:448			0x5af39f		4889742468		MOVQ SI, 0x68(SP)										
  utf8.go:448			0x5af3a4		4889d1			MOVQ DX, CX											
  utf8.go:448			0x5af3a7		e854deecff		CALL runtime.decoderune(SB)									
  utf8.go:448			0x5af3ac		488b842428010000	MOVQ 0x128(SP), AX										
  utf8.go:449			0x5af3b4		488b742468		MOVQ 0x68(SP), SI										
  utf8.go:449			0x5af3b9		4889d9			MOVQ BX, CX											
  utf8.go:448			0x5af3bc		488b5c2458		MOVQ 0x58(SP), BX										
  utf8.go:448			0x5af3c1		ebc2			JMP 0x5af385											
  value_methods.go:657		0x5af3c3		4889742440		MOVQ SI, 0x40(SP)										
  value_methods.go:659		0x5af3c8		e853cae9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:657		0x5af3cd		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af3d2		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af3d9		5d			POPQ BP												
  value_methods.go:659		0x5af3da		c3			RET												
  value_methods.go:605		0x5af3db		4889442408		MOVQ AX, 0x8(SP)										
  value_methods.go:605		0x5af3e0		48895c2410		MOVQ BX, 0x10(SP)										
  value_methods.go:605		0x5af3e5		48894c2418		MOVQ CX, 0x18(SP)										
  value_methods.go:605		0x5af3ea		48897c2420		MOVQ DI, 0x20(SP)										
  value_methods.go:605		0x5af3ef		4889742428		MOVQ SI, 0x28(SP)										
  value_methods.go:605		0x5af3f4		e847d2edff		CALL runtime.morestack_noctxt.abi0(SB)								
  value_methods.go:605		0x5af3f9		488b442408		MOVQ 0x8(SP), AX										
  value_methods.go:605		0x5af3fe		488b5c2410		MOVQ 0x10(SP), BX										
  value_methods.go:605		0x5af403		488b4c2418		MOVQ 0x18(SP), CX										
  value_methods.go:605		0x5af408		488b7c2420		MOVQ 0x20(SP), DI										
  value_methods.go:605		0x5af40d		488b742428		MOVQ 0x28(SP), SI										
  value_methods.go:605		0x5af412		e9e9f8ffff		JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB) /home/runner/work/vibescript/vibescript/head/vibes/value/value_methods.go
  value_methods.go:844		0x5b0780		4c8da42468feffff	LEAQ 0xfffffe68(SP), R12										
  value_methods.go:844		0x5b0788		4d3b6610		CMPQ R12, 0x10(R14)											
  value_methods.go:844		0x5b078c		0f86210a0000		JBE 0x5b11b3												
  value_methods.go:844		0x5b0792		55			PUSHQ BP												
  value_methods.go:844		0x5b0793		4889e5			MOVQ SP, BP												
  value_methods.go:844		0x5b0796		4881ec10020000		SUBQ $0x210, SP												
  value_methods.go:844		0x5b079d		48899c2428020000	MOVQ BX, 0x228(SP)											
  value_methods.go:844		0x5b07a5		48898c2430020000	MOVQ CX, 0x230(SP)											
  value_methods.go:845		0x5b07ad		4889b42440020000	MOVQ SI, 0x240(SP)											
  value_methods.go:845		0x5b07b5		4c89842448020000	MOVQ R8, 0x248(SP)											
  value_methods.go:845		0x5b07bd		48898c24f0010000	MOVQ CX, 0x1f0(SP)											
  value_methods.go:845		0x5b07c5		48899c24c8000000	MOVQ BX, 0xc8(SP)											
  value_methods.go:845		0x5b07cd		48898424c0000000	MOVQ AX, 0xc0(SP)											
  value_methods.go:845		0x5b07d5		4889bc24b8000000	MOVQ DI, 0xb8(SP)											
  value_methods.go:844		0x5b07dd		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:844		0x5b07e6		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:845		0x5b07ef		498b00			MOVQ 0(R8), AX												
  value_methods.go:845		0x5b07f2		4c89c2			MOVQ R8, DX												
  value_methods.go:845		0x5b07f5		ffd0			CALL AX													
  value_methods.go:845		0x5b07f7		660f1f840000000000	NOPW 0(AX)(AX*1)											
  value_methods.go:845		0x5b0800		4885c0			TESTQ AX, AX												
  value_methods.go:845		0x5b0803		0f854d050000		JNE 0x5b0d56												
  value_methods.go:849		0x5b0809		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:849		0x5b0811		4883f805		CMPQ AX, $0x5												
  value_methods.go:849		0x5b0815		0f85e5010000		JNE 0x5b0a00												
  value_methods.go:850		0x5b081b		90			NOPL													
  value_accessors.go:86		0x5b081c		488b8424c8000000	MOVQ 0xc8(SP), AX											
  value_accessors.go:86		0x5b0824		488d1dcdf15000		LEAQ 0x50f1cd(IP), BX											
  value_accessors.go:86		0x5b082b		4839d8			CMPQ AX, BX												
  value_accessors.go:86		0x5b082e		0f8572090000		JNE 0x5b11a6												
  value_accessors.go:86		0x5b0834		488b9424f0010000	MOVQ 0x1f0(SP), DX											
  value_accessors.go:86		0x5b083c		488b5a08		MOVQ 0x8(DX), BX											
  value_accessors.go:86		0x5b0840		48895c2430		MOVQ BX, 0x30(SP)											
  value_accessors.go:86		0x5b0845		488b4a10		MOVQ 0x10(DX), CX											
  value_accessors.go:86		0x5b0849		48894c2438		MOVQ CX, 0x38(SP)											
  value_accessors.go:86		0x5b084e		488b02			MOVQ 0(DX), AX												
  value_accessors.go:86		0x5b0851		4889842440010000	MOVQ AX, 0x140(SP)											
  value_methods.go:852		0x5b0859		e80253edff		CALL runtime.convTslice(SB)										
  type.go:208			0x5b085e		0fb61577495100		MOVZX 0x514977(IP), DX											
  value.go:165			0x5b0865		90			NOPL													
  type.go:208			0x5b0866		f6c220			TESTL $0x20, DL												
  value.go:3164			0x5b0869		b997000000		MOVL $0x97, CX												
  value.go:3164			0x5b086e		ba17000000		MOVL $0x17, DX												
  value.go:3164			0x5b0873		480f45ca		CMOVNE DX, CX												
  value_methods.go:852		0x5b0877		4889c3			MOVQ AX, BX												
  value_methods.go:852		0x5b087a		488d0547495100		LEAQ 0x514947(IP), AX											
  value_methods.go:852		0x5b0881		e8fa65f1ff		CALL reflect.Value.Pointer(SB)										
  value_methods.go:856		0x5b0886		4885c0			TESTQ AX, AX												
  value_methods.go:856		0x5b0889		0f840d010000		JE 0x5b099c												
  value_methods.go:852		0x5b088f		4889842490000000	MOVQ AX, 0x90(SP)											
  value_methods.go:857		0x5b0897		4889842498000000	MOVQ AX, 0x98(SP)											
  value_methods.go:857		0x5b089f		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:857		0x5b08a4		48899424a0000000	MOVQ DX, 0xa0(SP)											
  value_methods.go:857		0x5b08ac		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:857		0x5b08b1		48899424a8000000	MOVQ DX, 0xa8(SP)											
  value_methods.go:857		0x5b08b9		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:857		0x5b08c1		488b1a			MOVQ 0(DX), BX												
  value_methods.go:857		0x5b08c4		488d05c5ac5100		LEAQ 0x51acc5(IP), AX											
  value_methods.go:857		0x5b08cb		488d8c2498000000	LEAQ 0x98(SP), CX											
  value_methods.go:857		0x5b08d3		e848d2e5ff		CALL runtime.mapaccess2(SB)										
  value_methods.go:857		0x5b08d8		0f1f840000000000	NOPL 0(AX)(AX*1)											
  value_methods.go:857		0x5b08e0		84db			TESTL BL, BL												
  value_methods.go:857		0x5b08e2		0f85dd000000		JNE 0x5b09c5												
  value_methods.go:860		0x5b08e8		488b942490000000	MOVQ 0x90(SP), DX											
  value_methods.go:860		0x5b08f0		4889942498000000	MOVQ DX, 0x98(SP)											
  value_methods.go:860		0x5b08f8		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:860		0x5b08fd		48899424a0000000	MOVQ DX, 0xa0(SP)											
  value_methods.go:860		0x5b0905		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:860		0x5b090a		48899424a8000000	MOVQ DX, 0xa8(SP)											
  value_methods.go:860		0x5b0912		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:860		0x5b091a		488b1a			MOVQ 0(DX), BX												
  value_methods.go:860		0x5b091d		488d056cac5100		LEAQ 0x51ac6c(IP), AX											
  value_methods.go:860		0x5b0924		488d8c2498000000	LEAQ 0x98(SP), CX											
  value_methods.go:860		0x5b092c		e8cfd4e5ff		CALL runtime.mapassign(SB)										
  value_methods.go:860		0x5b0931		8400			TESTB AL, 0(AX)												
  value_methods.go:861		0x5b0933		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:861		0x5b093b		488b12			MOVQ 0(DX), DX												
  value_methods.go:861		0x5b093e		488d35fb420000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB), SI	
  value_methods.go:861		0x5b0945		4889b42460010000	MOVQ SI, 0x160(SP)											
  value_methods.go:861		0x5b094d		4889942468010000	MOVQ DX, 0x168(SP)											
  value_methods.go:861		0x5b0955		488b942490000000	MOVQ 0x90(SP), DX											
  value_methods.go:861		0x5b095d		4889942470010000	MOVQ DX, 0x170(SP)											
  value_methods.go:861		0x5b0965		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:861		0x5b096a		4889942478010000	MOVQ DX, 0x178(SP)											
  value_methods.go:861		0x5b0972		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:861		0x5b0977		4889942480010000	MOVQ DX, 0x180(SP)											
  value_methods.go:861		0x5b097f		488d942460010000	LEAQ 0x160(SP), DX											
  value_methods.go:861		0x5b0987		4889942418010000	MOVQ DX, 0x118(SP)											
  value_methods.go:861		0x5b098f		488d842400010000	LEAQ 0x100(SP), AX											
  value_methods.go:861		0x5b0997		e864afe9ff		CALL runtime.deferprocStack(SB)										
  value_methods.go:1031		0x5b099c		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:1031		0x5b09a1		4883fa02		CMPQ DX, $0x2												
  value_methods.go:1031		0x5b09a5		7d05			JGE 0x5b09ac												
  value_methods.go:1031		0x5b09a7		4531c9			XORL R9, R9												
  value_methods.go:864		0x5b09aa		eb08			JMP 0x5b09b4												
  value_methods.go:1034		0x5b09ac		4c8d0c12		LEAQ 0(DX)(DX*1), R9											
  value_methods.go:1034		0x5b09b0		4d8d49fe		LEAQ -0x2(R9), R9											
  value_methods.go:864		0x5b09b4		4983c102		ADDQ $0x2, R9												
  value_methods.go:865		0x5b09b8		4c8b942440010000	MOVQ 0x140(SP), R10											
  value_methods.go:865		0x5b09c0		e931070000		JMP 0x5b10f6												
  value_methods.go:858		0x5b09c5		48c744244807000000	MOVQ $0x7, 0x48(SP)											
  value_methods.go:858		0x5b09ce		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b09d7		e844b4e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:858		0x5b09dc		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:858		0x5b09e4		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:858		0x5b09ec		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b09f1		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b09f8		5d			POPQ BP													
  value_methods.go:918		0x5b09f9		c3			RET													
  value_methods.go:918		0x5b09fa		660f1f440000		NOPW 0(AX)(AX*1)											
  value_methods.go:873		0x5b0a00		4883f806		CMPQ AX, $0x6												
  value_methods.go:873		0x5b0a04		0f850e020000		JNE 0x5b0c18												
  value_methods.go:874		0x5b0a0a		90			NOPL													
  value_accessors.go:113	0x5b0a0b		488b8424c8000000	MOVQ 0xc8(SP), AX											
  value_accessors.go:113	0x5b0a13		488d1d86f05000		LEAQ 0x50f086(IP), BX											
  value_accessors.go:113	0x5b0a1a		660f1f440000		NOPW 0(AX)(AX*1)											
  value_accessors.go:113	0x5b0a20		4839d8			CMPQ AX, BX												
  value_accessors.go:113	0x5b0a23		0f85a1060000		JNE 0x5b10ca												
  value_accessors.go:113	0x5b0a29		488b9424f0010000	MOVQ 0x1f0(SP), DX											
  value_accessors.go:113	0x5b0a31		488b1a			MOVQ 0(DX), BX												
  value_methods.go:875		0x5b0a34		4885db			TESTQ BX, BX												
  value_methods.go:875		0x5b0a37		7405			JE 0x5b0a3e												
  value_methods.go:875		0x5b0a39		488b13			MOVQ 0(BX), DX												
  value_methods.go:875		0x5b0a3c		eb02			JMP 0x5b0a40												
  value_methods.go:875		0x5b0a3e		31d2			XORL DX, DX												
  value_methods.go:875		0x5b0a40		4885d2			TESTQ DX, DX												
  value_methods.go:875		0x5b0a43		0f849a010000		JE 0x5b0be3												
  value_accessors.go:113	0x5b0a49		48899c2448010000	MOVQ BX, 0x148(SP)											
  type.go:208			0x5b0a51		0fb615eca45100		MOVZX 0x51a4ec(IP), DX											
  value.go:165			0x5b0a58		90			NOPL													
  type.go:208			0x5b0a59		f6c220			TESTL $0x20, DL												
  value.go:3164			0x5b0a5c		b995000000		MOVL $0x95, CX												
  value.go:3164			0x5b0a61		ba15000000		MOVL $0x15, DX												
  value.go:3164			0x5b0a66		480f45ca		CMOVNE DX, CX												
  value_methods.go:878		0x5b0a6a		488d05bfa45100		LEAQ 0x51a4bf(IP), AX											
  value_methods.go:878		0x5b0a71		e80a64f1ff		CALL reflect.Value.Pointer(SB)										
  value_methods.go:879		0x5b0a76		4885c0			TESTQ AX, AX												
  value_methods.go:879		0x5b0a79		7510			JNE 0x5b0a8b												
  value_methods.go:875		0x5b0a7b		488b9c2448010000	MOVQ 0x148(SP), BX											
  value_methods.go:875		0x5b0a83		4885db			TESTQ BX, BX												
  value_methods.go:879		0x5b0a86		e99f000000		JMP 0x5b0b2a												
  value_methods.go:878		0x5b0a8b		4889442468		MOVQ AX, 0x68(SP)											
  value_methods.go:880		0x5b0a90		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:880		0x5b0a98		488b5a08		MOVQ 0x8(DX), BX											
  value_methods.go:880		0x5b0a9c		4889c1			MOVQ AX, CX												
  value_methods.go:880		0x5b0a9f		488d05caa85100		LEAQ 0x51a8ca(IP), AX											
  value_methods.go:880		0x5b0aa6		e815e0e5ff		CALL runtime.mapaccess2_fast64(SB)									
  value_methods.go:880		0x5b0aab		84db			TESTL BL, BL												
  value_methods.go:880		0x5b0aad		0f85f9000000		JNE 0x5b0bac												
  value_methods.go:883		0x5b0ab3		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:883		0x5b0abb		488b5a08		MOVQ 0x8(DX), BX											
  value_methods.go:883		0x5b0abf		488d05aaa85100		LEAQ 0x51a8aa(IP), AX											
  value_methods.go:883		0x5b0ac6		488b4c2468		MOVQ 0x68(SP), CX											
  value_methods.go:883		0x5b0acb		e870e2e5ff		CALL runtime.mapassign_fast64(SB)									
  value_methods.go:883		0x5b0ad0		8400			TESTB AL, 0(AX)												
  value_methods.go:884		0x5b0ad2		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:884		0x5b0ada		488b5208		MOVQ 0x8(DX), DX											
  value_methods.go:884		0x5b0ade		488d351b410000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB), SI	
  value_methods.go:884		0x5b0ae5		4889b424f8010000	MOVQ SI, 0x1f8(SP)											
  value_methods.go:884		0x5b0aed		4889942400020000	MOVQ DX, 0x200(SP)											
  value_methods.go:884		0x5b0af5		488b542468		MOVQ 0x68(SP), DX											
  value_methods.go:884		0x5b0afa		4889942408020000	MOVQ DX, 0x208(SP)											
  value_methods.go:884		0x5b0b02		488d9424f8010000	LEAQ 0x1f8(SP), DX											
  value_methods.go:884		0x5b0b0a		48899424e8000000	MOVQ DX, 0xe8(SP)											
  value_methods.go:884		0x5b0b12		488d8424d0000000	LEAQ 0xd0(SP), AX											
  value_methods.go:884		0x5b0b1a		e8e1ade9ff		CALL runtime.deferprocStack(SB)										
  value_methods.go:875		0x5b0b1f		488b9c2448010000	MOVQ 0x148(SP), BX											
  value_methods.go:875		0x5b0b27		4885db			TESTQ BX, BX												
  value_methods.go:887		0x5b0b2a		7405			JE 0x5b0b31												
  value_methods.go:887		0x5b0b2c		488b13			MOVQ 0(BX), DX												
  value_methods.go:887		0x5b0b2f		eb02			JMP 0x5b0b33												
  value_methods.go:887		0x5b0b31		31d2			XORL DX, DX												
  value_methods.go:1031		0x5b0b33		4883fa02		CMPQ DX, $0x2												
  value_methods.go:1031		0x5b0b37		7d04			JGE 0x5b0b3d												
  value_methods.go:1031		0x5b0b39		31d2			XORL DX, DX												
  value_methods.go:887		0x5b0b3b		eb08			JMP 0x5b0b45												
  value_methods.go:1034		0x5b0b3d		488d1412		LEAQ 0(DX)(DX*1), DX											
  value_methods.go:1034		0x5b0b41		488d52fe		LEAQ -0x2(DX), DX											
  value_methods.go:887		0x5b0b45		4889542440		MOVQ DX, 0x40(SP)											
  value_methods.go:888		0x5b0b4a		488d8c2488010000	LEAQ 0x188(SP), CX											
  value_methods.go:888		0x5b0b52		440f1139		MOVUPS X15, 0(CX)											
  value_methods.go:888		0x5b0b56		440f117910		MOVUPS X15, 0x10(CX)											
  value_methods.go:888		0x5b0b5b		440f117920		MOVUPS X15, 0x20(CX)											
  value_methods.go:888		0x5b0b60		440f117930		MOVUPS X15, 0x30(CX)											
  value_methods.go:888		0x5b0b65		440f117940		MOVUPS X15, 0x40(CX)											
  value_methods.go:888		0x5b0b6a		440f117950		MOVUPS X15, 0x50(CX)											
  value_methods.go:888		0x5b0b6f		488d05baa35100		LEAQ 0x51a3ba(IP), AX											
  value_methods.go:888		0x5b0b76		e8853de7ff		CALL runtime.mapIterStart(SB)										
  value_methods.go:887		0x5b0b7b		488b542440		MOVQ 0x40(SP), DX											
  value_methods.go:887		0x5b0b80		4883c202		ADDQ $0x2, DX												
  value_methods.go:888		0x5b0b84		e9c7030000		JMP 0x5b0f50												
  value_methods.go:918		0x5b0b89		e892b2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:861		0x5b0b8e		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:861		0x5b0b96		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:861		0x5b0b9e		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0ba3		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0baa		5d			POPQ BP													
  value_methods.go:918		0x5b0bab		c3			RET													
  value_methods.go:881		0x5b0bac		48c744244807000000	MOVQ $0x7, 0x48(SP)											
  value_methods.go:881		0x5b0bb5		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:881		0x5b0bbe		6690			NOPW													
  value_methods.go:918		0x5b0bc0		e85bb2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:881		0x5b0bc5		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:881		0x5b0bcd		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:881		0x5b0bd5		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0bda		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0be1		5d			POPQ BP													
  value_methods.go:918		0x5b0be2		c3			RET													
  value_methods.go:876		0x5b0be3		48c744244802000000	MOVQ $0x2, 0x48(SP)											
  value_methods.go:876		0x5b0bec		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0bf5		e826b2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:876		0x5b0bfa		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:876		0x5b0c02		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:876		0x5b0c0a		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0c0f		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0c16		5d			POPQ BP													
  value_methods.go:918		0x5b0c17		c3			RET													
  value_methods.go:897		0x5b0c18		4883f814		CMPQ AX, $0x14												
  value_methods.go:897		0x5b0c1c		752d			JNE 0x5b0c4b												
  regex.go:180			0x5b0c1e		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0c26		488d1dcba35500		LEAQ 0x55a3cb(IP), BX											
  regex.go:180			0x5b0c2d		4839d8			CMPQ AX, BX												
  regex.go:180			0x5b0c30		0f85d9020000		JNE 0x5b0f0f												
  regex.go:180			0x5b0c36		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  regex.go:180			0x5b0c3e		4d8b4808		MOVQ 0x8(R8), R9											
  regex.go:180			0x5b0c42		49c1e906		SHRQ $0x6, R9												
  regex.go:180			0x5b0c46		e9da010000		JMP 0x5b0e25												
  value_methods.go:908		0x5b0c4b		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:908		0x5b0c53		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:908		0x5b0c5b		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:908		0x5b0c63		488bb42448020000	MOVQ 0x248(SP), SI											
  value_methods.go:908		0x5b0c6b		e850ebfeff		CALL github.com/mgomes/vibescript/vibes/value.chargeBigIntRenderSteps(SB)				
  value_methods.go:908		0x5b0c70		4885c0			TESTQ AX, AX												
  value_methods.go:908		0x5b0c73		0f85a1000000		JNE 0x5b0d1a												
  value_methods.go:911		0x5b0c79		488b1500365b00		MOVQ github.com/mgomes/vibescript/vibes/value.RuntimeStringRuneLen(SB), DX				
  value_methods.go:911		0x5b0c80		4885d2			TESTQ DX, DX												
  value_methods.go:911		0x5b0c83		7429			JE 0x5b0cae												
  value_methods.go:912		0x5b0c85		488b32			MOVQ 0(DX), SI												
  value_methods.go:912		0x5b0c88		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:912		0x5b0c90		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:912		0x5b0c98		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:912		0x5b0ca0		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:912		0x5b0ca8		ffd6			CALL SI													
  value_methods.go:912		0x5b0caa		84db			TESTL BL, BL												
  value_methods.go:912		0x5b0cac		753b			JNE 0x5b0ce9												
  value_methods.go:916		0x5b0cae		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:916		0x5b0cb6		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:916		0x5b0cbe		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:916		0x5b0cc6		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:916		0x5b0cce		e84db6ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)						
  value_methods.go:916		0x5b0cd3		4889842450010000	MOVQ AX, 0x150(SP)											
  value_methods.go:916		0x5b0cdb		48895c2460		MOVQ BX, 0x60(SP)											
  utf8.go:448			0x5b0ce0		31d2			XORL DX, DX												
  utf8.go:448			0x5b0ce2		31f6			XORL SI, SI												
  utf8.go:448			0x5b0ce4		e9af000000		JMP 0x5b0d98												
  value_methods.go:913		0x5b0ce9		4889442448		MOVQ AX, 0x48(SP)											
  value_methods.go:913		0x5b0cee		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0cf7		e824b1e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:913		0x5b0cfc		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:913		0x5b0d04		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:913		0x5b0d0c		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0d11		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0d18		5d			POPQ BP													
  value_methods.go:918		0x5b0d19		c3			RET													
  value_methods.go:909		0x5b0d1a		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:909		0x5b0d23		4889842430010000	MOVQ AX, 0x130(SP)											
  value_methods.go:909		0x5b0d2b		48899c2438010000	MOVQ BX, 0x138(SP)											
  value_methods.go:918		0x5b0d33		e8e8b0e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:909		0x5b0d38		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:909		0x5b0d40		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:909		0x5b0d48		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0d4d		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0d54		5d			POPQ BP													
  value_methods.go:918		0x5b0d55		c3			RET													
  value_methods.go:846		0x5b0d56		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:846		0x5b0d5f		4889842430010000	MOVQ AX, 0x130(SP)											
  value_methods.go:846		0x5b0d67		48899c2438010000	MOVQ BX, 0x138(SP)											
  value_methods.go:918		0x5b0d6f		e8acb0e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:846		0x5b0d74		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:846		0x5b0d7c		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:846		0x5b0d84		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0d89		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0d90		5d			POPQ BP													
  value_methods.go:918		0x5b0d91		c3			RET													
  utf8.go:449			0x5b0d92		48ffc6			INCQ SI													
  utf8.go:448			0x5b0d95		4889ca			MOVQ CX, DX												
  utf8.go:448			0x5b0d98		4839d3			CMPQ BX, DX												
  utf8.go:448			0x5b0d9b		7e33			JLE 0x5b0dd0												
  utf8.go:448			0x5b0d9d		0fb63c02		MOVZX 0(DX)(AX*1), DI											
  utf8.go:448			0x5b0da1		83ff7f			CMPL DI, $0x7f												
  utf8.go:448			0x5b0da4		7f06			JG 0x5b0dac												
  utf8.go:448			0x5b0da6		488d4a01		LEAQ 0x1(DX), CX											
  utf8.go:448			0x5b0daa		ebe6			JMP 0x5b0d92												
  utf8.go:448			0x5b0dac		4889742470		MOVQ SI, 0x70(SP)											
  utf8.go:448			0x5b0db1		4889d1			MOVQ DX, CX												
  utf8.go:448			0x5b0db4		e847c4ecff		CALL runtime.decoderune(SB)										
  utf8.go:448			0x5b0db9		488b842450010000	MOVQ 0x150(SP), AX											
  utf8.go:449			0x5b0dc1		488b742470		MOVQ 0x70(SP), SI											
  utf8.go:449			0x5b0dc6		4889d9			MOVQ BX, CX												
  utf8.go:448			0x5b0dc9		488b5c2460		MOVQ 0x60(SP), BX											
  utf8.go:448			0x5b0dce		ebc2			JMP 0x5b0d92												
  value_methods.go:916		0x5b0dd0		4889742448		MOVQ SI, 0x48(SP)											
  value_methods.go:916		0x5b0dd5		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0dde		6690			NOPW													
  value_methods.go:918		0x5b0de0		e83bb0e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:916		0x5b0de5		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:916		0x5b0ded		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:916		0x5b0df5		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0dfa		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0e01		5d			POPQ BP													
  value_methods.go:918		0x5b0e02		c3			RET													
  regex.go:180			0x5b0e03		4c8b8c24b0000000	MOVQ 0xb0(SP), R9											
  regex.go:180			0x5b0e0b		49ffc9			DECQ R9													
  regex.go:180			0x5b0e0e		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0e16		488d1ddba15500		LEAQ 0x55a1db(IP), BX											
  value_methods.go:906		0x5b0e1d		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  regex.go:180			0x5b0e25		4d85c9			TESTQ R9, R9												
  regex.go:180			0x5b0e28		7e3a			JLE 0x5b0e64												
  regex.go:180			0x5b0e2a		4c898c24b0000000	MOVQ R9, 0xb0(SP)											
  regex.go:181			0x5b0e32		488b942448020000	MOVQ 0x248(SP), DX											
  regex.go:181			0x5b0e3a		488b02			MOVQ 0(DX), AX												
  regex.go:181			0x5b0e3d		ffd0			CALL AX													
  regex.go:181			0x5b0e3f		90			NOPL													
  regex.go:181			0x5b0e40		4885c0			TESTQ AX, AX												
  regex.go:181			0x5b0e43		74be			JE 0x5b0e03												
  value_methods.go:906		0x5b0e45		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  value_methods.go:903		0x5b0e4d		4889c1			MOVQ AX, CX												
  value_methods.go:903		0x5b0e50		4889da			MOVQ BX, DX												
  regex.go:180			0x5b0e53		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0e5b		488d1d96a15500		LEAQ 0x55a196(IP), BX											
  value_methods.go:903		0x5b0e62		eb04			JMP 0x5b0e68												
  value_methods.go:903		0x5b0e64		31c9			XORL CX, CX												
  value_methods.go:903		0x5b0e66		31d2			XORL DX, DX												
  value_methods.go:903		0x5b0e68		4885c9			TESTQ CX, CX												
  value_methods.go:903		0x5b0e6b		7556			JNE 0x5b0ec3												
  regex.go:180			0x5b0e6d		4839d8			CMPQ AX, BX												
  value_methods.go:906		0x5b0e70		0f858d000000		JNE 0x5b0f03												
  value_methods.go:906		0x5b0e76		498b00			MOVQ 0(R8), AX												
  value_methods.go:906		0x5b0e79		498b5808		MOVQ 0x8(R8), BX											
  value_methods.go:906		0x5b0e7d		498b4810		MOVQ 0x10(R8), CX											
  value_methods.go:906		0x5b0e81		498b7818		MOVQ 0x18(R8), DI											
  value_methods.go:906		0x5b0e85		498b7020		MOVQ 0x20(R8), SI											
  value_methods.go:906		0x5b0e89		e8f248ffff		CALL github.com/mgomes/vibescript/vibes/value.Regex.StringRuneLen(SB)					
  value_methods.go:906		0x5b0e8e		4889442448		MOVQ AX, 0x48(SP)											
  value_methods.go:906		0x5b0e93		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:906		0x5b0e9c		0f1f4000		NOPL 0(AX)												
  value_methods.go:918		0x5b0ea0		e87bafe9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:906		0x5b0ea5		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:906		0x5b0ead		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:906		0x5b0eb5		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0eba		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0ec1		5d			POPQ BP													
  value_methods.go:918		0x5b0ec2		c3			RET													
  value_methods.go:904		0x5b0ec3		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:904		0x5b0ecc		48898c2430010000	MOVQ CX, 0x130(SP)											
  value_methods.go:904		0x5b0ed4		4889942438010000	MOVQ DX, 0x138(SP)											
  value_methods.go:904		0x5b0edc		0f1f4000		NOPL 0(AX)												
  value_methods.go:918		0x5b0ee0		e83bafe9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:904		0x5b0ee5		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:904		0x5b0eed		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:904		0x5b0ef5		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0efa		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0f01		5d			POPQ BP													
  value_methods.go:918		0x5b0f02		c3			RET													
  value_methods.go:906		0x5b0f03		488d0da69c5300		LEAQ 0x539ca6(IP), CX											
  value_methods.go:906		0x5b0f0a		e831bfe6ff		CALL runtime.panicdottypeE(SB)										
  regex.go:180			0x5b0f0f		488d0d9a9c5300		LEAQ 0x539c9a(IP), CX											
  regex.go:180			0x5b0f16		e825bfe6ff		CALL runtime.panicdottypeE(SB)										
  value_methods.go:890		0x5b0f1b		4889842480000000	MOVQ AX, 0x80(SP)											
  value_methods.go:889		0x5b0f23		48899424b0000000	MOVQ DX, 0xb0(SP)											
  value_methods.go:888		0x5b0f2b		488d842488010000	LEAQ 0x188(SP), AX											
  value_methods.go:888		0x5b0f33		e8283ae7ff		CALL runtime.mapIterNext(SB)										
  value_methods.go:894		0x5b0f38		488b8c2480000000	MOVQ 0x80(SP), CX											
  value_methods.go:894		0x5b0f40		488b9424b0000000	MOVQ 0xb0(SP), DX											
  value_methods.go:894		0x5b0f48		488d140a		LEAQ 0(DX)(CX*1), DX											
  value_methods.go:894		0x5b0f4c		488d5202		LEAQ 0x2(DX), DX											
  value_methods.go:888		0x5b0f50		4c8b8c2488010000	MOVQ 0x188(SP), R9											
  value_methods.go:888		0x5b0f58		0f1f840000000000	NOPL 0(AX)(AX*1)											
  value_methods.go:888		0x5b0f60		4d85c9			TESTQ R9, R9												
  value_methods.go:888		0x5b0f63		0f84f4000000		JE 0x5b105d												
  value_methods.go:888		0x5b0f69		4889542450		MOVQ DX, 0x50(SP)											
  value_methods.go:888		0x5b0f6e		4c8b942490010000	MOVQ 0x190(SP), R10											
  value_methods.go:888		0x5b0f76		498b01			MOVQ 0(R9), AX												
  value_methods.go:888		0x5b0f79		4889842458010000	MOVQ AX, 0x158(SP)											
  value_methods.go:888		0x5b0f81		498b5908		MOVQ 0x8(R9), BX											
  value_methods.go:888		0x5b0f85		48899c2488000000	MOVQ BX, 0x88(SP)											
  value_methods.go:888		0x5b0f8d		4d8b0a			MOVQ 0(R10), R9												
  value_methods.go:888		0x5b0f90		4c898c24c0000000	MOVQ R9, 0xc0(SP)											
  value_methods.go:888		0x5b0f98		4d8b5a08		MOVQ 0x8(R10), R11											
  value_methods.go:888		0x5b0f9c		4c899c24c8000000	MOVQ R11, 0xc8(SP)											
  value_methods.go:888		0x5b0fa4		498b4a10		MOVQ 0x10(R10), CX											
  value_methods.go:888		0x5b0fa8		48898c24f0010000	MOVQ CX, 0x1f0(SP)											
  value_methods.go:888		0x5b0fb0		498b7a18		MOVQ 0x18(R10), DI											
  value_methods.go:888		0x5b0fb4		4889bc24b8000000	MOVQ DI, 0xb8(SP)											
  utf8.go:448			0x5b0fbc		4531d2			XORL R10, R10												
  utf8.go:448			0x5b0fbf		4531e4			XORL R12, R12												
  utf8.go:448			0x5b0fc2		eb03			JMP 0x5b0fc7												
  utf8.go:449			0x5b0fc4		49ffc2			INCQ R10												
  utf8.go:448			0x5b0fc7		4c89542478		MOVQ R10, 0x78(SP)											
  utf8.go:448			0x5b0fcc		4939dc			CMPQ R12, BX												
  utf8.go:448			0x5b0fcf		7d58			JGE 0x5b1029												
  utf8.go:448			0x5b0fd1		450fb62c04		MOVZX 0(R12)(AX*1), R13											
  utf8.go:448			0x5b0fd6		4183fd7f		CMPL R13, $0x7f												
  utf8.go:448			0x5b0fda		7f06			JG 0x5b0fe2												
  utf8.go:448			0x5b0fdc		49ffc4			INCQ R12												
  utf8.go:448			0x5b0fdf		90			NOPL													
  utf8.go:448			0x5b0fe0		ebe2			JMP 0x5b0fc4												
  utf8.go:448			0x5b0fe2		4c89e1			MOVQ R12, CX												
  utf8.go:448			0x5b0fe5		e816c2ecff		CALL runtime.decoderune(SB)										
  utf8.go:448			0x5b0fea		488b842458010000	MOVQ 0x158(SP), AX											
  value_methods.go:890		0x5b0ff2		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:889		0x5b0ffa		488b542450		MOVQ 0x50(SP), DX											
  value_methods.go:890		0x5b0fff		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:890		0x5b1007		4c8b8c24c0000000	MOVQ 0xc0(SP), R9											
  utf8.go:449			0x5b100f		4c8b542478		MOVQ 0x78(SP), R10											
  value_methods.go:890		0x5b1014		4c8b9c24c8000000	MOVQ 0xc8(SP), R11											
  utf8.go:449			0x5b101c		4989dc			MOVQ BX, R12												
  utf8.go:448			0x5b101f		488b9c2488000000	MOVQ 0x88(SP), BX											
  utf8.go:448			0x5b1027		eb9b			JMP 0x5b0fc4												
  value_methods.go:890		0x5b1029		4c89c8			MOVQ R9, AX												
  value_methods.go:890		0x5b102c		4c89db			MOVQ R11, BX												
  value_methods.go:890		0x5b102f		488bb42440020000	MOVQ 0x240(SP), SI											
  value_methods.go:890		0x5b1037		4c8b842448020000	MOVQ 0x248(SP), R8											
  value_methods.go:890		0x5b103f		90			NOPL													
  value_methods.go:890		0x5b1040		e83bf7ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			
  value_methods.go:889		0x5b1045		488b542478		MOVQ 0x78(SP), DX											
  value_methods.go:889		0x5b104a		4c8b4c2450		MOVQ 0x50(SP), R9											
  value_methods.go:889		0x5b104f		4c01ca			ADDQ R9, DX												
  value_methods.go:891		0x5b1052		4885db			TESTQ BX, BX												
  value_methods.go:891		0x5b1055		0f84c0feffff		JE 0x5b0f1b												
  value_methods.go:891		0x5b105b		eb31			JMP 0x5b108e												
  value_methods.go:896		0x5b105d		4889542448		MOVQ DX, 0x48(SP)											
  value_methods.go:896		0x5b1062		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b106b		e8b0ade9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:896		0x5b1070		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:896		0x5b1078		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:896		0x5b1080		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b1085		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b108c		5d			POPQ BP													
  value_methods.go:918		0x5b108d		c3			RET													
  value_methods.go:892		0x5b108e		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:892		0x5b1097		48899c2430010000	MOVQ BX, 0x130(SP)											
  value_methods.go:892		0x5b109f		48898c2438010000	MOVQ CX, 0x138(SP)											
  value_methods.go:918		0x5b10a7		e874ade9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:892		0x5b10ac		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:892		0x5b10b4		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:892		0x5b10bc		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b10c1		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b10c8		5d			POPQ BP													
  value_methods.go:918		0x5b10c9		c3			RET													
  value_accessors.go:113	0x5b10ca		488d0ddf9a5300		LEAQ 0x539adf(IP), CX											
  value_accessors.go:113	0x5b10d1		e86abde6ff		CALL runtime.panicdottypeE(SB)										
  value_methods.go:865		0x5b10d6		4c8b9424e8010000	MOVQ 0x1e8(SP), R10											
  value_methods.go:865		0x5b10de		4983c220		ADDQ $0x20, R10												
  value_methods.go:870		0x5b10e2		4c8b5c2458		MOVQ 0x58(SP), R11											
  value_methods.go:870		0x5b10e7		4d8d0c03		LEAQ 0(R11)(AX*1), R9											
  value_methods.go:865		0x5b10eb		488b9424b0000000	MOVQ 0xb0(SP), DX											
  value_methods.go:865		0x5b10f3		48ffca			DECQ DX													
  value_methods.go:865		0x5b10f6		4885d2			TESTQ DX, DX												
  value_methods.go:865		0x5b10f9		7e7a			JLE 0x5b1175												
  value_methods.go:865		0x5b10fb		48899424b0000000	MOVQ DX, 0xb0(SP)											
  value_methods.go:865		0x5b1103		4c894c2458		MOVQ R9, 0x58(SP)											
  value_methods.go:865		0x5b1108		4c899424e8010000	MOVQ R10, 0x1e8(SP)											
  value_methods.go:865		0x5b1110		498b02			MOVQ 0(R10), AX												
  value_methods.go:865		0x5b1113		498b5a08		MOVQ 0x8(R10), BX											
  value_methods.go:865		0x5b1117		498b4a10		MOVQ 0x10(R10), CX											
  value_methods.go:865		0x5b111b		498b7a18		MOVQ 0x18(R10), DI											
  value_methods.go:866		0x5b111f		488bb42440020000	MOVQ 0x240(SP), SI											
  value_methods.go:866		0x5b1127		4c8b842448020000	MOVQ 0x248(SP), R8											
  value_methods.go:866		0x5b112f		e84cf6ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			
  value_methods.go:867		0x5b1134		4885db			TESTQ BX, BX												
  value_methods.go:867		0x5b1137		749d			JE 0x5b10d6												
  value_methods.go:868		0x5b1139		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:868		0x5b1142		48899c2430010000	MOVQ BX, 0x130(SP)											
  value_methods.go:868		0x5b114a		48898c2438010000	MOVQ CX, 0x138(SP)											
  value_methods.go:918		0x5b1152		e8c9ace9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:868		0x5b1157		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:868		0x5b115f		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:868		0x5b1167		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b116c		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b1173		5d			POPQ BP													
  value_methods.go:918		0x5b1174		c3			RET													
  value_methods.go:872		0x5b1175		4c894c2448		MOVQ R9, 0x48(SP)											
  value_methods.go:872		0x5b117a		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b1183		e898ace9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:872		0x5b1188		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:872		0x5b1190		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:872		0x5b1198		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b119d		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b11a4		5d			POPQ BP													
  value_methods.go:918		0x5b11a5		c3			RET													
  value_accessors.go:86		0x5b11a6		488d0d039a5300		LEAQ 0x539a03(IP), CX											
  value_accessors.go:86		0x5b11ad		e88ebce6ff		CALL runtime.panicdottypeE(SB)										
  value_accessors.go:86		0x5b11b2		90			NOPL													
  value_methods.go:844		0x5b11b3		4889442408		MOVQ AX, 0x8(SP)											
  value_methods.go:844		0x5b11b8		48895c2410		MOVQ BX, 0x10(SP)											
  value_methods.go:844		0x5b11bd		48894c2418		MOVQ CX, 0x18(SP)											
  value_methods.go:844		0x5b11c2		48897c2420		MOVQ DI, 0x20(SP)											
  value_methods.go:844		0x5b11c7		4889742428		MOVQ SI, 0x28(SP)											
  value_methods.go:844		0x5b11cc		4c89442430		MOVQ R8, 0x30(SP)											
  value_methods.go:844		0x5b11d1		e86ab4edff		CALL runtime.morestack_noctxt.abi0(SB)									
  value_methods.go:844		0x5b11d6		488b442408		MOVQ 0x8(SP), AX											
  value_methods.go:844		0x5b11db		488b5c2410		MOVQ 0x10(SP), BX											
  value_methods.go:844		0x5b11e0		488b4c2418		MOVQ 0x18(SP), CX											
  value_methods.go:844		0x5b11e5		488b7c2420		MOVQ 0x20(SP), DI											
  value_methods.go:844		0x5b11ea		488b742428		MOVQ 0x28(SP), SI											
  value_methods.go:844		0x5b11ef		4c8b442430		MOVQ 0x30(SP), R8											
  value_methods.go:844		0x5b11f4		e987f5ffff		JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB) /home/runner/work/vibescript/vibescript/head/vibes/value/value_methods.go
  value_methods.go:638	0x5b4b00		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:638	0x5b4b04		7625			JBE 0x5b4b2b											
  value_methods.go:638	0x5b4b06		55			PUSHQ BP											
  value_methods.go:638	0x5b4b07		4889e5			MOVQ SP, BP											
  value_methods.go:638	0x5b4b0a		4883ec18		SUBQ $0x18, SP											
  value_methods.go:638	0x5b4b0e		488b4a10		MOVQ 0x10(DX), CX										
  value_methods.go:638	0x5b4b12		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:638	0x5b4b16		488d0553685100		LEAQ 0x516853(IP), AX										
  value_methods.go:638	0x5b4b1d		0f1f00			NOPL 0(AX)											
  value_methods.go:638	0x5b4b20		e83baae5ff		CALL runtime.mapdelete_fast64(SB)								
  value_methods.go:638	0x5b4b25		4883c418		ADDQ $0x18, SP											
  value_methods.go:638	0x5b4b29		5d			POPQ BP												
  value_methods.go:638	0x5b4b2a		c3			RET												
  value_methods.go:638	0x5b4b2b		e8707aedff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:638	0x5b4b30		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB) /home/runner/work/vibescript/vibescript/head/vibes/value/value_methods.go
  value_methods.go:619	0x5b4b40		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:619	0x5b4b44		7625			JBE 0x5b4b6b											
  value_methods.go:619	0x5b4b46		55			PUSHQ BP											
  value_methods.go:619	0x5b4b47		4889e5			MOVQ SP, BP											
  value_methods.go:619	0x5b4b4a		4883ec18		SUBQ $0x18, SP											
  value_methods.go:619	0x5b4b4e		488d4a10		LEAQ 0x10(DX), CX										
  value_methods.go:619	0x5b4b52		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:619	0x5b4b56		488d05336a5100		LEAQ 0x516a33(IP), AX										
  value_methods.go:619	0x5b4b5d		0f1f00			NOPL 0(AX)											
  value_methods.go:619	0x5b4b60		e83b17edff		CALL runtime.mapdelete(SB)									
  value_methods.go:619	0x5b4b65		4883c418		ADDQ $0x18, SP											
  value_methods.go:619	0x5b4b69		5d			POPQ BP												
  value_methods.go:619	0x5b4b6a		c3			RET												
  value_methods.go:619	0x5b4b6b		e8307aedff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:619	0x5b4b70		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB) /home/runner/work/vibescript/vibescript/head/vibes/value/value_methods.go
  value_methods.go:884	0x5b4c00		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:884	0x5b4c04		7625			JBE 0x5b4c2b											
  value_methods.go:884	0x5b4c06		55			PUSHQ BP											
  value_methods.go:884	0x5b4c07		4889e5			MOVQ SP, BP											
  value_methods.go:884	0x5b4c0a		4883ec18		SUBQ $0x18, SP											
  value_methods.go:884	0x5b4c0e		488b4a10		MOVQ 0x10(DX), CX										
  value_methods.go:884	0x5b4c12		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:884	0x5b4c16		488d0553675100		LEAQ 0x516753(IP), AX										
  value_methods.go:884	0x5b4c1d		0f1f00			NOPL 0(AX)											
  value_methods.go:884	0x5b4c20		e83ba9e5ff		CALL runtime.mapdelete_fast64(SB)								
  value_methods.go:884	0x5b4c25		4883c418		ADDQ $0x18, SP											
  value_methods.go:884	0x5b4c29		5d			POPQ BP												
  value_methods.go:884	0x5b4c2a		c3			RET												
  value_methods.go:884	0x5b4c2b		e87079edff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:884	0x5b4c30		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB) /home/runner/work/vibescript/vibescript/head/vibes/value/value_methods.go
  value_methods.go:861	0x5b4c40		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:861	0x5b4c44		7625			JBE 0x5b4c6b											
  value_methods.go:861	0x5b4c46		55			PUSHQ BP											
  value_methods.go:861	0x5b4c47		4889e5			MOVQ SP, BP											
  value_methods.go:861	0x5b4c4a		4883ec18		SUBQ $0x18, SP											
  value_methods.go:861	0x5b4c4e		488d4a10		LEAQ 0x10(DX), CX										
  value_methods.go:861	0x5b4c52		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:861	0x5b4c56		488d0533695100		LEAQ 0x516933(IP), AX										
  value_methods.go:861	0x5b4c5d		0f1f00			NOPL 0(AX)											
  value_methods.go:861	0x5b4c60		e83b16edff		CALL runtime.mapdelete(SB)									
  value_methods.go:861	0x5b4c65		4883c418		ADDQ $0x18, SP											
  value_methods.go:861	0x5b4c69		5d			POPQ BP												
  value_methods.go:861	0x5b4c6a		c3			RET												
  value_methods.go:861	0x5b4c6b		e83079edff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:861	0x5b4c70		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneIndex(SB) /home/runner/work/vibescript/vibescript/head/internal/runtime/members_string.go
  members_string.go:1231	0x6cfb20		493b6610		CMPQ SP, 0x10(R14)									
  members_string.go:1231	0x6cfb24		0f8601030000		JBE 0x6cfe2b										
  members_string.go:1231	0x6cfb2a		55			PUSHQ BP										
  members_string.go:1231	0x6cfb2b		4889e5			MOVQ SP, BP										
  members_string.go:1231	0x6cfb2e		4883ec50		SUBQ $0x50, SP										
  members_string.go:1231	0x6cfb32		48895c2468		MOVQ BX, 0x68(SP)									
  members_string.go:1231	0x6cfb37		48897c2478		MOVQ DI, 0x78(SP)									
  members_string.go:1231	0x6cfb3c		0f1f4000		NOPL 0(AX)										
  members_string.go:1232	0x6cfb40		4d85c0			TESTQ R8, R8										
  members_string.go:1232	0x6cfb43		0f8c74020000		JL 0x6cfdbd										
  members_string.go:5207	0x6cfb49		4885c9			TESTQ CX, CX										
  members_string.go:5207	0x6cfb4c		7504			JNE 0x6cfb52										
  members_string.go:5207	0x6cfb4e		31d2			XORL DX, DX										
  members_string.go:1248	0x6cfb50		eb3d			JMP 0x6cfb8f										
  members_string.go:1232	0x6cfb52		4889c2			MOVQ AX, DX										
  members_string.go:5210	0x6cfb55		48b8ffffffffffffff7f	MOVQ $0x7fffffffffffffff, AX								
  members_string.go:1232	0x6cfb5f		4989d1			MOVQ DX, R9										
  members_string.go:5210	0x6cfb62		31d2			XORL DX, DX										
  members_string.go:5210	0x6cfb64		48f7f1			DIVQ CX											
  members_string.go:5210	0x6cfb67		4883f804		CMPQ AX, $0x4										
  members_string.go:5210	0x6cfb6b		7d0f			JGE 0x6cfb7c										
  members_string.go:1265	0x6cfb6d		4c89c8			MOVQ R9, AX										
  members_string.go:1265	0x6cfb70		48baffffffffffffff7f	MOVQ $0x7fffffffffffffff, DX								
  members_string.go:1248	0x6cfb7a		eb13			JMP 0x6cfb8f										
  members_string.go:5213	0x6cfb7c		4889ca			MOVQ CX, DX										
  members_string.go:5213	0x6cfb7f		48c1e102		SHLQ $0x2, CX										
  members_string.go:1265	0x6cfb83		4c89c8			MOVQ R9, AX										
  ascii_scan_simd_amd64.go:9	0x6cfb86		4989ca			MOVQ CX, R10										
  ascii_scan_simd_amd64.go:9	0x6cfb89		4889d1			MOVQ DX, CX										
  members_string.go:1248	0x6cfb8c		4c89d2			MOVQ R10, DX										
  members_string.go:1248	0x6cfb8f		4839d6			CMPQ SI, DX										
  members_string.go:1248	0x6cfb92		0f8f14020000		JG 0x6cfdac										
  members_string.go:1232	0x6cfb98		4889442460		MOVQ AX, 0x60(SP)									
  members_string.go:1232	0x6cfb9d		4c89842488000000	MOVQ R8, 0x88(SP)									
  members_string.go:1232	0x6cfba5		4889b42480000000	MOVQ SI, 0x80(SP)									
  members_string.go:1232	0x6cfbad		48897c2478		MOVQ DI, 0x78(SP)									
  members_string.go:1232	0x6cfbb2		48894c2470		MOVQ CX, 0x70(SP)									
  members_string.go:1232	0x6cfbb7		48895c2468		MOVQ BX, 0x68(SP)									
  ascii_scan_simd_amd64.go:9	0x6cfbbc		4889d8			MOVQ BX, AX										
  ascii_scan_simd_amd64.go:9	0x6cfbbf		4889cb			MOVQ CX, BX										
  ascii_scan_simd_amd64.go:9	0x6cfbc2		e87929f4ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIVector(SB)		
  ascii_scan_simd_amd64.go:9	0x6cfbc7		84c0			TESTL AL, AL										
  members_string.go:1251	0x6cfbc9		7504			JNE 0x6cfbcf										
  members_string.go:1251	0x6cfbcb		31c0			XORL AX, AX										
  members_string.go:1251	0x6cfbcd		eb16			JMP 0x6cfbe5										
  ascii_scan_simd_amd64.go:9	0x6cfbcf		488b442478		MOVQ 0x78(SP), AX									
  ascii_scan_simd_amd64.go:9	0x6cfbd4		488b9c2480000000	MOVQ 0x80(SP), BX									
  ascii_scan_simd_amd64.go:9	0x6cfbdc		0f1f4000		NOPL 0(AX)										
  ascii_scan_simd_amd64.go:9	0x6cfbe0		e85b29f4ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIVector(SB)		
  members_string.go:1251	0x6cfbe5		84c0			TESTL AL, AL										
  members_string.go:1251	0x6cfbe7		0f8488000000		JE 0x6cfc75										
  members_string.go:1252	0x6cfbed		488b5c2470		MOVQ 0x70(SP), BX									
  members_string.go:1252	0x6cfbf2		488b842488000000	MOVQ 0x88(SP), AX									
  members_string.go:1252	0x6cfbfa		4839c3			CMPQ BX, AX										
  members_string.go:1252	0x6cfbfd		7c65			JL 0x6cfc64										
  members_string.go:1255	0x6cfbff		488bbc2480000000	MOVQ 0x80(SP), DI									
  members_string.go:1255	0x6cfc07		4885ff			TESTQ DI, DI										
  members_string.go:1255	0x6cfc0a		744e			JE 0x6cfc5a										
  members_string.go:1258	0x6cfc0c		4829c3			SUBQ AX, BX										
  members_string.go:1258	0x6cfc0f		4889da			MOVQ BX, DX										
  members_string.go:1258	0x6cfc12		48f7da			NEGQ DX											
  members_string.go:1258	0x6cfc15		48c1fa3f		SARQ $0x3f, DX										
  members_string.go:1258	0x6cfc19		4821c2			ANDQ AX, DX										
  members_string.go:1258	0x6cfc1c		488b742468		MOVQ 0x68(SP), SI									
  members_string.go:1258	0x6cfc21		488d0416		LEAQ 0(SI)(DX*1), AX									
  strings.go:1264		0x6cfc25		488b4c2478		MOVQ 0x78(SP), CX									
  strings.go:1264		0x6cfc2a		e87154d4ff		CALL internal/stringslite.Index(SB)							
  members_string.go:1259	0x6cfc2f		4885c0			TESTQ AX, AX										
  members_string.go:1259	0x6cfc32		7d11			JGE 0x6cfc45										
  members_string.go:1260	0x6cfc34		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1260	0x6cfc3b		31db			XORL BX, BX										
  members_string.go:1260	0x6cfc3d		31c9			XORL CX, CX										
  members_string.go:1260	0x6cfc3f		4883c450		ADDQ $0x50, SP										
  members_string.go:1260	0x6cfc43		5d			POPQ BP											
  members_string.go:1260	0x6cfc44		c3			RET											
  members_string.go:1262	0x6cfc45		488b942488000000	MOVQ 0x88(SP), DX									
  members_string.go:1262	0x6cfc4d		4801d0			ADDQ DX, AX										
  members_string.go:1262	0x6cfc50		31db			XORL BX, BX										
  members_string.go:1262	0x6cfc52		31c9			XORL CX, CX										
  members_string.go:1262	0x6cfc54		4883c450		ADDQ $0x50, SP										
  members_string.go:1262	0x6cfc58		5d			POPQ BP											
  members_string.go:1262	0x6cfc59		c3			RET											
  members_string.go:1256	0x6cfc5a		31db			XORL BX, BX										
  members_string.go:1256	0x6cfc5c		31c9			XORL CX, CX										
  members_string.go:1256	0x6cfc5e		4883c450		ADDQ $0x50, SP										
  members_string.go:1256	0x6cfc62		5d			POPQ BP											
  members_string.go:1256	0x6cfc63		c3			RET											
  members_string.go:1253	0x6cfc64		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1253	0x6cfc6b		31db			XORL BX, BX										
  members_string.go:1253	0x6cfc6d		31c9			XORL CX, CX										
  members_string.go:1253	0x6cfc6f		4883c450		ADDQ $0x50, SP										
  members_string.go:1253	0x6cfc73		5d			POPQ BP											
  members_string.go:1253	0x6cfc74		c3			RET											
  members_string.go:1264	0x6cfc75		488b442468		MOVQ 0x68(SP), AX									
  members_string.go:1264	0x6cfc7a		488b5c2470		MOVQ 0x70(SP), BX									
  members_string.go:1264	0x6cfc7f		90			NOPL											
  members_string.go:1264	0x6cfc80		e8dbf2ddff		CALL unicode/utf8.ValidString(SB)							
  members_string.go:1264	0x6cfc85		84c0			TESTL AL, AL										
  members_string.go:1264	0x6cfc87		7416			JE 0x6cfc9f										
  members_string.go:1264	0x6cfc89		488b442478		MOVQ 0x78(SP), AX									
  members_string.go:1264	0x6cfc8e		488b9c2480000000	MOVQ 0x80(SP), BX									
  members_string.go:1264	0x6cfc96		e8c5f2ddff		CALL unicode/utf8.ValidString(SB)							
  members_string.go:1264	0x6cfc9b		84c0			TESTL AL, AL										
  members_string.go:1264	0x6cfc9d		752f			JNE 0x6cfcce										
  members_string.go:1265	0x6cfc9f		488b442460		MOVQ 0x60(SP), AX									
  members_string.go:1265	0x6cfca4		488b5c2468		MOVQ 0x68(SP), BX									
  members_string.go:1265	0x6cfca9		488b4c2470		MOVQ 0x70(SP), CX									
  members_string.go:1265	0x6cfcae		488b7c2478		MOVQ 0x78(SP), DI									
  members_string.go:1265	0x6cfcb3		488bb42480000000	MOVQ 0x80(SP), SI									
  members_string.go:1265	0x6cfcbb		4c8b842488000000	MOVQ 0x88(SP), R8									
  members_string.go:1265	0x6cfcc3		e8f8020000		CALL github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB)		
  members_string.go:1265	0x6cfcc8		4883c450		ADDQ $0x50, SP										
  members_string.go:1265	0x6cfccc		5d			POPQ BP											
  members_string.go:1265	0x6cfccd		c3			RET											
  members_string.go:1267	0x6cfcce		488b442468		MOVQ 0x68(SP), AX									
  members_string.go:1267	0x6cfcd3		488b5c2470		MOVQ 0x70(SP), BX									
  members_string.go:1267	0x6cfcd8		488b8c2488000000	MOVQ 0x88(SP), CX									
  members_string.go:1267	0x6cfce0		e8fbfbffff		CALL github.com/mgomes/vibescript/internal/runtime.stringByteIndexForRuneOffset(SB)	
  members_string.go:1267	0x6cfce5		84db			TESTL BL, BL										
  members_string.go:1268	0x6cfce7		0f84ae000000		JE 0x6cfd9b										
  members_string.go:1271	0x6cfced		488bbc2480000000	MOVQ 0x80(SP), DI									
  members_string.go:1271	0x6cfcf5		4885ff			TESTQ DI, DI										
  members_string.go:1271	0x6cfcf8		0f848b000000		JE 0x6cfd89										
  members_string.go:1274	0x6cfcfe		488b5c2470		MOVQ 0x70(SP), BX									
  members_string.go:1274	0x6cfd03		4839d8			CMPQ AX, BX										
  members_string.go:1274	0x6cfd06		0f8719010000		JA 0x6cfe25										
  members_string.go:1267	0x6cfd0c		4889442430		MOVQ AX, 0x30(SP)									
  members_string.go:1274	0x6cfd11		4889da			MOVQ BX, DX										
  members_string.go:1274	0x6cfd14		4829c2			SUBQ AX, DX										
  members_string.go:1274	0x6cfd17		4889d3			MOVQ DX, BX										
  members_string.go:1274	0x6cfd1a		48f7da			NEGQ DX											
  members_string.go:1274	0x6cfd1d		48c1fa3f		SARQ $0x3f, DX										
  members_string.go:1274	0x6cfd21		4821c2			ANDQ AX, DX										
  members_string.go:1274	0x6cfd24		488b742468		MOVQ 0x68(SP), SI									
  members_string.go:1274	0x6cfd29		488d0432		LEAQ 0(DX)(SI*1), AX									
  strings.go:1264		0x6cfd2d		488b4c2478		MOVQ 0x78(SP), CX									
  strings.go:1264		0x6cfd32		e86953d4ff		CALL internal/stringslite.Index(SB)							
  members_string.go:1275	0x6cfd37		4885c0			TESTQ AX, AX										
  members_string.go:1275	0x6cfd3a		7c3c			JL 0x6cfd78										
  members_string.go:1278	0x6cfd3c		488b542430		MOVQ 0x30(SP), DX									
  members_string.go:1278	0x6cfd41		488d3402		LEAQ 0(DX)(AX*1), SI									
  members_string.go:1278	0x6cfd45		488b7c2470		MOVQ 0x70(SP), DI									
  members_string.go:1278	0x6cfd4a		4839f7			CMPQ DI, SI										
  members_string.go:1278	0x6cfd4d		0f82c8000000		JB 0x6cfe1b										
  strings.go:1264		0x6cfd53		4889442440		MOVQ AX, 0x40(SP)									
  members_string.go:1278	0x6cfd58		4889c3			MOVQ AX, BX										
  members_string.go:1278	0x6cfd5b		48f7d8			NEGQ AX											
  members_string.go:1278	0x6cfd5e		48c1f83f		SARQ $0x3f, AX										
  members_string.go:1278	0x6cfd62		4821d0			ANDQ DX, AX										
  members_string.go:1278	0x6cfd65		488b542468		MOVQ 0x68(SP), DX									
  members_string.go:1278	0x6cfd6a		4801d0			ADDQ DX, AX										
  members_string.go:1278	0x6cfd6d		4889442448		MOVQ AX, 0x48(SP)									
  utf8.go:448			0x6cfd72		31d2			XORL DX, DX										
  utf8.go:448			0x6cfd74		31f6			XORL SI, SI										
  utf8.go:448			0x6cfd76		eb59			JMP 0x6cfdd1										
  members_string.go:1276	0x6cfd78		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1276	0x6cfd7f		31db			XORL BX, BX										
  members_string.go:1276	0x6cfd81		31c9			XORL CX, CX										
  members_string.go:1276	0x6cfd83		4883c450		ADDQ $0x50, SP										
  members_string.go:1276	0x6cfd87		5d			POPQ BP											
  members_string.go:1276	0x6cfd88		c3			RET											
  members_string.go:1272	0x6cfd89		488b842488000000	MOVQ 0x88(SP), AX									
  members_string.go:1272	0x6cfd91		31db			XORL BX, BX										
  members_string.go:1272	0x6cfd93		31c9			XORL CX, CX										
  members_string.go:1272	0x6cfd95		4883c450		ADDQ $0x50, SP										
  members_string.go:1272	0x6cfd99		5d			POPQ BP											
  members_string.go:1272	0x6cfd9a		c3			RET											
  members_string.go:1269	0x6cfd9b		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1269	0x6cfda2		31db			XORL BX, BX										
  members_string.go:1269	0x6cfda4		31c9			XORL CX, CX										
  members_string.go:1269	0x6cfda6		4883c450		ADDQ $0x50, SP										
  members_string.go:1269	0x6cfdaa		5d			POPQ BP											
  members_string.go:1269	0x6cfdab		c3			RET											
  members_string.go:1249	0x6cfdac		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1249	0x6cfdb3		31db			XORL BX, BX										
  members_string.go:1249	0x6cfdb5		31c9			XORL CX, CX										
  members_string.go:1249	0x6cfdb7		4883c450		ADDQ $0x50, SP										
  members_string.go:1249	0x6cfdbb		5d			POPQ BP											
  members_string.go:1249	0x6cfdbc		c3			RET											
  members_string.go:1233	0x6cfdbd		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1233	0x6cfdc4		31db			XORL BX, BX										
  members_string.go:1233	0x6cfdc6		31c9			XORL CX, CX										
  members_string.go:1233	0x6cfdc8		4883c450		ADDQ $0x50, SP										
  members_string.go:1233	0x6cfdcc		5d			POPQ BP											
  members_string.go:1233	0x6cfdcd		c3			RET											
  utf8.go:449			0x6cfdce		48ffc2			INCQ DX											
  utf8.go:448			0x6cfdd1		4839f3			CMPQ BX, SI										
  utf8.go:448			0x6cfdd4		7e2f			JLE 0x6cfe05										
  utf8.go:448			0x6cfdd6		0fb63c30		MOVZX 0(AX)(SI*1), DI									
  utf8.go:448			0x6cfdda		83ff7f			CMPL DI, $0x7f										
  utf8.go:448			0x6cfddd		7f05			JG 0x6cfde4										
  utf8.go:448			0x6cfddf		48ffc6			INCQ SI											
  utf8.go:448			0x6cfde2		ebea			JMP 0x6cfdce										
  utf8.go:448			0x6cfde4		4889542438		MOVQ DX, 0x38(SP)									
  utf8.go:448			0x6cfde9		4889f1			MOVQ SI, CX										
  utf8.go:448			0x6cfdec		e80fd4daff		CALL runtime.decoderune(SB)								
  utf8.go:448			0x6cfdf1		488b442448		MOVQ 0x48(SP), AX									
  utf8.go:449			0x6cfdf6		488b542438		MOVQ 0x38(SP), DX									
  utf8.go:449			0x6cfdfb		4889de			MOVQ BX, SI										
  utf8.go:448			0x6cfdfe		488b5c2440		MOVQ 0x40(SP), BX									
  utf8.go:448			0x6cfe03		ebc9			JMP 0x6cfdce										
  members_string.go:1278	0x6cfe05		488bb42488000000	MOVQ 0x88(SP), SI									
  members_string.go:1278	0x6cfe0d		488d0416		LEAQ 0(SI)(DX*1), AX									
  members_string.go:1278	0x6cfe11		31db			XORL BX, BX										
  members_string.go:1278	0x6cfe13		31c9			XORL CX, CX										
  members_string.go:1278	0x6cfe15		4883c450		ADDQ $0x50, SP										
  members_string.go:1278	0x6cfe19		5d			POPQ BP											
  members_string.go:1278	0x6cfe1a		c3			RET											
  members_string.go:1278	0x6cfe1b		0f1f440000		NOPL 0(AX)(AX*1)									
  members_string.go:1278	0x6cfe20		e85be4dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1274	0x6cfe25		e856e4dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1274	0x6cfe2a		90			NOPL											
  members_string.go:1231	0x6cfe2b		4889442408		MOVQ AX, 0x8(SP)									
  members_string.go:1231	0x6cfe30		48895c2410		MOVQ BX, 0x10(SP)									
  members_string.go:1231	0x6cfe35		48894c2418		MOVQ CX, 0x18(SP)									
  members_string.go:1231	0x6cfe3a		48897c2420		MOVQ DI, 0x20(SP)									
  members_string.go:1231	0x6cfe3f		4889742428		MOVQ SI, 0x28(SP)									
  members_string.go:1231	0x6cfe44		4c89442430		MOVQ R8, 0x30(SP)									
  members_string.go:1231	0x6cfe49		e8f2c7dbff		CALL runtime.morestack_noctxt.abi0(SB)							
  members_string.go:1231	0x6cfe4e		488b442408		MOVQ 0x8(SP), AX									
  members_string.go:1231	0x6cfe53		488b5c2410		MOVQ 0x10(SP), BX									
  members_string.go:1231	0x6cfe58		488b4c2418		MOVQ 0x18(SP), CX									
  members_string.go:1231	0x6cfe5d		488b7c2420		MOVQ 0x20(SP), DI									
  members_string.go:1231	0x6cfe62		488b742428		MOVQ 0x28(SP), SI									
  members_string.go:1231	0x6cfe67		4c8b442430		MOVQ 0x30(SP), R8									
  members_string.go:1231	0x6cfe6c		e9affcffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneIndex(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB) /home/runner/work/vibescript/vibescript/head/internal/runtime/members_string.go
  members_string.go:1305	0x6cffc0		4c8da424c0feffff	LEAQ 0xfffffec0(SP), R12								
  members_string.go:1305	0x6cffc8		4d3b6610		CMPQ R12, 0x10(R14)									
  members_string.go:1305	0x6cffcc		0f865f020000		JBE 0x6d0231										
  members_string.go:1305	0x6cffd2		55			PUSHQ BP										
  members_string.go:1305	0x6cffd3		4889e5			MOVQ SP, BP										
  members_string.go:1305	0x6cffd6		4881ecb8010000		SUBQ $0x1b8, SP										
  members_string.go:1306	0x6cffdd		4c898424f0010000	MOVQ R8, 0x1f0(SP)									
  members_string.go:1306	0x6cffe5		48898c24d8010000	MOVQ CX, 0x1d8(SP)									
  members_string.go:1306	0x6cffed		48899c24d0010000	MOVQ BX, 0x1d0(SP)									
  members_string.go:1306	0x6cfff5		4889b424e8010000	MOVQ SI, 0x1e8(SP)									
  members_string.go:1306	0x6cfffd		4889bc24e0010000	MOVQ DI, 0x1e0(SP)									
  members_string.go:1306	0x6d0005		e876feffff		CALL github.com/mgomes/vibescript/internal/runtime.reserveFallbackSearchScratch(SB)	
  members_string.go:1306	0x6d000a		4885c0			TESTQ AX, AX										
  members_string.go:1306	0x6d000d		0f859b010000		JNE 0x6d01ae										
  members_string.go:1309	0x6d0013		488d8424e8000000	LEAQ 0xe8(SP), AX									
  members_string.go:1309	0x6d001b		488b9c24d0010000	MOVQ 0x1d0(SP), BX									
  members_string.go:1309	0x6d0023		488b8c24d8010000	MOVQ 0x1d8(SP), CX									
  members_string.go:1309	0x6d002b		e850add9ff		CALL runtime.stringtoslicerune(SB)							
  members_string.go:1309	0x6d0030		48899c2488010000	MOVQ BX, 0x188(SP)									
  members_string.go:1309	0x6d0038		48898424a8010000	MOVQ AX, 0x1a8(SP)									
  members_string.go:1309	0x6d0040		48898c2490010000	MOVQ CX, 0x190(SP)									
  members_string.go:1310	0x6d0048		488d442468		LEAQ 0x68(SP), AX									
  members_string.go:1310	0x6d004d		488b9c24e0010000	MOVQ 0x1e0(SP), BX									
  members_string.go:1310	0x6d0055		488b8c24e8010000	MOVQ 0x1e8(SP), CX									
  members_string.go:1310	0x6d005d		0f1f00			NOPL 0(AX)										
  members_string.go:1310	0x6d0060		e81badd9ff		CALL runtime.stringtoslicerune(SB)							
  members_string.go:1311	0x6d0065		488b942488010000	MOVQ 0x188(SP), DX									
  members_string.go:1311	0x6d006d		488bb424f0010000	MOVQ 0x1f0(SP), SI									
  members_string.go:1311	0x6d0075		4839f2			CMPQ DX, SI										
  members_string.go:1311	0x6d0078		0f8c1c010000		JL 0x6d019a										
  members_string.go:1311	0x6d007e		6690			NOPW											
  members_string.go:1314	0x6d0080		4885db			TESTQ BX, BX										
  members_string.go:1314	0x6d0083		0f8401010000		JE 0x6d018a										
  members_string.go:1317	0x6d0089		4989d0			MOVQ DX, R8										
  members_string.go:1317	0x6d008c		4829da			SUBQ BX, DX										
  members_string.go:1318	0x6d008f		4839d6			CMPQ SI, DX										
  members_string.go:1318	0x6d0092		0f8fde000000		JG 0x6d0176										
  members_string.go:1318	0x6d0098		0f1f840000000000	NOPL 0(AX)(AX*1)									
  members_string.go:1311	0x6d00a0		4939f0			CMPQ R8, SI										
  members_string.go:1328	0x6d00a3		0f8282010000		JB 0x6d022b										
  members_string.go:1310	0x6d00a9		48899c2470010000	MOVQ BX, 0x170(SP)									
  members_string.go:1310	0x6d00b1		48898424a0010000	MOVQ AX, 0x1a0(SP)									
  members_string.go:1310	0x6d00b9		48898c2478010000	MOVQ CX, 0x178(SP)									
  members_string.go:1328	0x6d00c1		4929f0			SUBQ SI, R8										
  members_string.go:1328	0x6d00c4		488bbc2490010000	MOVQ 0x190(SP), DI									
  members_string.go:1328	0x6d00cc		4829f7			SUBQ SI, DI										
  members_string.go:1328	0x6d00cf		488b9424a8010000	MOVQ 0x1a8(SP), DX									
  members_string.go:1328	0x6d00d7		488d1cb2		LEAQ 0(DX)(SI*4), BX									
  members_string.go:1328	0x6d00db		488d442448		LEAQ 0x48(SP), AX									
  members_string.go:1328	0x6d00e0		4c89c1			MOVQ R8, CX										
  members_string.go:1328	0x6d00e3		e818aed9ff		CALL runtime.slicerunetostring(SB)							
  members_string.go:1328	0x6d00e8		48898424b0010000	MOVQ AX, 0x1b0(SP)									
  members_string.go:1328	0x6d00f0		48899c2498010000	MOVQ BX, 0x198(SP)									
  members_string.go:1329	0x6d00f8		488d442428		LEAQ 0x28(SP), AX									
  members_string.go:1329	0x6d00fd		488b9c24a0010000	MOVQ 0x1a0(SP), BX									
  members_string.go:1329	0x6d0105		488b8c2470010000	MOVQ 0x170(SP), CX									
  members_string.go:1329	0x6d010d		488bbc2478010000	MOVQ 0x178(SP), DI									
  members_string.go:1329	0x6d0115		e8e6add9ff		CALL runtime.slicerunetostring(SB)							
  strings.go:1264		0x6d011a		4889c1			MOVQ AX, CX										
  strings.go:1264		0x6d011d		4889df			MOVQ BX, DI										
  strings.go:1264		0x6d0120		488b8424b0010000	MOVQ 0x1b0(SP), AX									
  strings.go:1264		0x6d0128		488b9c2498010000	MOVQ 0x198(SP), BX									
  strings.go:1264		0x6d0130		e86b4fd4ff		CALL internal/stringslite.Index(SB)							
  members_string.go:1330	0x6d0135		4885c0			TESTQ AX, AX										
  members_string.go:1330	0x6d0138		7c28			JL 0x6d0162										
  members_string.go:1333	0x6d013a		488b942498010000	MOVQ 0x198(SP), DX									
  members_string.go:1333	0x6d0142		4839d0			CMPQ AX, DX										
  members_string.go:1333	0x6d0145		0f87db000000		JA 0x6d0226										
  strings.go:1264		0x6d014b		4889842468010000	MOVQ AX, 0x168(SP)									
  utf8.go:448			0x6d0153		31d2			XORL DX, DX										
  utf8.go:448			0x6d0155		488bb424b0010000	MOVQ 0x1b0(SP), SI									
  utf8.go:448			0x6d015d		31c9			XORL CX, CX										
  utf8.go:448			0x6d015f		90			NOPL											
  utf8.go:448			0x6d0160		eb65			JMP 0x6d01c7										
  members_string.go:1331	0x6d0162		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1331	0x6d0169		31db			XORL BX, BX										
  members_string.go:1331	0x6d016b		31c9			XORL CX, CX										
  members_string.go:1331	0x6d016d		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1331	0x6d0174		5d			POPQ BP											
  members_string.go:1331	0x6d0175		c3			RET											
  members_string.go:1319	0x6d0176		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1319	0x6d017d		31db			XORL BX, BX										
  members_string.go:1319	0x6d017f		31c9			XORL CX, CX										
  members_string.go:1319	0x6d0181		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1319	0x6d0188		5d			POPQ BP											
  members_string.go:1319	0x6d0189		c3			RET											
  members_string.go:1315	0x6d018a		4889f0			MOVQ SI, AX										
  members_string.go:1315	0x6d018d		31db			XORL BX, BX										
  members_string.go:1315	0x6d018f		31c9			XORL CX, CX										
  members_string.go:1315	0x6d0191		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1315	0x6d0198		5d			POPQ BP											
  members_string.go:1315	0x6d0199		c3			RET											
  members_string.go:1312	0x6d019a		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1312	0x6d01a1		31db			XORL BX, BX										
  members_string.go:1312	0x6d01a3		31c9			XORL CX, CX										
  members_string.go:1312	0x6d01a5		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1312	0x6d01ac		5d			POPQ BP											
  members_string.go:1312	0x6d01ad		c3			RET											
  members_string.go:1307	0x6d01ae		4889d9			MOVQ BX, CX										
  members_string.go:1307	0x6d01b1		4889c3			MOVQ AX, BX										
  members_string.go:1307	0x6d01b4		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1307	0x6d01bb		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1307	0x6d01c2		5d			POPQ BP											
  members_string.go:1307	0x6d01c3		c3			RET											
  utf8.go:449			0x6d01c4		48ffc1			INCQ CX											
  utf8.go:448			0x6d01c7		4839d0			CMPQ AX, DX										
  utf8.go:448			0x6d01ca		7e41			JLE 0x6d020d										
  utf8.go:448			0x6d01cc		0fb63c16		MOVZX 0(SI)(DX*1), DI									
  utf8.go:448			0x6d01d0		83ff7f			CMPL DI, $0x7f										
  utf8.go:448			0x6d01d3		7f05			JG 0x6d01da										
  utf8.go:448			0x6d01d5		48ffc2			INCQ DX											
  utf8.go:448			0x6d01d8		ebea			JMP 0x6d01c4										
  utf8.go:448			0x6d01da		48898c2480010000	MOVQ CX, 0x180(SP)									
  utf8.go:448			0x6d01e2		4889c3			MOVQ AX, BX										
  utf8.go:448			0x6d01e5		4889d1			MOVQ DX, CX										
  utf8.go:448			0x6d01e8		4889f0			MOVQ SI, AX										
  utf8.go:448			0x6d01eb		e810d0daff		CALL runtime.decoderune(SB)								
  utf8.go:448			0x6d01f0		488b842468010000	MOVQ 0x168(SP), AX									
  utf8.go:449			0x6d01f8		488b8c2480010000	MOVQ 0x180(SP), CX									
  utf8.go:448			0x6d0200		488bb424b0010000	MOVQ 0x1b0(SP), SI									
  utf8.go:449			0x6d0208		4889da			MOVQ BX, DX										
  utf8.go:448			0x6d020b		ebb7			JMP 0x6d01c4										
  members_string.go:1333	0x6d020d		488b9424f0010000	MOVQ 0x1f0(SP), DX									
  members_string.go:1333	0x6d0215		488d040a		LEAQ 0(DX)(CX*1), AX									
  members_string.go:1333	0x6d0219		31db			XORL BX, BX										
  members_string.go:1333	0x6d021b		31c9			XORL CX, CX										
  members_string.go:1333	0x6d021d		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1333	0x6d0224		5d			POPQ BP											
  members_string.go:1333	0x6d0225		c3			RET											
  members_string.go:1333	0x6d0226		e855e0dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1328	0x6d022b		e850e0dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1328	0x6d0230		90			NOPL											
  members_string.go:1305	0x6d0231		4889442408		MOVQ AX, 0x8(SP)									
  members_string.go:1305	0x6d0236		48895c2410		MOVQ BX, 0x10(SP)									
  members_string.go:1305	0x6d023b		48894c2418		MOVQ CX, 0x18(SP)									
  members_string.go:1305	0x6d0240		48897c2420		MOVQ DI, 0x20(SP)									
  members_string.go:1305	0x6d0245		4889742428		MOVQ SI, 0x28(SP)									
  members_string.go:1305	0x6d024a		4c89442430		MOVQ R8, 0x30(SP)									
  members_string.go:1305	0x6d024f		e8ecc3dbff		CALL runtime.morestack_noctxt.abi0(SB)							
  members_string.go:1305	0x6d0254		488b442408		MOVQ 0x8(SP), AX									
  members_string.go:1305	0x6d0259		488b5c2410		MOVQ 0x10(SP), BX									
  members_string.go:1305	0x6d025e		488b4c2418		MOVQ 0x18(SP), CX									
  members_string.go:1305	0x6d0263		488b7c2420		MOVQ 0x20(SP), DI									
  members_string.go:1305	0x6d0268		488b742428		MOVQ 0x28(SP), SI									
  members_string.go:1305	0x6d026d		4c8b442430		MOVQ 0x30(SP), R8									
  members_string.go:1305	0x6d0272		e949fdffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB)		

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneSlice(SB) /home/runner/work/vibescript/vibescript/head/internal/runtime/members_string.go
  members_string.go:1454	0x6d0980		4c8d6424a0		LEAQ -0x60(SP), R12									
  members_string.go:1454	0x6d0985		4d3b6610		CMPQ R12, 0x10(R14)									
  members_string.go:1454	0x6d0989		0f865b020000		JBE 0x6d0bea										
  members_string.go:1454	0x6d098f		55			PUSHQ BP										
  members_string.go:1454	0x6d0990		4889e5			MOVQ SP, BP										
  members_string.go:1454	0x6d0993		4881ecd8000000		SUBQ $0xd8, SP										
  members_string.go:1454	0x6d099a		48898424e8000000	MOVQ AX, 0xe8(SP)									
  members_string.go:1455	0x6d09a2		4885ff			TESTQ DI, DI										
  members_string.go:1455	0x6d09a5		7c53			JL 0x6d09fa										
  members_string.go:1455	0x6d09a7		4889bc2400010000	MOVQ DI, 0x100(SP)									
  members_string.go:1455	0x6d09af		48898424e8000000	MOVQ AX, 0xe8(SP)									
  members_string.go:1455	0x6d09b7		48899c24f0000000	MOVQ BX, 0xf0(SP)									
  members_string.go:1455	0x6d09bf		90			NOPL											
  members_string.go:1458	0x6d09c0		4885c9			TESTQ CX, CX										
  members_string.go:1458	0x6d09c3		7d67			JGE 0x6d0a2c										
  members_string.go:1455	0x6d09c5		48898c24f8000000	MOVQ CX, 0xf8(SP)									
  ascii_scan_simd_amd64.go:9	0x6d09cd		e86e1bf4ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIVector(SB)		
  ascii_scan_simd_amd64.go:9	0x6d09d2		84c0			TESTL AL, AL										
  members_string.go:1186	0x6d09d4		751a			JNE 0x6d09f0										
  members_string.go:1189	0x6d09d6		90			NOPL											
  utf8.go:448			0x6d09d7		31d2			XORL DX, DX										
  utf8.go:448			0x6d09d9		31f6			XORL SI, SI										
  utf8.go:448			0x6d09db		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  utf8.go:448			0x6d09e3		488b8424e8000000	MOVQ 0xe8(SP), AX									
  utf8.go:448			0x6d09eb		e9b0010000		JMP 0x6d0ba0										
  members_string.go:1459	0x6d09f0		488b8424f0000000	MOVQ 0xf0(SP), AX									
  members_string.go:1459	0x6d09f8		eb11			JMP 0x6d0a0b										
  members_string.go:1456	0x6d09fa		31c0			XORL AX, AX										
  members_string.go:1456	0x6d09fc		31db			XORL BX, BX										
  members_string.go:1456	0x6d09fe		31c9			XORL CX, CX										
  members_string.go:1456	0x6d0a00		89cf			MOVL CX, DI										
  members_string.go:1456	0x6d0a02		4881c4d8000000		ADDQ $0xd8, SP										
  members_string.go:1456	0x6d0a09		5d			POPQ BP											
  members_string.go:1456	0x6d0a0a		c3			RET											
  members_string.go:1459	0x6d0a0b		488b9424f8000000	MOVQ 0xf8(SP), DX									
  members_string.go:1459	0x6d0a13		488d0c10		LEAQ 0(AX)(DX*1), CX									
  members_string.go:1460	0x6d0a17		4885c9			TESTQ CX, CX										
  members_string.go:1460	0x6d0a1a		7c4f			JL 0x6d0a6b										
  members_string.go:1464	0x6d0a1c		488b8424e8000000	MOVQ 0xe8(SP), AX									
  members_string.go:1464	0x6d0a24		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  members_string.go:1464	0x6d0a2c		e8afeeffff		CALL github.com/mgomes/vibescript/internal/runtime.stringByteIndexForRuneOffset(SB)	
  members_string.go:1464	0x6d0a31		84db			TESTL BL, BL										
  members_string.go:1465	0x6d0a33		7425			JE 0x6d0a5a										
  members_string.go:1464	0x6d0a35		48898424b8000000	MOVQ AX, 0xb8(SP)									
  members_string.go:1469	0x6d0a3d		488bbc2400010000	MOVQ 0x100(SP), DI									
  members_string.go:1469	0x6d0a45		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  members_string.go:1469	0x6d0a4d		488b8c24e8000000	MOVQ 0xe8(SP), CX									
  members_string.go:1464	0x6d0a55		4889c2			MOVQ AX, DX										
  members_string.go:1469	0x6d0a58		eb28			JMP 0x6d0a82										
  members_string.go:1466	0x6d0a5a		31c0			XORL AX, AX										
  members_string.go:1466	0x6d0a5c		31db			XORL BX, BX										
  members_string.go:1466	0x6d0a5e		31c9			XORL CX, CX										
  members_string.go:1466	0x6d0a60		89cf			MOVL CX, DI										
  members_string.go:1466	0x6d0a62		4881c4d8000000		ADDQ $0xd8, SP										
  members_string.go:1466	0x6d0a69		5d			POPQ BP											
  members_string.go:1466	0x6d0a6a		c3			RET											
  members_string.go:1461	0x6d0a6b		31c0			XORL AX, AX										
  members_string.go:1461	0x6d0a6d		31db			XORL BX, BX										
  members_string.go:1461	0x6d0a6f		31c9			XORL CX, CX										
  members_string.go:1461	0x6d0a71		89cf			MOVL CX, DI										
  members_string.go:1461	0x6d0a73		4881c4d8000000		ADDQ $0xd8, SP										
  members_string.go:1461	0x6d0a7a		5d			POPQ BP											
  members_string.go:1461	0x6d0a7b		c3			RET											
  members_string.go:1474	0x6d0a7c		4801f0			ADDQ SI, AX										
  members_string.go:1469	0x6d0a7f		48ffcf			DECQ DI											
  members_string.go:1469	0x6d0a82		4885ff			TESTQ DI, DI										
  members_string.go:1469	0x6d0a85		7e6e			JLE 0x6d0af5										
  members_string.go:1470	0x6d0a87		4839c3			CMPQ BX, AX										
  members_string.go:1470	0x6d0a8a		7469			JE 0x6d0af5										
  members_string.go:1473	0x6d0a8c		0f8203010000		JB 0x6d0b95										
  utf8.go:223			0x6d0a92		0fb63401		MOVZX 0(CX)(AX*1), SI									
  members_string.go:1473	0x6d0a96		4989d8			MOVQ BX, R8										
  members_string.go:1473	0x6d0a99		4929c0			SUBQ AX, R8										
  members_string.go:1473	0x6d0a9c		4c8d0c08		LEAQ 0(AX)(CX*1), R9									
  utf8.go:223			0x6d0aa0		4080fe80		CMPL SI, $0x80										
  utf8.go:223			0x6d0aa4		7307			JAE 0x6d0aad										
  utf8.go:223			0x6d0aa6		be01000000		MOVL $0x1, SI										
  members_string.go:1473	0x6d0aab		ebcf			JMP 0x6d0a7c										
  members_string.go:1469	0x6d0aad		4889bc24c8000000	MOVQ DI, 0xc8(SP)									
  members_string.go:1469	0x6d0ab5		48898424c0000000	MOVQ AX, 0xc0(SP)									
  utf8.go:226			0x6d0abd		4c89c8			MOVQ R9, AX										
  utf8.go:226			0x6d0ac0		4c89c3			MOVQ R8, BX										
  utf8.go:226			0x6d0ac3		e838deddff		CALL unicode/utf8.decodeRuneInStringSlow(SB)						
  members_string.go:1474	0x6d0ac8		488b8424c0000000	MOVQ 0xc0(SP), AX									
  utf8.go:223			0x6d0ad0		488b8c24e8000000	MOVQ 0xe8(SP), CX									
  members_string.go:1476	0x6d0ad8		488b9424b8000000	MOVQ 0xb8(SP), DX									
  members_string.go:1469	0x6d0ae0		488bbc24c8000000	MOVQ 0xc8(SP), DI									
  members_string.go:1473	0x6d0ae8		4889de			MOVQ BX, SI										
  members_string.go:1470	0x6d0aeb		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  members_string.go:1473	0x6d0af3		eb87			JMP 0x6d0a7c										
  members_string.go:1476	0x6d0af5		4839c3			CMPQ BX, AX										
  members_string.go:1476	0x6d0af8		0f8292000000		JB 0x6d0b90										
  members_string.go:1476	0x6d0afe		6690			NOPW											
  members_string.go:1476	0x6d0b00		4839c2			CMPQ DX, AX										
  members_string.go:1476	0x6d0b03		0f8782000000		JA 0x6d0b8b										
  members_string.go:1476	0x6d0b09		4829d0			SUBQ DX, AX										
  members_string.go:1476	0x6d0b0c		48898424b0000000	MOVQ AX, 0xb0(SP)									
  members_string.go:1476	0x6d0b14		4889c3			MOVQ AX, BX										
  members_string.go:1476	0x6d0b17		48f7d8			NEGQ AX											
  members_string.go:1476	0x6d0b1a		48c1f83f		SARQ $0x3f, AX										
  members_string.go:1476	0x6d0b1e		4821d0			ANDQ DX, AX										
  members_string.go:1476	0x6d0b21		4801c8			ADDQ CX, AX										
  members_string.go:1476	0x6d0b24		48898424d0000000	MOVQ AX, 0xd0(SP)									
  members_string.go:1441	0x6d0b2c		e82fe4ddff		CALL unicode/utf8.ValidString(SB)							
  members_string.go:1441	0x6d0b31		88442427		MOVB AL, 0x27(SP)									
  members_string.go:1441	0x6d0b35		84c0			TESTL AL, AL										
  members_string.go:1441	0x6d0b37		7412			JE 0x6d0b4b										
  members_string.go:1476	0x6d0b39		488b9c24b0000000	MOVQ 0xb0(SP), BX									
  members_string.go:1476	0x6d0b41		488b8424d0000000	MOVQ 0xd0(SP), AX									
  members_string.go:1476	0x6d0b49		eb2a			JMP 0x6d0b75										
  members_string.go:1444	0x6d0b4b		488d442428		LEAQ 0x28(SP), AX									
  members_string.go:1444	0x6d0b50		488b9c24d0000000	MOVQ 0xd0(SP), BX									
  members_string.go:1444	0x6d0b58		488b8c24b0000000	MOVQ 0xb0(SP), CX									
  members_string.go:1444	0x6d0b60		e81ba2d9ff		CALL runtime.stringtoslicerune(SB)							
  members_string.go:1444	0x6d0b65		4889cf			MOVQ CX, DI										
  members_string.go:1444	0x6d0b68		4889d9			MOVQ BX, CX										
  members_string.go:1444	0x6d0b6b		4889c3			MOVQ AX, BX										
  members_string.go:1444	0x6d0b6e		31c0			XORL AX, AX										
  members_string.go:1444	0x6d0b70		e88ba3d9ff		CALL runtime.slicerunetostring(SB)							
  members_string.go:1476	0x6d0b75		0fb64c2427		MOVZX 0x27(SP), CX									
  members_string.go:1476	0x6d0b7a		83f101			XORL $0x1, CX										
  members_string.go:1476	0x6d0b7d		bf01000000		MOVL $0x1, DI										
  members_string.go:1476	0x6d0b82		4881c4d8000000		ADDQ $0xd8, SP										
  members_string.go:1476	0x6d0b89		5d			POPQ BP											
  members_string.go:1476	0x6d0b8a		c3			RET											
  members_string.go:1476	0x6d0b8b		e8f0d6dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1476	0x6d0b90		e8ebd6dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1473	0x6d0b95		e8e6d6dbff		CALL runtime.panicBounds(SB)								
  utf8.go:449			0x6d0b9a		48ffc2			INCQ DX											
  utf8.go:449			0x6d0b9d		0f1f00			NOPL 0(AX)										
  utf8.go:448			0x6d0ba0		4839f3			CMPQ BX, SI										
  utf8.go:448			0x6d0ba3		7e3d			JLE 0x6d0be2										
  utf8.go:448			0x6d0ba5		440fb60430		MOVZX 0(AX)(SI*1), R8									
  utf8.go:448			0x6d0baa		4183f87f		CMPL R8, $0x7f										
  utf8.go:448			0x6d0bae		7f05			JG 0x6d0bb5										
  utf8.go:448			0x6d0bb0		48ffc6			INCQ SI											
  utf8.go:448			0x6d0bb3		ebe5			JMP 0x6d0b9a										
  utf8.go:448			0x6d0bb5		48899424a8000000	MOVQ DX, 0xa8(SP)									
  utf8.go:448			0x6d0bbd		4889f1			MOVQ SI, CX										
  utf8.go:448			0x6d0bc0		e83bc6daff		CALL runtime.decoderune(SB)								
  utf8.go:448			0x6d0bc5		488b8424e8000000	MOVQ 0xe8(SP), AX									
  utf8.go:449			0x6d0bcd		488b9424a8000000	MOVQ 0xa8(SP), DX									
  utf8.go:449			0x6d0bd5		4889de			MOVQ BX, SI										
  utf8.go:448			0x6d0bd8		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  utf8.go:448			0x6d0be0		ebb8			JMP 0x6d0b9a										
  members_string.go:1459	0x6d0be2		4889d0			MOVQ DX, AX										
  members_string.go:1459	0x6d0be5		e921feffff		JMP 0x6d0a0b										
  members_string.go:1454	0x6d0bea		4889442408		MOVQ AX, 0x8(SP)									
  members_string.go:1454	0x6d0bef		48895c2410		MOVQ BX, 0x10(SP)									
  members_string.go:1454	0x6d0bf4		48894c2418		MOVQ CX, 0x18(SP)									
  members_string.go:1454	0x6d0bf9		48897c2420		MOVQ DI, 0x20(SP)									
  members_string.go:1454	0x6d0bfe		6690			NOPW											
  members_string.go:1454	0x6d0c00		e83bbadbff		CALL runtime.morestack_noctxt.abi0(SB)							
  members_string.go:1454	0x6d0c05		488b442408		MOVQ 0x8(SP), AX									
  members_string.go:1454	0x6d0c0a		488b5c2410		MOVQ 0x10(SP), BX									
  members_string.go:1454	0x6d0c0f		488b4c2418		MOVQ 0x18(SP), CX									
  members_string.go:1454	0x6d0c14		488b7c2420		MOVQ 0x20(SP), DI									
  members_string.go:1454	0x6d0c19		e962fdffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneSlice(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func2(SB) /home/runner/work/vibescript/vibescript/head/internal/runtime/members_string.go
  members_string.go:3804	0x75ab20		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:3804	0x75ab24		0f861e010000		JBE 0x75ac48									
  members_string.go:3804	0x75ab2a		55			PUSHQ BP									
  members_string.go:3804	0x75ab2b		4889e5			MOVQ SP, BP									
  members_string.go:3804	0x75ab2e		4883ec40		SUBQ $0x40, SP									
  members_string.go:3804	0x75ab32		48898c2480000000	MOVQ CX, 0x80(SP)								
  members_string.go:3804	0x75ab3a		4889bc2488000000	MOVQ DI, 0x88(SP)								
  members_string.go:3804	0x75ab42		4c89842498000000	MOVQ R8, 0x98(SP)								
  members_string.go:3805	0x75ab4a		4d85c9			TESTQ R9, R9									
  members_string.go:3805	0x75ab4d		7466			JE 0x75abb5									
  errors.go:26			0x75ab4f		488d0594720600		LEAQ 0x67294(IP), AX								
  errors.go:26			0x75ab56		bb25000000		MOVL $0x25, BX									
  errors.go:26			0x75ab5b		31c9			XORL CX, CX									
  errors.go:26			0x75ab5d		31ff			XORL DI, DI									
  errors.go:26			0x75ab5f		89fe			MOVL DI, SI									
  errors.go:26			0x75ab61		e85a33d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75ab66		4885c0			TESTQ AX, AX									
  errors.go:26			0x75ab69		7536			JNE 0x75aba1									
  errors.go:31			0x75ab6b		90			NOPL										
  errors.go:65			0x75ab6c		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75ab71		488d1d28423900		LEAQ 0x394228(IP), BX								
  errors.go:65			0x75ab78		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75ab7d		0f1f00			NOPL 0(AX)									
  errors.go:65			0x75ab80		e81b68ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75ab85		48c7400825000000	MOVQ $0x25, 0x8(AX)								
  errors.go:65			0x75ab8d		488d1556720600		LEAQ 0x67256(IP), DX								
  errors.go:65			0x75ab94		488910			MOVQ DX, 0(AX)									
  members_string.go:3806	0x75ab97		4889c3			MOVQ AX, BX									
  members_string.go:3806	0x75ab9a		488d05af1f3c00		LEAQ 0x3c1faf(IP), AX								
  members_string.go:3806	0x75aba1		31c9			XORL CX, CX									
  members_string.go:3806	0x75aba3		31ff			XORL DI, DI									
  members_string.go:3806	0x75aba5		4889c6			MOVQ AX, SI									
  members_string.go:3806	0x75aba8		4989d8			MOVQ BX, R8									
  members_string.go:3806	0x75abab		31c0			XORL AX, AX									
  members_string.go:3806	0x75abad		31db			XORL BX, BX									
  members_string.go:3806	0x75abaf		4883c440		ADDQ $0x40, SP									
  members_string.go:3806	0x75abb3		5d			POPQ BP										
  members_string.go:3806	0x75abb4		c3			RET										
  members_string.go:3808	0x75abb5		4889d8			MOVQ BX, AX									
  members_string.go:3808	0x75abb8		4889cb			MOVQ CX, BX									
  members_string.go:3808	0x75abbb		4889f9			MOVQ DI, CX									
  members_string.go:3808	0x75abbe		4889f7			MOVQ SI, DI									
  members_string.go:3808	0x75abc1		e85a17e5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:3808	0x75abc6		4889442438		MOVQ AX, 0x38(SP)								
  members_string.go:3808	0x75abcb		48895c2428		MOVQ BX, 0x28(SP)								
  ascii_scan_simd_amd64.go:9	0x75abd0		e86b79ebff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIVector(SB)	
  ascii_scan_simd_amd64.go:9	0x75abd5		84c0			TESTL AL, AL									
  members_string.go:1186	0x75abd7		7512			JNE 0x75abeb									
  members_string.go:1189	0x75abd9		90			NOPL										
  utf8.go:448			0x75abda		31d2			XORL DX, DX									
  utf8.go:448			0x75abdc		4531c9			XORL R9, R9									
  utf8.go:448			0x75abdf		488b5c2428		MOVQ 0x28(SP), BX								
  utf8.go:448			0x75abe4		488b442438		MOVQ 0x38(SP), AX								
  utf8.go:448			0x75abe9		eb22			JMP 0x75ac0d									
  members_string.go:3808	0x75abeb		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:3808	0x75abf0		31db			XORL BX, BX									
  members_string.go:3808	0x75abf2		31c9			XORL CX, CX									
  members_string.go:3808	0x75abf4		4889c7			MOVQ AX, DI									
  members_string.go:3808	0x75abf7		89de			MOVL BX, SI									
  members_string.go:3808	0x75abf9		4189c8			MOVL CX, R8									
  members_string.go:3808	0x75abfc		b802000000		MOVL $0x2, AX									
  members_string.go:3808	0x75ac01		4883c440		ADDQ $0x40, SP									
  members_string.go:3808	0x75ac05		5d			POPQ BP										
  members_string.go:3808	0x75ac06		c3			RET										
  utf8.go:449			0x75ac07		48ffc2			INCQ DX										
  utf8.go:448			0x75ac0a		4989f9			MOVQ DI, R9									
  utf8.go:448			0x75ac0d		4c39cb			CMPQ BX, R9									
  utf8.go:448			0x75ac10		7e31			JLE 0x75ac43									
  utf8.go:448			0x75ac12		420fb63c08		MOVZX 0(AX)(R9*1), DI								
  utf8.go:448			0x75ac17		83ff7f			CMPL DI, $0x7f									
  utf8.go:448			0x75ac1a		7f06			JG 0x75ac22									
  utf8.go:448			0x75ac1c		498d7901		LEAQ 0x1(R9), DI								
  utf8.go:448			0x75ac20		ebe5			JMP 0x75ac07									
  utf8.go:448			0x75ac22		4889542430		MOVQ DX, 0x30(SP)								
  utf8.go:448			0x75ac27		4c89c9			MOVQ R9, CX									
  utf8.go:448			0x75ac2a		e8d125d2ff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x75ac2f		488b442438		MOVQ 0x38(SP), AX								
  utf8.go:449			0x75ac34		488b542430		MOVQ 0x30(SP), DX								
  utf8.go:449			0x75ac39		4889df			MOVQ BX, DI									
  utf8.go:448			0x75ac3c		488b5c2428		MOVQ 0x28(SP), BX								
  utf8.go:448			0x75ac41		ebc4			JMP 0x75ac07									
  members_string.go:3808	0x75ac43		4889d0			MOVQ DX, AX									
  members_string.go:3808	0x75ac46		eba8			JMP 0x75abf0									
  members_string.go:3804	0x75ac48		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:3804	0x75ac4d		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:3804	0x75ac52		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:3804	0x75ac57		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:3804	0x75ac5c		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:3804	0x75ac61		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:3804	0x75ac66		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:3804	0x75ac6b		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:3804	0x75ac70		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:3804	0x75ac75		e8c619d3ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:3804	0x75ac7a		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:3804	0x75ac7f		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:3804	0x75ac84		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:3804	0x75ac89		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:3804	0x75ac8e		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:3804	0x75ac93		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:3804	0x75ac98		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:3804	0x75ac9d		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:3804	0x75aca2		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:3804	0x75aca7		e974feffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func2(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func20(SB) /home/runner/work/vibescript/vibescript/head/internal/runtime/members_string.go
  members_string.go:4045	0x75d740		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4045	0x75d744		0f8615010000		JBE 0x75d85f									
  members_string.go:4045	0x75d74a		55			PUSHQ BP									
  members_string.go:4045	0x75d74b		4889e5			MOVQ SP, BP									
  members_string.go:4045	0x75d74e		4883ec38		SUBQ $0x38, SP									
  members_string.go:4045	0x75d752		48894c2478		MOVQ CX, 0x78(SP)								
  members_string.go:4045	0x75d757		4889bc2480000000	MOVQ DI, 0x80(SP)								
  members_string.go:4045	0x75d75f		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4046	0x75d767		4983f901		CMPQ R9, $0x1									
  members_string.go:4046	0x75d76b		0f858b000000		JNE 0x75d7fc									
  members_string.go:4049	0x75d771		49833804		CMPQ 0(R8), $0x4								
  members_string.go:4049	0x75d775		7413			JE 0x75d78a									
  members_string.go:4050	0x75d777		31c0			XORL AX, AX									
  members_string.go:4050	0x75d779		31db			XORL BX, BX									
  members_string.go:4050	0x75d77b		31c9			XORL CX, CX									
  members_string.go:4050	0x75d77d		31ff			XORL DI, DI									
  members_string.go:4050	0x75d77f		89de			MOVL BX, SI									
  members_string.go:4050	0x75d781		4189c8			MOVL CX, R8									
  members_string.go:4050	0x75d784		4883c438		ADDQ $0x38, SP									
  members_string.go:4050	0x75d788		5d			POPQ BP										
  members_string.go:4050	0x75d789		c3			RET										
  members_string.go:4046	0x75d78a		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4052	0x75d792		4889d8			MOVQ BX, AX									
  members_string.go:4052	0x75d795		4889cb			MOVQ CX, BX									
  members_string.go:4052	0x75d798		4889f9			MOVQ DI, CX									
  members_string.go:4052	0x75d79b		4889f7			MOVQ SI, DI									
  members_string.go:4052	0x75d79e		6690			NOPW										
  members_string.go:4052	0x75d7a0		e87bebe4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4052	0x75d7a5		4889442430		MOVQ AX, 0x30(SP)								
  members_string.go:4052	0x75d7aa		48895c2428		MOVQ BX, 0x28(SP)								
  members_string.go:4052	0x75d7af		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4052	0x75d7b7		488b02			MOVQ 0(DX), AX									
  members_string.go:4052	0x75d7ba		488b4a10		MOVQ 0x10(DX), CX								
  members_string.go:4052	0x75d7be		488b7a18		MOVQ 0x18(DX), DI								
  members_string.go:4052	0x75d7c2		488b5a08		MOVQ 0x8(DX), BX								
  members_string.go:4052	0x75d7c6		e855ebe4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:1152	0x75d7cb		4889c1			MOVQ AX, CX									
  members_string.go:1152	0x75d7ce		4889df			MOVQ BX, DI									
  members_string.go:1152	0x75d7d1		488b442430		MOVQ 0x30(SP), AX								
  members_string.go:1152	0x75d7d6		488b5c2428		MOVQ 0x28(SP), BX								
  members_string.go:1152	0x75d7db		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:1152	0x75d7e0		e83b48ebff		CALL github.com/mgomes/vibescript/internal/runtime.asciiCaseCompareImpl(SB)	
  members_string.go:4052	0x75d7e5		31db			XORL BX, BX									
  members_string.go:4052	0x75d7e7		31c9			XORL CX, CX									
  members_string.go:4052	0x75d7e9		4889c7			MOVQ AX, DI									
  members_string.go:4052	0x75d7ec		89de			MOVL BX, SI									
  members_string.go:4052	0x75d7ee		4189c8			MOVL CX, R8									
  members_string.go:4052	0x75d7f1		b802000000		MOVL $0x2, AX									
  members_string.go:4052	0x75d7f6		4883c438		ADDQ $0x38, SP									
  members_string.go:4052	0x75d7fa		5d			POPQ BP										
  members_string.go:4052	0x75d7fb		c3			RET										
  errors.go:26			0x75d7fc		488d056e700600		LEAQ 0x6706e(IP), AX								
  errors.go:26			0x75d803		bb29000000		MOVL $0x29, BX									
  errors.go:26			0x75d808		31c9			XORL CX, CX									
  errors.go:26			0x75d80a		31ff			XORL DI, DI									
  errors.go:26			0x75d80c		89fe			MOVL DI, SI									
  errors.go:26			0x75d80e		e8ad06d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75d813		4885c0			TESTQ AX, AX									
  errors.go:26			0x75d816		7533			JNE 0x75d84b									
  errors.go:31			0x75d818		90			NOPL										
  errors.go:65			0x75d819		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75d81e		488d1d7b153900		LEAQ 0x39157b(IP), BX								
  errors.go:65			0x75d825		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75d82a		e8713bccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75d82f		48c7400829000000	MOVQ $0x29, 0x8(AX)								
  errors.go:65			0x75d837		488d1533700600		LEAQ 0x67033(IP), DX								
  errors.go:65			0x75d83e		488910			MOVQ DX, 0(AX)									
  members_string.go:4047	0x75d841		4889c3			MOVQ AX, BX									
  members_string.go:4047	0x75d844		488d0505f33b00		LEAQ 0x3bf305(IP), AX								
  members_string.go:4047	0x75d84b		31c9			XORL CX, CX									
  members_string.go:4047	0x75d84d		31ff			XORL DI, DI									
  members_string.go:4047	0x75d84f		4889c6			MOVQ AX, SI									
  members_string.go:4047	0x75d852		4989d8			MOVQ BX, R8									
  members_string.go:4047	0x75d855		31c0			XORL AX, AX									
  members_string.go:4047	0x75d857		31db			XORL BX, BX									
  members_string.go:4047	0x75d859		4883c438		ADDQ $0x38, SP									
  members_string.go:4047	0x75d85d		5d			POPQ BP										
  members_string.go:4047	0x75d85e		c3			RET										
  members_string.go:4045	0x75d85f		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4045	0x75d864		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4045	0x75d869		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4045	0x75d86e		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4045	0x75d873		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4045	0x75d878		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4045	0x75d87d		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4045	0x75d882		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4045	0x75d887		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4045	0x75d88c		e8afedd2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4045	0x75d891		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4045	0x75d896		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4045	0x75d89b		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4045	0x75d8a0		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4045	0x75d8a5		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4045	0x75d8aa		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4045	0x75d8af		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4045	0x75d8b4		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4045	0x75d8b9		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4045	0x75d8be		6690			NOPW										
  members_string.go:4045	0x75d8c0		e97bfeffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func20(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func21(SB) /home/runner/work/vibescript/vibescript/head/internal/runtime/members_string.go
  members_string.go:4055	0x75d8e0		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4055	0x75d8e4		0f8615010000		JBE 0x75d9ff									
  members_string.go:4055	0x75d8ea		55			PUSHQ BP									
  members_string.go:4055	0x75d8eb		4889e5			MOVQ SP, BP									
  members_string.go:4055	0x75d8ee		4883ec38		SUBQ $0x38, SP									
  members_string.go:4055	0x75d8f2		48894c2478		MOVQ CX, 0x78(SP)								
  members_string.go:4055	0x75d8f7		4889bc2480000000	MOVQ DI, 0x80(SP)								
  members_string.go:4055	0x75d8ff		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4056	0x75d907		4983f901		CMPQ R9, $0x1									
  members_string.go:4056	0x75d90b		0f858b000000		JNE 0x75d99c									
  members_string.go:4059	0x75d911		49833804		CMPQ 0(R8), $0x4								
  members_string.go:4059	0x75d915		7413			JE 0x75d92a									
  members_string.go:4060	0x75d917		31c0			XORL AX, AX									
  members_string.go:4060	0x75d919		31db			XORL BX, BX									
  members_string.go:4060	0x75d91b		31c9			XORL CX, CX									
  members_string.go:4060	0x75d91d		31ff			XORL DI, DI									
  members_string.go:4060	0x75d91f		89de			MOVL BX, SI									
  members_string.go:4060	0x75d921		4189c8			MOVL CX, R8									
  members_string.go:4060	0x75d924		4883c438		ADDQ $0x38, SP									
  members_string.go:4060	0x75d928		5d			POPQ BP										
  members_string.go:4060	0x75d929		c3			RET										
  members_string.go:4056	0x75d92a		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4062	0x75d932		4889d8			MOVQ BX, AX									
  members_string.go:4062	0x75d935		4889cb			MOVQ CX, BX									
  members_string.go:4062	0x75d938		4889f9			MOVQ DI, CX									
  members_string.go:4062	0x75d93b		4889f7			MOVQ SI, DI									
  members_string.go:4062	0x75d93e		6690			NOPW										
  members_string.go:4062	0x75d940		e8dbe9e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4062	0x75d945		4889442430		MOVQ AX, 0x30(SP)								
  members_string.go:4062	0x75d94a		48895c2428		MOVQ BX, 0x28(SP)								
  members_string.go:4062	0x75d94f		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4062	0x75d957		488b02			MOVQ 0(DX), AX									
  members_string.go:4062	0x75d95a		488b5a08		MOVQ 0x8(DX), BX								
  members_string.go:4062	0x75d95e		488b4a10		MOVQ 0x10(DX), CX								
  members_string.go:4062	0x75d962		488b7a18		MOVQ 0x18(DX), DI								
  members_string.go:4062	0x75d966		e8b5e9e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4062	0x75d96b		4889c1			MOVQ AX, CX									
  members_string.go:4062	0x75d96e		4889df			MOVQ BX, DI									
  members_string.go:4062	0x75d971		488b442430		MOVQ 0x30(SP), AX								
  members_string.go:4062	0x75d976		488b5c2428		MOVQ 0x28(SP), BX								
  members_string.go:4062	0x75d97b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4062	0x75d980		e89b1ef7ff		CALL github.com/mgomes/vibescript/internal/runtime.caseInsensitiveEqual(SB)	
  members_string.go:4062	0x75d985		0fb6f8			MOVZX AL, DI									
  members_string.go:4062	0x75d988		b801000000		MOVL $0x1, AX									
  members_string.go:4062	0x75d98d		31db			XORL BX, BX									
  members_string.go:4062	0x75d98f		31c9			XORL CX, CX									
  members_string.go:4062	0x75d991		89de			MOVL BX, SI									
  members_string.go:4062	0x75d993		4189c8			MOVL CX, R8									
  members_string.go:4062	0x75d996		4883c438		ADDQ $0x38, SP									
  members_string.go:4062	0x75d99a		5d			POPQ BP										
  members_string.go:4062	0x75d99b		c3			RET										
  errors.go:26			0x75d99c		488d0543790600		LEAQ 0x67943(IP), AX								
  errors.go:26			0x75d9a3		bb2a000000		MOVL $0x2a, BX									
  errors.go:26			0x75d9a8		31c9			XORL CX, CX									
  errors.go:26			0x75d9aa		31ff			XORL DI, DI									
  errors.go:26			0x75d9ac		89fe			MOVL DI, SI									
  errors.go:26			0x75d9ae		e80d05d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75d9b3		4885c0			TESTQ AX, AX									
  errors.go:26			0x75d9b6		7533			JNE 0x75d9eb									
  errors.go:31			0x75d9b8		90			NOPL										
  errors.go:65			0x75d9b9		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75d9be		488d1ddb133900		LEAQ 0x3913db(IP), BX								
  errors.go:65			0x75d9c5		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75d9ca		e8d139ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75d9cf		48c740082a000000	MOVQ $0x2a, 0x8(AX)								
  errors.go:65			0x75d9d7		488d1508790600		LEAQ 0x67908(IP), DX								
  errors.go:65			0x75d9de		488910			MOVQ DX, 0(AX)									
  members_string.go:4057	0x75d9e1		4889c3			MOVQ AX, BX									
  members_string.go:4057	0x75d9e4		488d0565f13b00		LEAQ 0x3bf165(IP), AX								
  members_string.go:4057	0x75d9eb		31c9			XORL CX, CX									
  members_string.go:4057	0x75d9ed		31ff			XORL DI, DI									
  members_string.go:4057	0x75d9ef		4889c6			MOVQ AX, SI									
  members_string.go:4057	0x75d9f2		4989d8			MOVQ BX, R8									
  members_string.go:4057	0x75d9f5		31c0			XORL AX, AX									
  members_string.go:4057	0x75d9f7		31db			XORL BX, BX									
  members_string.go:4057	0x75d9f9		4883c438		ADDQ $0x38, SP									
  members_string.go:4057	0x75d9fd		5d			POPQ BP										
  members_string.go:4057	0x75d9fe		c3			RET										
  members_string.go:4055	0x75d9ff		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4055	0x75da04		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4055	0x75da09		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4055	0x75da0e		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4055	0x75da13		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4055	0x75da18		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4055	0x75da1d		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4055	0x75da22		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4055	0x75da27		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4055	0x75da2c		e80fecd2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4055	0x75da31		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4055	0x75da36		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4055	0x75da3b		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4055	0x75da40		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4055	0x75da45		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4055	0x75da4a		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4055	0x75da4f		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4055	0x75da54		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4055	0x75da59		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4055	0x75da5e		6690			NOPW										
  members_string.go:4055	0x75da60		e97bfeffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func21(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func22(SB) /home/runner/work/vibescript/vibescript/head/internal/runtime/members_string.go
  members_string.go:4065	0x75da80		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4065	0x75da84		0f8684000000		JBE 0x75db0e									
  members_string.go:4065	0x75da8a		55			PUSHQ BP									
  members_string.go:4065	0x75da8b		4889e5			MOVQ SP, BP									
  members_string.go:4065	0x75da8e		4883ec70		SUBQ $0x70, SP									
  members_string.go:4065	0x75da92		48898c24b0000000	MOVQ CX, 0xb0(SP)								
  members_string.go:4065	0x75da9a		4889bc24b8000000	MOVQ DI, 0xb8(SP)								
  members_string.go:4065	0x75daa2		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4066	0x75daaa		4c891c24		MOVQ R11, 0(SP)									
  members_string.go:4066	0x75daae		488b942480000000	MOVQ 0x80(SP), DX								
  members_string.go:4066	0x75dab6		4889542408		MOVQ DX, 0x8(SP)								
  members_string.go:4066	0x75dabb		488b942488000000	MOVQ 0x88(SP), DX								
  members_string.go:4066	0x75dac3		4889542410		MOVQ DX, 0x10(SP)								
  members_string.go:4066	0x75dac8		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4066	0x75dad0		4889542418		MOVQ DX, 0x18(SP)								
  members_string.go:4066	0x75dad5		488b942498000000	MOVQ 0x98(SP), DX								
  members_string.go:4066	0x75dadd		4889542420		MOVQ DX, 0x20(SP)								
  members_string.go:4066	0x75dae2		488d05fc830500		LEAQ 0x583fc(IP), AX								
  members_string.go:4066	0x75dae9		4d89d3			MOVQ R10, R11									
  members_string.go:4066	0x75daec		4d89ca			MOVQ R9, R10									
  members_string.go:4066	0x75daef		4d89c1			MOVQ R8, R9									
  members_string.go:4066	0x75daf2		4989f0			MOVQ SI, R8									
  members_string.go:4066	0x75daf5		4889fe			MOVQ DI, SI									
  members_string.go:4066	0x75daf8		4889cf			MOVQ CX, DI									
  members_string.go:4066	0x75dafb		4889d9			MOVQ BX, CX									
  members_string.go:4066	0x75dafe		bb0f000000		MOVL $0xf, BX									
  members_string.go:4066	0x75db03		e8b8ebfdff		CALL github.com/mgomes/vibescript/internal/runtime.comparableBetween(SB)	
  members_string.go:4066	0x75db08		4883c470		ADDQ $0x70, SP									
  members_string.go:4066	0x75db0c		5d			POPQ BP										
  members_string.go:4066	0x75db0d		c3			RET										
  members_string.go:4065	0x75db0e		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4065	0x75db13		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4065	0x75db18		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4065	0x75db1d		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4065	0x75db22		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4065	0x75db27		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4065	0x75db2c		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4065	0x75db31		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4065	0x75db36		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4065	0x75db3b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4065	0x75db40		e8fbead2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4065	0x75db45		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4065	0x75db4a		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4065	0x75db4f		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4065	0x75db54		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4065	0x75db59		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4065	0x75db5e		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4065	0x75db63		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4065	0x75db68		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4065	0x75db6d		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4065	0x75db72		e909ffffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func22(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func23(SB) /home/runner/work/vibescript/vibescript/head/internal/runtime/members_string.go
  members_string.go:4069	0x75db80		4c8da42410ffffff	LEAQ 0xffffff10(SP), R12									
  members_string.go:4069	0x75db88		4d3b6610		CMPQ R12, 0x10(R14)										
  members_string.go:4069	0x75db8c		0f863e080000		JBE 0x75e3d0											
  members_string.go:4069	0x75db92		55			PUSHQ BP											
  members_string.go:4069	0x75db93		4889e5			MOVQ SP, BP											
  members_string.go:4069	0x75db96		4881ec68010000		SUBQ $0x168, SP											
  members_string.go:4069	0x75db9d		48898c24a8010000	MOVQ CX, 0x1a8(SP)										
  members_string.go:4069	0x75dba5		4889bc24b0010000	MOVQ DI, 0x1b0(SP)										
  members_string.go:4069	0x75dbad		4c898424c0010000	MOVQ R8, 0x1c0(SP)										
  members_string.go:4070	0x75dbb5		4d85db			TESTQ R11, R11											
  members_string.go:4070	0x75dbb8		7405			JE 0x75dbbf											
  members_string.go:4070	0x75dbba		498b13			MOVQ 0(R11), DX											
  members_string.go:4070	0x75dbbd		eb02			JMP 0x75dbc1											
  members_string.go:4070	0x75dbbf		31d2			XORL DX, DX											
  members_string.go:4070	0x75dbc1		4885d2			TESTQ DX, DX											
  members_string.go:4070	0x75dbc4		0f8f63030000		JG 0x75df2d											
  members_string.go:4073	0x75dbca		4d85c9			TESTQ R9, R9											
  members_string.go:4073	0x75dbcd		7406			JE 0x75dbd5											
  members_string.go:4073	0x75dbcf		4983f902		CMPQ R9, $0x2											
  members_string.go:4073	0x75dbd3		7e66			JLE 0x75dc3b											
  errors.go:26			0x75dbd5		488d05bbb20600		LEAQ 0x6b2bb(IP), AX										
  errors.go:26			0x75dbdc		bb32000000		MOVL $0x32, BX											
  errors.go:26			0x75dbe1		31c9			XORL CX, CX											
  errors.go:26			0x75dbe3		31ff			XORL DI, DI											
  errors.go:26			0x75dbe5		89fe			MOVL DI, SI											
  errors.go:26			0x75dbe7		e8d402d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75dbec		4885c0			TESTQ AX, AX											
  errors.go:26			0x75dbef		7533			JNE 0x75dc24											
  errors.go:31			0x75dbf1		90			NOPL												
  errors.go:65			0x75dbf2		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75dbf7		488d1da2113900		LEAQ 0x3911a2(IP), BX										
  errors.go:65			0x75dbfe		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75dc03		e89837ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75dc08		48c7400832000000	MOVQ $0x32, 0x8(AX)										
  errors.go:65			0x75dc10		488d1580b20600		LEAQ 0x6b280(IP), DX										
  errors.go:65			0x75dc17		488910			MOVQ DX, 0(AX)											
  members_string.go:4074	0x75dc1a		4889c3			MOVQ AX, BX											
  members_string.go:4074	0x75dc1d		488d052cef3b00		LEAQ 0x3bef2c(IP), AX										
  members_string.go:4074	0x75dc24		31c9			XORL CX, CX											
  members_string.go:4074	0x75dc26		31ff			XORL DI, DI											
  members_string.go:4074	0x75dc28		4889c6			MOVQ AX, SI											
  members_string.go:4074	0x75dc2b		4989d8			MOVQ BX, R8											
  members_string.go:4074	0x75dc2e		31c0			XORL AX, AX											
  members_string.go:4074	0x75dc30		31db			XORL BX, BX											
  members_string.go:4074	0x75dc32		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4074	0x75dc39		5d			POPQ BP												
  members_string.go:4074	0x75dc3a		c3			RET												
  members_string.go:4070	0x75dc3b		4889842498010000	MOVQ AX, 0x198(SP)										
  members_string.go:4070	0x75dc43		4c899c24d8010000	MOVQ R11, 0x1d8(SP)										
  members_string.go:4070	0x75dc4b		4c898c24c8010000	MOVQ R9, 0x1c8(SP)										
  members_string.go:4070	0x75dc53		4889b42408010000	MOVQ SI, 0x108(SP)										
  members_string.go:4070	0x75dc5b		4c898424c0010000	MOVQ R8, 0x1c0(SP)										
  members_string.go:4070	0x75dc63		4c899424d0010000	MOVQ R10, 0x1d0(SP)										
  members_string.go:4070	0x75dc6b		4889bc2430010000	MOVQ DI, 0x130(SP)										
  members_string.go:4070	0x75dc73		48898c2400010000	MOVQ CX, 0x100(SP)										
  members_string.go:4070	0x75dc7b		48899c24f8000000	MOVQ BX, 0xf8(SP)										
  members_string.go:4076	0x75dc83		498b7808		MOVQ 0x8(R8), DI										
  members_string.go:4076	0x75dc87		498b7010		MOVQ 0x10(R8), SI										
  members_string.go:4076	0x75dc8b		498b5018		MOVQ 0x18(R8), DX										
  members_string.go:4076	0x75dc8f		498b08			MOVQ 0(R8), CX											
  members_string.go:4076	0x75dc92		488d05af6d0500		LEAQ 0x56daf(IP), AX										
  members_string.go:4076	0x75dc99		bb0c000000		MOVL $0xc, BX											
  members_string.go:4076	0x75dc9e		4989d0			MOVQ DX, R8											
  members_string.go:4076	0x75dca1		e87a44fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4077	0x75dca6		4885ff			TESTQ DI, DI											
  members_string.go:4077	0x75dca9		0f8567020000		JNE 0x75df16											
  members_string.go:4076	0x75dcaf		48899c24d0000000	MOVQ BX, 0xd0(SP)										
  members_string.go:4076	0x75dcb7		4889842420010000	MOVQ AX, 0x120(SP)										
  members_string.go:4076	0x75dcbf		888c24af000000		MOVB CL, 0xaf(SP)										
  members_string.go:4080	0x75dcc6		488b8424f8000000	MOVQ 0xf8(SP), AX										
  members_string.go:4080	0x75dcce		488b9c2400010000	MOVQ 0x100(SP), BX										
  members_string.go:4080	0x75dcd6		488b8c2430010000	MOVQ 0x130(SP), CX										
  members_string.go:4080	0x75dcde		488bbc2408010000	MOVQ 0x108(SP), DI										
  members_string.go:4080	0x75dce6		e835e6e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  members_string.go:4080	0x75dceb		4889842418010000	MOVQ AX, 0x118(SP)										
  members_string.go:4080	0x75dcf3		48899c24c8000000	MOVQ BX, 0xc8(SP)										
  members_string.go:4081	0x75dcfb		4889c1			MOVQ AX, CX											
  members_string.go:4081	0x75dcfe		4889df			MOVQ BX, DI											
  members_string.go:4081	0x75dd01		488bb42420010000	MOVQ 0x120(SP), SI										
  members_string.go:4081	0x75dd09		4c8b8424d0000000	MOVQ 0xd0(SP), R8										
  members_string.go:4081	0x75dd11		440fb68c24af000000	MOVZX 0xaf(SP), R9										
  members_string.go:4081	0x75dd1a		488d05276d0500		LEAQ 0x56d27(IP), AX										
  members_string.go:4081	0x75dd21		bb0c000000		MOVL $0xc, BX											
  members_string.go:4081	0x75dd26		e8555af7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)			
  members_string.go:4081	0x75dd2b		4885c0			TESTQ AX, AX											
  members_string.go:4081	0x75dd2e		0f85cb010000		JNE 0x75deff											
  members_string.go:4073	0x75dd34		488b9424c8010000	MOVQ 0x1c8(SP), DX										
  members_string.go:4073	0x75dd3c		0f1f4000		NOPL 0(AX)											
  members_string.go:4073	0x75dd40		4883fa02		CMPQ DX, $0x2											
  members_string.go:4096	0x75dd44		7408			JE 0x75dd4e											
  members_string.go:4096	0x75dd46		4531d2			XORL R10, R10											
  members_string.go:4096	0x75dd49		e959020000		JMP 0x75dfa7											
  members_string.go:4097	0x75dd4e		488b9424c0010000	MOVQ 0x1c0(SP), DX										
  members_string.go:4097	0x75dd56		488b4220		MOVQ 0x20(DX), AX										
  members_string.go:4097	0x75dd5a		488b5a28		MOVQ 0x28(DX), BX										
  members_string.go:4097	0x75dd5e		488b4a30		MOVQ 0x30(DX), CX										
  members_string.go:4097	0x75dd62		488b7a38		MOVQ 0x38(DX), DI										
  members_string.go:4097	0x75dd66		e8157dfdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)				
  members_string.go:4098	0x75dd6b		4885db			TESTQ BX, BX											
  members_string.go:4098	0x75dd6e		7468			JE 0x75ddd8											
  errors.go:26			0x75dd70		488d05d9260600		LEAQ 0x626d9(IP), AX										
  errors.go:26			0x75dd77		bb23000000		MOVL $0x23, BX											
  errors.go:26			0x75dd7c		31c9			XORL CX, CX											
  errors.go:26			0x75dd7e		31ff			XORL DI, DI											
  errors.go:26			0x75dd80		89fe			MOVL DI, SI											
  errors.go:26			0x75dd82		e83901d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75dd87		4885c0			TESTQ AX, AX											
  errors.go:26			0x75dd8a		7535			JNE 0x75ddc1											
  errors.go:31			0x75dd8c		90			NOPL												
  errors.go:65			0x75dd8d		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75dd92		488d1d07103900		LEAQ 0x391007(IP), BX										
  errors.go:65			0x75dd99		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75dd9e		6690			NOPW												
  errors.go:65			0x75dda0		e8fb35ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75dda5		48c7400823000000	MOVQ $0x23, 0x8(AX)										
  errors.go:65			0x75ddad		488d159c260600		LEAQ 0x6269c(IP), DX										
  errors.go:65			0x75ddb4		488910			MOVQ DX, 0(AX)											
  members_string.go:4099	0x75ddb7		4889c3			MOVQ AX, BX											
  members_string.go:4099	0x75ddba		488d058fed3b00		LEAQ 0x3bed8f(IP), AX										
  members_string.go:4099	0x75ddc1		31c9			XORL CX, CX											
  members_string.go:4099	0x75ddc3		31ff			XORL DI, DI											
  members_string.go:4099	0x75ddc5		4889c6			MOVQ AX, SI											
  members_string.go:4099	0x75ddc8		4989d8			MOVQ BX, R8											
  members_string.go:4099	0x75ddcb		31c0			XORL AX, AX											
  members_string.go:4099	0x75ddcd		31db			XORL BX, BX											
  members_string.go:4099	0x75ddcf		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4099	0x75ddd6		5d			POPQ BP												
  members_string.go:4099	0x75ddd7		c3			RET												
  members_string.go:4101	0x75ddd8		488b9c24c8000000	MOVQ 0xc8(SP), BX										
  members_string.go:4101	0x75dde0		4889c1			MOVQ AX, CX											
  members_string.go:4101	0x75dde3		488b842418010000	MOVQ 0x118(SP), AX										
  members_string.go:4101	0x75ddeb		e8301cf7ff		CALL github.com/mgomes/vibescript/internal/runtime.stringEffectiveOffset(SB)			
  members_string.go:4101	0x75ddf0		84db			TESTL BL, BL											
  members_string.go:4102	0x75ddf2		7449			JE 0x75de3d											
  members_string.go:4101	0x75ddf4		48898424d8000000	MOVQ AX, 0xd8(SP)										
  ascii_scan_simd_amd64.go:9	0x75ddfc		488b842418010000	MOVQ 0x118(SP), AX										
  ascii_scan_simd_amd64.go:9	0x75de04		488b9c24c8000000	MOVQ 0xc8(SP), BX										
  ascii_scan_simd_amd64.go:9	0x75de0c		e82f47ebff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIVector(SB)			
  ascii_scan_simd_amd64.go:9	0x75de11		84c0			TESTL AL, AL											
  members_string.go:1186	0x75de13		751b			JNE 0x75de30											
  members_string.go:1189	0x75de15		90			NOPL												
  utf8.go:448			0x75de16		31d2			XORL DX, DX											
  utf8.go:448			0x75de18		4531db			XORL R11, R11											
  utf8.go:448			0x75de1b		488bb424c8000000	MOVQ 0xc8(SP), SI										
  utf8.go:448			0x75de23		488bbc2418010000	MOVQ 0x118(SP), DI										
  utf8.go:448			0x75de2b		e950050000		JMP 0x75e380											
  members_string.go:4108	0x75de30		488b8424c8000000	MOVQ 0xc8(SP), AX										
  members_string.go:4108	0x75de38		e95b010000		JMP 0x75df98											
  members_string.go:4103	0x75de3d		488b842420010000	MOVQ 0x120(SP), AX										
  members_string.go:4103	0x75de45		488b9c24d0000000	MOVQ 0xd0(SP), BX										
  members_string.go:4103	0x75de4d		e88ed2faff		CALL github.com/mgomes/vibescript/internal/runtime.compileCachedRegex(SB)			
  members_string.go:4103	0x75de52		4885db			TESTQ BX, BX											
  members_string.go:4103	0x75de55		0f848e000000		JE 0x75dee9											
  members_string.go:4104	0x75de5b		440f11bc2458010000	MOVUPS X15, 0x158(SP)										
  members_string.go:4104	0x75de64		7404			JE 0x75de6a											
  members_string.go:4104	0x75de66		488b5b08		MOVQ 0x8(BX), BX										
  members_string.go:4104	0x75de6a		48899c2458010000	MOVQ BX, 0x158(SP)										
  members_string.go:4104	0x75de72		48898c2460010000	MOVQ CX, 0x160(SP)										
  errors.go:26			0x75de7a		488d0539ef0500		LEAQ 0x5ef39(IP), AX										
  errors.go:26			0x75de81		bb1e000000		MOVL $0x1e, BX											
  errors.go:26			0x75de86		488d8c2458010000	LEAQ 0x158(SP), CX										
  errors.go:26			0x75de8e		bf01000000		MOVL $0x1, DI											
  errors.go:26			0x75de93		89fe			MOVL DI, SI											
  errors.go:26			0x75de95		e82600d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75de9a		4885c0			TESTQ AX, AX											
  errors.go:26			0x75de9d		7533			JNE 0x75ded2											
  errors.go:31			0x75de9f		90			NOPL												
  errors.go:65			0x75dea0		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75dea5		488d1df40e3900		LEAQ 0x390ef4(IP), BX										
  errors.go:65			0x75deac		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75deb1		e8ea34ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75deb6		48c740081e000000	MOVQ $0x1e, 0x8(AX)										
  errors.go:65			0x75debe		488d15f5ee0500		LEAQ 0x5eef5(IP), DX										
  errors.go:65			0x75dec5		488910			MOVQ DX, 0(AX)											
  members_string.go:4104	0x75dec8		4889c3			MOVQ AX, BX											
  members_string.go:4104	0x75decb		488d057eec3b00		LEAQ 0x3bec7e(IP), AX										
  members_string.go:4104	0x75ded2		31c9			XORL CX, CX											
  members_string.go:4104	0x75ded4		31ff			XORL DI, DI											
  members_string.go:4104	0x75ded6		4889c6			MOVQ AX, SI											
  members_string.go:4104	0x75ded9		4989d8			MOVQ BX, R8											
  members_string.go:4104	0x75dedc		31c0			XORL AX, AX											
  members_string.go:4104	0x75dede		31db			XORL BX, BX											
  members_string.go:4104	0x75dee0		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4104	0x75dee7		5d			POPQ BP												
  members_string.go:4104	0x75dee8		c3			RET												
  members_string.go:4106	0x75dee9		31c0			XORL AX, AX											
  members_string.go:4106	0x75deeb		31db			XORL BX, BX											
  members_string.go:4106	0x75deed		31c9			XORL CX, CX											
  members_string.go:4106	0x75deef		31ff			XORL DI, DI											
  members_string.go:4106	0x75def1		89de			MOVL BX, SI											
  members_string.go:4106	0x75def3		4189c8			MOVL CX, R8											
  members_string.go:4106	0x75def6		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4106	0x75defd		5d			POPQ BP												
  members_string.go:4106	0x75defe		c3			RET												
  members_string.go:4082	0x75deff		31c9			XORL CX, CX											
  members_string.go:4082	0x75df01		31ff			XORL DI, DI											
  members_string.go:4082	0x75df03		4889c6			MOVQ AX, SI											
  members_string.go:4082	0x75df06		4989d8			MOVQ BX, R8											
  members_string.go:4082	0x75df09		31c0			XORL AX, AX											
  members_string.go:4082	0x75df0b		31db			XORL BX, BX											
  members_string.go:4082	0x75df0d		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4082	0x75df14		5d			POPQ BP												
  members_string.go:4082	0x75df15		c3			RET												
  members_string.go:4078	0x75df16		31c0			XORL AX, AX											
  members_string.go:4078	0x75df18		31db			XORL BX, BX											
  members_string.go:4078	0x75df1a		31c9			XORL CX, CX											
  members_string.go:4078	0x75df1c		4989f0			MOVQ SI, R8											
  members_string.go:4078	0x75df1f		4889fe			MOVQ DI, SI											
  members_string.go:4078	0x75df22		31ff			XORL DI, DI											
  members_string.go:4078	0x75df24		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4078	0x75df2b		5d			POPQ BP												
  members_string.go:4078	0x75df2c		c3			RET												
  errors.go:26			0x75df2d		488d05e9980600		LEAQ 0x698e9(IP), AX										
  errors.go:26			0x75df34		bb2e000000		MOVL $0x2e, BX											
  errors.go:26			0x75df39		31c9			XORL CX, CX											
  errors.go:26			0x75df3b		31ff			XORL DI, DI											
  errors.go:26			0x75df3d		89fe			MOVL DI, SI											
  errors.go:26			0x75df3f		90			NOPL												
  errors.go:26			0x75df40		e87bffd7ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75df45		4885c0			TESTQ AX, AX											
  errors.go:26			0x75df48		7537			JNE 0x75df81											
  errors.go:31			0x75df4a		90			NOPL												
  errors.go:65			0x75df4b		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75df50		488d1d490e3900		LEAQ 0x390e49(IP), BX										
  errors.go:65			0x75df57		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75df5c		0f1f4000		NOPL 0(AX)											
  errors.go:65			0x75df60		e83b34ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75df65		48c740082e000000	MOVQ $0x2e, 0x8(AX)										
  errors.go:65			0x75df6d		488d15a9980600		LEAQ 0x698a9(IP), DX										
  errors.go:65			0x75df74		488910			MOVQ DX, 0(AX)											
  members_string.go:4071	0x75df77		4889c3			MOVQ AX, BX											
  members_string.go:4071	0x75df7a		488d05cfeb3b00		LEAQ 0x3bebcf(IP), AX										
  members_string.go:4071	0x75df81		31c9			XORL CX, CX											
  members_string.go:4071	0x75df83		31ff			XORL DI, DI											
  members_string.go:4071	0x75df85		4889c6			MOVQ AX, SI											
  members_string.go:4071	0x75df88		4989d8			MOVQ BX, R8											
  members_string.go:4071	0x75df8b		31c0			XORL AX, AX											
  members_string.go:4071	0x75df8d		31db			XORL BX, BX											
  members_string.go:4071	0x75df8f		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4071	0x75df96		5d			POPQ BP												
  members_string.go:4071	0x75df97		c3			RET												
  members_string.go:4108	0x75df98		4c8b9424d8000000	MOVQ 0xd8(SP), R10										
  members_string.go:4108	0x75dfa0		4939c2			CMPQ R10, AX											
  members_string.go:4111	0x75dfa3		4c0f4fd0		CMOVG AX, R10											
  members_string.go:2100	0x75dfa7		488b0592654000		MOVQ github.com/mgomes/vibescript/internal/runtime.compiledRegexps(SB), AX			
  members_string.go:4113	0x75dfae		90			NOPL												
  members_string.go:2100	0x75dfaf		488d1d926a0500		LEAQ 0x56a92(IP), BX										
  members_string.go:2100	0x75dfb6		b90c000000		MOVL $0xc, CX											
  members_string.go:2100	0x75dfbb		488bbc2418010000	MOVQ 0x118(SP), DI										
  members_string.go:2100	0x75dfc3		488bb424c8000000	MOVQ 0xc8(SP), SI										
  members_string.go:2100	0x75dfcb		4c8b842420010000	MOVQ 0x120(SP), R8										
  members_string.go:2100	0x75dfd3		4c8b8c24d0000000	MOVQ 0xd0(SP), R9										
  members_string.go:2100	0x75dfdb		0f1f440000		NOPL 0(AX)(AX*1)										
  members_string.go:2100	0x75dfe0		e8bb5df7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexSubmatchFromRuneOffsetWithCache(SB)	
  members_string.go:4114	0x75dfe5		4885ff			TESTQ DI, DI											
  members_string.go:4114	0x75dfe8		0f85a5010000		JNE 0x75e193											
  members_string.go:4117	0x75dfee		4885c0			TESTQ AX, AX											
  members_string.go:4117	0x75dff1		0f8486010000		JE 0x75e17d											
  members_string.go:2100	0x75dff7		48898c24b8000000	MOVQ CX, 0xb8(SP)										
  members_string.go:2100	0x75dfff		48899c24b0000000	MOVQ BX, 0xb0(SP)										
  members_string.go:2100	0x75e007		4889842410010000	MOVQ AX, 0x110(SP)										
  members_string.go:4122	0x75e00f		488b842420010000	MOVQ 0x120(SP), AX										
  members_string.go:4122	0x75e017		488b9c24d0000000	MOVQ 0xd0(SP), BX										
  members_string.go:4122	0x75e01f		90			NOPL												
  members_string.go:4122	0x75e020		e8fb5cf7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexSubexpNames(SB)				
  members_string.go:4122	0x75e025		488b9424f8000000	MOVQ 0xf8(SP), DX										
  members_string.go:4122	0x75e02d		48891424		MOVQ DX, 0(SP)											
  members_string.go:4122	0x75e031		488b942400010000	MOVQ 0x100(SP), DX										
  members_string.go:4122	0x75e039		4889542408		MOVQ DX, 0x8(SP)										
  members_string.go:4122	0x75e03e		488b942430010000	MOVQ 0x130(SP), DX										
  members_string.go:4122	0x75e046		4889542410		MOVQ DX, 0x10(SP)										
  members_string.go:4122	0x75e04b		488b942408010000	MOVQ 0x108(SP), DX										
  members_string.go:4122	0x75e053		4889542418		MOVQ DX, 0x18(SP)										
  members_string.go:4122	0x75e058		488b9424c0010000	MOVQ 0x1c0(SP), DX										
  members_string.go:4122	0x75e060		4889542420		MOVQ DX, 0x20(SP)										
  members_string.go:4122	0x75e065		488b9424c8010000	MOVQ 0x1c8(SP), DX										
  members_string.go:4122	0x75e06d		4889542428		MOVQ DX, 0x28(SP)										
  members_string.go:4122	0x75e072		488b9424d0010000	MOVQ 0x1d0(SP), DX										
  members_string.go:4122	0x75e07a		4889542430		MOVQ DX, 0x30(SP)										
  members_string.go:4122	0x75e07f		488b9424d8010000	MOVQ 0x1d8(SP), DX										
  members_string.go:4122	0x75e087		4889542438		MOVQ DX, 0x38(SP)										
  members_string.go:4122	0x75e08c		488b942478010000	MOVQ 0x178(SP), DX										
  members_string.go:4122	0x75e094		4889542440		MOVQ DX, 0x40(SP)										
  members_string.go:4122	0x75e099		488b942480010000	MOVQ 0x180(SP), DX										
  members_string.go:4122	0x75e0a1		4889542448		MOVQ DX, 0x48(SP)										
  members_string.go:4122	0x75e0a6		488b942488010000	MOVQ 0x188(SP), DX										
  members_string.go:4122	0x75e0ae		4889542450		MOVQ DX, 0x50(SP)										
  members_string.go:4122	0x75e0b3		488b942490010000	MOVQ 0x190(SP), DX										
  members_string.go:4122	0x75e0bb		4889542458		MOVQ DX, 0x58(SP)										
  members_string.go:4122	0x75e0c0		488bbc2410010000	MOVQ 0x110(SP), DI										
  members_string.go:4122	0x75e0c8		488bb424b0000000	MOVQ 0xb0(SP), SI										
  members_string.go:4122	0x75e0d0		4c8b8424b8000000	MOVQ 0xb8(SP), R8										
  members_string.go:4122	0x75e0d8		4989c1			MOVQ AX, R9											
  members_string.go:4122	0x75e0db		4989da			MOVQ BX, R10											
  members_string.go:4122	0x75e0de		4989cb			MOVQ CX, R11											
  members_string.go:4122	0x75e0e1		488b842498010000	MOVQ 0x198(SP), AX										
  members_string.go:4122	0x75e0e9		488b9c2418010000	MOVQ 0x118(SP), BX										
  members_string.go:4122	0x75e0f1		488b8c24c8000000	MOVQ 0xc8(SP), CX										
  members_string.go:4122	0x75e0f9		e8228ff3ff		CALL github.com/mgomes/vibescript/internal/runtime.newMatchData(SB)				
  members_string.go:4122	0x75e0fe		6690			NOPW												
  members_string.go:4123	0x75e100		4885f6			TESTQ SI, SI											
  members_string.go:4123	0x75e103		7567			JNE 0x75e16c											
  members_string.go:4122	0x75e105		48898424f0000000	MOVQ AX, 0xf0(SP)										
  members_string.go:4122	0x75e10d		48899c24e8000000	MOVQ BX, 0xe8(SP)										
  members_string.go:4122	0x75e115		48898c2428010000	MOVQ CX, 0x128(SP)										
  members_string.go:4122	0x75e11d		4889bc24e0000000	MOVQ DI, 0xe0(SP)										
  aliases.go:1400		0x75e125		90			NOPL												
  value_accessors.go:180	0x75e126		488b942478010000	MOVQ 0x178(SP), DX										
  value_accessors.go:180	0x75e12e		4883fa0f		CMPQ DX, $0xf											
  value_accessors.go:180	0x75e132		7531			JNE 0x75e165											
  value_accessors.go:183	0x75e134		4c8b9c2480010000	MOVQ 0x180(SP), R11										
  value_accessors.go:183	0x75e13c		0f1f4000		NOPL 0(AX)											
  value_accessors.go:183	0x75e140		4d85db			TESTQ R11, R11											
  value_accessors.go:183	0x75e143		7414			JE 0x75e159											
  value_accessors.go:183	0x75e145		4c8b2594543f00		MOVQ github.com/mgomes/vibescript/internal/runtime..typeAssert.357(SB), R12			
  value_accessors.go:183	0x75e14c		4d8b2c24		MOVQ 0(R12), R13										
  value_accessors.go:183	0x75e150		458b7b10		MOVL 0x10(R11), R15										
  value_accessors.go:183	0x75e154		e9ac010000		JMP 0x75e305											
  members_string.go:4069	0x75e159		4c89de			MOVQ R11, SI											
  members_string.go:4069	0x75e15c		0f1f4000		NOPL 0(AX)											
  value_accessors.go:183	0x75e160		e98f010000		JMP 0x75e2f4											
  value_accessors.go:183	0x75e165		31f6			XORL SI, SI											
  value_accessors.go:183	0x75e167		4531c0			XORL R8, R8											
  aliases.go:1367		0x75e16a		eb3e			JMP 0x75e1aa											
  members_string.go:4124	0x75e16c		31c0			XORL AX, AX											
  members_string.go:4124	0x75e16e		31db			XORL BX, BX											
  members_string.go:4124	0x75e170		31c9			XORL CX, CX											
  members_string.go:4124	0x75e172		31ff			XORL DI, DI											
  members_string.go:4124	0x75e174		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4124	0x75e17b		5d			POPQ BP												
  members_string.go:4124	0x75e17c		c3			RET												
  members_string.go:4120	0x75e17d		31c0			XORL AX, AX											
  members_string.go:4120	0x75e17f		31db			XORL BX, BX											
  members_string.go:4120	0x75e181		31c9			XORL CX, CX											
  members_string.go:4120	0x75e183		31ff			XORL DI, DI											
  members_string.go:4120	0x75e185		89de			MOVL BX, SI											
  members_string.go:4120	0x75e187		4189c8			MOVL CX, R8											
  members_string.go:4120	0x75e18a		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4120	0x75e191		5d			POPQ BP												
  members_string.go:4120	0x75e192		c3			RET												
  members_string.go:4115	0x75e193		31c0			XORL AX, AX											
  members_string.go:4115	0x75e195		31db			XORL BX, BX											
  members_string.go:4115	0x75e197		31c9			XORL CX, CX											
  members_string.go:4115	0x75e199		4989f0			MOVQ SI, R8											
  members_string.go:4115	0x75e19c		4889fe			MOVQ DI, SI											
  members_string.go:4115	0x75e19f		31ff			XORL DI, DI											
  members_string.go:4115	0x75e1a1		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4115	0x75e1a8		5d			POPQ BP												
  members_string.go:4115	0x75e1a9		c3			RET												
  aliases.go:1367		0x75e1aa		4c8d1dfff13b00		LEAQ 0x3bf1ff(IP), R11										
  aliases.go:1367		0x75e1b1		4c39de			CMPQ SI, R11											
  aliases.go:1367		0x75e1b4		740a			JE 0x75e1c0											
  aliases.go:1367		0x75e1b6		4531c0			XORL R8, R8											
  aliases.go:1367		0x75e1b9		0f1f8000000000		NOPL 0(AX)											
  members_string.go:4126	0x75e1c0		4d85c0			TESTQ R8, R8											
  members_string.go:4126	0x75e1c3		0f841d010000		JE 0x75e2e6											
  members_string.go:4130	0x75e1c9		4c8b9c24f8000000	MOVQ 0xf8(SP), R11										
  members_string.go:4130	0x75e1d1		4c891c24		MOVQ R11, 0(SP)											
  members_string.go:4130	0x75e1d5		4c8b9c2400010000	MOVQ 0x100(SP), R11										
  members_string.go:4130	0x75e1dd		4c895c2408		MOVQ R11, 0x8(SP)										
  members_string.go:4130	0x75e1e2		4c8b9c2430010000	MOVQ 0x130(SP), R11										
  members_string.go:4130	0x75e1ea		4c895c2410		MOVQ R11, 0x10(SP)										
  members_string.go:4130	0x75e1ef		4c8b9c2408010000	MOVQ 0x108(SP), R11										
  members_string.go:4130	0x75e1f7		4c895c2418		MOVQ R11, 0x18(SP)										
  members_string.go:4130	0x75e1fc		4c8b9c24c0010000	MOVQ 0x1c0(SP), R11										
  members_string.go:4130	0x75e204		4c895c2420		MOVQ R11, 0x20(SP)										
  members_string.go:4130	0x75e209		4c8b9c24c8010000	MOVQ 0x1c8(SP), R11										
  members_string.go:4130	0x75e211		4c895c2428		MOVQ R11, 0x28(SP)										
  members_string.go:4130	0x75e216		4c8b9c24d0010000	MOVQ 0x1d0(SP), R11										
  members_string.go:4130	0x75e21e		4c895c2430		MOVQ R11, 0x30(SP)										
  members_string.go:4130	0x75e223		488b842498010000	MOVQ 0x198(SP), AX										
  members_string.go:4130	0x75e22b		4889d3			MOVQ DX, BX											
  members_string.go:4130	0x75e22e		488b8c2480010000	MOVQ 0x180(SP), CX										
  members_string.go:4130	0x75e236		488bbc2488010000	MOVQ 0x188(SP), DI										
  members_string.go:4130	0x75e23e		488bb42490010000	MOVQ 0x190(SP), SI										
  members_string.go:4130	0x75e246		4c8d05fb670500		LEAQ 0x567fb(IP), R8										
  members_string.go:4130	0x75e24d		41b90c000000		MOVL $0xc, R9											
  members_string.go:4130	0x75e253		4c8b9424d8010000	MOVQ 0x1d8(SP), R10										
  members_string.go:4130	0x75e25b		0f1f440000		NOPL 0(AX)(AX*1)										
  members_string.go:4130	0x75e260		e85b4bf1ff		CALL github.com/mgomes/vibescript/internal/runtime.newBlockCallRunner(SB)			
  members_string.go:4131	0x75e265		4885db			TESTQ BX, BX											
  members_string.go:4131	0x75e268		7417			JE 0x75e281											
  members_string.go:4132	0x75e26a		31c0			XORL AX, AX											
  members_string.go:4132	0x75e26c		31ff			XORL DI, DI											
  members_string.go:4132	0x75e26e		4889de			MOVQ BX, SI											
  members_string.go:4132	0x75e271		4989c8			MOVQ CX, R8											
  members_string.go:4132	0x75e274		31db			XORL BX, BX											
  members_string.go:4132	0x75e276		31c9			XORL CX, CX											
  members_string.go:4132	0x75e278		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4132	0x75e27f		5d			POPQ BP												
  members_string.go:4132	0x75e280		c3			RET												
  members_string.go:4134	0x75e281		488b9424f0000000	MOVQ 0xf0(SP), DX										
  members_string.go:4134	0x75e289		4889942438010000	MOVQ DX, 0x138(SP)										
  members_string.go:4134	0x75e291		488b9424e8000000	MOVQ 0xe8(SP), DX										
  members_string.go:4134	0x75e299		4889942440010000	MOVQ DX, 0x140(SP)										
  members_string.go:4134	0x75e2a1		488b9424e0000000	MOVQ 0xe0(SP), DX										
  members_string.go:4134	0x75e2a9		4889942450010000	MOVQ DX, 0x150(SP)										
  members_string.go:4134	0x75e2b1		488b942428010000	MOVQ 0x128(SP), DX										
  members_string.go:4134	0x75e2b9		4889942448010000	MOVQ DX, 0x148(SP)										
  eval.go:1785			0x75e2c1		488d9c2438010000	LEAQ 0x138(SP), BX										
  eval.go:1785			0x75e2c9		b901000000		MOVL $0x1, CX											
  eval.go:1785			0x75e2ce		89cf			MOVL CX, DI											
  eval.go:1785			0x75e2d0		31f6			XORL SI, SI											
  eval.go:1785			0x75e2d2		4531c0			XORL R8, R8											
  eval.go:1785			0x75e2d5		4589c1			MOVL R8, R9											
  eval.go:1785			0x75e2d8		e82350f1ff		CALL github.com/mgomes/vibescript/internal/runtime.(*blockCallRunner).callWithChargedRoots(SB)	
  members_string.go:4134	0x75e2dd		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4134	0x75e2e4		5d			POPQ BP												
  members_string.go:4134	0x75e2e5		c3			RET												
  members_string.go:4136	0x75e2e6		31f6			XORL SI, SI											
  members_string.go:4136	0x75e2e8		4531c0			XORL R8, R8											
  members_string.go:4136	0x75e2eb		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4136	0x75e2f2		5d			POPQ BP												
  members_string.go:4136	0x75e2f3		c3			RET												
  aliases.go:1367		0x75e2f4		4c89de			MOVQ R11, SI											
  aliases.go:1367		0x75e2f7		4c8b842488010000	MOVQ 0x188(SP), R8										
  aliases.go:1367		0x75e2ff		90			NOPL												
  aliases.go:1367		0x75e300		e9a5feffff		JMP 0x75e1aa											
  value_accessors.go:183	0x75e305		4c89fe			MOVQ R15, SI											
  value_accessors.go:183	0x75e308		4d21ef			ANDQ R13, R15											
  value_accessors.go:183	0x75e30b		49c1e704		SHLQ $0x4, R15											
  value_accessors.go:183	0x75e30f		4f8b442708		MOVQ 0x8(R15)(R12*1), R8									
  value_accessors.go:183	0x75e314		4d39c3			CMPQ R11, R8											
  value_accessors.go:183	0x75e317		7450			JE 0x75e369											
  value_accessors.go:183	0x75e319		4c8d7e01		LEAQ 0x1(SI), R15										
  value_accessors.go:183	0x75e31d		0f1f00			NOPL 0(AX)											
  value_accessors.go:183	0x75e320		4d85c0			TESTQ R8, R8											
  value_accessors.go:183	0x75e323		75e0			JNE 0x75e305											
  value_accessors.go:183	0x75e325		488d05b4523f00		LEAQ github.com/mgomes/vibescript/internal/runtime..typeAssert.357(SB), AX			
  value_accessors.go:183	0x75e32c		4c89db			MOVQ R11, BX											
  value_accessors.go:183	0x75e32f		e8cceecbff		CALL runtime.typeAssert(SB)									
  members_string.go:4136	0x75e334		488b8c2428010000	MOVQ 0x128(SP), CX										
  members_string.go:4130	0x75e33c		488b942478010000	MOVQ 0x178(SP), DX										
  members_string.go:4136	0x75e344		488b9c24e8000000	MOVQ 0xe8(SP), BX										
  members_string.go:4130	0x75e34c		488bb42480010000	MOVQ 0x180(SP), SI										
  members_string.go:4136	0x75e354		488bbc24e0000000	MOVQ 0xe0(SP), DI										
  value_accessors.go:183	0x75e35c		4989c3			MOVQ AX, R11											
  members_string.go:4136	0x75e35f		488b8424f0000000	MOVQ 0xf0(SP), AX										
  value_accessors.go:183	0x75e367		eb8b			JMP 0x75e2f4											
  value_accessors.go:183	0x75e369		4f8b642710		MOVQ 0x10(R15)(R12*1), R12									
  members_string.go:4130	0x75e36e		4c89de			MOVQ R11, SI											
  value_accessors.go:183	0x75e371		4d89e3			MOVQ R12, R11											
  value_accessors.go:183	0x75e374		e97bffffff		JMP 0x75e2f4											
  utf8.go:449			0x75e379		48ffc2			INCQ DX												
  utf8.go:449			0x75e37c		0f1f4000		NOPL 0(AX)											
  utf8.go:448			0x75e380		4c39de			CMPQ SI, R11											
  utf8.go:448			0x75e383		7e43			JLE 0x75e3c8											
  utf8.go:448			0x75e385		460fb6241f		MOVZX 0(DI)(R11*1), R12										
  utf8.go:448			0x75e38a		4183fc7f		CMPL R12, $0x7f											
  utf8.go:448			0x75e38e		7f05			JG 0x75e395											
  utf8.go:448			0x75e390		49ffc3			INCQ R11											
  utf8.go:448			0x75e393		ebe4			JMP 0x75e379											
  utf8.go:448			0x75e395		48899424c0000000	MOVQ DX, 0xc0(SP)										
  utf8.go:448			0x75e39d		4889f8			MOVQ DI, AX											
  utf8.go:448			0x75e3a0		4889f3			MOVQ SI, BX											
  utf8.go:448			0x75e3a3		4c89d9			MOVQ R11, CX											
  utf8.go:448			0x75e3a6		e855eed1ff		CALL runtime.decoderune(SB)									
  utf8.go:449			0x75e3ab		488b9424c0000000	MOVQ 0xc0(SP), DX										
  utf8.go:448			0x75e3b3		488bb424c8000000	MOVQ 0xc8(SP), SI										
  utf8.go:448			0x75e3bb		488bbc2418010000	MOVQ 0x118(SP), DI										
  utf8.go:449			0x75e3c3		4989db			MOVQ BX, R11											
  utf8.go:448			0x75e3c6		ebb1			JMP 0x75e379											
  members_string.go:4108	0x75e3c8		4889d0			MOVQ DX, AX											
  members_string.go:4108	0x75e3cb		e9c8fbffff		JMP 0x75df98											
  members_string.go:4069	0x75e3d0		4889442428		MOVQ AX, 0x28(SP)										
  members_string.go:4069	0x75e3d5		48895c2430		MOVQ BX, 0x30(SP)										
  members_string.go:4069	0x75e3da		48894c2438		MOVQ CX, 0x38(SP)										
  members_string.go:4069	0x75e3df		48897c2440		MOVQ DI, 0x40(SP)										
  members_string.go:4069	0x75e3e4		4889742448		MOVQ SI, 0x48(SP)										
  members_string.go:4069	0x75e3e9		4c89442450		MOVQ R8, 0x50(SP)										
  members_string.go:4069	0x75e3ee		4c894c2458		MOVQ R9, 0x58(SP)										
  members_string.go:4069	0x75e3f3		4c89542460		MOVQ R10, 0x60(SP)										
  members_string.go:4069	0x75e3f8		4c895c2468		MOVQ R11, 0x68(SP)										
  members_string.go:4069	0x75e3fd		0f1f00			NOPL 0(AX)											
  members_string.go:4069	0x75e400		e83be2d2ff		CALL runtime.morestack_noctxt.abi0(SB)								
  members_string.go:4069	0x75e405		488b442428		MOVQ 0x28(SP), AX										
  members_string.go:4069	0x75e40a		488b5c2430		MOVQ 0x30(SP), BX										
  members_string.go:4069	0x75e40f		488b4c2438		MOVQ 0x38(SP), CX										
  members_string.go:4069	0x75e414		488b7c2440		MOVQ 0x40(SP), DI										
  members_string.go:4069	0x75e419		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:4069	0x75e41e		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4069	0x75e423		4c8b4c2458		MOVQ 0x58(SP), R9										
  members_string.go:4069	0x75e428		4c8b542460		MOVQ 0x60(SP), R10										
  members_string.go:4069	0x75e42d		4c8b5c2468		MOVQ 0x68(SP), R11										
  members_string.go:4069	0x75e432		e949f7ffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func23(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func24(SB) /home/runner/work/vibescript/vibescript/head/internal/runtime/members_string.go
  members_string.go:4139	0x75e440		4c8d6424e8		LEAQ -0x18(SP), R12										
  members_string.go:4139	0x75e445		4d3b6610		CMPQ R12, 0x10(R14)										
  members_string.go:4139	0x75e449		0f8660030000		JBE 0x75e7af											
  members_string.go:4139	0x75e44f		55			PUSHQ BP											
  members_string.go:4139	0x75e450		4889e5			MOVQ SP, BP											
  members_string.go:4139	0x75e453		4881ec90000000		SUBQ $0x90, SP											
  members_string.go:4139	0x75e45a		48898c24d0000000	MOVQ CX, 0xd0(SP)										
  members_string.go:4139	0x75e462		4889bc24d8000000	MOVQ DI, 0xd8(SP)										
  members_string.go:4139	0x75e46a		4c898424e8000000	MOVQ R8, 0xe8(SP)										
  members_string.go:4140	0x75e472		4d85db			TESTQ R11, R11											
  members_string.go:4140	0x75e475		7405			JE 0x75e47c											
  members_string.go:4140	0x75e477		498b13			MOVQ 0(R11), DX											
  members_string.go:4140	0x75e47a		eb04			JMP 0x75e480											
  members_string.go:4140	0x75e47c		31d2			XORL DX, DX											
  members_string.go:4140	0x75e47e		6690			NOPW												
  members_string.go:4140	0x75e480		4885d2			TESTQ DX, DX											
  members_string.go:4140	0x75e483		0f8fbb020000		JG 0x75e744											
  members_string.go:4143	0x75e489		4d85c9			TESTQ R9, R9											
  members_string.go:4143	0x75e48c		7406			JE 0x75e494											
  members_string.go:4143	0x75e48e		4983f902		CMPQ R9, $0x2											
  members_string.go:4143	0x75e492		7e66			JLE 0x75e4fa											
  errors.go:26			0x75e494		488d0529ad0600		LEAQ 0x6ad29(IP), AX										
  errors.go:26			0x75e49b		bb33000000		MOVL $0x33, BX											
  errors.go:26			0x75e4a0		31c9			XORL CX, CX											
  errors.go:26			0x75e4a2		31ff			XORL DI, DI											
  errors.go:26			0x75e4a4		89fe			MOVL DI, SI											
  errors.go:26			0x75e4a6		e815fad7ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75e4ab		4885c0			TESTQ AX, AX											
  errors.go:26			0x75e4ae		7533			JNE 0x75e4e3											
  errors.go:31			0x75e4b0		90			NOPL												
  errors.go:65			0x75e4b1		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75e4b6		488d1de3083900		LEAQ 0x3908e3(IP), BX										
  errors.go:65			0x75e4bd		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75e4c2		e8d92eccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75e4c7		48c7400833000000	MOVQ $0x33, 0x8(AX)										
  errors.go:65			0x75e4cf		488d15eeac0600		LEAQ 0x6acee(IP), DX										
  errors.go:65			0x75e4d6		488910			MOVQ DX, 0(AX)											
  members_string.go:4144	0x75e4d9		4889c3			MOVQ AX, BX											
  members_string.go:4144	0x75e4dc		488d056de63b00		LEAQ 0x3be66d(IP), AX										
  members_string.go:4144	0x75e4e3		31c9			XORL CX, CX											
  members_string.go:4144	0x75e4e5		31ff			XORL DI, DI											
  members_string.go:4144	0x75e4e7		4889c6			MOVQ AX, SI											
  members_string.go:4144	0x75e4ea		4989d8			MOVQ BX, R8											
  members_string.go:4144	0x75e4ed		31c0			XORL AX, AX											
  members_string.go:4144	0x75e4ef		31db			XORL BX, BX											
  members_string.go:4144	0x75e4f1		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4144	0x75e4f8		5d			POPQ BP												
  members_string.go:4144	0x75e4f9		c3			RET												
  members_string.go:4140	0x75e4fa		4889742470		MOVQ SI, 0x70(SP)										
  members_string.go:4140	0x75e4ff		4889bc2488000000	MOVQ DI, 0x88(SP)										
  members_string.go:4140	0x75e507		4c898c24f0000000	MOVQ R9, 0xf0(SP)										
  members_string.go:4140	0x75e50f		4c898424e8000000	MOVQ R8, 0xe8(SP)										
  members_string.go:4140	0x75e517		48895c2468		MOVQ BX, 0x68(SP)										
  members_string.go:4140	0x75e51c		48894c2460		MOVQ CX, 0x60(SP)										
  members_string.go:4146	0x75e521		498b7808		MOVQ 0x8(R8), DI										
  members_string.go:4146	0x75e525		498b7010		MOVQ 0x10(R8), SI										
  members_string.go:4146	0x75e529		498b5018		MOVQ 0x18(R8), DX										
  members_string.go:4146	0x75e52d		498b08			MOVQ 0(R8), CX											
  members_string.go:4146	0x75e530		488d05f56b0500		LEAQ 0x56bf5(IP), AX										
  members_string.go:4146	0x75e537		bb0d000000		MOVL $0xd, BX											
  members_string.go:4146	0x75e53c		4989d0			MOVQ DX, R8											
  members_string.go:4146	0x75e53f		90			NOPL												
  members_string.go:4146	0x75e540		e8db3bfbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4146	0x75e545		4885ff			TESTQ DI, DI											
  members_string.go:4146	0x75e548		0f85df010000		JNE 0x75e72d											
  members_string.go:4143	0x75e54e		488b9424f0000000	MOVQ 0xf0(SP), DX										
  members_string.go:4143	0x75e556		4883fa02		CMPQ DX, $0x2											
  members_string.go:4150	0x75e55a		7409			JE 0x75e565											
  members_string.go:4150	0x75e55c		31c0			XORL AX, AX											
  members_string.go:4150	0x75e55e		6690			NOPW												
  members_string.go:4150	0x75e560		e993000000		JMP 0x75e5f8											
  members_string.go:4151	0x75e565		488b9424e8000000	MOVQ 0xe8(SP), DX										
  members_string.go:4151	0x75e56d		488b4220		MOVQ 0x20(DX), AX										
  members_string.go:4151	0x75e571		488b5a28		MOVQ 0x28(DX), BX										
  members_string.go:4151	0x75e575		488b4a30		MOVQ 0x30(DX), CX										
  members_string.go:4151	0x75e579		488b7a38		MOVQ 0x38(DX), DI										
  members_string.go:4151	0x75e57d		0f1f00			NOPL 0(AX)											
  members_string.go:4151	0x75e580		e8fb74fdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)				
  members_string.go:4152	0x75e585		4885db			TESTQ BX, BX											
  members_string.go:4152	0x75e588		7505			JNE 0x75e58f											
  members_string.go:4152	0x75e58a		4885c0			TESTQ AX, AX											
  members_string.go:4152	0x75e58d		7d69			JGE 0x75e5f8											
  errors.go:26			0x75e58f		488d051da50600		LEAQ 0x6a51d(IP), AX										
  errors.go:26			0x75e596		bb31000000		MOVL $0x31, BX											
  errors.go:26			0x75e59b		31c9			XORL CX, CX											
  errors.go:26			0x75e59d		31ff			XORL DI, DI											
  errors.go:26			0x75e59f		89fe			MOVL DI, SI											
  errors.go:26			0x75e5a1		e81af9d7ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75e5a6		4885c0			TESTQ AX, AX											
  errors.go:26			0x75e5a9		7536			JNE 0x75e5e1											
  errors.go:31			0x75e5ab		90			NOPL												
  errors.go:65			0x75e5ac		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75e5b1		488d1de8073900		LEAQ 0x3907e8(IP), BX										
  errors.go:65			0x75e5b8		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75e5bd		0f1f00			NOPL 0(AX)											
  errors.go:65			0x75e5c0		e8db2dccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75e5c5		48c7400831000000	MOVQ $0x31, 0x8(AX)										
  errors.go:65			0x75e5cd		488d15dfa40600		LEAQ 0x6a4df(IP), DX										
  errors.go:65			0x75e5d4		488910			MOVQ DX, 0(AX)											
  members_string.go:4153	0x75e5d7		4889c3			MOVQ AX, BX											
  members_string.go:4153	0x75e5da		488d056fe53b00		LEAQ 0x3be56f(IP), AX										
  members_string.go:4153	0x75e5e1		31c9			XORL CX, CX											
  members_string.go:4153	0x75e5e3		31ff			XORL DI, DI											
  members_string.go:4153	0x75e5e5		4889c6			MOVQ AX, SI											
  members_string.go:4153	0x75e5e8		4989d8			MOVQ BX, R8											
  members_string.go:4153	0x75e5eb		31c0			XORL AX, AX											
  members_string.go:4153	0x75e5ed		31db			XORL BX, BX											
  members_string.go:4153	0x75e5ef		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4153	0x75e5f6		5d			POPQ BP												
  members_string.go:4153	0x75e5f7		c3			RET												
  members_string.go:4157	0x75e5f8		4889442458		MOVQ AX, 0x58(SP)										
  members_string.go:4157	0x75e5fd		488b9424e8000000	MOVQ 0xe8(SP), DX										
  members_string.go:4157	0x75e605		488b0a			MOVQ 0(DX), CX											
  members_string.go:4157	0x75e608		488b7a08		MOVQ 0x8(DX), DI										
  members_string.go:4157	0x75e60c		488b7210		MOVQ 0x10(DX), SI										
  members_string.go:4157	0x75e610		4c8b4218		MOVQ 0x18(DX), R8										
  members_string.go:4157	0x75e614		488d05116b0500		LEAQ 0x56b11(IP), AX										
  members_string.go:4157	0x75e61b		bb0d000000		MOVL $0xd, BX											
  members_string.go:4157	0x75e620		e8fb3afbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4158	0x75e625		4885ff			TESTQ DI, DI											
  members_string.go:4158	0x75e628		0f85e8000000		JNE 0x75e716											
  members_string.go:4157	0x75e62e		884c2447		MOVB CL, 0x47(SP)										
  members_string.go:4157	0x75e632		4889842480000000	MOVQ AX, 0x80(SP)										
  members_string.go:4157	0x75e63a		48895c2450		MOVQ BX, 0x50(SP)										
  members_string.go:4161	0x75e63f		488b442468		MOVQ 0x68(SP), AX										
  members_string.go:4161	0x75e644		488b5c2460		MOVQ 0x60(SP), BX										
  members_string.go:4161	0x75e649		488b8c2488000000	MOVQ 0x88(SP), CX										
  members_string.go:4161	0x75e651		488b7c2470		MOVQ 0x70(SP), DI										
  members_string.go:4161	0x75e656		e8c5dce4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  members_string.go:4161	0x75e65b		4889442478		MOVQ AX, 0x78(SP)										
  members_string.go:4161	0x75e660		48895c2448		MOVQ BX, 0x48(SP)										
  members_string.go:4162	0x75e665		4889c1			MOVQ AX, CX											
  members_string.go:4162	0x75e668		4889df			MOVQ BX, DI											
  members_string.go:4162	0x75e66b		488bb42480000000	MOVQ 0x80(SP), SI										
  members_string.go:4162	0x75e673		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4162	0x75e678		440fb64c2447		MOVZX 0x47(SP), R9										
  members_string.go:4162	0x75e67e		488d05a76a0500		LEAQ 0x56aa7(IP), AX										
  members_string.go:4162	0x75e685		bb0d000000		MOVL $0xd, BX											
  members_string.go:4162	0x75e68a		e8f150f7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)			
  members_string.go:4162	0x75e68f		4885c0			TESTQ AX, AX											
  members_string.go:4162	0x75e692		756b			JNE 0x75e6ff											
  members_string.go:2034	0x75e694		488b05a55e4000		MOVQ github.com/mgomes/vibescript/internal/runtime.compiledRegexps(SB), AX			
  members_string.go:4165	0x75e69b		90			NOPL												
  members_string.go:2034	0x75e69c		488d1d896a0500		LEAQ 0x56a89(IP), BX										
  members_string.go:2034	0x75e6a3		b90d000000		MOVL $0xd, CX											
  members_string.go:2034	0x75e6a8		488b7c2478		MOVQ 0x78(SP), DI										
  members_string.go:2034	0x75e6ad		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:2034	0x75e6b2		4c8b842480000000	MOVQ 0x80(SP), R8										
  members_string.go:2034	0x75e6ba		4c8b4c2450		MOVQ 0x50(SP), R9										
  members_string.go:2034	0x75e6bf		4c8b542458		MOVQ 0x58(SP), R10										
  members_string.go:2034	0x75e6c4		e81752f7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexMatchFromRuneOffsetWithCache(SB)	
  members_string.go:4166	0x75e6c9		4885db			TESTQ BX, BX											
  members_string.go:4166	0x75e6cc		7417			JE 0x75e6e5											
  members_string.go:4167	0x75e6ce		31c0			XORL AX, AX											
  members_string.go:4167	0x75e6d0		31ff			XORL DI, DI											
  members_string.go:4167	0x75e6d2		4889de			MOVQ BX, SI											
  members_string.go:4167	0x75e6d5		4989c8			MOVQ CX, R8											
  members_string.go:4167	0x75e6d8		31db			XORL BX, BX											
  members_string.go:4167	0x75e6da		31c9			XORL CX, CX											
  members_string.go:4167	0x75e6dc		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4167	0x75e6e3		5d			POPQ BP												
  members_string.go:4167	0x75e6e4		c3			RET												
  members_string.go:4169	0x75e6e5		0fb6f8			MOVZX AL, DI											
  members_string.go:4169	0x75e6e8		b801000000		MOVL $0x1, AX											
  members_string.go:4169	0x75e6ed		31db			XORL BX, BX											
  members_string.go:4169	0x75e6ef		31c9			XORL CX, CX											
  members_string.go:4169	0x75e6f1		89de			MOVL BX, SI											
  members_string.go:4169	0x75e6f3		4189c8			MOVL CX, R8											
  members_string.go:4169	0x75e6f6		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4169	0x75e6fd		5d			POPQ BP												
  members_string.go:4169	0x75e6fe		c3			RET												
  members_string.go:4163	0x75e6ff		31c9			XORL CX, CX											
  members_string.go:4163	0x75e701		31ff			XORL DI, DI											
  members_string.go:4163	0x75e703		4889c6			MOVQ AX, SI											
  members_string.go:4163	0x75e706		4989d8			MOVQ BX, R8											
  members_string.go:4163	0x75e709		31c0			XORL AX, AX											
  members_string.go:4163	0x75e70b		31db			XORL BX, BX											
  members_string.go:4163	0x75e70d		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4163	0x75e714		5d			POPQ BP												
  members_string.go:4163	0x75e715		c3			RET												
  members_string.go:4159	0x75e716		31c0			XORL AX, AX											
  members_string.go:4159	0x75e718		31db			XORL BX, BX											
  members_string.go:4159	0x75e71a		31c9			XORL CX, CX											
  members_string.go:4159	0x75e71c		4989f0			MOVQ SI, R8											
  members_string.go:4159	0x75e71f		4889fe			MOVQ DI, SI											
  members_string.go:4159	0x75e722		31ff			XORL DI, DI											
  members_string.go:4159	0x75e724		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4159	0x75e72b		5d			POPQ BP												
  members_string.go:4159	0x75e72c		c3			RET												
  members_string.go:4147	0x75e72d		31c0			XORL AX, AX											
  members_string.go:4147	0x75e72f		31db			XORL BX, BX											
  members_string.go:4147	0x75e731		31c9			XORL CX, CX											
  members_string.go:4147	0x75e733		4989f0			MOVQ SI, R8											
  members_string.go:4147	0x75e736		4889fe			MOVQ DI, SI											
  members_string.go:4147	0x75e739		31ff			XORL DI, DI											
  members_string.go:4147	0x75e73b		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4147	0x75e742		5d			POPQ BP												
  members_string.go:4147	0x75e743		c3			RET												
  errors.go:26			0x75e744		488d05ef970600		LEAQ 0x697ef(IP), AX										
  errors.go:26			0x75e74b		bb2f000000		MOVL $0x2f, BX											
  errors.go:26			0x75e750		31c9			XORL CX, CX											
  errors.go:26			0x75e752		31ff			XORL DI, DI											
  errors.go:26			0x75e754		89fe			MOVL DI, SI											
  errors.go:26			0x75e756		e865f7d7ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75e75b		0f1f440000		NOPL 0(AX)(AX*1)										
  errors.go:26			0x75e760		4885c0			TESTQ AX, AX											
  errors.go:26			0x75e763		7533			JNE 0x75e798											
  errors.go:31			0x75e765		90			NOPL												
  errors.go:65			0x75e766		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75e76b		488d1d2e063900		LEAQ 0x39062e(IP), BX										
  errors.go:65			0x75e772		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75e777		e8242cccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75e77c		48c740082f000000	MOVQ $0x2f, 0x8(AX)										
  errors.go:65			0x75e784		488d15af970600		LEAQ 0x697af(IP), DX										
  errors.go:65			0x75e78b		488910			MOVQ DX, 0(AX)											
  members_string.go:4141	0x75e78e		4889c3			MOVQ AX, BX											
  members_string.go:4141	0x75e791		488d05b8e33b00		LEAQ 0x3be3b8(IP), AX										
  members_string.go:4141	0x75e798		31c9			XORL CX, CX											
  members_string.go:4141	0x75e79a		31ff			XORL DI, DI											
  members_string.go:4141	0x75e79c		4889c6			MOVQ AX, SI											
  members_string.go:4141	0x75e79f		4989d8			MOVQ BX, R8											
  members_string.go:4141	0x75e7a2		31c0			XORL AX, AX											
  members_string.go:4141	0x75e7a4		31db			XORL BX, BX											
  members_string.go:4141	0x75e7a6		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4141	0x75e7ad		5d			POPQ BP												
  members_string.go:4141	0x75e7ae		c3			RET												
  members_string.go:4139	0x75e7af		4889442428		MOVQ AX, 0x28(SP)										
  members_string.go:4139	0x75e7b4		48895c2430		MOVQ BX, 0x30(SP)										
  members_string.go:4139	0x75e7b9		48894c2438		MOVQ CX, 0x38(SP)										
  members_string.go:4139	0x75e7be		48897c2440		MOVQ DI, 0x40(SP)										
  members_string.go:4139	0x75e7c3		4889742448		MOVQ SI, 0x48(SP)										
  members_string.go:4139	0x75e7c8		4c89442450		MOVQ R8, 0x50(SP)										
  members_string.go:4139	0x75e7cd		4c894c2458		MOVQ R9, 0x58(SP)										
  members_string.go:4139	0x75e7d2		4c89542460		MOVQ R10, 0x60(SP)										
  members_string.go:4139	0x75e7d7		4c895c2468		MOVQ R11, 0x68(SP)										
  members_string.go:4139	0x75e7dc		0f1f4000		NOPL 0(AX)											
  members_string.go:4139	0x75e7e0		e85bded2ff		CALL runtime.morestack_noctxt.abi0(SB)								
  members_string.go:4139	0x75e7e5		488b442428		MOVQ 0x28(SP), AX										
  members_string.go:4139	0x75e7ea		488b5c2430		MOVQ 0x30(SP), BX										
  members_string.go:4139	0x75e7ef		488b4c2438		MOVQ 0x38(SP), CX										
  members_string.go:4139	0x75e7f4		488b7c2440		MOVQ 0x40(SP), DI										
  members_string.go:4139	0x75e7f9		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:4139	0x75e7fe		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4139	0x75e803		4c8b4c2458		MOVQ 0x58(SP), R9										
  members_string.go:4139	0x75e808		4c8b542460		MOVQ 0x60(SP), R10										
  members_string.go:4139	0x75e80d		4c8b5c2468		MOVQ 0x68(SP), R11										
  members_string.go:4139	0x75e812		e929fcffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func24(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func25(SB) /home/runner/work/vibescript/vibescript/head/internal/runtime/members_string.go
  members_string.go:4172	0x75e820		4c8d642490		LEAQ -0x70(SP), R12								
  members_string.go:4172	0x75e825		4d3b6610		CMPQ R12, 0x10(R14)								
  members_string.go:4172	0x75e829		0f86a9030000		JBE 0x75ebd8									
  members_string.go:4172	0x75e82f		55			PUSHQ BP									
  members_string.go:4172	0x75e830		4889e5			MOVQ SP, BP									
  members_string.go:4172	0x75e833		4881ece8000000		SUBQ $0xe8, SP									
  members_string.go:4172	0x75e83a		48898c2428010000	MOVQ CX, 0x128(SP)								
  members_string.go:4172	0x75e842		4889bc2430010000	MOVQ DI, 0x130(SP)								
  members_string.go:4172	0x75e84a		4c89842440010000	MOVQ R8, 0x140(SP)								
  members_string.go:4173	0x75e852		4d85db			TESTQ R11, R11									
  members_string.go:4173	0x75e855		7405			JE 0x75e85c									
  members_string.go:4173	0x75e857		498b13			MOVQ 0(R11), DX									
  members_string.go:4173	0x75e85a		eb04			JMP 0x75e860									
  members_string.go:4173	0x75e85c		31d2			XORL DX, DX									
  members_string.go:4173	0x75e85e		6690			NOPW										
  members_string.go:4173	0x75e860		4885d2			TESTQ DX, DX									
  members_string.go:4173	0x75e863		0f8f09030000		JG 0x75eb72									
  members_string.go:4176	0x75e869		4983f901		CMPQ R9, $0x1									
  members_string.go:4176	0x75e86d		7469			JE 0x75e8d8									
  errors.go:26			0x75e86f		488d05184b0600		LEAQ 0x64b18(IP), AX								
  errors.go:26			0x75e876		bb27000000		MOVL $0x27, BX									
  errors.go:26			0x75e87b		31c9			XORL CX, CX									
  errors.go:26			0x75e87d		31ff			XORL DI, DI									
  errors.go:26			0x75e87f		89fe			MOVL DI, SI									
  errors.go:26			0x75e881		e83af6d7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75e886		4885c0			TESTQ AX, AX									
  errors.go:26			0x75e889		7536			JNE 0x75e8c1									
  errors.go:31			0x75e88b		90			NOPL										
  errors.go:65			0x75e88c		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75e891		488d1d08053900		LEAQ 0x390508(IP), BX								
  errors.go:65			0x75e898		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75e89d		0f1f00			NOPL 0(AX)									
  errors.go:65			0x75e8a0		e8fb2accff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75e8a5		48c7400827000000	MOVQ $0x27, 0x8(AX)								
  errors.go:65			0x75e8ad		488d15da4a0600		LEAQ 0x64ada(IP), DX								
  errors.go:65			0x75e8b4		488910			MOVQ DX, 0(AX)									
  members_string.go:4177	0x75e8b7		4889c3			MOVQ AX, BX									
  members_string.go:4177	0x75e8ba		488d058fe23b00		LEAQ 0x3be28f(IP), AX								
  members_string.go:4177	0x75e8c1		31c9			XORL CX, CX									
  members_string.go:4177	0x75e8c3		31ff			XORL DI, DI									
  members_string.go:4177	0x75e8c5		4889c6			MOVQ AX, SI									
  members_string.go:4177	0x75e8c8		4989d8			MOVQ BX, R8									
  members_string.go:4177	0x75e8cb		31c0			XORL AX, AX									
  members_string.go:4177	0x75e8cd		31db			XORL BX, BX									
  members_string.go:4177	0x75e8cf		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4177	0x75e8d6		5d			POPQ BP										
  members_string.go:4177	0x75e8d7		c3			RET										
  members_string.go:4173	0x75e8d8		4889842418010000	MOVQ AX, 0x118(SP)								
  members_string.go:4173	0x75e8e0		4c899c2458010000	MOVQ R11, 0x158(SP)								
  members_string.go:4173	0x75e8e8		4c89842440010000	MOVQ R8, 0x140(SP)								
  members_string.go:4173	0x75e8f0		4889b424b8000000	MOVQ SI, 0xb8(SP)								
  members_string.go:4173	0x75e8f8		48899c24b0000000	MOVQ BX, 0xb0(SP)								
  members_string.go:4173	0x75e900		4889bc24e0000000	MOVQ DI, 0xe0(SP)								
  members_string.go:4173	0x75e908		48898c24a8000000	MOVQ CX, 0xa8(SP)								
  members_string.go:4173	0x75e910		4c898c2448010000	MOVQ R9, 0x148(SP)								
  members_string.go:4173	0x75e918		4c89942450010000	MOVQ R10, 0x150(SP)								
  members_string.go:4179	0x75e920		498b08			MOVQ 0(R8), CX									
  members_string.go:4179	0x75e923		498b7808		MOVQ 0x8(R8), DI								
  members_string.go:4179	0x75e927		498b7010		MOVQ 0x10(R8), SI								
  members_string.go:4179	0x75e92b		4d8b4018		MOVQ 0x18(R8), R8								
  members_string.go:4179	0x75e92f		488d05f4590500		LEAQ 0x559f4(IP), AX								
  members_string.go:4179	0x75e936		bb0b000000		MOVL $0xb, BX									
  members_string.go:4179	0x75e93b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4179	0x75e940		e8db37fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)	
  members_string.go:4180	0x75e945		4885ff			TESTQ DI, DI									
  members_string.go:4180	0x75e948		0f850d020000		JNE 0x75eb5b									
  members_string.go:4179	0x75e94e		888c2497000000		MOVB CL, 0x97(SP)								
  members_string.go:4179	0x75e955		48898424c8000000	MOVQ AX, 0xc8(SP)								
  members_string.go:4179	0x75e95d		48899c24a0000000	MOVQ BX, 0xa0(SP)								
  members_string.go:4183	0x75e965		488b8424b0000000	MOVQ 0xb0(SP), AX								
  members_string.go:4183	0x75e96d		488b9c24a8000000	MOVQ 0xa8(SP), BX								
  members_string.go:4183	0x75e975		488b8c24e0000000	MOVQ 0xe0(SP), CX								
  members_string.go:4183	0x75e97d		488bbc24b8000000	MOVQ 0xb8(SP), DI								
  members_string.go:4183	0x75e985		e896d9e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4183	0x75e98a		48898424c0000000	MOVQ AX, 0xc0(SP)								
  members_string.go:4183	0x75e992		48899c2498000000	MOVQ BX, 0x98(SP)								
  members_string.go:4184	0x75e99a		4889c1			MOVQ AX, CX									
  members_string.go:4184	0x75e99d		4889df			MOVQ BX, DI									
  members_string.go:4184	0x75e9a0		488bb424c8000000	MOVQ 0xc8(SP), SI								
  members_string.go:4184	0x75e9a8		4c8b8424a0000000	MOVQ 0xa0(SP), R8								
  members_string.go:4184	0x75e9b0		440fb68c2497000000	MOVZX 0x97(SP), R9								
  members_string.go:4184	0x75e9b9		488d056a590500		LEAQ 0x5596a(IP), AX								
  members_string.go:4184	0x75e9c0		bb0b000000		MOVL $0xb, BX									
  members_string.go:4184	0x75e9c5		e8b64df7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)	
  members_string.go:4184	0x75e9ca		4885c0			TESTQ AX, AX									
  members_string.go:4184	0x75e9cd		0f8571010000		JNE 0x75eb44									
  members_string.go:4187	0x75e9d3		488b8424c8000000	MOVQ 0xc8(SP), AX								
  members_string.go:4187	0x75e9db		488b9c24a0000000	MOVQ 0xa0(SP), BX								
  members_string.go:4187	0x75e9e3		e8f8c6faff		CALL github.com/mgomes/vibescript/internal/runtime.compileCachedRegex(SB)	
  members_string.go:4188	0x75e9e8		4885db			TESTQ BX, BX									
  members_string.go:4188	0x75e9eb		0f848e000000		JE 0x75ea7f									
  members_string.go:4189	0x75e9f1		440f11bc24d0000000	MOVUPS X15, 0xd0(SP)								
  members_string.go:4189	0x75e9fa		7404			JE 0x75ea00									
  members_string.go:4189	0x75e9fc		488b5b08		MOVQ 0x8(BX), BX								
  members_string.go:4189	0x75ea00		48899c24d0000000	MOVQ BX, 0xd0(SP)								
  members_string.go:4189	0x75ea08		48898c24d8000000	MOVQ CX, 0xd8(SP)								
  errors.go:26			0x75ea10		488d05eada0500		LEAQ 0x5daea(IP), AX								
  errors.go:26			0x75ea17		bb1d000000		MOVL $0x1d, BX									
  errors.go:26			0x75ea1c		488d8c24d0000000	LEAQ 0xd0(SP), CX								
  errors.go:26			0x75ea24		bf01000000		MOVL $0x1, DI									
  errors.go:26			0x75ea29		89fe			MOVL DI, SI									
  errors.go:26			0x75ea2b		e890f4d7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75ea30		4885c0			TESTQ AX, AX									
  errors.go:26			0x75ea33		7533			JNE 0x75ea68									
  errors.go:31			0x75ea35		90			NOPL										
  errors.go:65			0x75ea36		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75ea3b		488d1d5e033900		LEAQ 0x39035e(IP), BX								
  errors.go:65			0x75ea42		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75ea47		e85429ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75ea4c		48c740081d000000	MOVQ $0x1d, 0x8(AX)								
  errors.go:65			0x75ea54		488d15a6da0500		LEAQ 0x5daa6(IP), DX								
  errors.go:65			0x75ea5b		488910			MOVQ DX, 0(AX)									
  members_string.go:4189	0x75ea5e		4889c3			MOVQ AX, BX									
  members_string.go:4189	0x75ea61		488d05e8e03b00		LEAQ 0x3be0e8(IP), AX								
  members_string.go:4189	0x75ea68		31c9			XORL CX, CX									
  members_string.go:4189	0x75ea6a		31ff			XORL DI, DI									
  members_string.go:4189	0x75ea6c		4889c6			MOVQ AX, SI									
  members_string.go:4189	0x75ea6f		4989d8			MOVQ BX, R8									
  members_string.go:4189	0x75ea72		31c0			XORL AX, AX									
  members_string.go:4189	0x75ea74		31db			XORL BX, BX									
  members_string.go:4189	0x75ea76		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4189	0x75ea7d		5d			POPQ BP										
  members_string.go:4189	0x75ea7e		c3			RET										
  members_string.go:4191	0x75ea7f		488b9424b0000000	MOVQ 0xb0(SP), DX								
  members_string.go:4191	0x75ea87		48891424		MOVQ DX, 0(SP)									
  members_string.go:4191	0x75ea8b		488b9424a8000000	MOVQ 0xa8(SP), DX								
  members_string.go:4191	0x75ea93		4889542408		MOVQ DX, 0x8(SP)								
  members_string.go:4191	0x75ea98		488b9424e0000000	MOVQ 0xe0(SP), DX								
  members_string.go:4191	0x75eaa0		4889542410		MOVQ DX, 0x10(SP)								
  members_string.go:4191	0x75eaa5		488b9424b8000000	MOVQ 0xb8(SP), DX								
  members_string.go:4191	0x75eaad		4889542418		MOVQ DX, 0x18(SP)								
  members_string.go:4191	0x75eab2		488b942458010000	MOVQ 0x158(SP), DX								
  members_string.go:4191	0x75eaba		4889542420		MOVQ DX, 0x20(SP)								
  members_string.go:4191	0x75eabf		488b9424f8000000	MOVQ 0xf8(SP), DX								
  members_string.go:4191	0x75eac7		4889542428		MOVQ DX, 0x28(SP)								
  members_string.go:4191	0x75eacc		488b942400010000	MOVQ 0x100(SP), DX								
  members_string.go:4191	0x75ead4		4889542430		MOVQ DX, 0x30(SP)								
  members_string.go:4191	0x75ead9		488b942408010000	MOVQ 0x108(SP), DX								
  members_string.go:4191	0x75eae1		4889542438		MOVQ DX, 0x38(SP)								
  members_string.go:4191	0x75eae6		488b942410010000	MOVQ 0x110(SP), DX								
  members_string.go:4191	0x75eaee		4889542440		MOVQ DX, 0x40(SP)								
  members_string.go:4191	0x75eaf3		4889c3			MOVQ AX, BX									
  members_string.go:4191	0x75eaf6		488b8c24c8000000	MOVQ 0xc8(SP), CX								
  members_string.go:4191	0x75eafe		488bbc24a0000000	MOVQ 0xa0(SP), DI								
  members_string.go:4191	0x75eb06		488bb424c0000000	MOVQ 0xc0(SP), SI								
  members_string.go:4191	0x75eb0e		4c8b842498000000	MOVQ 0x98(SP), R8								
  members_string.go:4191	0x75eb16		4c8b8c2440010000	MOVQ 0x140(SP), R9								
  members_string.go:4191	0x75eb1e		4c8b942448010000	MOVQ 0x148(SP), R10								
  members_string.go:4191	0x75eb26		4c8b9c2450010000	MOVQ 0x150(SP), R11								
  members_string.go:4191	0x75eb2e		488b842418010000	MOVQ 0x118(SP), AX								
  members_string.go:4191	0x75eb36		e8c507f8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringScan(SB)		
  members_string.go:4191	0x75eb3b		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4191	0x75eb42		5d			POPQ BP										
  members_string.go:4191	0x75eb43		c3			RET										
  members_string.go:4185	0x75eb44		31c9			XORL CX, CX									
  members_string.go:4185	0x75eb46		31ff			XORL DI, DI									
  members_string.go:4185	0x75eb48		4889c6			MOVQ AX, SI									
  members_string.go:4185	0x75eb4b		4989d8			MOVQ BX, R8									
  members_string.go:4185	0x75eb4e		31c0			XORL AX, AX									
  members_string.go:4185	0x75eb50		31db			XORL BX, BX									
  members_string.go:4185	0x75eb52		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4185	0x75eb59		5d			POPQ BP										
  members_string.go:4185	0x75eb5a		c3			RET										
  members_string.go:4181	0x75eb5b		31c0			XORL AX, AX									
  members_string.go:4181	0x75eb5d		31db			XORL BX, BX									
  members_string.go:4181	0x75eb5f		31c9			XORL CX, CX									
  members_string.go:4181	0x75eb61		4989f0			MOVQ SI, R8									
  members_string.go:4181	0x75eb64		4889fe			MOVQ DI, SI									
  members_string.go:4181	0x75eb67		31ff			XORL DI, DI									
  members_string.go:4181	0x75eb69		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4181	0x75eb70		5d			POPQ BP										
  members_string.go:4181	0x75eb71		c3			RET										
  errors.go:26			0x75eb72		488d05e6830600		LEAQ 0x683e6(IP), AX								
  errors.go:26			0x75eb79		bb2d000000		MOVL $0x2d, BX									
  errors.go:26			0x75eb7e		31c9			XORL CX, CX									
  errors.go:26			0x75eb80		31ff			XORL DI, DI									
  errors.go:26			0x75eb82		89fe			MOVL DI, SI									
  errors.go:26			0x75eb84		e837f3d7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75eb89		4885c0			TESTQ AX, AX									
  errors.go:26			0x75eb8c		7533			JNE 0x75ebc1									
  errors.go:31			0x75eb8e		90			NOPL										
  errors.go:65			0x75eb8f		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75eb94		488d1d05023900		LEAQ 0x390205(IP), BX								
  errors.go:65			0x75eb9b		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75eba0		e8fb27ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75eba5		48c740082d000000	MOVQ $0x2d, 0x8(AX)								
  errors.go:65			0x75ebad		488d15ab830600		LEAQ 0x683ab(IP), DX								
  errors.go:65			0x75ebb4		488910			MOVQ DX, 0(AX)									
  members_string.go:4174	0x75ebb7		4889c3			MOVQ AX, BX									
  members_string.go:4174	0x75ebba		488d058fdf3b00		LEAQ 0x3bdf8f(IP), AX								
  members_string.go:4174	0x75ebc1		31c9			XORL CX, CX									
  members_string.go:4174	0x75ebc3		31ff			XORL DI, DI									
  members_string.go:4174	0x75ebc5		4889c6			MOVQ AX, SI									
  members_string.go:4174	0x75ebc8		4989d8			MOVQ BX, R8									
  members_string.go:4174	0x75ebcb		31c0			XORL AX, AX									
  members_string.go:4174	0x75ebcd		31db			XORL BX, BX									
  members_string.go:4174	0x75ebcf		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4174	0x75ebd6		5d			POPQ BP										
  members_string.go:4174	0x75ebd7		c3			RET										
  members_string.go:4172	0x75ebd8		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4172	0x75ebdd		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4172	0x75ebe2		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4172	0x75ebe7		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4172	0x75ebec		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4172	0x75ebf1		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4172	0x75ebf6		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4172	0x75ebfb		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4172	0x75ec00		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4172	0x75ec05		e836dad2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4172	0x75ec0a		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4172	0x75ec0f		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4172	0x75ec14		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4172	0x75ec19		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4172	0x75ec1e		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4172	0x75ec23		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4172	0x75ec28		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4172	0x75ec2d		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4172	0x75ec32		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4172	0x75ec37		e9e4fbffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func25(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func26(SB) /home/runner/work/vibescript/vibescript/head/internal/runtime/members_string.go
  members_string.go:4194	0x75ec40		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4194	0x75ec44		0f867a010000		JBE 0x75edc4									
  members_string.go:4194	0x75ec4a		55			PUSHQ BP									
  members_string.go:4194	0x75ec4b		4889e5			MOVQ SP, BP									
  members_string.go:4194	0x75ec4e		4883ec70		SUBQ $0x70, SP									
  members_string.go:4194	0x75ec52		48898c24b0000000	MOVQ CX, 0xb0(SP)								
  members_string.go:4194	0x75ec5a		4889bc24b8000000	MOVQ DI, 0xb8(SP)								
  members_string.go:4194	0x75ec62		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4195	0x75ec6a		4d85c9			TESTQ R9, R9									
  members_string.go:4195	0x75ec6d		7406			JE 0x75ec75									
  members_string.go:4195	0x75ec6f		4983f902		CMPQ R9, $0x2									
  members_string.go:4195	0x75ec73		7e63			JLE 0x75ecd8									
  errors.go:26			0x75ec75		488d054da20600		LEAQ 0x6a24d(IP), AX								
  errors.go:26			0x75ec7c		bb32000000		MOVL $0x32, BX									
  errors.go:26			0x75ec81		31c9			XORL CX, CX									
  errors.go:26			0x75ec83		31ff			XORL DI, DI									
  errors.go:26			0x75ec85		89fe			MOVL DI, SI									
  errors.go:26			0x75ec87		e834f2d7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75ec8c		4885c0			TESTQ AX, AX									
  errors.go:26			0x75ec8f		7533			JNE 0x75ecc4									
  errors.go:31			0x75ec91		90			NOPL										
  errors.go:65			0x75ec92		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75ec97		488d1d02013900		LEAQ 0x390102(IP), BX								
  errors.go:65			0x75ec9e		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75eca3		e8f826ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75eca8		48c7400832000000	MOVQ $0x32, 0x8(AX)								
  errors.go:65			0x75ecb0		488d1512a20600		LEAQ 0x6a212(IP), DX								
  errors.go:65			0x75ecb7		488910			MOVQ DX, 0(AX)									
  members_string.go:4196	0x75ecba		4889c3			MOVQ AX, BX									
  members_string.go:4196	0x75ecbd		488d058cde3b00		LEAQ 0x3bde8c(IP), AX								
  members_string.go:4196	0x75ecc4		31c9			XORL CX, CX									
  members_string.go:4196	0x75ecc6		31ff			XORL DI, DI									
  members_string.go:4196	0x75ecc8		4889c6			MOVQ AX, SI									
  members_string.go:4196	0x75eccb		4989d8			MOVQ BX, R8									
  members_string.go:4196	0x75ecce		31c0			XORL AX, AX									
  members_string.go:4196	0x75ecd0		31db			XORL BX, BX									
  members_string.go:4196	0x75ecd2		4883c470		ADDQ $0x70, SP									
  members_string.go:4196	0x75ecd6		5d			POPQ BP										
  members_string.go:4196	0x75ecd7		c3			RET										
  members_string.go:4199	0x75ecd8		7404			JE 0x75ecde									
  members_string.go:4199	0x75ecda		31d2			XORL DX, DX									
  members_string.go:4199	0x75ecdc		eb65			JMP 0x75ed43									
  members_string.go:4195	0x75ecde		48898424a0000000	MOVQ AX, 0xa0(SP)								
  members_string.go:4195	0x75ece6		48895c2460		MOVQ BX, 0x60(SP)								
  members_string.go:4195	0x75eceb		4889742458		MOVQ SI, 0x58(SP)								
  members_string.go:4195	0x75ecf0		48894c2450		MOVQ CX, 0x50(SP)								
  members_string.go:4195	0x75ecf5		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4195	0x75ecfd		48897c2468		MOVQ DI, 0x68(SP)								
  members_string.go:4200	0x75ed02		498b4020		MOVQ 0x20(R8), AX								
  members_string.go:4200	0x75ed06		498b5828		MOVQ 0x28(R8), BX								
  members_string.go:4200	0x75ed0a		498b4830		MOVQ 0x30(R8), CX								
  members_string.go:4200	0x75ed0e		498b7838		MOVQ 0x38(R8), DI								
  members_string.go:4200	0x75ed12		e8696dfdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)		
  members_string.go:4201	0x75ed17		4885db			TESTQ BX, BX									
  members_string.go:4201	0x75ed1a		7545			JNE 0x75ed61									
  members_string.go:4206	0x75ed1c		488b4c2450		MOVQ 0x50(SP), CX								
  members_string.go:4206	0x75ed21		488b5c2460		MOVQ 0x60(SP), BX								
  members_string.go:4206	0x75ed26		488b742458		MOVQ 0x58(SP), SI								
  members_string.go:4206	0x75ed2b		488b7c2468		MOVQ 0x68(SP), DI								
  members_string.go:4206	0x75ed30		4c8b8424c8000000	MOVQ 0xc8(SP), R8								
  members_string.go:4206	0x75ed38		4889c2			MOVQ AX, DX									
  members_string.go:4206	0x75ed3b		488b8424a0000000	MOVQ 0xa0(SP), AX								
  members_string.go:4206	0x75ed43		4d8b4808		MOVQ 0x8(R8), R9								
  members_string.go:4206	0x75ed47		4d8b5010		MOVQ 0x10(R8), R10								
  members_string.go:4206	0x75ed4b		4d8b5818		MOVQ 0x18(R8), R11								
  members_string.go:4206	0x75ed4f		4d8b00			MOVQ 0(R8), R8									
  members_string.go:4206	0x75ed52		48891424		MOVQ DX, 0(SP)									
  members_string.go:4206	0x75ed56		e88501f8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIndexResult(SB)	
  members_string.go:4206	0x75ed5b		4883c470		ADDQ $0x70, SP									
  members_string.go:4206	0x75ed5f		5d			POPQ BP										
  members_string.go:4206	0x75ed60		c3			RET										
  errors.go:26			0x75ed61		488d0509140600		LEAQ 0x61409(IP), AX								
  errors.go:26			0x75ed68		bb23000000		MOVL $0x23, BX									
  errors.go:26			0x75ed6d		31c9			XORL CX, CX									
  errors.go:26			0x75ed6f		31ff			XORL DI, DI									
  errors.go:26			0x75ed71		89fe			MOVL DI, SI									
  errors.go:26			0x75ed73		e848f1d7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75ed78		4885c0			TESTQ AX, AX									
  errors.go:26			0x75ed7b		7533			JNE 0x75edb0									
  errors.go:31			0x75ed7d		90			NOPL										
  errors.go:65			0x75ed7e		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75ed83		488d1d16003900		LEAQ 0x390016(IP), BX								
  errors.go:65			0x75ed8a		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75ed8f		e80c26ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75ed94		48c7400823000000	MOVQ $0x23, 0x8(AX)								
  errors.go:65			0x75ed9c		488d15ce130600		LEAQ 0x613ce(IP), DX								
  errors.go:65			0x75eda3		488910			MOVQ DX, 0(AX)									
  members_string.go:4202	0x75eda6		4889c3			MOVQ AX, BX									
  members_string.go:4202	0x75eda9		488d05a0dd3b00		LEAQ 0x3bdda0(IP), AX								
  members_string.go:4202	0x75edb0		31c9			XORL CX, CX									
  members_string.go:4202	0x75edb2		31ff			XORL DI, DI									
  members_string.go:4202	0x75edb4		4889c6			MOVQ AX, SI									
  members_string.go:4202	0x75edb7		4989d8			MOVQ BX, R8									
  members_string.go:4202	0x75edba		31c0			XORL AX, AX									
  members_string.go:4202	0x75edbc		31db			XORL BX, BX									
  members_string.go:4202	0x75edbe		4883c470		ADDQ $0x70, SP									
  members_string.go:4202	0x75edc2		5d			POPQ BP										
  members_string.go:4202	0x75edc3		c3			RET										
  members_string.go:4194	0x75edc4		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4194	0x75edc9		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4194	0x75edce		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4194	0x75edd3		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4194	0x75edd8		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4194	0x75eddd		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4194	0x75ede2		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4194	0x75ede7		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4194	0x75edec		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4194	0x75edf1		e84ad8d2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4194	0x75edf6		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4194	0x75edfb		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4194	0x75ee00		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4194	0x75ee05		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4194	0x75ee0a		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4194	0x75ee0f		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4194	0x75ee14		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4194	0x75ee19		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4194	0x75ee1e		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4194	0x75ee23		e918feffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func26(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func27(SB) /home/runner/work/vibescript/vibescript/head/internal/runtime/members_string.go
  members_string.go:4209	0x75ee40		4c8d6424e8		LEAQ -0x18(SP), R12								
  members_string.go:4209	0x75ee45		4d3b6610		CMPQ R12, 0x10(R14)								
  members_string.go:4209	0x75ee49		0f8688020000		JBE 0x75f0d7									
  members_string.go:4209	0x75ee4f		55			PUSHQ BP									
  members_string.go:4209	0x75ee50		4889e5			MOVQ SP, BP									
  members_string.go:4209	0x75ee53		4881ec90000000		SUBQ $0x90, SP									
  members_string.go:4209	0x75ee5a		48898c24d0000000	MOVQ CX, 0xd0(SP)								
  members_string.go:4209	0x75ee62		4889bc24d8000000	MOVQ DI, 0xd8(SP)								
  members_string.go:4209	0x75ee6a		4c898424e8000000	MOVQ R8, 0xe8(SP)								
  members_string.go:4210	0x75ee72		4d85c9			TESTQ R9, R9									
  members_string.go:4210	0x75ee75		7406			JE 0x75ee7d									
  members_string.go:4210	0x75ee77		4983f902		CMPQ R9, $0x2									
  members_string.go:4210	0x75ee7b		7e66			JLE 0x75eee3									
  errors.go:26			0x75ee7d		488d0573a30600		LEAQ 0x6a373(IP), AX								
  errors.go:26			0x75ee84		bb33000000		MOVL $0x33, BX									
  errors.go:26			0x75ee89		31c9			XORL CX, CX									
  errors.go:26			0x75ee8b		31ff			XORL DI, DI									
  errors.go:26			0x75ee8d		89fe			MOVL DI, SI									
  errors.go:26			0x75ee8f		e82cf0d7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75ee94		4885c0			TESTQ AX, AX									
  errors.go:26			0x75ee97		7533			JNE 0x75eecc									
  errors.go:31			0x75ee99		90			NOPL										
  errors.go:65			0x75ee9a		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75ee9f		488d1dfafe3800		LEAQ 0x38fefa(IP), BX								
  errors.go:65			0x75eea6		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75eeab		e8f024ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75eeb0		48c7400833000000	MOVQ $0x33, 0x8(AX)								
  errors.go:65			0x75eeb8		488d1538a30600		LEAQ 0x6a338(IP), DX								
  errors.go:65			0x75eebf		488910			MOVQ DX, 0(AX)									
  members_string.go:4211	0x75eec2		4889c3			MOVQ AX, BX									
  members_string.go:4211	0x75eec5		488d0584dc3b00		LEAQ 0x3bdc84(IP), AX								
  members_string.go:4211	0x75eecc		31c9			XORL CX, CX									
  members_string.go:4211	0x75eece		31ff			XORL DI, DI									
  members_string.go:4211	0x75eed0		4889c6			MOVQ AX, SI									
  members_string.go:4211	0x75eed3		4989d8			MOVQ BX, R8									
  members_string.go:4211	0x75eed6		31c0			XORL AX, AX									
  members_string.go:4211	0x75eed8		31db			XORL BX, BX									
  members_string.go:4211	0x75eeda		4881c490000000		ADDQ $0x90, SP									
  members_string.go:4211	0x75eee1		5d			POPQ BP										
  members_string.go:4211	0x75eee2		c3			RET										
  members_string.go:4210	0x75eee3		48898424c0000000	MOVQ AX, 0xc0(SP)								
  members_string.go:4210	0x75eeeb		4889742478		MOVQ SI, 0x78(SP)								
  members_string.go:4210	0x75eef0		48895c2470		MOVQ BX, 0x70(SP)								
  members_string.go:4210	0x75eef5		48894c2468		MOVQ CX, 0x68(SP)								
  members_string.go:4210	0x75eefa		4c898c24f0000000	MOVQ R9, 0xf0(SP)								
  members_string.go:4210	0x75ef02		4c898424e8000000	MOVQ R8, 0xe8(SP)								
  members_string.go:4210	0x75ef0a		4889bc2488000000	MOVQ DI, 0x88(SP)								
  members_string.go:4213	0x75ef12		4889d8			MOVQ BX, AX									
  members_string.go:4213	0x75ef15		4889cb			MOVQ CX, BX									
  members_string.go:4213	0x75ef18		4889f9			MOVQ DI, CX									
  members_string.go:4213	0x75ef1b		4889f7			MOVQ SI, DI									
  members_string.go:4213	0x75ef1e		6690			NOPW										
  members_string.go:4213	0x75ef20		e8fbd3e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4213	0x75ef25		4889842480000000	MOVQ AX, 0x80(SP)								
  members_string.go:4213	0x75ef2d		48895c2458		MOVQ BX, 0x58(SP)								
  ascii_scan_simd_amd64.go:9	0x75ef32		e80936ebff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIVector(SB)	
  ascii_scan_simd_amd64.go:9	0x75ef37		84c0			TESTL AL, AL									
  members_string.go:1186	0x75ef39		7518			JNE 0x75ef53									
  members_string.go:1189	0x75ef3b		90			NOPL										
  utf8.go:448			0x75ef3c		31d2			XORL DX, DX									
  utf8.go:448			0x75ef3e		4531e4			XORL R12, R12									
  utf8.go:448			0x75ef41		488b5c2458		MOVQ 0x58(SP), BX								
  utf8.go:448			0x75ef46		488b842480000000	MOVQ 0x80(SP), AX								
  utf8.go:448			0x75ef4e		e937010000		JMP 0x75f08a									
  members_string.go:4210	0x75ef53		488b9424f0000000	MOVQ 0xf0(SP), DX								
  members_string.go:4210	0x75ef5b		4883fa02		CMPQ DX, $0x2									
  members_string.go:4213	0x75ef5f		488b442458		MOVQ 0x58(SP), AX								
  members_string.go:4214	0x75ef64		0f85bf000000		JNE 0x75f029									
  members_string.go:4215	0x75ef6a		488b9424e8000000	MOVQ 0xe8(SP), DX								
  members_string.go:4215	0x75ef72		488b5a28		MOVQ 0x28(DX), BX								
  members_string.go:4215	0x75ef76		488b4a30		MOVQ 0x30(DX), CX								
  members_string.go:4215	0x75ef7a		488b7a38		MOVQ 0x38(DX), DI								
  members_string.go:4215	0x75ef7e		488b4220		MOVQ 0x20(DX), AX								
  members_string.go:4215	0x75ef82		e8f96afdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)		
  members_string.go:4216	0x75ef87		4885db			TESTQ BX, BX									
  members_string.go:4216	0x75ef8a		746c			JE 0x75eff8									
  errors.go:26			0x75ef8c		488d05571f0600		LEAQ 0x61f57(IP), AX								
  errors.go:26			0x75ef93		bb24000000		MOVL $0x24, BX									
  errors.go:26			0x75ef98		31c9			XORL CX, CX									
  errors.go:26			0x75ef9a		31ff			XORL DI, DI									
  errors.go:26			0x75ef9c		89fe			MOVL DI, SI									
  errors.go:26			0x75ef9e		6690			NOPW										
  errors.go:26			0x75efa0		e81befd7ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75efa5		4885c0			TESTQ AX, AX									
  errors.go:26			0x75efa8		7537			JNE 0x75efe1									
  errors.go:31			0x75efaa		90			NOPL										
  errors.go:65			0x75efab		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75efb0		488d1de9fd3800		LEAQ 0x38fde9(IP), BX								
  errors.go:65			0x75efb7		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75efbc		0f1f4000		NOPL 0(AX)									
  errors.go:65			0x75efc0		e8db23ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75efc5		48c7400824000000	MOVQ $0x24, 0x8(AX)								
  errors.go:65			0x75efcd		488d15161f0600		LEAQ 0x61f16(IP), DX								
  errors.go:65			0x75efd4		488910			MOVQ DX, 0(AX)									
  members_string.go:4217	0x75efd7		4889c3			MOVQ AX, BX									
  members_string.go:4217	0x75efda		488d056fdb3b00		LEAQ 0x3bdb6f(IP), AX								
  members_string.go:4217	0x75efe1		31c9			XORL CX, CX									
  members_string.go:4217	0x75efe3		31ff			XORL DI, DI									
  members_string.go:4217	0x75efe5		4889c6			MOVQ AX, SI									
  members_string.go:4217	0x75efe8		4989d8			MOVQ BX, R8									
  members_string.go:4217	0x75efeb		31c0			XORL AX, AX									
  members_string.go:4217	0x75efed		31db			XORL BX, BX									
  members_string.go:4217	0x75efef		4881c490000000		ADDQ $0x90, SP									
  members_string.go:4217	0x75eff6		5d			POPQ BP										
  members_string.go:4217	0x75eff7		c3			RET										
  members_string.go:4215	0x75eff8		4889442460		MOVQ AX, 0x60(SP)								
  members_string.go:4219	0x75effd		488b442470		MOVQ 0x70(SP), AX								
  members_string.go:4219	0x75f002		488b5c2468		MOVQ 0x68(SP), BX								
  members_string.go:4219	0x75f007		488b8c2488000000	MOVQ 0x88(SP), CX								
  members_string.go:4219	0x75f00f		488b7c2478		MOVQ 0x78(SP), DI								
  members_string.go:4219	0x75f014		e807d3e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4219	0x75f019		488b4c2460		MOVQ 0x60(SP), CX								
  members_string.go:4219	0x75f01e		6690			NOPW										
  members_string.go:4219	0x75f020		e8fb09f7ff		CALL github.com/mgomes/vibescript/internal/runtime.stringEffectiveOffset(SB)	
  members_string.go:4219	0x75f025		84db			TESTL BL, BL									
  members_string.go:4220	0x75f027		7448			JE 0x75f071									
  members_string.go:4225	0x75f029		488b9424e8000000	MOVQ 0xe8(SP), DX								
  members_string.go:4225	0x75f031		4c8b02			MOVQ 0(DX), R8									
  members_string.go:4225	0x75f034		4c8b4a08		MOVQ 0x8(DX), R9								
  members_string.go:4225	0x75f038		4c8b5210		MOVQ 0x10(DX), R10								
  members_string.go:4225	0x75f03c		4c8b5a18		MOVQ 0x18(DX), R11								
  members_string.go:4225	0x75f040		48890424		MOVQ AX, 0(SP)									
  members_string.go:4225	0x75f044		488b8424c0000000	MOVQ 0xc0(SP), AX								
  members_string.go:4225	0x75f04c		488b5c2470		MOVQ 0x70(SP), BX								
  members_string.go:4225	0x75f051		488b4c2468		MOVQ 0x68(SP), CX								
  members_string.go:4225	0x75f056		488bbc2488000000	MOVQ 0x88(SP), DI								
  members_string.go:4225	0x75f05e		488b742478		MOVQ 0x78(SP), SI								
  members_string.go:4225	0x75f063		e8d800f8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringRIndexResult(SB)	
  members_string.go:4225	0x75f068		4881c490000000		ADDQ $0x90, SP									
  members_string.go:4225	0x75f06f		5d			POPQ BP										
  members_string.go:4225	0x75f070		c3			RET										
  members_string.go:4221	0x75f071		31c0			XORL AX, AX									
  members_string.go:4221	0x75f073		31db			XORL BX, BX									
  members_string.go:4221	0x75f075		31c9			XORL CX, CX									
  members_string.go:4221	0x75f077		31ff			XORL DI, DI									
  members_string.go:4221	0x75f079		89de			MOVL BX, SI									
  members_string.go:4221	0x75f07b		4189c8			MOVL CX, R8									
  members_string.go:4221	0x75f07e		4881c490000000		ADDQ $0x90, SP									
  members_string.go:4221	0x75f085		5d			POPQ BP										
  members_string.go:4221	0x75f086		c3			RET										
  utf8.go:449			0x75f087		48ffc2			INCQ DX										
  utf8.go:448			0x75f08a		4c39e3			CMPQ BX, R12									
  utf8.go:448			0x75f08d		7e34			JLE 0x75f0c3									
  utf8.go:448			0x75f08f		460fb62c20		MOVZX 0(AX)(R12*1), R13								
  utf8.go:448			0x75f094		4183fd7f		CMPL R13, $0x7f									
  utf8.go:448			0x75f098		7f05			JG 0x75f09f									
  utf8.go:448			0x75f09a		49ffc4			INCQ R12									
  utf8.go:448			0x75f09d		ebe8			JMP 0x75f087									
  utf8.go:448			0x75f09f		4889542450		MOVQ DX, 0x50(SP)								
  utf8.go:448			0x75f0a4		4c89e1			MOVQ R12, CX									
  utf8.go:448			0x75f0a7		e854e1d1ff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x75f0ac		488b842480000000	MOVQ 0x80(SP), AX								
  utf8.go:449			0x75f0b4		488b542450		MOVQ 0x50(SP), DX								
  utf8.go:449			0x75f0b9		4989dc			MOVQ BX, R12									
  utf8.go:448			0x75f0bc		488b5c2458		MOVQ 0x58(SP), BX								
  utf8.go:448			0x75f0c1		ebc4			JMP 0x75f087									
  members_string.go:4210	0x75f0c3		4c8ba424f0000000	MOVQ 0xf0(SP), R12								
  members_string.go:4210	0x75f0cb		4983fc02		CMPQ R12, $0x2									
  members_string.go:4213	0x75f0cf		4889d0			MOVQ DX, AX									
  members_string.go:4213	0x75f0d2		e98dfeffff		JMP 0x75ef64									
  members_string.go:4209	0x75f0d7		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4209	0x75f0dc		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4209	0x75f0e1		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4209	0x75f0e6		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4209	0x75f0eb		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4209	0x75f0f0		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4209	0x75f0f5		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4209	0x75f0fa		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4209	0x75f0ff		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4209	0x75f104		e837d5d2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4209	0x75f109		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4209	0x75f10e		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4209	0x75f113		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4209	0x75f118		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4209	0x75f11d		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4209	0x75f122		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4209	0x75f127		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4209	0x75f12c		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4209	0x75f131		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4209	0x75f136		e905fdffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func27(SB)	

package main

import (
    "context"
    "regexp"
    "testing"

    "github.com/mgomes/vibescript/vibes"
    "github.com/mgomes/vibescript/vibes/value"
)

type Config = vibes.Config
type Engine = vibes.Engine
type Script = vibes.Script
type CallOptions = vibes.CallOptions
type Value = value.Value

func MustNewEngine(config Config) *Engine { return vibes.MustNewEngine(config) }
func NewString(text string) Value { return value.NewString(text) }
func NewInt(n int64) Value { return value.NewInt(n) }
func NewNil() Value { return value.NewNil() }
func NewHash(entries map[string]Value) Value { return value.NewHash(entries) }

func parseProbeJSON(text string) (Value, error) {
    engine := vibes.MustNewEngine(vibes.Config{StepQuota: 5_000_000, MemoryQuotaBytes: 64 << 20})
    script, err := engine.Compile("def run(s) JSON.parse(s) end")
    if err != nil { return value.NewNil(), err }
    return script.Call(context.Background(), "run", []value.Value{value.NewString(text)}, vibes.CallOptions{})
}

func main() {
    testing.Main(regexp.MatchString, nil, []testing.InternalBenchmark{
        {Name: "BenchmarkSIMDStringLengthLoopASCII", F: BenchmarkSIMDStringLengthLoopASCII},
        {Name: "BenchmarkSIMDStringLengthLoopUnicode", F: BenchmarkSIMDStringLengthLoopUnicode},
        {Name: "BenchmarkSIMDStringIndexLoopASCII", F: BenchmarkSIMDStringIndexLoopASCII},
        {Name: "BenchmarkSIMDStringIndexLoopUnicode", F: BenchmarkSIMDStringIndexLoopUnicode},
        {Name: "BenchmarkSIMDStringRIndexLoopASCII", F: BenchmarkSIMDStringRIndexLoopASCII},
        {Name: "BenchmarkSIMDStringRIndexLoopUnicode", F: BenchmarkSIMDStringRIndexLoopUnicode},
        {Name: "BenchmarkSIMDStringSliceLoopASCII", F: BenchmarkSIMDStringSliceLoopASCII},
        {Name: "BenchmarkSIMDStringSliceLoopUnicode", F: BenchmarkSIMDStringSliceLoopUnicode},
        {Name: "BenchmarkStringASCIICase", F: BenchmarkStringASCIICase},
        {Name: "BenchmarkStringCaseComparison", F: BenchmarkStringCaseComparison},
        {Name: "BenchmarkJSONSpans", F: BenchmarkJSONSpans},
        {Name: "BenchmarkJSONSpansMixedDocument", F: BenchmarkJSONSpansMixedDocument},
        {Name: "BenchmarkRegexpEscapeSpans", F: BenchmarkRegexpEscapeSpans},
        {Name: "BenchmarkRegexpEscapeCaller", F: BenchmarkRegexpEscapeCaller},
        {Name: "BenchmarkWhitespaceStrip", F: BenchmarkWhitespaceStrip},
        {Name: "BenchmarkWhitespaceSplit", F: BenchmarkWhitespaceSplit},
    }, nil)
}

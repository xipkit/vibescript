TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB) /home/runner/work/vibescript/vibescript/ascii/vibes/value/value_methods.go
  value_methods.go:605		0x5aeca0		4c8da42488feffff	LEAQ 0xfffffe88(SP), R12									
  value_methods.go:605		0x5aeca8		4d3b6610		CMPQ R12, 0x10(R14)										
  value_methods.go:605		0x5aecac		0f86c9060000		JBE 0x5af37b											
  value_methods.go:605		0x5aecb2		55			PUSHQ BP											
  value_methods.go:605		0x5aecb3		4889e5			MOVQ SP, BP											
  value_methods.go:605		0x5aecb6		4881ecf0010000		SUBQ $0x1f0, SP											
  value_methods.go:605		0x5aecbd		48899c2408020000	MOVQ BX, 0x208(SP)										
  value_methods.go:605		0x5aecc5		48898c2410020000	MOVQ CX, 0x210(SP)										
  value_methods.go:607		0x5aeccd		4889b42420020000	MOVQ SI, 0x220(SP)										
  value_methods.go:605		0x5aecd5		48c744244000000000	MOVQ $0x0, 0x40(SP)										
  value_methods.go:605		0x5aecde		6690			NOPW												
  value_methods.go:607		0x5aece0		4883f805		CMPQ AX, $0x5											
  value_methods.go:607		0x5aece4		0f8493020000		JE 0x5aef7d											
  value_methods.go:627		0x5aecea		4883f806		CMPQ AX, $0x6											
  value_methods.go:627		0x5aecee		0f84d5000000		JE 0x5aedc9											
  value_methods.go:647		0x5aecf4		4883f814		CMPQ AX, $0x14											
  value_methods.go:647		0x5aecf8		0f8488000000		JE 0x5aed86											
  value_methods.go:652		0x5aecfe		488b157b355b00		MOVQ github.com/mgomes/vibescript/vibes/value.RuntimeStringRuneLen(SB), DX			
  value_methods.go:652		0x5aed05		4885d2			TESTQ DX, DX											
  value_methods.go:652		0x5aed08		7449			JE 0x5aed53											
  value_methods.go:607		0x5aed0a		4889bc2418010000	MOVQ DI, 0x118(SP)										
  value_methods.go:607		0x5aed12		48898c24e8010000	MOVQ CX, 0x1e8(SP)										
  value_methods.go:607		0x5aed1a		48899c2410010000	MOVQ BX, 0x110(SP)										
  value_methods.go:607		0x5aed22		4889842408010000	MOVQ AX, 0x108(SP)										
  value_methods.go:653		0x5aed2a		488b32			MOVQ 0(DX), SI											
  value_methods.go:653		0x5aed2d		ffd6			CALL SI												
  value_methods.go:653		0x5aed2f		84db			TESTL BL, BL											
  value_methods.go:653		0x5aed31		753b			JNE 0x5aed6e											
  value_methods.go:657		0x5aed33		488b842408010000	MOVQ 0x108(SP), AX										
  value_methods.go:657		0x5aed3b		488b8c24e8010000	MOVQ 0x1e8(SP), CX										
  value_methods.go:657		0x5aed43		488b9c2410010000	MOVQ 0x110(SP), BX										
  value_methods.go:657		0x5aed4b		488bbc2418010000	MOVQ 0x118(SP), DI										
  value_methods.go:657		0x5aed53		e868d5ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  value_methods.go:657		0x5aed58		4889842428010000	MOVQ AX, 0x128(SP)										
  value_methods.go:657		0x5aed60		48895c2458		MOVQ BX, 0x58(SP)										
  utf8.go:448			0x5aed65		31d2			XORL DX, DX											
  utf8.go:448			0x5aed67		31f6			XORL SI, SI											
  utf8.go:448			0x5aed69		e9bd050000		JMP 0x5af32b											
  value_methods.go:654		0x5aed6e		4889442440		MOVQ AX, 0x40(SP)										
  value_methods.go:659		0x5aed73		e868d0e9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:654		0x5aed78		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aed7d		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aed84		5d			POPQ BP												
  value_methods.go:659		0x5aed85		c3			RET												
  value_methods.go:650		0x5aed86		488d15ab9e5500		LEAQ 0x559eab(IP), DX										
  value_methods.go:650		0x5aed8d		4839d3			CMPQ BX, DX											
  value_methods.go:650		0x5aed90		0f857b050000		JNE 0x5af311											
  value_methods.go:650		0x5aed96		488b01			MOVQ 0(CX), AX											
  value_methods.go:650		0x5aed99		488b5908		MOVQ 0x8(CX), BX										
  value_methods.go:650		0x5aed9d		488b5110		MOVQ 0x10(CX), DX										
  value_methods.go:650		0x5aeda1		488b7918		MOVQ 0x18(CX), DI										
  value_methods.go:650		0x5aeda5		488b7120		MOVQ 0x20(CX), SI										
  value_methods.go:650		0x5aeda9		4889d1			MOVQ DX, CX											
  value_methods.go:650		0x5aedac		e86f69ffff		CALL github.com/mgomes/vibescript/vibes/value.Regex.StringRuneLen(SB)				
  value_methods.go:650		0x5aedb1		4889442440		MOVQ AX, 0x40(SP)										
  value_methods.go:659		0x5aedb6		e825d0e9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:650		0x5aedbb		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aedc0		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aedc7		5d			POPQ BP												
  value_methods.go:659		0x5aedc8		c3			RET												
  value_methods.go:628		0x5aedc9		90			NOPL												
  value_accessors.go:113	0x5aedca		488d150fe95000		LEAQ 0x50e90f(IP), DX										
  value_accessors.go:113	0x5aedd1		4839d3			CMPQ BX, DX											
  value_accessors.go:113	0x5aedd4		0f8525050000		JNE 0x5af2ff											
  value_accessors.go:113	0x5aedda		488b19			MOVQ 0(CX), BX											
  value_accessors.go:113	0x5aeddd		0f1f00			NOPL 0(AX)											
  value_methods.go:629		0x5aede0		4885db			TESTQ BX, BX											
  value_methods.go:629		0x5aede3		7405			JE 0x5aedea											
  value_methods.go:629		0x5aede5		488b13			MOVQ 0(BX), DX											
  value_methods.go:629		0x5aede8		eb02			JMP 0x5aedec											
  value_methods.go:629		0x5aedea		31d2			XORL DX, DX											
  value_methods.go:629		0x5aedec		4885d2			TESTQ DX, DX											
  value_methods.go:629		0x5aedef		0f846c010000		JE 0x5aef61											
  value_accessors.go:113	0x5aedf5		48899c24e0010000	MOVQ BX, 0x1e0(SP)										
  type.go:208			0x5aedfd		0fb615809d5100		MOVZX 0x519d80(IP), DX										
  value.go:165			0x5aee04		90			NOPL												
  type.go:208			0x5aee05		f6c220			TESTL $0x20, DL											
  value.go:3164			0x5aee08		b995000000		MOVL $0x95, CX											
  value.go:3164			0x5aee0d		ba15000000		MOVL $0x15, DX											
  value.go:3164			0x5aee12		480f45ca		CMOVNE DX, CX											
  value_methods.go:632		0x5aee16		488d05539d5100		LEAQ 0x519d53(IP), AX										
  value_methods.go:632		0x5aee1d		0f1f00			NOPL 0(AX)											
  value_methods.go:632		0x5aee20		e8fb7ff1ff		CALL reflect.Value.Pointer(SB)									
  value_methods.go:633		0x5aee25		4885c0			TESTQ AX, AX											
  value_methods.go:633		0x5aee28		7510			JNE 0x5aee3a											
  value_methods.go:629		0x5aee2a		488b9c24e0010000	MOVQ 0x1e0(SP), BX										
  value_methods.go:629		0x5aee32		4885db			TESTQ BX, BX											
  value_methods.go:633		0x5aee35		e9a9000000		JMP 0x5aeee3											
  value_methods.go:632		0x5aee3a		4889442460		MOVQ AX, 0x60(SP)										
  value_methods.go:634		0x5aee3f		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:634		0x5aee47		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:634		0x5aee4b		4889c1			MOVQ AX, CX											
  value_methods.go:634		0x5aee4e		488d055ba15100		LEAQ 0x51a15b(IP), AX										
  value_methods.go:634		0x5aee55		e82699e5ff		CALL runtime.mapaccess2_fast64(SB)								
  value_methods.go:634		0x5aee5a		660f1f440000		NOPW 0(AX)(AX*1)										
  value_methods.go:634		0x5aee60		84db			TESTL BL, BL											
  value_methods.go:634		0x5aee62		0f85dd000000		JNE 0x5aef45											
  value_methods.go:637		0x5aee68		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:637		0x5aee70		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:637		0x5aee74		488d0535a15100		LEAQ 0x51a135(IP), AX										
  value_methods.go:637		0x5aee7b		488b4c2460		MOVQ 0x60(SP), CX										
  value_methods.go:637		0x5aee80		e85b9be5ff		CALL runtime.mapassign_fast64(SB)								
  value_methods.go:637		0x5aee85		8400			TESTB AL, 0(AX)											
  value_methods.go:638		0x5aee87		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:638		0x5aee8f		488b5208		MOVQ 0x8(DX), DX										
  value_methods.go:638		0x5aee93		488d35065c0000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB), SI	
  value_methods.go:638		0x5aee9a		4889b42438010000	MOVQ SI, 0x138(SP)										
  value_methods.go:638		0x5aeea2		4889942440010000	MOVQ DX, 0x140(SP)										
  value_methods.go:638		0x5aeeaa		488b542460		MOVQ 0x60(SP), DX										
  value_methods.go:638		0x5aeeaf		4889942448010000	MOVQ DX, 0x148(SP)										
  value_methods.go:638		0x5aeeb7		488d942438010000	LEAQ 0x138(SP), DX										
  value_methods.go:638		0x5aeebf		48899424a0000000	MOVQ DX, 0xa0(SP)										
  value_methods.go:638		0x5aeec7		488d842488000000	LEAQ 0x88(SP), AX										
  value_methods.go:638		0x5aeecf		e8ecc9e9ff		CALL runtime.deferprocStack(SB)									
  value_methods.go:629		0x5aeed4		488b9c24e0010000	MOVQ 0x1e0(SP), BX										
  value_methods.go:629		0x5aeedc		0f1f4000		NOPL 0(AX)											
  value_methods.go:629		0x5aeee0		4885db			TESTQ BX, BX											
  value_methods.go:641		0x5aeee3		7405			JE 0x5aeeea											
  value_methods.go:641		0x5aeee5		488b13			MOVQ 0(BX), DX											
  value_methods.go:641		0x5aeee8		eb02			JMP 0x5aeeec											
  value_methods.go:641		0x5aeeea		31d2			XORL DX, DX											
  value_methods.go:1031		0x5aeeec		4883fa02		CMPQ DX, $0x2											
  value_methods.go:1031		0x5aeef0		7d04			JGE 0x5aeef6											
  value_methods.go:1031		0x5aeef2		31d2			XORL DX, DX											
  value_methods.go:641		0x5aeef4		eb08			JMP 0x5aeefe											
  value_methods.go:1034		0x5aeef6		488d1412		LEAQ 0(DX)(DX*1), DX										
  value_methods.go:1034		0x5aeefa		488d52fe		LEAQ -0x2(DX), DX										
  value_methods.go:641		0x5aeefe		4889542438		MOVQ DX, 0x38(SP)										
  value_methods.go:642		0x5aef03		488d8c2478010000	LEAQ 0x178(SP), CX										
  value_methods.go:642		0x5aef0b		440f1139		MOVUPS X15, 0(CX)										
  value_methods.go:642		0x5aef0f		440f117910		MOVUPS X15, 0x10(CX)										
  value_methods.go:642		0x5aef14		440f117920		MOVUPS X15, 0x20(CX)										
  value_methods.go:642		0x5aef19		440f117930		MOVUPS X15, 0x30(CX)										
  value_methods.go:642		0x5aef1e		440f117940		MOVUPS X15, 0x40(CX)										
  value_methods.go:642		0x5aef23		440f117950		MOVUPS X15, 0x50(CX)										
  value_methods.go:642		0x5aef28		488d05419c5100		LEAQ 0x519c41(IP), AX										
  value_methods.go:642		0x5aef2f		e88c59e7ff		CALL runtime.mapIterStart(SB)									
  value_methods.go:641		0x5aef34		488b542438		MOVQ 0x38(SP), DX										
  value_methods.go:641		0x5aef39		4883c202		ADDQ $0x2, DX											
  value_methods.go:641		0x5aef3d		0f1f00			NOPL 0(AX)											
  value_methods.go:642		0x5aef40		e9d4020000		JMP 0x5af219											
  value_methods.go:635		0x5aef45		48c744244007000000	MOVQ $0x7, 0x40(SP)										
  value_methods.go:659		0x5aef4e		e88dcee9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:635		0x5aef53		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aef58		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aef5f		5d			POPQ BP												
  value_methods.go:659		0x5aef60		c3			RET												
  value_methods.go:630		0x5aef61		48c744244002000000	MOVQ $0x2, 0x40(SP)										
  value_methods.go:659		0x5aef6a		e871cee9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:630		0x5aef6f		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5aef74		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5aef7b		5d			POPQ BP												
  value_methods.go:659		0x5aef7c		c3			RET												
  value_methods.go:608		0x5aef7d		90			NOPL												
  value_accessors.go:86		0x5aef7e		488d15b3e65000		LEAQ 0x50e6b3(IP), DX										
  value_accessors.go:86		0x5aef85		4839d3			CMPQ BX, DX											
  value_accessors.go:86		0x5aef88		0f8534020000		JNE 0x5af1c2											
  value_accessors.go:86		0x5aef8e		488b5908		MOVQ 0x8(CX), BX										
  value_accessors.go:86		0x5aef92		48895c2428		MOVQ BX, 0x28(SP)										
  value_accessors.go:86		0x5aef97		488b5110		MOVQ 0x10(CX), DX										
  value_accessors.go:86		0x5aef9b		4889542430		MOVQ DX, 0x30(SP)										
  value_accessors.go:86		0x5aefa0		488b01			MOVQ 0(CX), AX											
  value_accessors.go:86		0x5aefa3		4889842420010000	MOVQ AX, 0x120(SP)										
  value_methods.go:610		0x5aefab		4889d1			MOVQ DX, CX											
  value_methods.go:610		0x5aefae		e86d6bedff		CALL runtime.convTslice(SB)									
  type.go:208			0x5aefb3		0fb615623e5100		MOVZX 0x513e62(IP), DX										
  value.go:165			0x5aefba		90			NOPL												
  type.go:208			0x5aefbb		f6c220			TESTL $0x20, DL											
  value.go:3164			0x5aefbe		b997000000		MOVL $0x97, CX											
  value.go:3164			0x5aefc3		ba17000000		MOVL $0x17, DX											
  value.go:3164			0x5aefc8		480f45ca		CMOVNE DX, CX											
  value_methods.go:610		0x5aefcc		4889c3			MOVQ AX, BX											
  value_methods.go:610		0x5aefcf		488d05323e5100		LEAQ 0x513e32(IP), AX										
  value_methods.go:610		0x5aefd6		e8457ef1ff		CALL reflect.Value.Pointer(SB)									
  value_methods.go:610		0x5aefdb		0f1f440000		NOPL 0(AX)(AX*1)										
  value_methods.go:614		0x5aefe0		4885c0			TESTQ AX, AX											
  value_methods.go:614		0x5aefe3		0f8407010000		JE 0x5af0f0											
  value_methods.go:610		0x5aefe9		4889842480000000	MOVQ AX, 0x80(SP)										
  value_methods.go:615		0x5aeff1		48898424e8000000	MOVQ AX, 0xe8(SP)										
  value_methods.go:615		0x5aeff9		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:615		0x5aeffe		48899424f0000000	MOVQ DX, 0xf0(SP)										
  value_methods.go:615		0x5af006		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:615		0x5af00b		48899424f8000000	MOVQ DX, 0xf8(SP)										
  value_methods.go:615		0x5af013		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:615		0x5af01b		488b1a			MOVQ 0(DX), BX											
  value_methods.go:615		0x5af01e		488d05aba15100		LEAQ 0x51a1ab(IP), AX										
  value_methods.go:615		0x5af025		488d8c24e8000000	LEAQ 0xe8(SP), CX										
  value_methods.go:615		0x5af02d		e8ee87e5ff		CALL runtime.mapaccess2(SB)									
  value_methods.go:615		0x5af032		84db			TESTL BL, BL											
  value_methods.go:615		0x5af034		0f85f9000000		JNE 0x5af133											
  value_methods.go:618		0x5af03a		488b942480000000	MOVQ 0x80(SP), DX										
  value_methods.go:618		0x5af042		48899424e8000000	MOVQ DX, 0xe8(SP)										
  value_methods.go:618		0x5af04a		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:618		0x5af04f		48899424f0000000	MOVQ DX, 0xf0(SP)										
  value_methods.go:618		0x5af057		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:618		0x5af05c		48899424f8000000	MOVQ DX, 0xf8(SP)										
  value_methods.go:618		0x5af064		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:618		0x5af06c		488b1a			MOVQ 0(DX), BX											
  value_methods.go:618		0x5af06f		488d055aa15100		LEAQ 0x51a15a(IP), AX										
  value_methods.go:618		0x5af076		488d8c24e8000000	LEAQ 0xe8(SP), CX										
  value_methods.go:618		0x5af07e		6690			NOPW												
  value_methods.go:618		0x5af080		e87b8ae5ff		CALL runtime.mapassign(SB)									
  value_methods.go:618		0x5af085		8400			TESTB AL, 0(AX)											
  value_methods.go:619		0x5af087		488b942420020000	MOVQ 0x220(SP), DX										
  value_methods.go:619		0x5af08f		488b12			MOVQ 0(DX), DX											
  value_methods.go:619		0x5af092		488d35475a0000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB), SI	
  value_methods.go:619		0x5af099		4889b42450010000	MOVQ SI, 0x150(SP)										
  value_methods.go:619		0x5af0a1		4889942458010000	MOVQ DX, 0x158(SP)										
  value_methods.go:619		0x5af0a9		488b942480000000	MOVQ 0x80(SP), DX										
  value_methods.go:619		0x5af0b1		4889942460010000	MOVQ DX, 0x160(SP)										
  value_methods.go:619		0x5af0b9		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:619		0x5af0be		4889942468010000	MOVQ DX, 0x168(SP)										
  value_methods.go:619		0x5af0c6		488b542430		MOVQ 0x30(SP), DX										
  value_methods.go:619		0x5af0cb		4889942470010000	MOVQ DX, 0x170(SP)										
  value_methods.go:619		0x5af0d3		488d942450010000	LEAQ 0x150(SP), DX										
  value_methods.go:619		0x5af0db		48899424d0000000	MOVQ DX, 0xd0(SP)										
  value_methods.go:619		0x5af0e3		488d8424b8000000	LEAQ 0xb8(SP), AX										
  value_methods.go:619		0x5af0eb		e8d0c7e9ff		CALL runtime.deferprocStack(SB)									
  value_methods.go:1031		0x5af0f0		488b542428		MOVQ 0x28(SP), DX										
  value_methods.go:1031		0x5af0f5		4883fa02		CMPQ DX, $0x2											
  value_methods.go:1031		0x5af0f9		7d07			JGE 0x5af102											
  value_methods.go:1031		0x5af0fb		4531c0			XORL R8, R8											
  value_methods.go:1031		0x5af0fe		6690			NOPW												
  value_methods.go:622		0x5af100		eb08			JMP 0x5af10a											
  value_methods.go:1034		0x5af102		4c8d0412		LEAQ 0(DX)(DX*1), R8										
  value_methods.go:1034		0x5af106		4d8d40fe		LEAQ -0x2(R8), R8										
  value_methods.go:622		0x5af10a		4983c002		ADDQ $0x2, R8											
  value_methods.go:623		0x5af10e		4c8b8c2420010000	MOVQ 0x120(SP), R9										
  value_methods.go:623		0x5af116		e98a000000		JMP 0x5af1a5											
  value_methods.go:659		0x5af11b		0f1f440000		NOPL 0(AX)(AX*1)										
  value_methods.go:659		0x5af120		e8bbcce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:619		0x5af125		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af12a		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af131		5d			POPQ BP												
  value_methods.go:659		0x5af132		c3			RET												
  value_methods.go:616		0x5af133		48c744244007000000	MOVQ $0x7, 0x40(SP)										
  value_methods.go:616		0x5af13c		0f1f4000		NOPL 0(AX)											
  value_methods.go:659		0x5af140		e89bcce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:616		0x5af145		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af14a		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af151		5d			POPQ BP												
  value_methods.go:659		0x5af152		c3			RET												
  value_methods.go:623		0x5af153		4889942400010000	MOVQ DX, 0x100(SP)										
  value_methods.go:623		0x5af15b		4c89442450		MOVQ R8, 0x50(SP)										
  value_methods.go:623		0x5af160		4c898c24d8010000	MOVQ R9, 0x1d8(SP)										
  value_methods.go:623		0x5af168		498b01			MOVQ 0(R9), AX											
  value_methods.go:623		0x5af16b		498b4910		MOVQ 0x10(R9), CX										
  value_methods.go:623		0x5af16f		498b7918		MOVQ 0x18(R9), DI										
  value_methods.go:623		0x5af173		498b5908		MOVQ 0x8(R9), BX										
  value_methods.go:624		0x5af177		488bb42420020000	MOVQ 0x220(SP), SI										
  value_methods.go:624		0x5af17f		90			NOPL												
  value_methods.go:624		0x5af180		e81bfbffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			
  value_methods.go:623		0x5af185		4c8b8c24d8010000	MOVQ 0x1d8(SP), R9										
  value_methods.go:623		0x5af18d		4983c120		ADDQ $0x20, R9											
  value_methods.go:624		0x5af191		488b542450		MOVQ 0x50(SP), DX										
  value_methods.go:624		0x5af196		4c8d0402		LEAQ 0(DX)(AX*1), R8										
  value_methods.go:623		0x5af19a		488b942400010000	MOVQ 0x100(SP), DX										
  value_methods.go:623		0x5af1a2		48ffca			DECQ DX												
  value_methods.go:623		0x5af1a5		4885d2			TESTQ DX, DX											
  value_methods.go:623		0x5af1a8		7fa9			JG 0x5af153											
  value_methods.go:626		0x5af1aa		4c89442440		MOVQ R8, 0x40(SP)										
  value_methods.go:659		0x5af1af		e82ccce9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:626		0x5af1b4		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af1b9		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af1c0		5d			POPQ BP												
  value_methods.go:659		0x5af1c1		c3			RET												
  value_accessors.go:86		0x5af1c2		4889d8			MOVQ BX, AX											
  value_accessors.go:86		0x5af1c5		4889d3			MOVQ DX, BX											
  value_accessors.go:86		0x5af1c8		488d0d21965300		LEAQ 0x539621(IP), CX										
  value_accessors.go:86		0x5af1cf		e82cdce6ff		CALL runtime.panicdottypeE(SB)									
  value_methods.go:644		0x5af1d4		4c89c0			MOVQ R8, AX											
  value_methods.go:644		0x5af1d7		4c89d3			MOVQ R10, BX											
  value_methods.go:644		0x5af1da		488bb42420020000	MOVQ 0x220(SP), SI										
  value_methods.go:644		0x5af1e2		e8b9faffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			
  value_methods.go:644		0x5af1e7		4889842400010000	MOVQ AX, 0x100(SP)										
  value_methods.go:642		0x5af1ef		488d842478010000	LEAQ 0x178(SP), AX										
  value_methods.go:642		0x5af1f7		e82457e7ff		CALL runtime.mapIterNext(SB)									
  value_methods.go:643		0x5af1fc		488b542470		MOVQ 0x70(SP), DX										
  value_methods.go:643		0x5af201		4c8b442448		MOVQ 0x48(SP), R8										
  value_methods.go:643		0x5af206		4c01c2			ADDQ R8, DX											
  value_methods.go:644		0x5af209		4c8b842400010000	MOVQ 0x100(SP), R8										
  value_methods.go:644		0x5af211		4a8d1402		LEAQ 0(DX)(R8*1), DX										
  value_methods.go:644		0x5af215		488d5202		LEAQ 0x2(DX), DX										
  value_methods.go:642		0x5af219		4c8b842478010000	MOVQ 0x178(SP), R8										
  value_methods.go:642		0x5af221		4d85c0			TESTQ R8, R8											
  value_methods.go:642		0x5af224		0f84bd000000		JE 0x5af2e7											
  value_methods.go:642		0x5af22a		4889542448		MOVQ DX, 0x48(SP)										
  value_methods.go:642		0x5af22f		4c8b8c2480010000	MOVQ 0x180(SP), R9										
  value_methods.go:642		0x5af237		498b00			MOVQ 0(R8), AX											
  value_methods.go:642		0x5af23a		4889842430010000	MOVQ AX, 0x130(SP)										
  value_methods.go:642		0x5af242		498b5808		MOVQ 0x8(R8), BX										
  value_methods.go:642		0x5af246		48895c2478		MOVQ BX, 0x78(SP)										
  value_methods.go:642		0x5af24b		4d8b01			MOVQ 0(R9), R8											
  value_methods.go:642		0x5af24e		4c89842408010000	MOVQ R8, 0x108(SP)										
  value_methods.go:642		0x5af256		4d8b5108		MOVQ 0x8(R9), R10										
  value_methods.go:642		0x5af25a		4c89942410010000	MOVQ R10, 0x110(SP)										
  value_methods.go:642		0x5af262		498b4910		MOVQ 0x10(R9), CX										
  value_methods.go:642		0x5af266		48898c24e8010000	MOVQ CX, 0x1e8(SP)										
  value_methods.go:642		0x5af26e		498b7918		MOVQ 0x18(R9), DI										
  value_methods.go:642		0x5af272		4889bc2418010000	MOVQ DI, 0x118(SP)										
  utf8.go:448			0x5af27a		4531c9			XORL R9, R9											
  utf8.go:448			0x5af27d		4531db			XORL R11, R11											
  utf8.go:448			0x5af280		eb03			JMP 0x5af285											
  utf8.go:449			0x5af282		49ffc1			INCQ R9												
  utf8.go:448			0x5af285		4c894c2470		MOVQ R9, 0x70(SP)										
  utf8.go:448			0x5af28a		4939db			CMPQ R11, BX											
  utf8.go:448			0x5af28d		0f8d41ffffff		JGE 0x5af1d4											
  utf8.go:448			0x5af293		450fb62403		MOVZX 0(R11)(AX*1), R12										
  utf8.go:448			0x5af298		4183fc7f		CMPL R12, $0x7f											
  utf8.go:448			0x5af29c		7f05			JG 0x5af2a3											
  utf8.go:448			0x5af29e		49ffc3			INCQ R11											
  utf8.go:448			0x5af2a1		ebdf			JMP 0x5af282											
  utf8.go:448			0x5af2a3		4c89d9			MOVQ R11, CX											
  utf8.go:448			0x5af2a6		e815dfecff		CALL runtime.decoderune(SB)									
  utf8.go:448			0x5af2ab		488b842430010000	MOVQ 0x130(SP), AX										
  value_methods.go:644		0x5af2b3		488b8c24e8010000	MOVQ 0x1e8(SP), CX										
  value_methods.go:643		0x5af2bb		488b542448		MOVQ 0x48(SP), DX										
  value_methods.go:644		0x5af2c0		488bbc2418010000	MOVQ 0x118(SP), DI										
  value_methods.go:644		0x5af2c8		4c8b842408010000	MOVQ 0x108(SP), R8										
  utf8.go:449			0x5af2d0		4c8b4c2470		MOVQ 0x70(SP), R9										
  value_methods.go:644		0x5af2d5		4c8b942410010000	MOVQ 0x110(SP), R10										
  utf8.go:449			0x5af2dd		4989db			MOVQ BX, R11											
  utf8.go:448			0x5af2e0		488b5c2478		MOVQ 0x78(SP), BX										
  utf8.go:448			0x5af2e5		eb9b			JMP 0x5af282											
  value_methods.go:646		0x5af2e7		4889542440		MOVQ DX, 0x40(SP)										
  value_methods.go:659		0x5af2ec		e8efcae9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:646		0x5af2f1		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af2f6		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af2fd		5d			POPQ BP												
  value_methods.go:659		0x5af2fe		c3			RET												
  value_accessors.go:113	0x5af2ff		4889d8			MOVQ BX, AX											
  value_accessors.go:113	0x5af302		4889d3			MOVQ DX, BX											
  value_accessors.go:113	0x5af305		488d0de4945300		LEAQ 0x5394e4(IP), CX										
  value_accessors.go:113	0x5af30c		e8efdae6ff		CALL runtime.panicdottypeE(SB)									
  value_methods.go:650		0x5af311		4889d8			MOVQ BX, AX											
  value_methods.go:650		0x5af314		4889d3			MOVQ DX, BX											
  value_methods.go:650		0x5af317		488d0dd2945300		LEAQ 0x5394d2(IP), CX										
  value_methods.go:650		0x5af31e		6690			NOPW												
  value_methods.go:650		0x5af320		e8dbdae6ff		CALL runtime.panicdottypeE(SB)									
  utf8.go:449			0x5af325		48ffc6			INCQ SI												
  utf8.go:448			0x5af328		4889ca			MOVQ CX, DX											
  utf8.go:448			0x5af32b		4839d3			CMPQ BX, DX											
  utf8.go:448			0x5af32e		7e33			JLE 0x5af363											
  utf8.go:448			0x5af330		0fb63c10		MOVZX 0(AX)(DX*1), DI										
  utf8.go:448			0x5af334		83ff7f			CMPL DI, $0x7f											
  utf8.go:448			0x5af337		7f06			JG 0x5af33f											
  utf8.go:448			0x5af339		488d4a01		LEAQ 0x1(DX), CX										
  utf8.go:448			0x5af33d		ebe6			JMP 0x5af325											
  utf8.go:448			0x5af33f		4889742468		MOVQ SI, 0x68(SP)										
  utf8.go:448			0x5af344		4889d1			MOVQ DX, CX											
  utf8.go:448			0x5af347		e874deecff		CALL runtime.decoderune(SB)									
  utf8.go:448			0x5af34c		488b842428010000	MOVQ 0x128(SP), AX										
  utf8.go:449			0x5af354		488b742468		MOVQ 0x68(SP), SI										
  utf8.go:449			0x5af359		4889d9			MOVQ BX, CX											
  utf8.go:448			0x5af35c		488b5c2458		MOVQ 0x58(SP), BX										
  utf8.go:448			0x5af361		ebc2			JMP 0x5af325											
  value_methods.go:657		0x5af363		4889742440		MOVQ SI, 0x40(SP)										
  value_methods.go:659		0x5af368		e873cae9ff		CALL runtime.deferreturn(SB)									
  value_methods.go:657		0x5af36d		488b442440		MOVQ 0x40(SP), AX										
  value_methods.go:659		0x5af372		4881c4f0010000		ADDQ $0x1f0, SP											
  value_methods.go:659		0x5af379		5d			POPQ BP												
  value_methods.go:659		0x5af37a		c3			RET												
  value_methods.go:605		0x5af37b		4889442408		MOVQ AX, 0x8(SP)										
  value_methods.go:605		0x5af380		48895c2410		MOVQ BX, 0x10(SP)										
  value_methods.go:605		0x5af385		48894c2418		MOVQ CX, 0x18(SP)										
  value_methods.go:605		0x5af38a		48897c2420		MOVQ DI, 0x20(SP)										
  value_methods.go:605		0x5af38f		4889742428		MOVQ SI, 0x28(SP)										
  value_methods.go:605		0x5af394		e867d2edff		CALL runtime.morestack_noctxt.abi0(SB)								
  value_methods.go:605		0x5af399		488b442408		MOVQ 0x8(SP), AX										
  value_methods.go:605		0x5af39e		488b5c2410		MOVQ 0x10(SP), BX										
  value_methods.go:605		0x5af3a3		488b4c2418		MOVQ 0x18(SP), CX										
  value_methods.go:605		0x5af3a8		488b7c2420		MOVQ 0x20(SP), DI										
  value_methods.go:605		0x5af3ad		488b742428		MOVQ 0x28(SP), SI										
  value_methods.go:605		0x5af3b2		e9e9f8ffff		JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState(SB)			

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB) /home/runner/work/vibescript/vibescript/ascii/vibes/value/value_methods.go
  value_methods.go:844		0x5b0720		4c8da42468feffff	LEAQ 0xfffffe68(SP), R12										
  value_methods.go:844		0x5b0728		4d3b6610		CMPQ R12, 0x10(R14)											
  value_methods.go:844		0x5b072c		0f86210a0000		JBE 0x5b1153												
  value_methods.go:844		0x5b0732		55			PUSHQ BP												
  value_methods.go:844		0x5b0733		4889e5			MOVQ SP, BP												
  value_methods.go:844		0x5b0736		4881ec10020000		SUBQ $0x210, SP												
  value_methods.go:844		0x5b073d		48899c2428020000	MOVQ BX, 0x228(SP)											
  value_methods.go:844		0x5b0745		48898c2430020000	MOVQ CX, 0x230(SP)											
  value_methods.go:845		0x5b074d		4889b42440020000	MOVQ SI, 0x240(SP)											
  value_methods.go:845		0x5b0755		4c89842448020000	MOVQ R8, 0x248(SP)											
  value_methods.go:845		0x5b075d		48898c24f0010000	MOVQ CX, 0x1f0(SP)											
  value_methods.go:845		0x5b0765		48899c24c8000000	MOVQ BX, 0xc8(SP)											
  value_methods.go:845		0x5b076d		48898424c0000000	MOVQ AX, 0xc0(SP)											
  value_methods.go:845		0x5b0775		4889bc24b8000000	MOVQ DI, 0xb8(SP)											
  value_methods.go:844		0x5b077d		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:844		0x5b0786		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:845		0x5b078f		498b00			MOVQ 0(R8), AX												
  value_methods.go:845		0x5b0792		4c89c2			MOVQ R8, DX												
  value_methods.go:845		0x5b0795		ffd0			CALL AX													
  value_methods.go:845		0x5b0797		660f1f840000000000	NOPW 0(AX)(AX*1)											
  value_methods.go:845		0x5b07a0		4885c0			TESTQ AX, AX												
  value_methods.go:845		0x5b07a3		0f854d050000		JNE 0x5b0cf6												
  value_methods.go:849		0x5b07a9		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:849		0x5b07b1		4883f805		CMPQ AX, $0x5												
  value_methods.go:849		0x5b07b5		0f85e5010000		JNE 0x5b09a0												
  value_methods.go:850		0x5b07bb		90			NOPL													
  value_accessors.go:86		0x5b07bc		488b8424c8000000	MOVQ 0xc8(SP), AX											
  value_accessors.go:86		0x5b07c4		488d1d6dce5000		LEAQ 0x50ce6d(IP), BX											
  value_accessors.go:86		0x5b07cb		4839d8			CMPQ AX, BX												
  value_accessors.go:86		0x5b07ce		0f8572090000		JNE 0x5b1146												
  value_accessors.go:86		0x5b07d4		488b9424f0010000	MOVQ 0x1f0(SP), DX											
  value_accessors.go:86		0x5b07dc		488b5a08		MOVQ 0x8(DX), BX											
  value_accessors.go:86		0x5b07e0		48895c2430		MOVQ BX, 0x30(SP)											
  value_accessors.go:86		0x5b07e5		488b4a10		MOVQ 0x10(DX), CX											
  value_accessors.go:86		0x5b07e9		48894c2438		MOVQ CX, 0x38(SP)											
  value_accessors.go:86		0x5b07ee		488b02			MOVQ 0(DX), AX												
  value_accessors.go:86		0x5b07f1		4889842440010000	MOVQ AX, 0x140(SP)											
  value_methods.go:852		0x5b07f9		e82253edff		CALL runtime.convTslice(SB)										
  type.go:208			0x5b07fe		0fb61517265100		MOVZX 0x512617(IP), DX											
  value.go:165			0x5b0805		90			NOPL													
  type.go:208			0x5b0806		f6c220			TESTL $0x20, DL												
  value.go:3164			0x5b0809		b997000000		MOVL $0x97, CX												
  value.go:3164			0x5b080e		ba17000000		MOVL $0x17, DX												
  value.go:3164			0x5b0813		480f45ca		CMOVNE DX, CX												
  value_methods.go:852		0x5b0817		4889c3			MOVQ AX, BX												
  value_methods.go:852		0x5b081a		488d05e7255100		LEAQ 0x5125e7(IP), AX											
  value_methods.go:852		0x5b0821		e8fa65f1ff		CALL reflect.Value.Pointer(SB)										
  value_methods.go:856		0x5b0826		4885c0			TESTQ AX, AX												
  value_methods.go:856		0x5b0829		0f840d010000		JE 0x5b093c												
  value_methods.go:852		0x5b082f		4889842490000000	MOVQ AX, 0x90(SP)											
  value_methods.go:857		0x5b0837		4889842498000000	MOVQ AX, 0x98(SP)											
  value_methods.go:857		0x5b083f		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:857		0x5b0844		48899424a0000000	MOVQ DX, 0xa0(SP)											
  value_methods.go:857		0x5b084c		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:857		0x5b0851		48899424a8000000	MOVQ DX, 0xa8(SP)											
  value_methods.go:857		0x5b0859		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:857		0x5b0861		488b1a			MOVQ 0(DX), BX												
  value_methods.go:857		0x5b0864		488d0565895100		LEAQ 0x518965(IP), AX											
  value_methods.go:857		0x5b086b		488d8c2498000000	LEAQ 0x98(SP), CX											
  value_methods.go:857		0x5b0873		e8a86fe5ff		CALL runtime.mapaccess2(SB)										
  value_methods.go:857		0x5b0878		0f1f840000000000	NOPL 0(AX)(AX*1)											
  value_methods.go:857		0x5b0880		84db			TESTL BL, BL												
  value_methods.go:857		0x5b0882		0f85dd000000		JNE 0x5b0965												
  value_methods.go:860		0x5b0888		488b942490000000	MOVQ 0x90(SP), DX											
  value_methods.go:860		0x5b0890		4889942498000000	MOVQ DX, 0x98(SP)											
  value_methods.go:860		0x5b0898		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:860		0x5b089d		48899424a0000000	MOVQ DX, 0xa0(SP)											
  value_methods.go:860		0x5b08a5		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:860		0x5b08aa		48899424a8000000	MOVQ DX, 0xa8(SP)											
  value_methods.go:860		0x5b08b2		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:860		0x5b08ba		488b1a			MOVQ 0(DX), BX												
  value_methods.go:860		0x5b08bd		488d050c895100		LEAQ 0x51890c(IP), AX											
  value_methods.go:860		0x5b08c4		488d8c2498000000	LEAQ 0x98(SP), CX											
  value_methods.go:860		0x5b08cc		e82f72e5ff		CALL runtime.mapassign(SB)										
  value_methods.go:860		0x5b08d1		8400			TESTB AL, 0(AX)												
  value_methods.go:861		0x5b08d3		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:861		0x5b08db		488b12			MOVQ 0(DX), DX												
  value_methods.go:861		0x5b08de		488d35fb420000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB), SI	
  value_methods.go:861		0x5b08e5		4889b42460010000	MOVQ SI, 0x160(SP)											
  value_methods.go:861		0x5b08ed		4889942468010000	MOVQ DX, 0x168(SP)											
  value_methods.go:861		0x5b08f5		488b942490000000	MOVQ 0x90(SP), DX											
  value_methods.go:861		0x5b08fd		4889942470010000	MOVQ DX, 0x170(SP)											
  value_methods.go:861		0x5b0905		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:861		0x5b090a		4889942478010000	MOVQ DX, 0x178(SP)											
  value_methods.go:861		0x5b0912		488b542438		MOVQ 0x38(SP), DX											
  value_methods.go:861		0x5b0917		4889942480010000	MOVQ DX, 0x180(SP)											
  value_methods.go:861		0x5b091f		488d942460010000	LEAQ 0x160(SP), DX											
  value_methods.go:861		0x5b0927		4889942418010000	MOVQ DX, 0x118(SP)											
  value_methods.go:861		0x5b092f		488d842400010000	LEAQ 0x100(SP), AX											
  value_methods.go:861		0x5b0937		e884afe9ff		CALL runtime.deferprocStack(SB)										
  value_methods.go:1031		0x5b093c		488b542430		MOVQ 0x30(SP), DX											
  value_methods.go:1031		0x5b0941		4883fa02		CMPQ DX, $0x2												
  value_methods.go:1031		0x5b0945		7d05			JGE 0x5b094c												
  value_methods.go:1031		0x5b0947		4531c9			XORL R9, R9												
  value_methods.go:864		0x5b094a		eb08			JMP 0x5b0954												
  value_methods.go:1034		0x5b094c		4c8d0c12		LEAQ 0(DX)(DX*1), R9											
  value_methods.go:1034		0x5b0950		4d8d49fe		LEAQ -0x2(R9), R9											
  value_methods.go:864		0x5b0954		4983c102		ADDQ $0x2, R9												
  value_methods.go:865		0x5b0958		4c8b942440010000	MOVQ 0x140(SP), R10											
  value_methods.go:865		0x5b0960		e931070000		JMP 0x5b1096												
  value_methods.go:858		0x5b0965		48c744244807000000	MOVQ $0x7, 0x48(SP)											
  value_methods.go:858		0x5b096e		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0977		e864b4e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:858		0x5b097c		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:858		0x5b0984		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:858		0x5b098c		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0991		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0998		5d			POPQ BP													
  value_methods.go:918		0x5b0999		c3			RET													
  value_methods.go:918		0x5b099a		660f1f440000		NOPW 0(AX)(AX*1)											
  value_methods.go:873		0x5b09a0		4883f806		CMPQ AX, $0x6												
  value_methods.go:873		0x5b09a4		0f850e020000		JNE 0x5b0bb8												
  value_methods.go:874		0x5b09aa		90			NOPL													
  value_accessors.go:113	0x5b09ab		488b8424c8000000	MOVQ 0xc8(SP), AX											
  value_accessors.go:113	0x5b09b3		488d1d26cd5000		LEAQ 0x50cd26(IP), BX											
  value_accessors.go:113	0x5b09ba		660f1f440000		NOPW 0(AX)(AX*1)											
  value_accessors.go:113	0x5b09c0		4839d8			CMPQ AX, BX												
  value_accessors.go:113	0x5b09c3		0f85a1060000		JNE 0x5b106a												
  value_accessors.go:113	0x5b09c9		488b9424f0010000	MOVQ 0x1f0(SP), DX											
  value_accessors.go:113	0x5b09d1		488b1a			MOVQ 0(DX), BX												
  value_methods.go:875		0x5b09d4		4885db			TESTQ BX, BX												
  value_methods.go:875		0x5b09d7		7405			JE 0x5b09de												
  value_methods.go:875		0x5b09d9		488b13			MOVQ 0(BX), DX												
  value_methods.go:875		0x5b09dc		eb02			JMP 0x5b09e0												
  value_methods.go:875		0x5b09de		31d2			XORL DX, DX												
  value_methods.go:875		0x5b09e0		4885d2			TESTQ DX, DX												
  value_methods.go:875		0x5b09e3		0f849a010000		JE 0x5b0b83												
  value_accessors.go:113	0x5b09e9		48899c2448010000	MOVQ BX, 0x148(SP)											
  type.go:208			0x5b09f1		0fb6158c815100		MOVZX 0x51818c(IP), DX											
  value.go:165			0x5b09f8		90			NOPL													
  type.go:208			0x5b09f9		f6c220			TESTL $0x20, DL												
  value.go:3164			0x5b09fc		b995000000		MOVL $0x95, CX												
  value.go:3164			0x5b0a01		ba15000000		MOVL $0x15, DX												
  value.go:3164			0x5b0a06		480f45ca		CMOVNE DX, CX												
  value_methods.go:878		0x5b0a0a		488d055f815100		LEAQ 0x51815f(IP), AX											
  value_methods.go:878		0x5b0a11		e80a64f1ff		CALL reflect.Value.Pointer(SB)										
  value_methods.go:879		0x5b0a16		4885c0			TESTQ AX, AX												
  value_methods.go:879		0x5b0a19		7510			JNE 0x5b0a2b												
  value_methods.go:875		0x5b0a1b		488b9c2448010000	MOVQ 0x148(SP), BX											
  value_methods.go:875		0x5b0a23		4885db			TESTQ BX, BX												
  value_methods.go:879		0x5b0a26		e99f000000		JMP 0x5b0aca												
  value_methods.go:878		0x5b0a2b		4889442468		MOVQ AX, 0x68(SP)											
  value_methods.go:880		0x5b0a30		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:880		0x5b0a38		488b5a08		MOVQ 0x8(DX), BX											
  value_methods.go:880		0x5b0a3c		4889c1			MOVQ AX, CX												
  value_methods.go:880		0x5b0a3f		488d056a855100		LEAQ 0x51856a(IP), AX											
  value_methods.go:880		0x5b0a46		e8357de5ff		CALL runtime.mapaccess2_fast64(SB)									
  value_methods.go:880		0x5b0a4b		84db			TESTL BL, BL												
  value_methods.go:880		0x5b0a4d		0f85f9000000		JNE 0x5b0b4c												
  value_methods.go:883		0x5b0a53		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:883		0x5b0a5b		488b5a08		MOVQ 0x8(DX), BX											
  value_methods.go:883		0x5b0a5f		488d054a855100		LEAQ 0x51854a(IP), AX											
  value_methods.go:883		0x5b0a66		488b4c2468		MOVQ 0x68(SP), CX											
  value_methods.go:883		0x5b0a6b		e8707fe5ff		CALL runtime.mapassign_fast64(SB)									
  value_methods.go:883		0x5b0a70		8400			TESTB AL, 0(AX)												
  value_methods.go:884		0x5b0a72		488b942440020000	MOVQ 0x240(SP), DX											
  value_methods.go:884		0x5b0a7a		488b5208		MOVQ 0x8(DX), DX											
  value_methods.go:884		0x5b0a7e		488d351b410000		LEAQ github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB), SI	
  value_methods.go:884		0x5b0a85		4889b424f8010000	MOVQ SI, 0x1f8(SP)											
  value_methods.go:884		0x5b0a8d		4889942400020000	MOVQ DX, 0x200(SP)											
  value_methods.go:884		0x5b0a95		488b542468		MOVQ 0x68(SP), DX											
  value_methods.go:884		0x5b0a9a		4889942408020000	MOVQ DX, 0x208(SP)											
  value_methods.go:884		0x5b0aa2		488d9424f8010000	LEAQ 0x1f8(SP), DX											
  value_methods.go:884		0x5b0aaa		48899424e8000000	MOVQ DX, 0xe8(SP)											
  value_methods.go:884		0x5b0ab2		488d8424d0000000	LEAQ 0xd0(SP), AX											
  value_methods.go:884		0x5b0aba		e801aee9ff		CALL runtime.deferprocStack(SB)										
  value_methods.go:875		0x5b0abf		488b9c2448010000	MOVQ 0x148(SP), BX											
  value_methods.go:875		0x5b0ac7		4885db			TESTQ BX, BX												
  value_methods.go:887		0x5b0aca		7405			JE 0x5b0ad1												
  value_methods.go:887		0x5b0acc		488b13			MOVQ 0(BX), DX												
  value_methods.go:887		0x5b0acf		eb02			JMP 0x5b0ad3												
  value_methods.go:887		0x5b0ad1		31d2			XORL DX, DX												
  value_methods.go:1031		0x5b0ad3		4883fa02		CMPQ DX, $0x2												
  value_methods.go:1031		0x5b0ad7		7d04			JGE 0x5b0add												
  value_methods.go:1031		0x5b0ad9		31d2			XORL DX, DX												
  value_methods.go:887		0x5b0adb		eb08			JMP 0x5b0ae5												
  value_methods.go:1034		0x5b0add		488d1412		LEAQ 0(DX)(DX*1), DX											
  value_methods.go:1034		0x5b0ae1		488d52fe		LEAQ -0x2(DX), DX											
  value_methods.go:887		0x5b0ae5		4889542440		MOVQ DX, 0x40(SP)											
  value_methods.go:888		0x5b0aea		488d8c2488010000	LEAQ 0x188(SP), CX											
  value_methods.go:888		0x5b0af2		440f1139		MOVUPS X15, 0(CX)											
  value_methods.go:888		0x5b0af6		440f117910		MOVUPS X15, 0x10(CX)											
  value_methods.go:888		0x5b0afb		440f117920		MOVUPS X15, 0x20(CX)											
  value_methods.go:888		0x5b0b00		440f117930		MOVUPS X15, 0x30(CX)											
  value_methods.go:888		0x5b0b05		440f117940		MOVUPS X15, 0x40(CX)											
  value_methods.go:888		0x5b0b0a		440f117950		MOVUPS X15, 0x50(CX)											
  value_methods.go:888		0x5b0b0f		488d055a805100		LEAQ 0x51805a(IP), AX											
  value_methods.go:888		0x5b0b16		e8a53de7ff		CALL runtime.mapIterStart(SB)										
  value_methods.go:887		0x5b0b1b		488b542440		MOVQ 0x40(SP), DX											
  value_methods.go:887		0x5b0b20		4883c202		ADDQ $0x2, DX												
  value_methods.go:888		0x5b0b24		e9c7030000		JMP 0x5b0ef0												
  value_methods.go:918		0x5b0b29		e8b2b2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:861		0x5b0b2e		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:861		0x5b0b36		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:861		0x5b0b3e		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0b43		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0b4a		5d			POPQ BP													
  value_methods.go:918		0x5b0b4b		c3			RET													
  value_methods.go:881		0x5b0b4c		48c744244807000000	MOVQ $0x7, 0x48(SP)											
  value_methods.go:881		0x5b0b55		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:881		0x5b0b5e		6690			NOPW													
  value_methods.go:918		0x5b0b60		e87bb2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:881		0x5b0b65		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:881		0x5b0b6d		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:881		0x5b0b75		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0b7a		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0b81		5d			POPQ BP													
  value_methods.go:918		0x5b0b82		c3			RET													
  value_methods.go:876		0x5b0b83		48c744244802000000	MOVQ $0x2, 0x48(SP)											
  value_methods.go:876		0x5b0b8c		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0b95		e846b2e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:876		0x5b0b9a		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:876		0x5b0ba2		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:876		0x5b0baa		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0baf		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0bb6		5d			POPQ BP													
  value_methods.go:918		0x5b0bb7		c3			RET													
  value_methods.go:897		0x5b0bb8		4883f814		CMPQ AX, $0x14												
  value_methods.go:897		0x5b0bbc		752d			JNE 0x5b0beb												
  regex.go:180			0x5b0bbe		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0bc6		488d1d6b805500		LEAQ 0x55806b(IP), BX											
  regex.go:180			0x5b0bcd		4839d8			CMPQ AX, BX												
  regex.go:180			0x5b0bd0		0f85d9020000		JNE 0x5b0eaf												
  regex.go:180			0x5b0bd6		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  regex.go:180			0x5b0bde		4d8b4808		MOVQ 0x8(R8), R9											
  regex.go:180			0x5b0be2		49c1e906		SHRQ $0x6, R9												
  regex.go:180			0x5b0be6		e9da010000		JMP 0x5b0dc5												
  value_methods.go:908		0x5b0beb		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:908		0x5b0bf3		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:908		0x5b0bfb		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:908		0x5b0c03		488bb42448020000	MOVQ 0x248(SP), SI											
  value_methods.go:908		0x5b0c0b		e850ebfeff		CALL github.com/mgomes/vibescript/vibes/value.chargeBigIntRenderSteps(SB)				
  value_methods.go:908		0x5b0c10		4885c0			TESTQ AX, AX												
  value_methods.go:908		0x5b0c13		0f85a1000000		JNE 0x5b0cba												
  value_methods.go:911		0x5b0c19		488b1560165b00		MOVQ github.com/mgomes/vibescript/vibes/value.RuntimeStringRuneLen(SB), DX				
  value_methods.go:911		0x5b0c20		4885d2			TESTQ DX, DX												
  value_methods.go:911		0x5b0c23		7429			JE 0x5b0c4e												
  value_methods.go:912		0x5b0c25		488b32			MOVQ 0(DX), SI												
  value_methods.go:912		0x5b0c28		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:912		0x5b0c30		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:912		0x5b0c38		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:912		0x5b0c40		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:912		0x5b0c48		ffd6			CALL SI													
  value_methods.go:912		0x5b0c4a		84db			TESTL BL, BL												
  value_methods.go:912		0x5b0c4c		753b			JNE 0x5b0c89												
  value_methods.go:916		0x5b0c4e		488b8424c0000000	MOVQ 0xc0(SP), AX											
  value_methods.go:916		0x5b0c56		488b9c24c8000000	MOVQ 0xc8(SP), BX											
  value_methods.go:916		0x5b0c5e		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:916		0x5b0c66		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:916		0x5b0c6e		e84db6ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)						
  value_methods.go:916		0x5b0c73		4889842450010000	MOVQ AX, 0x150(SP)											
  value_methods.go:916		0x5b0c7b		48895c2460		MOVQ BX, 0x60(SP)											
  utf8.go:448			0x5b0c80		31d2			XORL DX, DX												
  utf8.go:448			0x5b0c82		31f6			XORL SI, SI												
  utf8.go:448			0x5b0c84		e9af000000		JMP 0x5b0d38												
  value_methods.go:913		0x5b0c89		4889442448		MOVQ AX, 0x48(SP)											
  value_methods.go:913		0x5b0c8e		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0c97		e844b1e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:913		0x5b0c9c		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:913		0x5b0ca4		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:913		0x5b0cac		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0cb1		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0cb8		5d			POPQ BP													
  value_methods.go:918		0x5b0cb9		c3			RET													
  value_methods.go:909		0x5b0cba		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:909		0x5b0cc3		4889842430010000	MOVQ AX, 0x130(SP)											
  value_methods.go:909		0x5b0ccb		48899c2438010000	MOVQ BX, 0x138(SP)											
  value_methods.go:918		0x5b0cd3		e808b1e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:909		0x5b0cd8		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:909		0x5b0ce0		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:909		0x5b0ce8		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0ced		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0cf4		5d			POPQ BP													
  value_methods.go:918		0x5b0cf5		c3			RET													
  value_methods.go:846		0x5b0cf6		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:846		0x5b0cff		4889842430010000	MOVQ AX, 0x130(SP)											
  value_methods.go:846		0x5b0d07		48899c2438010000	MOVQ BX, 0x138(SP)											
  value_methods.go:918		0x5b0d0f		e8ccb0e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:846		0x5b0d14		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:846		0x5b0d1c		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:846		0x5b0d24		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0d29		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0d30		5d			POPQ BP													
  value_methods.go:918		0x5b0d31		c3			RET													
  utf8.go:449			0x5b0d32		48ffc6			INCQ SI													
  utf8.go:448			0x5b0d35		4889ca			MOVQ CX, DX												
  utf8.go:448			0x5b0d38		4839d3			CMPQ BX, DX												
  utf8.go:448			0x5b0d3b		7e33			JLE 0x5b0d70												
  utf8.go:448			0x5b0d3d		0fb63c02		MOVZX 0(DX)(AX*1), DI											
  utf8.go:448			0x5b0d41		83ff7f			CMPL DI, $0x7f												
  utf8.go:448			0x5b0d44		7f06			JG 0x5b0d4c												
  utf8.go:448			0x5b0d46		488d4a01		LEAQ 0x1(DX), CX											
  utf8.go:448			0x5b0d4a		ebe6			JMP 0x5b0d32												
  utf8.go:448			0x5b0d4c		4889742470		MOVQ SI, 0x70(SP)											
  utf8.go:448			0x5b0d51		4889d1			MOVQ DX, CX												
  utf8.go:448			0x5b0d54		e867c4ecff		CALL runtime.decoderune(SB)										
  utf8.go:448			0x5b0d59		488b842450010000	MOVQ 0x150(SP), AX											
  utf8.go:449			0x5b0d61		488b742470		MOVQ 0x70(SP), SI											
  utf8.go:449			0x5b0d66		4889d9			MOVQ BX, CX												
  utf8.go:448			0x5b0d69		488b5c2460		MOVQ 0x60(SP), BX											
  utf8.go:448			0x5b0d6e		ebc2			JMP 0x5b0d32												
  value_methods.go:916		0x5b0d70		4889742448		MOVQ SI, 0x48(SP)											
  value_methods.go:916		0x5b0d75		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b0d7e		6690			NOPW													
  value_methods.go:918		0x5b0d80		e85bb0e9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:916		0x5b0d85		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:916		0x5b0d8d		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:916		0x5b0d95		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0d9a		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0da1		5d			POPQ BP													
  value_methods.go:918		0x5b0da2		c3			RET													
  regex.go:180			0x5b0da3		4c8b8c24b0000000	MOVQ 0xb0(SP), R9											
  regex.go:180			0x5b0dab		49ffc9			DECQ R9													
  regex.go:180			0x5b0dae		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0db6		488d1d7b7e5500		LEAQ 0x557e7b(IP), BX											
  value_methods.go:906		0x5b0dbd		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  regex.go:180			0x5b0dc5		4d85c9			TESTQ R9, R9												
  regex.go:180			0x5b0dc8		7e3a			JLE 0x5b0e04												
  regex.go:180			0x5b0dca		4c898c24b0000000	MOVQ R9, 0xb0(SP)											
  regex.go:181			0x5b0dd2		488b942448020000	MOVQ 0x248(SP), DX											
  regex.go:181			0x5b0dda		488b02			MOVQ 0(DX), AX												
  regex.go:181			0x5b0ddd		ffd0			CALL AX													
  regex.go:181			0x5b0ddf		90			NOPL													
  regex.go:181			0x5b0de0		4885c0			TESTQ AX, AX												
  regex.go:181			0x5b0de3		74be			JE 0x5b0da3												
  value_methods.go:906		0x5b0de5		4c8b8424f0010000	MOVQ 0x1f0(SP), R8											
  value_methods.go:903		0x5b0ded		4889c1			MOVQ AX, CX												
  value_methods.go:903		0x5b0df0		4889da			MOVQ BX, DX												
  regex.go:180			0x5b0df3		488b8424c8000000	MOVQ 0xc8(SP), AX											
  regex.go:180			0x5b0dfb		488d1d367e5500		LEAQ 0x557e36(IP), BX											
  value_methods.go:903		0x5b0e02		eb04			JMP 0x5b0e08												
  value_methods.go:903		0x5b0e04		31c9			XORL CX, CX												
  value_methods.go:903		0x5b0e06		31d2			XORL DX, DX												
  value_methods.go:903		0x5b0e08		4885c9			TESTQ CX, CX												
  value_methods.go:903		0x5b0e0b		7556			JNE 0x5b0e63												
  regex.go:180			0x5b0e0d		4839d8			CMPQ AX, BX												
  value_methods.go:906		0x5b0e10		0f858d000000		JNE 0x5b0ea3												
  value_methods.go:906		0x5b0e16		498b00			MOVQ 0(R8), AX												
  value_methods.go:906		0x5b0e19		498b5808		MOVQ 0x8(R8), BX											
  value_methods.go:906		0x5b0e1d		498b4810		MOVQ 0x10(R8), CX											
  value_methods.go:906		0x5b0e21		498b7818		MOVQ 0x18(R8), DI											
  value_methods.go:906		0x5b0e25		498b7020		MOVQ 0x20(R8), SI											
  value_methods.go:906		0x5b0e29		e8f248ffff		CALL github.com/mgomes/vibescript/vibes/value.Regex.StringRuneLen(SB)					
  value_methods.go:906		0x5b0e2e		4889442448		MOVQ AX, 0x48(SP)											
  value_methods.go:906		0x5b0e33		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:906		0x5b0e3c		0f1f4000		NOPL 0(AX)												
  value_methods.go:918		0x5b0e40		e89bafe9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:906		0x5b0e45		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:906		0x5b0e4d		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:906		0x5b0e55		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0e5a		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0e61		5d			POPQ BP													
  value_methods.go:918		0x5b0e62		c3			RET													
  value_methods.go:904		0x5b0e63		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:904		0x5b0e6c		48898c2430010000	MOVQ CX, 0x130(SP)											
  value_methods.go:904		0x5b0e74		4889942438010000	MOVQ DX, 0x138(SP)											
  value_methods.go:904		0x5b0e7c		0f1f4000		NOPL 0(AX)												
  value_methods.go:918		0x5b0e80		e85bafe9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:904		0x5b0e85		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:904		0x5b0e8d		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:904		0x5b0e95		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b0e9a		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b0ea1		5d			POPQ BP													
  value_methods.go:918		0x5b0ea2		c3			RET													
  value_methods.go:906		0x5b0ea3		488d0d46795300		LEAQ 0x537946(IP), CX											
  value_methods.go:906		0x5b0eaa		e851bfe6ff		CALL runtime.panicdottypeE(SB)										
  regex.go:180			0x5b0eaf		488d0d3a795300		LEAQ 0x53793a(IP), CX											
  regex.go:180			0x5b0eb6		e845bfe6ff		CALL runtime.panicdottypeE(SB)										
  value_methods.go:890		0x5b0ebb		4889842480000000	MOVQ AX, 0x80(SP)											
  value_methods.go:889		0x5b0ec3		48899424b0000000	MOVQ DX, 0xb0(SP)											
  value_methods.go:888		0x5b0ecb		488d842488010000	LEAQ 0x188(SP), AX											
  value_methods.go:888		0x5b0ed3		e8483ae7ff		CALL runtime.mapIterNext(SB)										
  value_methods.go:894		0x5b0ed8		488b8c2480000000	MOVQ 0x80(SP), CX											
  value_methods.go:894		0x5b0ee0		488b9424b0000000	MOVQ 0xb0(SP), DX											
  value_methods.go:894		0x5b0ee8		488d140a		LEAQ 0(DX)(CX*1), DX											
  value_methods.go:894		0x5b0eec		488d5202		LEAQ 0x2(DX), DX											
  value_methods.go:888		0x5b0ef0		4c8b8c2488010000	MOVQ 0x188(SP), R9											
  value_methods.go:888		0x5b0ef8		0f1f840000000000	NOPL 0(AX)(AX*1)											
  value_methods.go:888		0x5b0f00		4d85c9			TESTQ R9, R9												
  value_methods.go:888		0x5b0f03		0f84f4000000		JE 0x5b0ffd												
  value_methods.go:888		0x5b0f09		4889542450		MOVQ DX, 0x50(SP)											
  value_methods.go:888		0x5b0f0e		4c8b942490010000	MOVQ 0x190(SP), R10											
  value_methods.go:888		0x5b0f16		498b01			MOVQ 0(R9), AX												
  value_methods.go:888		0x5b0f19		4889842458010000	MOVQ AX, 0x158(SP)											
  value_methods.go:888		0x5b0f21		498b5908		MOVQ 0x8(R9), BX											
  value_methods.go:888		0x5b0f25		48899c2488000000	MOVQ BX, 0x88(SP)											
  value_methods.go:888		0x5b0f2d		4d8b0a			MOVQ 0(R10), R9												
  value_methods.go:888		0x5b0f30		4c898c24c0000000	MOVQ R9, 0xc0(SP)											
  value_methods.go:888		0x5b0f38		4d8b5a08		MOVQ 0x8(R10), R11											
  value_methods.go:888		0x5b0f3c		4c899c24c8000000	MOVQ R11, 0xc8(SP)											
  value_methods.go:888		0x5b0f44		498b4a10		MOVQ 0x10(R10), CX											
  value_methods.go:888		0x5b0f48		48898c24f0010000	MOVQ CX, 0x1f0(SP)											
  value_methods.go:888		0x5b0f50		498b7a18		MOVQ 0x18(R10), DI											
  value_methods.go:888		0x5b0f54		4889bc24b8000000	MOVQ DI, 0xb8(SP)											
  utf8.go:448			0x5b0f5c		4531d2			XORL R10, R10												
  utf8.go:448			0x5b0f5f		4531e4			XORL R12, R12												
  utf8.go:448			0x5b0f62		eb03			JMP 0x5b0f67												
  utf8.go:449			0x5b0f64		49ffc2			INCQ R10												
  utf8.go:448			0x5b0f67		4c89542478		MOVQ R10, 0x78(SP)											
  utf8.go:448			0x5b0f6c		4939dc			CMPQ R12, BX												
  utf8.go:448			0x5b0f6f		7d58			JGE 0x5b0fc9												
  utf8.go:448			0x5b0f71		450fb62c04		MOVZX 0(R12)(AX*1), R13											
  utf8.go:448			0x5b0f76		4183fd7f		CMPL R13, $0x7f												
  utf8.go:448			0x5b0f7a		7f06			JG 0x5b0f82												
  utf8.go:448			0x5b0f7c		49ffc4			INCQ R12												
  utf8.go:448			0x5b0f7f		90			NOPL													
  utf8.go:448			0x5b0f80		ebe2			JMP 0x5b0f64												
  utf8.go:448			0x5b0f82		4c89e1			MOVQ R12, CX												
  utf8.go:448			0x5b0f85		e836c2ecff		CALL runtime.decoderune(SB)										
  utf8.go:448			0x5b0f8a		488b842458010000	MOVQ 0x158(SP), AX											
  value_methods.go:890		0x5b0f92		488b8c24f0010000	MOVQ 0x1f0(SP), CX											
  value_methods.go:889		0x5b0f9a		488b542450		MOVQ 0x50(SP), DX											
  value_methods.go:890		0x5b0f9f		488bbc24b8000000	MOVQ 0xb8(SP), DI											
  value_methods.go:890		0x5b0fa7		4c8b8c24c0000000	MOVQ 0xc0(SP), R9											
  utf8.go:449			0x5b0faf		4c8b542478		MOVQ 0x78(SP), R10											
  value_methods.go:890		0x5b0fb4		4c8b9c24c8000000	MOVQ 0xc8(SP), R11											
  utf8.go:449			0x5b0fbc		4989dc			MOVQ BX, R12												
  utf8.go:448			0x5b0fbf		488b9c2488000000	MOVQ 0x88(SP), BX											
  utf8.go:448			0x5b0fc7		eb9b			JMP 0x5b0f64												
  value_methods.go:890		0x5b0fc9		4c89c8			MOVQ R9, AX												
  value_methods.go:890		0x5b0fcc		4c89db			MOVQ R11, BX												
  value_methods.go:890		0x5b0fcf		488bb42440020000	MOVQ 0x240(SP), SI											
  value_methods.go:890		0x5b0fd7		4c8b842448020000	MOVQ 0x248(SP), R8											
  value_methods.go:890		0x5b0fdf		90			NOPL													
  value_methods.go:890		0x5b0fe0		e83bf7ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			
  value_methods.go:889		0x5b0fe5		488b542478		MOVQ 0x78(SP), DX											
  value_methods.go:889		0x5b0fea		4c8b4c2450		MOVQ 0x50(SP), R9											
  value_methods.go:889		0x5b0fef		4c01ca			ADDQ R9, DX												
  value_methods.go:891		0x5b0ff2		4885db			TESTQ BX, BX												
  value_methods.go:891		0x5b0ff5		0f84c0feffff		JE 0x5b0ebb												
  value_methods.go:891		0x5b0ffb		eb31			JMP 0x5b102e												
  value_methods.go:896		0x5b0ffd		4889542448		MOVQ DX, 0x48(SP)											
  value_methods.go:896		0x5b1002		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b100b		e8d0ade9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:896		0x5b1010		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:896		0x5b1018		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:896		0x5b1020		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b1025		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b102c		5d			POPQ BP													
  value_methods.go:918		0x5b102d		c3			RET													
  value_methods.go:892		0x5b102e		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:892		0x5b1037		48899c2430010000	MOVQ BX, 0x130(SP)											
  value_methods.go:892		0x5b103f		48898c2438010000	MOVQ CX, 0x138(SP)											
  value_methods.go:918		0x5b1047		e894ade9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:892		0x5b104c		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:892		0x5b1054		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:892		0x5b105c		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b1061		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b1068		5d			POPQ BP													
  value_methods.go:918		0x5b1069		c3			RET													
  value_accessors.go:113	0x5b106a		488d0d7f775300		LEAQ 0x53777f(IP), CX											
  value_accessors.go:113	0x5b1071		e88abde6ff		CALL runtime.panicdottypeE(SB)										
  value_methods.go:865		0x5b1076		4c8b9424e8010000	MOVQ 0x1e8(SP), R10											
  value_methods.go:865		0x5b107e		4983c220		ADDQ $0x20, R10												
  value_methods.go:870		0x5b1082		4c8b5c2458		MOVQ 0x58(SP), R11											
  value_methods.go:870		0x5b1087		4d8d0c03		LEAQ 0(R11)(AX*1), R9											
  value_methods.go:865		0x5b108b		488b9424b0000000	MOVQ 0xb0(SP), DX											
  value_methods.go:865		0x5b1093		48ffca			DECQ DX													
  value_methods.go:865		0x5b1096		4885d2			TESTQ DX, DX												
  value_methods.go:865		0x5b1099		7e7a			JLE 0x5b1115												
  value_methods.go:865		0x5b109b		48899424b0000000	MOVQ DX, 0xb0(SP)											
  value_methods.go:865		0x5b10a3		4c894c2458		MOVQ R9, 0x58(SP)											
  value_methods.go:865		0x5b10a8		4c899424e8010000	MOVQ R10, 0x1e8(SP)											
  value_methods.go:865		0x5b10b0		498b02			MOVQ 0(R10), AX												
  value_methods.go:865		0x5b10b3		498b5a08		MOVQ 0x8(R10), BX											
  value_methods.go:865		0x5b10b7		498b4a10		MOVQ 0x10(R10), CX											
  value_methods.go:865		0x5b10bb		498b7a18		MOVQ 0x18(R10), DI											
  value_methods.go:866		0x5b10bf		488bb42440020000	MOVQ 0x240(SP), SI											
  value_methods.go:866		0x5b10c7		4c8b842448020000	MOVQ 0x248(SP), R8											
  value_methods.go:866		0x5b10cf		e84cf6ffff		CALL github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			
  value_methods.go:867		0x5b10d4		4885db			TESTQ BX, BX												
  value_methods.go:867		0x5b10d7		749d			JE 0x5b1076												
  value_methods.go:868		0x5b10d9		48c744244800000000	MOVQ $0x0, 0x48(SP)											
  value_methods.go:868		0x5b10e2		48899c2430010000	MOVQ BX, 0x130(SP)											
  value_methods.go:868		0x5b10ea		48898c2438010000	MOVQ CX, 0x138(SP)											
  value_methods.go:918		0x5b10f2		e8e9ace9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:868		0x5b10f7		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:868		0x5b10ff		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:868		0x5b1107		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b110c		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b1113		5d			POPQ BP													
  value_methods.go:918		0x5b1114		c3			RET													
  value_methods.go:872		0x5b1115		4c894c2448		MOVQ R9, 0x48(SP)											
  value_methods.go:872		0x5b111a		440f11bc2430010000	MOVUPS X15, 0x130(SP)											
  value_methods.go:918		0x5b1123		e8b8ace9ff		CALL runtime.deferreturn(SB)										
  value_methods.go:872		0x5b1128		488b9c2430010000	MOVQ 0x130(SP), BX											
  value_methods.go:872		0x5b1130		488b8c2438010000	MOVQ 0x138(SP), CX											
  value_methods.go:872		0x5b1138		488b442448		MOVQ 0x48(SP), AX											
  value_methods.go:918		0x5b113d		4881c410020000		ADDQ $0x210, SP												
  value_methods.go:918		0x5b1144		5d			POPQ BP													
  value_methods.go:918		0x5b1145		c3			RET													
  value_accessors.go:86		0x5b1146		488d0da3765300		LEAQ 0x5376a3(IP), CX											
  value_accessors.go:86		0x5b114d		e8aebce6ff		CALL runtime.panicdottypeE(SB)										
  value_accessors.go:86		0x5b1152		90			NOPL													
  value_methods.go:844		0x5b1153		4889442408		MOVQ AX, 0x8(SP)											
  value_methods.go:844		0x5b1158		48895c2410		MOVQ BX, 0x10(SP)											
  value_methods.go:844		0x5b115d		48894c2418		MOVQ CX, 0x18(SP)											
  value_methods.go:844		0x5b1162		48897c2420		MOVQ DI, 0x20(SP)											
  value_methods.go:844		0x5b1167		4889742428		MOVQ SI, 0x28(SP)											
  value_methods.go:844		0x5b116c		4c89442430		MOVQ R8, 0x30(SP)											
  value_methods.go:844		0x5b1171		e88ab4edff		CALL runtime.morestack_noctxt.abi0(SB)									
  value_methods.go:844		0x5b1176		488b442408		MOVQ 0x8(SP), AX											
  value_methods.go:844		0x5b117b		488b5c2410		MOVQ 0x10(SP), BX											
  value_methods.go:844		0x5b1180		488b4c2418		MOVQ 0x18(SP), CX											
  value_methods.go:844		0x5b1185		488b7c2420		MOVQ 0x20(SP), DI											
  value_methods.go:844		0x5b118a		488b742428		MOVQ 0x28(SP), SI											
  value_methods.go:844		0x5b118f		4c8b442430		MOVQ 0x30(SP), R8											
  value_methods.go:844		0x5b1194		e987f5ffff		JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState(SB)			

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB) /home/runner/work/vibescript/vibescript/ascii/vibes/value/value_methods.go
  value_methods.go:638	0x5b4aa0		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:638	0x5b4aa4		7625			JBE 0x5b4acb											
  value_methods.go:638	0x5b4aa6		55			PUSHQ BP											
  value_methods.go:638	0x5b4aa7		4889e5			MOVQ SP, BP											
  value_methods.go:638	0x5b4aaa		4883ec18		SUBQ $0x18, SP											
  value_methods.go:638	0x5b4aae		488b4a10		MOVQ 0x10(DX), CX										
  value_methods.go:638	0x5b4ab2		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:638	0x5b4ab6		488d05f3445100		LEAQ 0x5144f3(IP), AX										
  value_methods.go:638	0x5b4abd		0f1f00			NOPL 0(AX)											
  value_methods.go:638	0x5b4ac0		e8fb46e5ff		CALL runtime.mapdelete_fast64(SB)								
  value_methods.go:638	0x5b4ac5		4883c418		ADDQ $0x18, SP											
  value_methods.go:638	0x5b4ac9		5d			POPQ BP												
  value_methods.go:638	0x5b4aca		c3			RET												
  value_methods.go:638	0x5b4acb		e8907aedff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:638	0x5b4ad0		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap2(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB) /home/runner/work/vibescript/vibescript/ascii/vibes/value/value_methods.go
  value_methods.go:619	0x5b4ae0		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:619	0x5b4ae4		7625			JBE 0x5b4b0b											
  value_methods.go:619	0x5b4ae6		55			PUSHQ BP											
  value_methods.go:619	0x5b4ae7		4889e5			MOVQ SP, BP											
  value_methods.go:619	0x5b4aea		4883ec18		SUBQ $0x18, SP											
  value_methods.go:619	0x5b4aee		488d4a10		LEAQ 0x10(DX), CX										
  value_methods.go:619	0x5b4af2		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:619	0x5b4af6		488d05d3465100		LEAQ 0x5146d3(IP), AX										
  value_methods.go:619	0x5b4afd		0f1f00			NOPL 0(AX)											
  value_methods.go:619	0x5b4b00		e85b17edff		CALL runtime.mapdelete(SB)									
  value_methods.go:619	0x5b4b05		4883c418		ADDQ $0x18, SP											
  value_methods.go:619	0x5b4b09		5d			POPQ BP												
  value_methods.go:619	0x5b4b0a		c3			RET												
  value_methods.go:619	0x5b4b0b		e8507aedff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:619	0x5b4b10		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenWithState.deferwrap1(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB) /home/runner/work/vibescript/vibescript/ascii/vibes/value/value_methods.go
  value_methods.go:884	0x5b4ba0		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:884	0x5b4ba4		7625			JBE 0x5b4bcb											
  value_methods.go:884	0x5b4ba6		55			PUSHQ BP											
  value_methods.go:884	0x5b4ba7		4889e5			MOVQ SP, BP											
  value_methods.go:884	0x5b4baa		4883ec18		SUBQ $0x18, SP											
  value_methods.go:884	0x5b4bae		488b4a10		MOVQ 0x10(DX), CX										
  value_methods.go:884	0x5b4bb2		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:884	0x5b4bb6		488d05f3435100		LEAQ 0x5143f3(IP), AX										
  value_methods.go:884	0x5b4bbd		0f1f00			NOPL 0(AX)											
  value_methods.go:884	0x5b4bc0		e8fb45e5ff		CALL runtime.mapdelete_fast64(SB)								
  value_methods.go:884	0x5b4bc5		4883c418		ADDQ $0x18, SP											
  value_methods.go:884	0x5b4bc9		5d			POPQ BP												
  value_methods.go:884	0x5b4bca		c3			RET												
  value_methods.go:884	0x5b4bcb		e89079edff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:884	0x5b4bd0		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap2(SB)	

TEXT github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB) /home/runner/work/vibescript/vibescript/ascii/vibes/value/value_methods.go
  value_methods.go:861	0x5b4be0		493b6610		CMPQ SP, 0x10(R14)										
  value_methods.go:861	0x5b4be4		7625			JBE 0x5b4c0b											
  value_methods.go:861	0x5b4be6		55			PUSHQ BP											
  value_methods.go:861	0x5b4be7		4889e5			MOVQ SP, BP											
  value_methods.go:861	0x5b4bea		4883ec18		SUBQ $0x18, SP											
  value_methods.go:861	0x5b4bee		488d4a10		LEAQ 0x10(DX), CX										
  value_methods.go:861	0x5b4bf2		488b5a08		MOVQ 0x8(DX), BX										
  value_methods.go:861	0x5b4bf6		488d05d3455100		LEAQ 0x5145d3(IP), AX										
  value_methods.go:861	0x5b4bfd		0f1f00			NOPL 0(AX)											
  value_methods.go:861	0x5b4c00		e85b16edff		CALL runtime.mapdelete(SB)									
  value_methods.go:861	0x5b4c05		4883c418		ADDQ $0x18, SP											
  value_methods.go:861	0x5b4c09		5d			POPQ BP												
  value_methods.go:861	0x5b4c0a		c3			RET												
  value_methods.go:861	0x5b4c0b		e85079edff		CALL runtime.morestack.abi0(SB)									
  value_methods.go:861	0x5b4c10		ebce			JMP github.com/mgomes/vibescript/vibes/value.Value.stringRuneLenBoundedWithState.deferwrap1(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneIndex(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:1231	0x6cefc0		493b6610		CMPQ SP, 0x10(R14)									
  members_string.go:1231	0x6cefc4		0f8601030000		JBE 0x6cf2cb										
  members_string.go:1231	0x6cefca		55			PUSHQ BP										
  members_string.go:1231	0x6cefcb		4889e5			MOVQ SP, BP										
  members_string.go:1231	0x6cefce		4883ec50		SUBQ $0x50, SP										
  members_string.go:1231	0x6cefd2		48895c2468		MOVQ BX, 0x68(SP)									
  members_string.go:1231	0x6cefd7		48897c2478		MOVQ DI, 0x78(SP)									
  members_string.go:1231	0x6cefdc		0f1f4000		NOPL 0(AX)										
  members_string.go:1232	0x6cefe0		4d85c0			TESTQ R8, R8										
  members_string.go:1232	0x6cefe3		0f8c74020000		JL 0x6cf25d										
  members_string.go:5185	0x6cefe9		4885c9			TESTQ CX, CX										
  members_string.go:5185	0x6cefec		7504			JNE 0x6ceff2										
  members_string.go:5185	0x6cefee		31d2			XORL DX, DX										
  members_string.go:1248	0x6ceff0		eb3d			JMP 0x6cf02f										
  members_string.go:1232	0x6ceff2		4889c2			MOVQ AX, DX										
  members_string.go:5188	0x6ceff5		48b8ffffffffffffff7f	MOVQ $0x7fffffffffffffff, AX								
  members_string.go:1232	0x6cefff		4989d1			MOVQ DX, R9										
  members_string.go:5188	0x6cf002		31d2			XORL DX, DX										
  members_string.go:5188	0x6cf004		48f7f1			DIVQ CX											
  members_string.go:5188	0x6cf007		4883f804		CMPQ AX, $0x4										
  members_string.go:5188	0x6cf00b		7d0f			JGE 0x6cf01c										
  members_string.go:1265	0x6cf00d		4c89c8			MOVQ R9, AX										
  members_string.go:1265	0x6cf010		48baffffffffffffff7f	MOVQ $0x7fffffffffffffff, DX								
  members_string.go:1248	0x6cf01a		eb13			JMP 0x6cf02f										
  members_string.go:5191	0x6cf01c		4889ca			MOVQ CX, DX										
  members_string.go:5191	0x6cf01f		48c1e102		SHLQ $0x2, CX										
  members_string.go:1265	0x6cf023		4c89c8			MOVQ R9, AX										
  ascii_scan_scalar_amd64.go:7	0x6cf026		4989ca			MOVQ CX, R10										
  ascii_scan_scalar_amd64.go:7	0x6cf029		4889d1			MOVQ DX, CX										
  members_string.go:1248	0x6cf02c		4c89d2			MOVQ R10, DX										
  members_string.go:1248	0x6cf02f		4839d6			CMPQ SI, DX										
  members_string.go:1248	0x6cf032		0f8f14020000		JG 0x6cf24c										
  members_string.go:1232	0x6cf038		4889442460		MOVQ AX, 0x60(SP)									
  members_string.go:1232	0x6cf03d		4c89842488000000	MOVQ R8, 0x88(SP)									
  members_string.go:1232	0x6cf045		4889b42480000000	MOVQ SI, 0x80(SP)									
  members_string.go:1232	0x6cf04d		48897c2478		MOVQ DI, 0x78(SP)									
  members_string.go:1232	0x6cf052		48894c2470		MOVQ CX, 0x70(SP)									
  members_string.go:1232	0x6cf057		48895c2468		MOVQ BX, 0x68(SP)									
  ascii_scan_scalar_amd64.go:7	0x6cf05c		4889d8			MOVQ BX, AX										
  ascii_scan_scalar_amd64.go:7	0x6cf05f		4889cb			MOVQ CX, BX										
  ascii_scan_scalar_amd64.go:7	0x6cf062		e8592ff4ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIWords(SB)		
  ascii_scan_scalar_amd64.go:7	0x6cf067		84c0			TESTL AL, AL										
  members_string.go:1251	0x6cf069		7504			JNE 0x6cf06f										
  members_string.go:1251	0x6cf06b		31c0			XORL AX, AX										
  members_string.go:1251	0x6cf06d		eb16			JMP 0x6cf085										
  ascii_scan_scalar_amd64.go:7	0x6cf06f		488b442478		MOVQ 0x78(SP), AX									
  ascii_scan_scalar_amd64.go:7	0x6cf074		488b9c2480000000	MOVQ 0x80(SP), BX									
  ascii_scan_scalar_amd64.go:7	0x6cf07c		0f1f4000		NOPL 0(AX)										
  ascii_scan_scalar_amd64.go:7	0x6cf080		e83b2ff4ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIWords(SB)		
  members_string.go:1251	0x6cf085		84c0			TESTL AL, AL										
  members_string.go:1251	0x6cf087		0f8488000000		JE 0x6cf115										
  members_string.go:1252	0x6cf08d		488b5c2470		MOVQ 0x70(SP), BX									
  members_string.go:1252	0x6cf092		488b842488000000	MOVQ 0x88(SP), AX									
  members_string.go:1252	0x6cf09a		4839c3			CMPQ BX, AX										
  members_string.go:1252	0x6cf09d		7c65			JL 0x6cf104										
  members_string.go:1255	0x6cf09f		488bbc2480000000	MOVQ 0x80(SP), DI									
  members_string.go:1255	0x6cf0a7		4885ff			TESTQ DI, DI										
  members_string.go:1255	0x6cf0aa		744e			JE 0x6cf0fa										
  members_string.go:1258	0x6cf0ac		4829c3			SUBQ AX, BX										
  members_string.go:1258	0x6cf0af		4889da			MOVQ BX, DX										
  members_string.go:1258	0x6cf0b2		48f7da			NEGQ DX											
  members_string.go:1258	0x6cf0b5		48c1fa3f		SARQ $0x3f, DX										
  members_string.go:1258	0x6cf0b9		4821c2			ANDQ AX, DX										
  members_string.go:1258	0x6cf0bc		488b742468		MOVQ 0x68(SP), SI									
  members_string.go:1258	0x6cf0c1		488d0416		LEAQ 0(SI)(DX*1), AX									
  strings.go:1264		0x6cf0c5		488b4c2478		MOVQ 0x78(SP), CX									
  strings.go:1264		0x6cf0ca		e8915fd4ff		CALL internal/stringslite.Index(SB)							
  members_string.go:1259	0x6cf0cf		4885c0			TESTQ AX, AX										
  members_string.go:1259	0x6cf0d2		7d11			JGE 0x6cf0e5										
  members_string.go:1260	0x6cf0d4		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1260	0x6cf0db		31db			XORL BX, BX										
  members_string.go:1260	0x6cf0dd		31c9			XORL CX, CX										
  members_string.go:1260	0x6cf0df		4883c450		ADDQ $0x50, SP										
  members_string.go:1260	0x6cf0e3		5d			POPQ BP											
  members_string.go:1260	0x6cf0e4		c3			RET											
  members_string.go:1262	0x6cf0e5		488b942488000000	MOVQ 0x88(SP), DX									
  members_string.go:1262	0x6cf0ed		4801d0			ADDQ DX, AX										
  members_string.go:1262	0x6cf0f0		31db			XORL BX, BX										
  members_string.go:1262	0x6cf0f2		31c9			XORL CX, CX										
  members_string.go:1262	0x6cf0f4		4883c450		ADDQ $0x50, SP										
  members_string.go:1262	0x6cf0f8		5d			POPQ BP											
  members_string.go:1262	0x6cf0f9		c3			RET											
  members_string.go:1256	0x6cf0fa		31db			XORL BX, BX										
  members_string.go:1256	0x6cf0fc		31c9			XORL CX, CX										
  members_string.go:1256	0x6cf0fe		4883c450		ADDQ $0x50, SP										
  members_string.go:1256	0x6cf102		5d			POPQ BP											
  members_string.go:1256	0x6cf103		c3			RET											
  members_string.go:1253	0x6cf104		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1253	0x6cf10b		31db			XORL BX, BX										
  members_string.go:1253	0x6cf10d		31c9			XORL CX, CX										
  members_string.go:1253	0x6cf10f		4883c450		ADDQ $0x50, SP										
  members_string.go:1253	0x6cf113		5d			POPQ BP											
  members_string.go:1253	0x6cf114		c3			RET											
  members_string.go:1264	0x6cf115		488b442468		MOVQ 0x68(SP), AX									
  members_string.go:1264	0x6cf11a		488b5c2470		MOVQ 0x70(SP), BX									
  members_string.go:1264	0x6cf11f		90			NOPL											
  members_string.go:1264	0x6cf120		e8dbfdddff		CALL unicode/utf8.ValidString(SB)							
  members_string.go:1264	0x6cf125		84c0			TESTL AL, AL										
  members_string.go:1264	0x6cf127		7416			JE 0x6cf13f										
  members_string.go:1264	0x6cf129		488b442478		MOVQ 0x78(SP), AX									
  members_string.go:1264	0x6cf12e		488b9c2480000000	MOVQ 0x80(SP), BX									
  members_string.go:1264	0x6cf136		e8c5fdddff		CALL unicode/utf8.ValidString(SB)							
  members_string.go:1264	0x6cf13b		84c0			TESTL AL, AL										
  members_string.go:1264	0x6cf13d		752f			JNE 0x6cf16e										
  members_string.go:1265	0x6cf13f		488b442460		MOVQ 0x60(SP), AX									
  members_string.go:1265	0x6cf144		488b5c2468		MOVQ 0x68(SP), BX									
  members_string.go:1265	0x6cf149		488b4c2470		MOVQ 0x70(SP), CX									
  members_string.go:1265	0x6cf14e		488b7c2478		MOVQ 0x78(SP), DI									
  members_string.go:1265	0x6cf153		488bb42480000000	MOVQ 0x80(SP), SI									
  members_string.go:1265	0x6cf15b		4c8b842488000000	MOVQ 0x88(SP), R8									
  members_string.go:1265	0x6cf163		e8f8020000		CALL github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB)		
  members_string.go:1265	0x6cf168		4883c450		ADDQ $0x50, SP										
  members_string.go:1265	0x6cf16c		5d			POPQ BP											
  members_string.go:1265	0x6cf16d		c3			RET											
  members_string.go:1267	0x6cf16e		488b442468		MOVQ 0x68(SP), AX									
  members_string.go:1267	0x6cf173		488b5c2470		MOVQ 0x70(SP), BX									
  members_string.go:1267	0x6cf178		488b8c2488000000	MOVQ 0x88(SP), CX									
  members_string.go:1267	0x6cf180		e8fbfbffff		CALL github.com/mgomes/vibescript/internal/runtime.stringByteIndexForRuneOffset(SB)	
  members_string.go:1267	0x6cf185		84db			TESTL BL, BL										
  members_string.go:1268	0x6cf187		0f84ae000000		JE 0x6cf23b										
  members_string.go:1271	0x6cf18d		488bbc2480000000	MOVQ 0x80(SP), DI									
  members_string.go:1271	0x6cf195		4885ff			TESTQ DI, DI										
  members_string.go:1271	0x6cf198		0f848b000000		JE 0x6cf229										
  members_string.go:1274	0x6cf19e		488b5c2470		MOVQ 0x70(SP), BX									
  members_string.go:1274	0x6cf1a3		4839d8			CMPQ AX, BX										
  members_string.go:1274	0x6cf1a6		0f8719010000		JA 0x6cf2c5										
  members_string.go:1267	0x6cf1ac		4889442430		MOVQ AX, 0x30(SP)									
  members_string.go:1274	0x6cf1b1		4889da			MOVQ BX, DX										
  members_string.go:1274	0x6cf1b4		4829c2			SUBQ AX, DX										
  members_string.go:1274	0x6cf1b7		4889d3			MOVQ DX, BX										
  members_string.go:1274	0x6cf1ba		48f7da			NEGQ DX											
  members_string.go:1274	0x6cf1bd		48c1fa3f		SARQ $0x3f, DX										
  members_string.go:1274	0x6cf1c1		4821c2			ANDQ AX, DX										
  members_string.go:1274	0x6cf1c4		488b742468		MOVQ 0x68(SP), SI									
  members_string.go:1274	0x6cf1c9		488d0432		LEAQ 0(DX)(SI*1), AX									
  strings.go:1264		0x6cf1cd		488b4c2478		MOVQ 0x78(SP), CX									
  strings.go:1264		0x6cf1d2		e8895ed4ff		CALL internal/stringslite.Index(SB)							
  members_string.go:1275	0x6cf1d7		4885c0			TESTQ AX, AX										
  members_string.go:1275	0x6cf1da		7c3c			JL 0x6cf218										
  members_string.go:1278	0x6cf1dc		488b542430		MOVQ 0x30(SP), DX									
  members_string.go:1278	0x6cf1e1		488d3402		LEAQ 0(DX)(AX*1), SI									
  members_string.go:1278	0x6cf1e5		488b7c2470		MOVQ 0x70(SP), DI									
  members_string.go:1278	0x6cf1ea		4839f7			CMPQ DI, SI										
  members_string.go:1278	0x6cf1ed		0f82c8000000		JB 0x6cf2bb										
  strings.go:1264		0x6cf1f3		4889442440		MOVQ AX, 0x40(SP)									
  members_string.go:1278	0x6cf1f8		4889c3			MOVQ AX, BX										
  members_string.go:1278	0x6cf1fb		48f7d8			NEGQ AX											
  members_string.go:1278	0x6cf1fe		48c1f83f		SARQ $0x3f, AX										
  members_string.go:1278	0x6cf202		4821d0			ANDQ DX, AX										
  members_string.go:1278	0x6cf205		488b542468		MOVQ 0x68(SP), DX									
  members_string.go:1278	0x6cf20a		4801d0			ADDQ DX, AX										
  members_string.go:1278	0x6cf20d		4889442448		MOVQ AX, 0x48(SP)									
  utf8.go:448			0x6cf212		31d2			XORL DX, DX										
  utf8.go:448			0x6cf214		31f6			XORL SI, SI										
  utf8.go:448			0x6cf216		eb59			JMP 0x6cf271										
  members_string.go:1276	0x6cf218		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1276	0x6cf21f		31db			XORL BX, BX										
  members_string.go:1276	0x6cf221		31c9			XORL CX, CX										
  members_string.go:1276	0x6cf223		4883c450		ADDQ $0x50, SP										
  members_string.go:1276	0x6cf227		5d			POPQ BP											
  members_string.go:1276	0x6cf228		c3			RET											
  members_string.go:1272	0x6cf229		488b842488000000	MOVQ 0x88(SP), AX									
  members_string.go:1272	0x6cf231		31db			XORL BX, BX										
  members_string.go:1272	0x6cf233		31c9			XORL CX, CX										
  members_string.go:1272	0x6cf235		4883c450		ADDQ $0x50, SP										
  members_string.go:1272	0x6cf239		5d			POPQ BP											
  members_string.go:1272	0x6cf23a		c3			RET											
  members_string.go:1269	0x6cf23b		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1269	0x6cf242		31db			XORL BX, BX										
  members_string.go:1269	0x6cf244		31c9			XORL CX, CX										
  members_string.go:1269	0x6cf246		4883c450		ADDQ $0x50, SP										
  members_string.go:1269	0x6cf24a		5d			POPQ BP											
  members_string.go:1269	0x6cf24b		c3			RET											
  members_string.go:1249	0x6cf24c		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1249	0x6cf253		31db			XORL BX, BX										
  members_string.go:1249	0x6cf255		31c9			XORL CX, CX										
  members_string.go:1249	0x6cf257		4883c450		ADDQ $0x50, SP										
  members_string.go:1249	0x6cf25b		5d			POPQ BP											
  members_string.go:1249	0x6cf25c		c3			RET											
  members_string.go:1233	0x6cf25d		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1233	0x6cf264		31db			XORL BX, BX										
  members_string.go:1233	0x6cf266		31c9			XORL CX, CX										
  members_string.go:1233	0x6cf268		4883c450		ADDQ $0x50, SP										
  members_string.go:1233	0x6cf26c		5d			POPQ BP											
  members_string.go:1233	0x6cf26d		c3			RET											
  utf8.go:449			0x6cf26e		48ffc2			INCQ DX											
  utf8.go:448			0x6cf271		4839f3			CMPQ BX, SI										
  utf8.go:448			0x6cf274		7e2f			JLE 0x6cf2a5										
  utf8.go:448			0x6cf276		0fb63c30		MOVZX 0(AX)(SI*1), DI									
  utf8.go:448			0x6cf27a		83ff7f			CMPL DI, $0x7f										
  utf8.go:448			0x6cf27d		7f05			JG 0x6cf284										
  utf8.go:448			0x6cf27f		48ffc6			INCQ SI											
  utf8.go:448			0x6cf282		ebea			JMP 0x6cf26e										
  utf8.go:448			0x6cf284		4889542438		MOVQ DX, 0x38(SP)									
  utf8.go:448			0x6cf289		4889f1			MOVQ SI, CX										
  utf8.go:448			0x6cf28c		e82fdfdaff		CALL runtime.decoderune(SB)								
  utf8.go:448			0x6cf291		488b442448		MOVQ 0x48(SP), AX									
  utf8.go:449			0x6cf296		488b542438		MOVQ 0x38(SP), DX									
  utf8.go:449			0x6cf29b		4889de			MOVQ BX, SI										
  utf8.go:448			0x6cf29e		488b5c2440		MOVQ 0x40(SP), BX									
  utf8.go:448			0x6cf2a3		ebc9			JMP 0x6cf26e										
  members_string.go:1278	0x6cf2a5		488bb42488000000	MOVQ 0x88(SP), SI									
  members_string.go:1278	0x6cf2ad		488d0416		LEAQ 0(SI)(DX*1), AX									
  members_string.go:1278	0x6cf2b1		31db			XORL BX, BX										
  members_string.go:1278	0x6cf2b3		31c9			XORL CX, CX										
  members_string.go:1278	0x6cf2b5		4883c450		ADDQ $0x50, SP										
  members_string.go:1278	0x6cf2b9		5d			POPQ BP											
  members_string.go:1278	0x6cf2ba		c3			RET											
  members_string.go:1278	0x6cf2bb		0f1f440000		NOPL 0(AX)(AX*1)									
  members_string.go:1278	0x6cf2c0		e87befdbff		CALL runtime.panicBounds(SB)								
  members_string.go:1274	0x6cf2c5		e876efdbff		CALL runtime.panicBounds(SB)								
  members_string.go:1274	0x6cf2ca		90			NOPL											
  members_string.go:1231	0x6cf2cb		4889442408		MOVQ AX, 0x8(SP)									
  members_string.go:1231	0x6cf2d0		48895c2410		MOVQ BX, 0x10(SP)									
  members_string.go:1231	0x6cf2d5		48894c2418		MOVQ CX, 0x18(SP)									
  members_string.go:1231	0x6cf2da		48897c2420		MOVQ DI, 0x20(SP)									
  members_string.go:1231	0x6cf2df		4889742428		MOVQ SI, 0x28(SP)									
  members_string.go:1231	0x6cf2e4		4c89442430		MOVQ R8, 0x30(SP)									
  members_string.go:1231	0x6cf2e9		e812d3dbff		CALL runtime.morestack_noctxt.abi0(SB)							
  members_string.go:1231	0x6cf2ee		488b442408		MOVQ 0x8(SP), AX									
  members_string.go:1231	0x6cf2f3		488b5c2410		MOVQ 0x10(SP), BX									
  members_string.go:1231	0x6cf2f8		488b4c2418		MOVQ 0x18(SP), CX									
  members_string.go:1231	0x6cf2fd		488b7c2420		MOVQ 0x20(SP), DI									
  members_string.go:1231	0x6cf302		488b742428		MOVQ 0x28(SP), SI									
  members_string.go:1231	0x6cf307		4c8b442430		MOVQ 0x30(SP), R8									
  members_string.go:1231	0x6cf30c		e9affcffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneIndex(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:1305	0x6cf460		4c8da424c0feffff	LEAQ 0xfffffec0(SP), R12								
  members_string.go:1305	0x6cf468		4d3b6610		CMPQ R12, 0x10(R14)									
  members_string.go:1305	0x6cf46c		0f865f020000		JBE 0x6cf6d1										
  members_string.go:1305	0x6cf472		55			PUSHQ BP										
  members_string.go:1305	0x6cf473		4889e5			MOVQ SP, BP										
  members_string.go:1305	0x6cf476		4881ecb8010000		SUBQ $0x1b8, SP										
  members_string.go:1306	0x6cf47d		4c898424f0010000	MOVQ R8, 0x1f0(SP)									
  members_string.go:1306	0x6cf485		48898c24d8010000	MOVQ CX, 0x1d8(SP)									
  members_string.go:1306	0x6cf48d		48899c24d0010000	MOVQ BX, 0x1d0(SP)									
  members_string.go:1306	0x6cf495		4889b424e8010000	MOVQ SI, 0x1e8(SP)									
  members_string.go:1306	0x6cf49d		4889bc24e0010000	MOVQ DI, 0x1e0(SP)									
  members_string.go:1306	0x6cf4a5		e876feffff		CALL github.com/mgomes/vibescript/internal/runtime.reserveFallbackSearchScratch(SB)	
  members_string.go:1306	0x6cf4aa		4885c0			TESTQ AX, AX										
  members_string.go:1306	0x6cf4ad		0f859b010000		JNE 0x6cf64e										
  members_string.go:1309	0x6cf4b3		488d8424e8000000	LEAQ 0xe8(SP), AX									
  members_string.go:1309	0x6cf4bb		488b9c24d0010000	MOVQ 0x1d0(SP), BX									
  members_string.go:1309	0x6cf4c3		488b8c24d8010000	MOVQ 0x1d8(SP), CX									
  members_string.go:1309	0x6cf4cb		e870b8d9ff		CALL runtime.stringtoslicerune(SB)							
  members_string.go:1309	0x6cf4d0		48899c2488010000	MOVQ BX, 0x188(SP)									
  members_string.go:1309	0x6cf4d8		48898424a8010000	MOVQ AX, 0x1a8(SP)									
  members_string.go:1309	0x6cf4e0		48898c2490010000	MOVQ CX, 0x190(SP)									
  members_string.go:1310	0x6cf4e8		488d442468		LEAQ 0x68(SP), AX									
  members_string.go:1310	0x6cf4ed		488b9c24e0010000	MOVQ 0x1e0(SP), BX									
  members_string.go:1310	0x6cf4f5		488b8c24e8010000	MOVQ 0x1e8(SP), CX									
  members_string.go:1310	0x6cf4fd		0f1f00			NOPL 0(AX)										
  members_string.go:1310	0x6cf500		e83bb8d9ff		CALL runtime.stringtoslicerune(SB)							
  members_string.go:1311	0x6cf505		488b942488010000	MOVQ 0x188(SP), DX									
  members_string.go:1311	0x6cf50d		488bb424f0010000	MOVQ 0x1f0(SP), SI									
  members_string.go:1311	0x6cf515		4839f2			CMPQ DX, SI										
  members_string.go:1311	0x6cf518		0f8c1c010000		JL 0x6cf63a										
  members_string.go:1311	0x6cf51e		6690			NOPW											
  members_string.go:1314	0x6cf520		4885db			TESTQ BX, BX										
  members_string.go:1314	0x6cf523		0f8401010000		JE 0x6cf62a										
  members_string.go:1317	0x6cf529		4989d0			MOVQ DX, R8										
  members_string.go:1317	0x6cf52c		4829da			SUBQ BX, DX										
  members_string.go:1318	0x6cf52f		4839d6			CMPQ SI, DX										
  members_string.go:1318	0x6cf532		0f8fde000000		JG 0x6cf616										
  members_string.go:1318	0x6cf538		0f1f840000000000	NOPL 0(AX)(AX*1)									
  members_string.go:1311	0x6cf540		4939f0			CMPQ R8, SI										
  members_string.go:1328	0x6cf543		0f8282010000		JB 0x6cf6cb										
  members_string.go:1310	0x6cf549		48899c2470010000	MOVQ BX, 0x170(SP)									
  members_string.go:1310	0x6cf551		48898424a0010000	MOVQ AX, 0x1a0(SP)									
  members_string.go:1310	0x6cf559		48898c2478010000	MOVQ CX, 0x178(SP)									
  members_string.go:1328	0x6cf561		4929f0			SUBQ SI, R8										
  members_string.go:1328	0x6cf564		488bbc2490010000	MOVQ 0x190(SP), DI									
  members_string.go:1328	0x6cf56c		4829f7			SUBQ SI, DI										
  members_string.go:1328	0x6cf56f		488b9424a8010000	MOVQ 0x1a8(SP), DX									
  members_string.go:1328	0x6cf577		488d1cb2		LEAQ 0(DX)(SI*4), BX									
  members_string.go:1328	0x6cf57b		488d442448		LEAQ 0x48(SP), AX									
  members_string.go:1328	0x6cf580		4c89c1			MOVQ R8, CX										
  members_string.go:1328	0x6cf583		e838b9d9ff		CALL runtime.slicerunetostring(SB)							
  members_string.go:1328	0x6cf588		48898424b0010000	MOVQ AX, 0x1b0(SP)									
  members_string.go:1328	0x6cf590		48899c2498010000	MOVQ BX, 0x198(SP)									
  members_string.go:1329	0x6cf598		488d442428		LEAQ 0x28(SP), AX									
  members_string.go:1329	0x6cf59d		488b9c24a0010000	MOVQ 0x1a0(SP), BX									
  members_string.go:1329	0x6cf5a5		488b8c2470010000	MOVQ 0x170(SP), CX									
  members_string.go:1329	0x6cf5ad		488bbc2478010000	MOVQ 0x178(SP), DI									
  members_string.go:1329	0x6cf5b5		e806b9d9ff		CALL runtime.slicerunetostring(SB)							
  strings.go:1264		0x6cf5ba		4889c1			MOVQ AX, CX										
  strings.go:1264		0x6cf5bd		4889df			MOVQ BX, DI										
  strings.go:1264		0x6cf5c0		488b8424b0010000	MOVQ 0x1b0(SP), AX									
  strings.go:1264		0x6cf5c8		488b9c2498010000	MOVQ 0x198(SP), BX									
  strings.go:1264		0x6cf5d0		e88b5ad4ff		CALL internal/stringslite.Index(SB)							
  members_string.go:1330	0x6cf5d5		4885c0			TESTQ AX, AX										
  members_string.go:1330	0x6cf5d8		7c28			JL 0x6cf602										
  members_string.go:1333	0x6cf5da		488b942498010000	MOVQ 0x198(SP), DX									
  members_string.go:1333	0x6cf5e2		4839d0			CMPQ AX, DX										
  members_string.go:1333	0x6cf5e5		0f87db000000		JA 0x6cf6c6										
  strings.go:1264		0x6cf5eb		4889842468010000	MOVQ AX, 0x168(SP)									
  utf8.go:448			0x6cf5f3		31d2			XORL DX, DX										
  utf8.go:448			0x6cf5f5		488bb424b0010000	MOVQ 0x1b0(SP), SI									
  utf8.go:448			0x6cf5fd		31c9			XORL CX, CX										
  utf8.go:448			0x6cf5ff		90			NOPL											
  utf8.go:448			0x6cf600		eb65			JMP 0x6cf667										
  members_string.go:1331	0x6cf602		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1331	0x6cf609		31db			XORL BX, BX										
  members_string.go:1331	0x6cf60b		31c9			XORL CX, CX										
  members_string.go:1331	0x6cf60d		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1331	0x6cf614		5d			POPQ BP											
  members_string.go:1331	0x6cf615		c3			RET											
  members_string.go:1319	0x6cf616		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1319	0x6cf61d		31db			XORL BX, BX										
  members_string.go:1319	0x6cf61f		31c9			XORL CX, CX										
  members_string.go:1319	0x6cf621		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1319	0x6cf628		5d			POPQ BP											
  members_string.go:1319	0x6cf629		c3			RET											
  members_string.go:1315	0x6cf62a		4889f0			MOVQ SI, AX										
  members_string.go:1315	0x6cf62d		31db			XORL BX, BX										
  members_string.go:1315	0x6cf62f		31c9			XORL CX, CX										
  members_string.go:1315	0x6cf631		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1315	0x6cf638		5d			POPQ BP											
  members_string.go:1315	0x6cf639		c3			RET											
  members_string.go:1312	0x6cf63a		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1312	0x6cf641		31db			XORL BX, BX										
  members_string.go:1312	0x6cf643		31c9			XORL CX, CX										
  members_string.go:1312	0x6cf645		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1312	0x6cf64c		5d			POPQ BP											
  members_string.go:1312	0x6cf64d		c3			RET											
  members_string.go:1307	0x6cf64e		4889d9			MOVQ BX, CX										
  members_string.go:1307	0x6cf651		4889c3			MOVQ AX, BX										
  members_string.go:1307	0x6cf654		48c7c0ffffffff		MOVQ $-0x1, AX										
  members_string.go:1307	0x6cf65b		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1307	0x6cf662		5d			POPQ BP											
  members_string.go:1307	0x6cf663		c3			RET											
  utf8.go:449			0x6cf664		48ffc1			INCQ CX											
  utf8.go:448			0x6cf667		4839d0			CMPQ AX, DX										
  utf8.go:448			0x6cf66a		7e41			JLE 0x6cf6ad										
  utf8.go:448			0x6cf66c		0fb63c16		MOVZX 0(SI)(DX*1), DI									
  utf8.go:448			0x6cf670		83ff7f			CMPL DI, $0x7f										
  utf8.go:448			0x6cf673		7f05			JG 0x6cf67a										
  utf8.go:448			0x6cf675		48ffc2			INCQ DX											
  utf8.go:448			0x6cf678		ebea			JMP 0x6cf664										
  utf8.go:448			0x6cf67a		48898c2480010000	MOVQ CX, 0x180(SP)									
  utf8.go:448			0x6cf682		4889c3			MOVQ AX, BX										
  utf8.go:448			0x6cf685		4889d1			MOVQ DX, CX										
  utf8.go:448			0x6cf688		4889f0			MOVQ SI, AX										
  utf8.go:448			0x6cf68b		e830dbdaff		CALL runtime.decoderune(SB)								
  utf8.go:448			0x6cf690		488b842468010000	MOVQ 0x168(SP), AX									
  utf8.go:449			0x6cf698		488b8c2480010000	MOVQ 0x180(SP), CX									
  utf8.go:448			0x6cf6a0		488bb424b0010000	MOVQ 0x1b0(SP), SI									
  utf8.go:449			0x6cf6a8		4889da			MOVQ BX, DX										
  utf8.go:448			0x6cf6ab		ebb7			JMP 0x6cf664										
  members_string.go:1333	0x6cf6ad		488b9424f0010000	MOVQ 0x1f0(SP), DX									
  members_string.go:1333	0x6cf6b5		488d040a		LEAQ 0(DX)(CX*1), AX									
  members_string.go:1333	0x6cf6b9		31db			XORL BX, BX										
  members_string.go:1333	0x6cf6bb		31c9			XORL CX, CX										
  members_string.go:1333	0x6cf6bd		4881c4b8010000		ADDQ $0x1b8, SP										
  members_string.go:1333	0x6cf6c4		5d			POPQ BP											
  members_string.go:1333	0x6cf6c5		c3			RET											
  members_string.go:1333	0x6cf6c6		e875ebdbff		CALL runtime.panicBounds(SB)								
  members_string.go:1328	0x6cf6cb		e870ebdbff		CALL runtime.panicBounds(SB)								
  members_string.go:1328	0x6cf6d0		90			NOPL											
  members_string.go:1305	0x6cf6d1		4889442408		MOVQ AX, 0x8(SP)									
  members_string.go:1305	0x6cf6d6		48895c2410		MOVQ BX, 0x10(SP)									
  members_string.go:1305	0x6cf6db		48894c2418		MOVQ CX, 0x18(SP)									
  members_string.go:1305	0x6cf6e0		48897c2420		MOVQ DI, 0x20(SP)									
  members_string.go:1305	0x6cf6e5		4889742428		MOVQ SI, 0x28(SP)									
  members_string.go:1305	0x6cf6ea		4c89442430		MOVQ R8, 0x30(SP)									
  members_string.go:1305	0x6cf6ef		e80ccfdbff		CALL runtime.morestack_noctxt.abi0(SB)							
  members_string.go:1305	0x6cf6f4		488b442408		MOVQ 0x8(SP), AX									
  members_string.go:1305	0x6cf6f9		488b5c2410		MOVQ 0x10(SP), BX									
  members_string.go:1305	0x6cf6fe		488b4c2418		MOVQ 0x18(SP), CX									
  members_string.go:1305	0x6cf703		488b7c2420		MOVQ 0x20(SP), DI									
  members_string.go:1305	0x6cf708		488b742428		MOVQ 0x28(SP), SI									
  members_string.go:1305	0x6cf70d		4c8b442430		MOVQ 0x30(SP), R8									
  members_string.go:1305	0x6cf712		e949fdffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneIndexFallback(SB)		

TEXT github.com/mgomes/vibescript/internal/runtime.stringRuneSlice(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:1454	0x6cfe20		4c8d6424a0		LEAQ -0x60(SP), R12									
  members_string.go:1454	0x6cfe25		4d3b6610		CMPQ R12, 0x10(R14)									
  members_string.go:1454	0x6cfe29		0f865b020000		JBE 0x6d008a										
  members_string.go:1454	0x6cfe2f		55			PUSHQ BP										
  members_string.go:1454	0x6cfe30		4889e5			MOVQ SP, BP										
  members_string.go:1454	0x6cfe33		4881ecd8000000		SUBQ $0xd8, SP										
  members_string.go:1454	0x6cfe3a		48898424e8000000	MOVQ AX, 0xe8(SP)									
  members_string.go:1455	0x6cfe42		4885ff			TESTQ DI, DI										
  members_string.go:1455	0x6cfe45		7c53			JL 0x6cfe9a										
  members_string.go:1455	0x6cfe47		4889bc2400010000	MOVQ DI, 0x100(SP)									
  members_string.go:1455	0x6cfe4f		48898424e8000000	MOVQ AX, 0xe8(SP)									
  members_string.go:1455	0x6cfe57		48899c24f0000000	MOVQ BX, 0xf0(SP)									
  members_string.go:1455	0x6cfe5f		90			NOPL											
  members_string.go:1458	0x6cfe60		4885c9			TESTQ CX, CX										
  members_string.go:1458	0x6cfe63		7d67			JGE 0x6cfecc										
  members_string.go:1455	0x6cfe65		48898c24f8000000	MOVQ CX, 0xf8(SP)									
  ascii_scan_scalar_amd64.go:7	0x6cfe6d		e84e21f4ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIWords(SB)		
  ascii_scan_scalar_amd64.go:7	0x6cfe72		84c0			TESTL AL, AL										
  members_string.go:1186	0x6cfe74		751a			JNE 0x6cfe90										
  members_string.go:1189	0x6cfe76		90			NOPL											
  utf8.go:448			0x6cfe77		31d2			XORL DX, DX										
  utf8.go:448			0x6cfe79		31f6			XORL SI, SI										
  utf8.go:448			0x6cfe7b		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  utf8.go:448			0x6cfe83		488b8424e8000000	MOVQ 0xe8(SP), AX									
  utf8.go:448			0x6cfe8b		e9b0010000		JMP 0x6d0040										
  members_string.go:1459	0x6cfe90		488b8424f0000000	MOVQ 0xf0(SP), AX									
  members_string.go:1459	0x6cfe98		eb11			JMP 0x6cfeab										
  members_string.go:1456	0x6cfe9a		31c0			XORL AX, AX										
  members_string.go:1456	0x6cfe9c		31db			XORL BX, BX										
  members_string.go:1456	0x6cfe9e		31c9			XORL CX, CX										
  members_string.go:1456	0x6cfea0		89cf			MOVL CX, DI										
  members_string.go:1456	0x6cfea2		4881c4d8000000		ADDQ $0xd8, SP										
  members_string.go:1456	0x6cfea9		5d			POPQ BP											
  members_string.go:1456	0x6cfeaa		c3			RET											
  members_string.go:1459	0x6cfeab		488b9424f8000000	MOVQ 0xf8(SP), DX									
  members_string.go:1459	0x6cfeb3		488d0c10		LEAQ 0(AX)(DX*1), CX									
  members_string.go:1460	0x6cfeb7		4885c9			TESTQ CX, CX										
  members_string.go:1460	0x6cfeba		7c4f			JL 0x6cff0b										
  members_string.go:1464	0x6cfebc		488b8424e8000000	MOVQ 0xe8(SP), AX									
  members_string.go:1464	0x6cfec4		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  members_string.go:1464	0x6cfecc		e8afeeffff		CALL github.com/mgomes/vibescript/internal/runtime.stringByteIndexForRuneOffset(SB)	
  members_string.go:1464	0x6cfed1		84db			TESTL BL, BL										
  members_string.go:1465	0x6cfed3		7425			JE 0x6cfefa										
  members_string.go:1464	0x6cfed5		48898424b8000000	MOVQ AX, 0xb8(SP)									
  members_string.go:1469	0x6cfedd		488bbc2400010000	MOVQ 0x100(SP), DI									
  members_string.go:1469	0x6cfee5		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  members_string.go:1469	0x6cfeed		488b8c24e8000000	MOVQ 0xe8(SP), CX									
  members_string.go:1464	0x6cfef5		4889c2			MOVQ AX, DX										
  members_string.go:1469	0x6cfef8		eb28			JMP 0x6cff22										
  members_string.go:1466	0x6cfefa		31c0			XORL AX, AX										
  members_string.go:1466	0x6cfefc		31db			XORL BX, BX										
  members_string.go:1466	0x6cfefe		31c9			XORL CX, CX										
  members_string.go:1466	0x6cff00		89cf			MOVL CX, DI										
  members_string.go:1466	0x6cff02		4881c4d8000000		ADDQ $0xd8, SP										
  members_string.go:1466	0x6cff09		5d			POPQ BP											
  members_string.go:1466	0x6cff0a		c3			RET											
  members_string.go:1461	0x6cff0b		31c0			XORL AX, AX										
  members_string.go:1461	0x6cff0d		31db			XORL BX, BX										
  members_string.go:1461	0x6cff0f		31c9			XORL CX, CX										
  members_string.go:1461	0x6cff11		89cf			MOVL CX, DI										
  members_string.go:1461	0x6cff13		4881c4d8000000		ADDQ $0xd8, SP										
  members_string.go:1461	0x6cff1a		5d			POPQ BP											
  members_string.go:1461	0x6cff1b		c3			RET											
  members_string.go:1474	0x6cff1c		4801f0			ADDQ SI, AX										
  members_string.go:1469	0x6cff1f		48ffcf			DECQ DI											
  members_string.go:1469	0x6cff22		4885ff			TESTQ DI, DI										
  members_string.go:1469	0x6cff25		7e6e			JLE 0x6cff95										
  members_string.go:1470	0x6cff27		4839c3			CMPQ BX, AX										
  members_string.go:1470	0x6cff2a		7469			JE 0x6cff95										
  members_string.go:1473	0x6cff2c		0f8203010000		JB 0x6d0035										
  utf8.go:223			0x6cff32		0fb63401		MOVZX 0(CX)(AX*1), SI									
  members_string.go:1473	0x6cff36		4989d8			MOVQ BX, R8										
  members_string.go:1473	0x6cff39		4929c0			SUBQ AX, R8										
  members_string.go:1473	0x6cff3c		4c8d0c08		LEAQ 0(AX)(CX*1), R9									
  utf8.go:223			0x6cff40		4080fe80		CMPL SI, $0x80										
  utf8.go:223			0x6cff44		7307			JAE 0x6cff4d										
  utf8.go:223			0x6cff46		be01000000		MOVL $0x1, SI										
  members_string.go:1473	0x6cff4b		ebcf			JMP 0x6cff1c										
  members_string.go:1469	0x6cff4d		4889bc24c8000000	MOVQ DI, 0xc8(SP)									
  members_string.go:1469	0x6cff55		48898424c0000000	MOVQ AX, 0xc0(SP)									
  utf8.go:226			0x6cff5d		4c89c8			MOVQ R9, AX										
  utf8.go:226			0x6cff60		4c89c3			MOVQ R8, BX										
  utf8.go:226			0x6cff63		e838e9ddff		CALL unicode/utf8.decodeRuneInStringSlow(SB)						
  members_string.go:1474	0x6cff68		488b8424c0000000	MOVQ 0xc0(SP), AX									
  utf8.go:223			0x6cff70		488b8c24e8000000	MOVQ 0xe8(SP), CX									
  members_string.go:1476	0x6cff78		488b9424b8000000	MOVQ 0xb8(SP), DX									
  members_string.go:1469	0x6cff80		488bbc24c8000000	MOVQ 0xc8(SP), DI									
  members_string.go:1473	0x6cff88		4889de			MOVQ BX, SI										
  members_string.go:1470	0x6cff8b		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  members_string.go:1473	0x6cff93		eb87			JMP 0x6cff1c										
  members_string.go:1476	0x6cff95		4839c3			CMPQ BX, AX										
  members_string.go:1476	0x6cff98		0f8292000000		JB 0x6d0030										
  members_string.go:1476	0x6cff9e		6690			NOPW											
  members_string.go:1476	0x6cffa0		4839c2			CMPQ DX, AX										
  members_string.go:1476	0x6cffa3		0f8782000000		JA 0x6d002b										
  members_string.go:1476	0x6cffa9		4829d0			SUBQ DX, AX										
  members_string.go:1476	0x6cffac		48898424b0000000	MOVQ AX, 0xb0(SP)									
  members_string.go:1476	0x6cffb4		4889c3			MOVQ AX, BX										
  members_string.go:1476	0x6cffb7		48f7d8			NEGQ AX											
  members_string.go:1476	0x6cffba		48c1f83f		SARQ $0x3f, AX										
  members_string.go:1476	0x6cffbe		4821d0			ANDQ DX, AX										
  members_string.go:1476	0x6cffc1		4801c8			ADDQ CX, AX										
  members_string.go:1476	0x6cffc4		48898424d0000000	MOVQ AX, 0xd0(SP)									
  members_string.go:1441	0x6cffcc		e82fefddff		CALL unicode/utf8.ValidString(SB)							
  members_string.go:1441	0x6cffd1		88442427		MOVB AL, 0x27(SP)									
  members_string.go:1441	0x6cffd5		84c0			TESTL AL, AL										
  members_string.go:1441	0x6cffd7		7412			JE 0x6cffeb										
  members_string.go:1476	0x6cffd9		488b9c24b0000000	MOVQ 0xb0(SP), BX									
  members_string.go:1476	0x6cffe1		488b8424d0000000	MOVQ 0xd0(SP), AX									
  members_string.go:1476	0x6cffe9		eb2a			JMP 0x6d0015										
  members_string.go:1444	0x6cffeb		488d442428		LEAQ 0x28(SP), AX									
  members_string.go:1444	0x6cfff0		488b9c24d0000000	MOVQ 0xd0(SP), BX									
  members_string.go:1444	0x6cfff8		488b8c24b0000000	MOVQ 0xb0(SP), CX									
  members_string.go:1444	0x6d0000		e83badd9ff		CALL runtime.stringtoslicerune(SB)							
  members_string.go:1444	0x6d0005		4889cf			MOVQ CX, DI										
  members_string.go:1444	0x6d0008		4889d9			MOVQ BX, CX										
  members_string.go:1444	0x6d000b		4889c3			MOVQ AX, BX										
  members_string.go:1444	0x6d000e		31c0			XORL AX, AX										
  members_string.go:1444	0x6d0010		e8abaed9ff		CALL runtime.slicerunetostring(SB)							
  members_string.go:1476	0x6d0015		0fb64c2427		MOVZX 0x27(SP), CX									
  members_string.go:1476	0x6d001a		83f101			XORL $0x1, CX										
  members_string.go:1476	0x6d001d		bf01000000		MOVL $0x1, DI										
  members_string.go:1476	0x6d0022		4881c4d8000000		ADDQ $0xd8, SP										
  members_string.go:1476	0x6d0029		5d			POPQ BP											
  members_string.go:1476	0x6d002a		c3			RET											
  members_string.go:1476	0x6d002b		e810e2dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1476	0x6d0030		e80be2dbff		CALL runtime.panicBounds(SB)								
  members_string.go:1473	0x6d0035		e806e2dbff		CALL runtime.panicBounds(SB)								
  utf8.go:449			0x6d003a		48ffc2			INCQ DX											
  utf8.go:449			0x6d003d		0f1f00			NOPL 0(AX)										
  utf8.go:448			0x6d0040		4839f3			CMPQ BX, SI										
  utf8.go:448			0x6d0043		7e3d			JLE 0x6d0082										
  utf8.go:448			0x6d0045		440fb60430		MOVZX 0(AX)(SI*1), R8									
  utf8.go:448			0x6d004a		4183f87f		CMPL R8, $0x7f										
  utf8.go:448			0x6d004e		7f05			JG 0x6d0055										
  utf8.go:448			0x6d0050		48ffc6			INCQ SI											
  utf8.go:448			0x6d0053		ebe5			JMP 0x6d003a										
  utf8.go:448			0x6d0055		48899424a8000000	MOVQ DX, 0xa8(SP)									
  utf8.go:448			0x6d005d		4889f1			MOVQ SI, CX										
  utf8.go:448			0x6d0060		e85bd1daff		CALL runtime.decoderune(SB)								
  utf8.go:448			0x6d0065		488b8424e8000000	MOVQ 0xe8(SP), AX									
  utf8.go:449			0x6d006d		488b9424a8000000	MOVQ 0xa8(SP), DX									
  utf8.go:449			0x6d0075		4889de			MOVQ BX, SI										
  utf8.go:448			0x6d0078		488b9c24f0000000	MOVQ 0xf0(SP), BX									
  utf8.go:448			0x6d0080		ebb8			JMP 0x6d003a										
  members_string.go:1459	0x6d0082		4889d0			MOVQ DX, AX										
  members_string.go:1459	0x6d0085		e921feffff		JMP 0x6cfeab										
  members_string.go:1454	0x6d008a		4889442408		MOVQ AX, 0x8(SP)									
  members_string.go:1454	0x6d008f		48895c2410		MOVQ BX, 0x10(SP)									
  members_string.go:1454	0x6d0094		48894c2418		MOVQ CX, 0x18(SP)									
  members_string.go:1454	0x6d0099		48897c2420		MOVQ DI, 0x20(SP)									
  members_string.go:1454	0x6d009e		6690			NOPW											
  members_string.go:1454	0x6d00a0		e85bc5dbff		CALL runtime.morestack_noctxt.abi0(SB)							
  members_string.go:1454	0x6d00a5		488b442408		MOVQ 0x8(SP), AX									
  members_string.go:1454	0x6d00aa		488b5c2410		MOVQ 0x10(SP), BX									
  members_string.go:1454	0x6d00af		488b4c2418		MOVQ 0x18(SP), CX									
  members_string.go:1454	0x6d00b4		488b7c2420		MOVQ 0x20(SP), DI									
  members_string.go:1454	0x6d00b9		e962fdffff		JMP github.com/mgomes/vibescript/internal/runtime.stringRuneSlice(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func2(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:3782	0x759920		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:3782	0x759924		0f861e010000		JBE 0x759a48									
  members_string.go:3782	0x75992a		55			PUSHQ BP									
  members_string.go:3782	0x75992b		4889e5			MOVQ SP, BP									
  members_string.go:3782	0x75992e		4883ec40		SUBQ $0x40, SP									
  members_string.go:3782	0x759932		48898c2480000000	MOVQ CX, 0x80(SP)								
  members_string.go:3782	0x75993a		4889bc2488000000	MOVQ DI, 0x88(SP)								
  members_string.go:3782	0x759942		4c89842498000000	MOVQ R8, 0x98(SP)								
  members_string.go:3783	0x75994a		4d85c9			TESTQ R9, R9									
  members_string.go:3783	0x75994d		7466			JE 0x7599b5									
  errors.go:26			0x75994f		488d0594740600		LEAQ 0x67494(IP), AX								
  errors.go:26			0x759956		bb25000000		MOVL $0x25, BX									
  errors.go:26			0x75995b		31c9			XORL CX, CX									
  errors.go:26			0x75995d		31ff			XORL DI, DI									
  errors.go:26			0x75995f		89fe			MOVL DI, SI									
  errors.go:26			0x759961		e8fa44d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x759966		4885c0			TESTQ AX, AX									
  errors.go:26			0x759969		7536			JNE 0x7599a1									
  errors.go:31			0x75996b		90			NOPL										
  errors.go:65			0x75996c		b810000000		MOVL $0x10, AX									
  errors.go:65			0x759971		488d1d68303900		LEAQ 0x393068(IP), BX								
  errors.go:65			0x759978		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75997d		0f1f00			NOPL 0(AX)									
  errors.go:65			0x759980		e8db79ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x759985		48c7400825000000	MOVQ $0x25, 0x8(AX)								
  errors.go:65			0x75998d		488d1556740600		LEAQ 0x67456(IP), DX								
  errors.go:65			0x759994		488910			MOVQ DX, 0(AX)									
  members_string.go:3784	0x759997		4889c3			MOVQ AX, BX									
  members_string.go:3784	0x75999a		488d05ef0d3c00		LEAQ 0x3c0def(IP), AX								
  members_string.go:3784	0x7599a1		31c9			XORL CX, CX									
  members_string.go:3784	0x7599a3		31ff			XORL DI, DI									
  members_string.go:3784	0x7599a5		4889c6			MOVQ AX, SI									
  members_string.go:3784	0x7599a8		4989d8			MOVQ BX, R8									
  members_string.go:3784	0x7599ab		31c0			XORL AX, AX									
  members_string.go:3784	0x7599ad		31db			XORL BX, BX									
  members_string.go:3784	0x7599af		4883c440		ADDQ $0x40, SP									
  members_string.go:3784	0x7599b3		5d			POPQ BP										
  members_string.go:3784	0x7599b4		c3			RET										
  members_string.go:3786	0x7599b5		4889d8			MOVQ BX, AX									
  members_string.go:3786	0x7599b8		4889cb			MOVQ CX, BX									
  members_string.go:3786	0x7599bb		4889f9			MOVQ DI, CX									
  members_string.go:3786	0x7599be		4889f7			MOVQ SI, DI									
  members_string.go:3786	0x7599c1		e8fa28e5ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:3786	0x7599c6		4889442438		MOVQ AX, 0x38(SP)								
  members_string.go:3786	0x7599cb		48895c2428		MOVQ BX, 0x28(SP)								
  ascii_scan_scalar_amd64.go:7	0x7599d0		e8eb85ebff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIWords(SB)	
  ascii_scan_scalar_amd64.go:7	0x7599d5		84c0			TESTL AL, AL									
  members_string.go:1186	0x7599d7		7512			JNE 0x7599eb									
  members_string.go:1189	0x7599d9		90			NOPL										
  utf8.go:448			0x7599da		31d2			XORL DX, DX									
  utf8.go:448			0x7599dc		4531c9			XORL R9, R9									
  utf8.go:448			0x7599df		488b5c2428		MOVQ 0x28(SP), BX								
  utf8.go:448			0x7599e4		488b442438		MOVQ 0x38(SP), AX								
  utf8.go:448			0x7599e9		eb22			JMP 0x759a0d									
  members_string.go:3786	0x7599eb		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:3786	0x7599f0		31db			XORL BX, BX									
  members_string.go:3786	0x7599f2		31c9			XORL CX, CX									
  members_string.go:3786	0x7599f4		4889c7			MOVQ AX, DI									
  members_string.go:3786	0x7599f7		89de			MOVL BX, SI									
  members_string.go:3786	0x7599f9		4189c8			MOVL CX, R8									
  members_string.go:3786	0x7599fc		b802000000		MOVL $0x2, AX									
  members_string.go:3786	0x759a01		4883c440		ADDQ $0x40, SP									
  members_string.go:3786	0x759a05		5d			POPQ BP										
  members_string.go:3786	0x759a06		c3			RET										
  utf8.go:449			0x759a07		48ffc2			INCQ DX										
  utf8.go:448			0x759a0a		4989f9			MOVQ DI, R9									
  utf8.go:448			0x759a0d		4c39cb			CMPQ BX, R9									
  utf8.go:448			0x759a10		7e31			JLE 0x759a43									
  utf8.go:448			0x759a12		420fb63c08		MOVZX 0(AX)(R9*1), DI								
  utf8.go:448			0x759a17		83ff7f			CMPL DI, $0x7f									
  utf8.go:448			0x759a1a		7f06			JG 0x759a22									
  utf8.go:448			0x759a1c		498d7901		LEAQ 0x1(R9), DI								
  utf8.go:448			0x759a20		ebe5			JMP 0x759a07									
  utf8.go:448			0x759a22		4889542430		MOVQ DX, 0x30(SP)								
  utf8.go:448			0x759a27		4c89c9			MOVQ R9, CX									
  utf8.go:448			0x759a2a		e89137d2ff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x759a2f		488b442438		MOVQ 0x38(SP), AX								
  utf8.go:449			0x759a34		488b542430		MOVQ 0x30(SP), DX								
  utf8.go:449			0x759a39		4889df			MOVQ BX, DI									
  utf8.go:448			0x759a3c		488b5c2428		MOVQ 0x28(SP), BX								
  utf8.go:448			0x759a41		ebc4			JMP 0x759a07									
  members_string.go:3786	0x759a43		4889d0			MOVQ DX, AX									
  members_string.go:3786	0x759a46		eba8			JMP 0x7599f0									
  members_string.go:3782	0x759a48		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:3782	0x759a4d		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:3782	0x759a52		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:3782	0x759a57		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:3782	0x759a5c		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:3782	0x759a61		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:3782	0x759a66		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:3782	0x759a6b		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:3782	0x759a70		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:3782	0x759a75		e8862bd3ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:3782	0x759a7a		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:3782	0x759a7f		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:3782	0x759a84		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:3782	0x759a89		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:3782	0x759a8e		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:3782	0x759a93		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:3782	0x759a98		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:3782	0x759a9d		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:3782	0x759aa2		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:3782	0x759aa7		e974feffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func2(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func20(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4023		0x75c540		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4023		0x75c544		0f8615010000		JBE 0x75c65f									
  members_string.go:4023		0x75c54a		55			PUSHQ BP									
  members_string.go:4023		0x75c54b		4889e5			MOVQ SP, BP									
  members_string.go:4023		0x75c54e		4883ec38		SUBQ $0x38, SP									
  members_string.go:4023		0x75c552		48894c2478		MOVQ CX, 0x78(SP)								
  members_string.go:4023		0x75c557		4889bc2480000000	MOVQ DI, 0x80(SP)								
  members_string.go:4023		0x75c55f		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4024		0x75c567		4983f901		CMPQ R9, $0x1									
  members_string.go:4024		0x75c56b		0f858b000000		JNE 0x75c5fc									
  members_string.go:4027		0x75c571		49833804		CMPQ 0(R8), $0x4								
  members_string.go:4027		0x75c575		7413			JE 0x75c58a									
  members_string.go:4028		0x75c577		31c0			XORL AX, AX									
  members_string.go:4028		0x75c579		31db			XORL BX, BX									
  members_string.go:4028		0x75c57b		31c9			XORL CX, CX									
  members_string.go:4028		0x75c57d		31ff			XORL DI, DI									
  members_string.go:4028		0x75c57f		89de			MOVL BX, SI									
  members_string.go:4028		0x75c581		4189c8			MOVL CX, R8									
  members_string.go:4028		0x75c584		4883c438		ADDQ $0x38, SP									
  members_string.go:4028		0x75c588		5d			POPQ BP										
  members_string.go:4028		0x75c589		c3			RET										
  members_string.go:4024		0x75c58a		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4030		0x75c592		4889d8			MOVQ BX, AX									
  members_string.go:4030		0x75c595		4889cb			MOVQ CX, BX									
  members_string.go:4030		0x75c598		4889f9			MOVQ DI, CX									
  members_string.go:4030		0x75c59b		4889f7			MOVQ SI, DI									
  members_string.go:4030		0x75c59e		6690			NOPW										
  members_string.go:4030		0x75c5a0		e81bfde4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4030		0x75c5a5		4889442430		MOVQ AX, 0x30(SP)								
  members_string.go:4030		0x75c5aa		48895c2428		MOVQ BX, 0x28(SP)								
  members_string.go:4030		0x75c5af		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4030		0x75c5b7		488b02			MOVQ 0(DX), AX									
  members_string.go:4030		0x75c5ba		488b4a10		MOVQ 0x10(DX), CX								
  members_string.go:4030		0x75c5be		488b7a18		MOVQ 0x18(DX), DI								
  members_string.go:4030		0x75c5c2		488b5a08		MOVQ 0x8(DX), BX								
  members_string.go:4030		0x75c5c6		e8f5fce4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:1152		0x75c5cb		90			NOPL										
  ascii_case_compare_scalar.go:6	0x75c5cc		4889c1			MOVQ AX, CX									
  ascii_case_compare_scalar.go:6	0x75c5cf		4889df			MOVQ BX, DI									
  ascii_case_compare_scalar.go:6	0x75c5d2		488b442430		MOVQ 0x30(SP), AX								
  ascii_case_compare_scalar.go:6	0x75c5d7		488b5c2428		MOVQ 0x28(SP), BX								
  ascii_case_compare_scalar.go:6	0x75c5dc		0f1f4000		NOPL 0(AX)									
  ascii_case_compare_scalar.go:6	0x75c5e0		e83b56ebff		CALL github.com/mgomes/vibescript/internal/runtime.asciiCaseCompareWords(SB)	
  members_string.go:4030		0x75c5e5		31db			XORL BX, BX									
  members_string.go:4030		0x75c5e7		31c9			XORL CX, CX									
  members_string.go:4030		0x75c5e9		4889c7			MOVQ AX, DI									
  members_string.go:4030		0x75c5ec		89de			MOVL BX, SI									
  members_string.go:4030		0x75c5ee		4189c8			MOVL CX, R8									
  members_string.go:4030		0x75c5f1		b802000000		MOVL $0x2, AX									
  members_string.go:4030		0x75c5f6		4883c438		ADDQ $0x38, SP									
  members_string.go:4030		0x75c5fa		5d			POPQ BP										
  members_string.go:4030		0x75c5fb		c3			RET										
  errors.go:26				0x75c5fc		488d056e720600		LEAQ 0x6726e(IP), AX								
  errors.go:26				0x75c603		bb29000000		MOVL $0x29, BX									
  errors.go:26				0x75c608		31c9			XORL CX, CX									
  errors.go:26				0x75c60a		31ff			XORL DI, DI									
  errors.go:26				0x75c60c		89fe			MOVL DI, SI									
  errors.go:26				0x75c60e		e84d18d8ff		CALL fmt.errorf(SB)								
  errors.go:26				0x75c613		4885c0			TESTQ AX, AX									
  errors.go:26				0x75c616		7533			JNE 0x75c64b									
  errors.go:31				0x75c618		90			NOPL										
  errors.go:65				0x75c619		b810000000		MOVL $0x10, AX									
  errors.go:65				0x75c61e		488d1dbb033900		LEAQ 0x3903bb(IP), BX								
  errors.go:65				0x75c625		b901000000		MOVL $0x1, CX									
  errors.go:65				0x75c62a		e8314dccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65				0x75c62f		48c7400829000000	MOVQ $0x29, 0x8(AX)								
  errors.go:65				0x75c637		488d1533720600		LEAQ 0x67233(IP), DX								
  errors.go:65				0x75c63e		488910			MOVQ DX, 0(AX)									
  members_string.go:4025		0x75c641		4889c3			MOVQ AX, BX									
  members_string.go:4025		0x75c644		488d0545e13b00		LEAQ 0x3be145(IP), AX								
  members_string.go:4025		0x75c64b		31c9			XORL CX, CX									
  members_string.go:4025		0x75c64d		31ff			XORL DI, DI									
  members_string.go:4025		0x75c64f		4889c6			MOVQ AX, SI									
  members_string.go:4025		0x75c652		4989d8			MOVQ BX, R8									
  members_string.go:4025		0x75c655		31c0			XORL AX, AX									
  members_string.go:4025		0x75c657		31db			XORL BX, BX									
  members_string.go:4025		0x75c659		4883c438		ADDQ $0x38, SP									
  members_string.go:4025		0x75c65d		5d			POPQ BP										
  members_string.go:4025		0x75c65e		c3			RET										
  members_string.go:4023		0x75c65f		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4023		0x75c664		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4023		0x75c669		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4023		0x75c66e		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4023		0x75c673		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4023		0x75c678		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4023		0x75c67d		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4023		0x75c682		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4023		0x75c687		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4023		0x75c68c		e86fffd2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4023		0x75c691		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4023		0x75c696		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4023		0x75c69b		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4023		0x75c6a0		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4023		0x75c6a5		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4023		0x75c6aa		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4023		0x75c6af		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4023		0x75c6b4		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4023		0x75c6b9		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4023		0x75c6be		6690			NOPW										
  members_string.go:4023		0x75c6c0		e97bfeffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func20(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func21(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4033	0x75c6e0		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4033	0x75c6e4		0f8615010000		JBE 0x75c7ff									
  members_string.go:4033	0x75c6ea		55			PUSHQ BP									
  members_string.go:4033	0x75c6eb		4889e5			MOVQ SP, BP									
  members_string.go:4033	0x75c6ee		4883ec38		SUBQ $0x38, SP									
  members_string.go:4033	0x75c6f2		48894c2478		MOVQ CX, 0x78(SP)								
  members_string.go:4033	0x75c6f7		4889bc2480000000	MOVQ DI, 0x80(SP)								
  members_string.go:4033	0x75c6ff		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4034	0x75c707		4983f901		CMPQ R9, $0x1									
  members_string.go:4034	0x75c70b		0f858b000000		JNE 0x75c79c									
  members_string.go:4037	0x75c711		49833804		CMPQ 0(R8), $0x4								
  members_string.go:4037	0x75c715		7413			JE 0x75c72a									
  members_string.go:4038	0x75c717		31c0			XORL AX, AX									
  members_string.go:4038	0x75c719		31db			XORL BX, BX									
  members_string.go:4038	0x75c71b		31c9			XORL CX, CX									
  members_string.go:4038	0x75c71d		31ff			XORL DI, DI									
  members_string.go:4038	0x75c71f		89de			MOVL BX, SI									
  members_string.go:4038	0x75c721		4189c8			MOVL CX, R8									
  members_string.go:4038	0x75c724		4883c438		ADDQ $0x38, SP									
  members_string.go:4038	0x75c728		5d			POPQ BP										
  members_string.go:4038	0x75c729		c3			RET										
  members_string.go:4034	0x75c72a		4c89842490000000	MOVQ R8, 0x90(SP)								
  members_string.go:4040	0x75c732		4889d8			MOVQ BX, AX									
  members_string.go:4040	0x75c735		4889cb			MOVQ CX, BX									
  members_string.go:4040	0x75c738		4889f9			MOVQ DI, CX									
  members_string.go:4040	0x75c73b		4889f7			MOVQ SI, DI									
  members_string.go:4040	0x75c73e		6690			NOPW										
  members_string.go:4040	0x75c740		e87bfbe4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4040	0x75c745		4889442430		MOVQ AX, 0x30(SP)								
  members_string.go:4040	0x75c74a		48895c2428		MOVQ BX, 0x28(SP)								
  members_string.go:4040	0x75c74f		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4040	0x75c757		488b02			MOVQ 0(DX), AX									
  members_string.go:4040	0x75c75a		488b5a08		MOVQ 0x8(DX), BX								
  members_string.go:4040	0x75c75e		488b4a10		MOVQ 0x10(DX), CX								
  members_string.go:4040	0x75c762		488b7a18		MOVQ 0x18(DX), DI								
  members_string.go:4040	0x75c766		e855fbe4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4040	0x75c76b		4889c1			MOVQ AX, CX									
  members_string.go:4040	0x75c76e		4889df			MOVQ BX, DI									
  members_string.go:4040	0x75c771		488b442430		MOVQ 0x30(SP), AX								
  members_string.go:4040	0x75c776		488b5c2428		MOVQ 0x28(SP), BX								
  members_string.go:4040	0x75c77b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4040	0x75c780		e83b25f7ff		CALL github.com/mgomes/vibescript/internal/runtime.caseInsensitiveEqual(SB)	
  members_string.go:4040	0x75c785		0fb6f8			MOVZX AL, DI									
  members_string.go:4040	0x75c788		b801000000		MOVL $0x1, AX									
  members_string.go:4040	0x75c78d		31db			XORL BX, BX									
  members_string.go:4040	0x75c78f		31c9			XORL CX, CX									
  members_string.go:4040	0x75c791		89de			MOVL BX, SI									
  members_string.go:4040	0x75c793		4189c8			MOVL CX, R8									
  members_string.go:4040	0x75c796		4883c438		ADDQ $0x38, SP									
  members_string.go:4040	0x75c79a		5d			POPQ BP										
  members_string.go:4040	0x75c79b		c3			RET										
  errors.go:26			0x75c79c		488d05437b0600		LEAQ 0x67b43(IP), AX								
  errors.go:26			0x75c7a3		bb2a000000		MOVL $0x2a, BX									
  errors.go:26			0x75c7a8		31c9			XORL CX, CX									
  errors.go:26			0x75c7aa		31ff			XORL DI, DI									
  errors.go:26			0x75c7ac		89fe			MOVL DI, SI									
  errors.go:26			0x75c7ae		e8ad16d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75c7b3		4885c0			TESTQ AX, AX									
  errors.go:26			0x75c7b6		7533			JNE 0x75c7eb									
  errors.go:31			0x75c7b8		90			NOPL										
  errors.go:65			0x75c7b9		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75c7be		488d1d1b023900		LEAQ 0x39021b(IP), BX								
  errors.go:65			0x75c7c5		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75c7ca		e8914bccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75c7cf		48c740082a000000	MOVQ $0x2a, 0x8(AX)								
  errors.go:65			0x75c7d7		488d15087b0600		LEAQ 0x67b08(IP), DX								
  errors.go:65			0x75c7de		488910			MOVQ DX, 0(AX)									
  members_string.go:4035	0x75c7e1		4889c3			MOVQ AX, BX									
  members_string.go:4035	0x75c7e4		488d05a5df3b00		LEAQ 0x3bdfa5(IP), AX								
  members_string.go:4035	0x75c7eb		31c9			XORL CX, CX									
  members_string.go:4035	0x75c7ed		31ff			XORL DI, DI									
  members_string.go:4035	0x75c7ef		4889c6			MOVQ AX, SI									
  members_string.go:4035	0x75c7f2		4989d8			MOVQ BX, R8									
  members_string.go:4035	0x75c7f5		31c0			XORL AX, AX									
  members_string.go:4035	0x75c7f7		31db			XORL BX, BX									
  members_string.go:4035	0x75c7f9		4883c438		ADDQ $0x38, SP									
  members_string.go:4035	0x75c7fd		5d			POPQ BP										
  members_string.go:4035	0x75c7fe		c3			RET										
  members_string.go:4033	0x75c7ff		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4033	0x75c804		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4033	0x75c809		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4033	0x75c80e		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4033	0x75c813		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4033	0x75c818		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4033	0x75c81d		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4033	0x75c822		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4033	0x75c827		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4033	0x75c82c		e8cffdd2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4033	0x75c831		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4033	0x75c836		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4033	0x75c83b		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4033	0x75c840		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4033	0x75c845		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4033	0x75c84a		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4033	0x75c84f		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4033	0x75c854		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4033	0x75c859		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4033	0x75c85e		6690			NOPW										
  members_string.go:4033	0x75c860		e97bfeffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func21(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func22(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4043	0x75c880		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4043	0x75c884		0f8684000000		JBE 0x75c90e									
  members_string.go:4043	0x75c88a		55			PUSHQ BP									
  members_string.go:4043	0x75c88b		4889e5			MOVQ SP, BP									
  members_string.go:4043	0x75c88e		4883ec70		SUBQ $0x70, SP									
  members_string.go:4043	0x75c892		48898c24b0000000	MOVQ CX, 0xb0(SP)								
  members_string.go:4043	0x75c89a		4889bc24b8000000	MOVQ DI, 0xb8(SP)								
  members_string.go:4043	0x75c8a2		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4044	0x75c8aa		4c891c24		MOVQ R11, 0(SP)									
  members_string.go:4044	0x75c8ae		488b942480000000	MOVQ 0x80(SP), DX								
  members_string.go:4044	0x75c8b6		4889542408		MOVQ DX, 0x8(SP)								
  members_string.go:4044	0x75c8bb		488b942488000000	MOVQ 0x88(SP), DX								
  members_string.go:4044	0x75c8c3		4889542410		MOVQ DX, 0x10(SP)								
  members_string.go:4044	0x75c8c8		488b942490000000	MOVQ 0x90(SP), DX								
  members_string.go:4044	0x75c8d0		4889542418		MOVQ DX, 0x18(SP)								
  members_string.go:4044	0x75c8d5		488b942498000000	MOVQ 0x98(SP), DX								
  members_string.go:4044	0x75c8dd		4889542420		MOVQ DX, 0x20(SP)								
  members_string.go:4044	0x75c8e2		488d05fc850500		LEAQ 0x585fc(IP), AX								
  members_string.go:4044	0x75c8e9		4d89d3			MOVQ R10, R11									
  members_string.go:4044	0x75c8ec		4d89ca			MOVQ R9, R10									
  members_string.go:4044	0x75c8ef		4d89c1			MOVQ R8, R9									
  members_string.go:4044	0x75c8f2		4989f0			MOVQ SI, R8									
  members_string.go:4044	0x75c8f5		4889fe			MOVQ DI, SI									
  members_string.go:4044	0x75c8f8		4889cf			MOVQ CX, DI									
  members_string.go:4044	0x75c8fb		4889d9			MOVQ BX, CX									
  members_string.go:4044	0x75c8fe		bb0f000000		MOVL $0xf, BX									
  members_string.go:4044	0x75c903		e818f0fdff		CALL github.com/mgomes/vibescript/internal/runtime.comparableBetween(SB)	
  members_string.go:4044	0x75c908		4883c470		ADDQ $0x70, SP									
  members_string.go:4044	0x75c90c		5d			POPQ BP										
  members_string.go:4044	0x75c90d		c3			RET										
  members_string.go:4043	0x75c90e		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4043	0x75c913		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4043	0x75c918		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4043	0x75c91d		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4043	0x75c922		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4043	0x75c927		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4043	0x75c92c		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4043	0x75c931		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4043	0x75c936		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4043	0x75c93b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4043	0x75c940		e8bbfcd2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4043	0x75c945		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4043	0x75c94a		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4043	0x75c94f		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4043	0x75c954		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4043	0x75c959		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4043	0x75c95e		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4043	0x75c963		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4043	0x75c968		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4043	0x75c96d		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4043	0x75c972		e909ffffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func22(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func23(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4047	0x75c980		4c8da42410ffffff	LEAQ 0xffffff10(SP), R12									
  members_string.go:4047	0x75c988		4d3b6610		CMPQ R12, 0x10(R14)										
  members_string.go:4047	0x75c98c		0f863e080000		JBE 0x75d1d0											
  members_string.go:4047	0x75c992		55			PUSHQ BP											
  members_string.go:4047	0x75c993		4889e5			MOVQ SP, BP											
  members_string.go:4047	0x75c996		4881ec68010000		SUBQ $0x168, SP											
  members_string.go:4047	0x75c99d		48898c24a8010000	MOVQ CX, 0x1a8(SP)										
  members_string.go:4047	0x75c9a5		4889bc24b0010000	MOVQ DI, 0x1b0(SP)										
  members_string.go:4047	0x75c9ad		4c898424c0010000	MOVQ R8, 0x1c0(SP)										
  members_string.go:4048	0x75c9b5		4d85db			TESTQ R11, R11											
  members_string.go:4048	0x75c9b8		7405			JE 0x75c9bf											
  members_string.go:4048	0x75c9ba		498b13			MOVQ 0(R11), DX											
  members_string.go:4048	0x75c9bd		eb02			JMP 0x75c9c1											
  members_string.go:4048	0x75c9bf		31d2			XORL DX, DX											
  members_string.go:4048	0x75c9c1		4885d2			TESTQ DX, DX											
  members_string.go:4048	0x75c9c4		0f8f63030000		JG 0x75cd2d											
  members_string.go:4051	0x75c9ca		4d85c9			TESTQ R9, R9											
  members_string.go:4051	0x75c9cd		7406			JE 0x75c9d5											
  members_string.go:4051	0x75c9cf		4983f902		CMPQ R9, $0x2											
  members_string.go:4051	0x75c9d3		7e66			JLE 0x75ca3b											
  errors.go:26			0x75c9d5		488d05bbb40600		LEAQ 0x6b4bb(IP), AX										
  errors.go:26			0x75c9dc		bb32000000		MOVL $0x32, BX											
  errors.go:26			0x75c9e1		31c9			XORL CX, CX											
  errors.go:26			0x75c9e3		31ff			XORL DI, DI											
  errors.go:26			0x75c9e5		89fe			MOVL DI, SI											
  errors.go:26			0x75c9e7		e87414d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75c9ec		4885c0			TESTQ AX, AX											
  errors.go:26			0x75c9ef		7533			JNE 0x75ca24											
  errors.go:31			0x75c9f1		90			NOPL												
  errors.go:65			0x75c9f2		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75c9f7		488d1de2ff3800		LEAQ 0x38ffe2(IP), BX										
  errors.go:65			0x75c9fe		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75ca03		e85849ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75ca08		48c7400832000000	MOVQ $0x32, 0x8(AX)										
  errors.go:65			0x75ca10		488d1580b40600		LEAQ 0x6b480(IP), DX										
  errors.go:65			0x75ca17		488910			MOVQ DX, 0(AX)											
  members_string.go:4052	0x75ca1a		4889c3			MOVQ AX, BX											
  members_string.go:4052	0x75ca1d		488d056cdd3b00		LEAQ 0x3bdd6c(IP), AX										
  members_string.go:4052	0x75ca24		31c9			XORL CX, CX											
  members_string.go:4052	0x75ca26		31ff			XORL DI, DI											
  members_string.go:4052	0x75ca28		4889c6			MOVQ AX, SI											
  members_string.go:4052	0x75ca2b		4989d8			MOVQ BX, R8											
  members_string.go:4052	0x75ca2e		31c0			XORL AX, AX											
  members_string.go:4052	0x75ca30		31db			XORL BX, BX											
  members_string.go:4052	0x75ca32		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4052	0x75ca39		5d			POPQ BP												
  members_string.go:4052	0x75ca3a		c3			RET												
  members_string.go:4048	0x75ca3b		4889842498010000	MOVQ AX, 0x198(SP)										
  members_string.go:4048	0x75ca43		4c899c24d8010000	MOVQ R11, 0x1d8(SP)										
  members_string.go:4048	0x75ca4b		4c898c24c8010000	MOVQ R9, 0x1c8(SP)										
  members_string.go:4048	0x75ca53		4889b42408010000	MOVQ SI, 0x108(SP)										
  members_string.go:4048	0x75ca5b		4c898424c0010000	MOVQ R8, 0x1c0(SP)										
  members_string.go:4048	0x75ca63		4c899424d0010000	MOVQ R10, 0x1d0(SP)										
  members_string.go:4048	0x75ca6b		4889bc2430010000	MOVQ DI, 0x130(SP)										
  members_string.go:4048	0x75ca73		48898c2400010000	MOVQ CX, 0x100(SP)										
  members_string.go:4048	0x75ca7b		48899c24f8000000	MOVQ BX, 0xf8(SP)										
  members_string.go:4054	0x75ca83		498b7808		MOVQ 0x8(R8), DI										
  members_string.go:4054	0x75ca87		498b7010		MOVQ 0x10(R8), SI										
  members_string.go:4054	0x75ca8b		498b5018		MOVQ 0x18(R8), DX										
  members_string.go:4054	0x75ca8f		498b08			MOVQ 0(R8), CX											
  members_string.go:4054	0x75ca92		488d05af6f0500		LEAQ 0x56faf(IP), AX										
  members_string.go:4054	0x75ca99		bb0c000000		MOVL $0xc, BX											
  members_string.go:4054	0x75ca9e		4989d0			MOVQ DX, R8											
  members_string.go:4054	0x75caa1		e8da48fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4055	0x75caa6		4885ff			TESTQ DI, DI											
  members_string.go:4055	0x75caa9		0f8567020000		JNE 0x75cd16											
  members_string.go:4054	0x75caaf		48899c24d0000000	MOVQ BX, 0xd0(SP)										
  members_string.go:4054	0x75cab7		4889842420010000	MOVQ AX, 0x120(SP)										
  members_string.go:4054	0x75cabf		888c24af000000		MOVB CL, 0xaf(SP)										
  members_string.go:4058	0x75cac6		488b8424f8000000	MOVQ 0xf8(SP), AX										
  members_string.go:4058	0x75cace		488b9c2400010000	MOVQ 0x100(SP), BX										
  members_string.go:4058	0x75cad6		488b8c2430010000	MOVQ 0x130(SP), CX										
  members_string.go:4058	0x75cade		488bbc2408010000	MOVQ 0x108(SP), DI										
  members_string.go:4058	0x75cae6		e8d5f7e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  members_string.go:4058	0x75caeb		4889842418010000	MOVQ AX, 0x118(SP)										
  members_string.go:4058	0x75caf3		48899c24c8000000	MOVQ BX, 0xc8(SP)										
  members_string.go:4059	0x75cafb		4889c1			MOVQ AX, CX											
  members_string.go:4059	0x75cafe		4889df			MOVQ BX, DI											
  members_string.go:4059	0x75cb01		488bb42420010000	MOVQ 0x120(SP), SI										
  members_string.go:4059	0x75cb09		4c8b8424d0000000	MOVQ 0xd0(SP), R8										
  members_string.go:4059	0x75cb11		440fb68c24af000000	MOVZX 0xaf(SP), R9										
  members_string.go:4059	0x75cb1a		488d05276f0500		LEAQ 0x56f27(IP), AX										
  members_string.go:4059	0x75cb21		bb0c000000		MOVL $0xc, BX											
  members_string.go:4059	0x75cb26		e8f560f7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)			
  members_string.go:4059	0x75cb2b		4885c0			TESTQ AX, AX											
  members_string.go:4059	0x75cb2e		0f85cb010000		JNE 0x75ccff											
  members_string.go:4051	0x75cb34		488b9424c8010000	MOVQ 0x1c8(SP), DX										
  members_string.go:4051	0x75cb3c		0f1f4000		NOPL 0(AX)											
  members_string.go:4051	0x75cb40		4883fa02		CMPQ DX, $0x2											
  members_string.go:4074	0x75cb44		7408			JE 0x75cb4e											
  members_string.go:4074	0x75cb46		4531d2			XORL R10, R10											
  members_string.go:4074	0x75cb49		e959020000		JMP 0x75cda7											
  members_string.go:4075	0x75cb4e		488b9424c0010000	MOVQ 0x1c0(SP), DX										
  members_string.go:4075	0x75cb56		488b4220		MOVQ 0x20(DX), AX										
  members_string.go:4075	0x75cb5a		488b5a28		MOVQ 0x28(DX), BX										
  members_string.go:4075	0x75cb5e		488b4a30		MOVQ 0x30(DX), CX										
  members_string.go:4075	0x75cb62		488b7a38		MOVQ 0x38(DX), DI										
  members_string.go:4075	0x75cb66		e87581fdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)				
  members_string.go:4076	0x75cb6b		4885db			TESTQ BX, BX											
  members_string.go:4076	0x75cb6e		7468			JE 0x75cbd8											
  errors.go:26			0x75cb70		488d05d9280600		LEAQ 0x628d9(IP), AX										
  errors.go:26			0x75cb77		bb23000000		MOVL $0x23, BX											
  errors.go:26			0x75cb7c		31c9			XORL CX, CX											
  errors.go:26			0x75cb7e		31ff			XORL DI, DI											
  errors.go:26			0x75cb80		89fe			MOVL DI, SI											
  errors.go:26			0x75cb82		e8d912d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75cb87		4885c0			TESTQ AX, AX											
  errors.go:26			0x75cb8a		7535			JNE 0x75cbc1											
  errors.go:31			0x75cb8c		90			NOPL												
  errors.go:65			0x75cb8d		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75cb92		488d1d47fe3800		LEAQ 0x38fe47(IP), BX										
  errors.go:65			0x75cb99		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75cb9e		6690			NOPW												
  errors.go:65			0x75cba0		e8bb47ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75cba5		48c7400823000000	MOVQ $0x23, 0x8(AX)										
  errors.go:65			0x75cbad		488d159c280600		LEAQ 0x6289c(IP), DX										
  errors.go:65			0x75cbb4		488910			MOVQ DX, 0(AX)											
  members_string.go:4077	0x75cbb7		4889c3			MOVQ AX, BX											
  members_string.go:4077	0x75cbba		488d05cfdb3b00		LEAQ 0x3bdbcf(IP), AX										
  members_string.go:4077	0x75cbc1		31c9			XORL CX, CX											
  members_string.go:4077	0x75cbc3		31ff			XORL DI, DI											
  members_string.go:4077	0x75cbc5		4889c6			MOVQ AX, SI											
  members_string.go:4077	0x75cbc8		4989d8			MOVQ BX, R8											
  members_string.go:4077	0x75cbcb		31c0			XORL AX, AX											
  members_string.go:4077	0x75cbcd		31db			XORL BX, BX											
  members_string.go:4077	0x75cbcf		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4077	0x75cbd6		5d			POPQ BP												
  members_string.go:4077	0x75cbd7		c3			RET												
  members_string.go:4079	0x75cbd8		488b9c24c8000000	MOVQ 0xc8(SP), BX										
  members_string.go:4079	0x75cbe0		4889c1			MOVQ AX, CX											
  members_string.go:4079	0x75cbe3		488b842418010000	MOVQ 0x118(SP), AX										
  members_string.go:4079	0x75cbeb		e8d022f7ff		CALL github.com/mgomes/vibescript/internal/runtime.stringEffectiveOffset(SB)			
  members_string.go:4079	0x75cbf0		84db			TESTL BL, BL											
  members_string.go:4080	0x75cbf2		7449			JE 0x75cc3d											
  members_string.go:4079	0x75cbf4		48898424d8000000	MOVQ AX, 0xd8(SP)										
  ascii_scan_scalar_amd64.go:7	0x75cbfc		488b842418010000	MOVQ 0x118(SP), AX										
  ascii_scan_scalar_amd64.go:7	0x75cc04		488b9c24c8000000	MOVQ 0xc8(SP), BX										
  ascii_scan_scalar_amd64.go:7	0x75cc0c		e8af53ebff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIWords(SB)			
  ascii_scan_scalar_amd64.go:7	0x75cc11		84c0			TESTL AL, AL											
  members_string.go:1186	0x75cc13		751b			JNE 0x75cc30											
  members_string.go:1189	0x75cc15		90			NOPL												
  utf8.go:448			0x75cc16		31d2			XORL DX, DX											
  utf8.go:448			0x75cc18		4531db			XORL R11, R11											
  utf8.go:448			0x75cc1b		488bb424c8000000	MOVQ 0xc8(SP), SI										
  utf8.go:448			0x75cc23		488bbc2418010000	MOVQ 0x118(SP), DI										
  utf8.go:448			0x75cc2b		e950050000		JMP 0x75d180											
  members_string.go:4086	0x75cc30		488b8424c8000000	MOVQ 0xc8(SP), AX										
  members_string.go:4086	0x75cc38		e95b010000		JMP 0x75cd98											
  members_string.go:4081	0x75cc3d		488b842420010000	MOVQ 0x120(SP), AX										
  members_string.go:4081	0x75cc45		488b9c24d0000000	MOVQ 0xd0(SP), BX										
  members_string.go:4081	0x75cc4d		e8eed6faff		CALL github.com/mgomes/vibescript/internal/runtime.compileCachedRegex(SB)			
  members_string.go:4081	0x75cc52		4885db			TESTQ BX, BX											
  members_string.go:4081	0x75cc55		0f848e000000		JE 0x75cce9											
  members_string.go:4082	0x75cc5b		440f11bc2458010000	MOVUPS X15, 0x158(SP)										
  members_string.go:4082	0x75cc64		7404			JE 0x75cc6a											
  members_string.go:4082	0x75cc66		488b5b08		MOVQ 0x8(BX), BX										
  members_string.go:4082	0x75cc6a		48899c2458010000	MOVQ BX, 0x158(SP)										
  members_string.go:4082	0x75cc72		48898c2460010000	MOVQ CX, 0x160(SP)										
  errors.go:26			0x75cc7a		488d0539f10500		LEAQ 0x5f139(IP), AX										
  errors.go:26			0x75cc81		bb1e000000		MOVL $0x1e, BX											
  errors.go:26			0x75cc86		488d8c2458010000	LEAQ 0x158(SP), CX										
  errors.go:26			0x75cc8e		bf01000000		MOVL $0x1, DI											
  errors.go:26			0x75cc93		89fe			MOVL DI, SI											
  errors.go:26			0x75cc95		e8c611d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75cc9a		4885c0			TESTQ AX, AX											
  errors.go:26			0x75cc9d		7533			JNE 0x75ccd2											
  errors.go:31			0x75cc9f		90			NOPL												
  errors.go:65			0x75cca0		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75cca5		488d1d34fd3800		LEAQ 0x38fd34(IP), BX										
  errors.go:65			0x75ccac		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75ccb1		e8aa46ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75ccb6		48c740081e000000	MOVQ $0x1e, 0x8(AX)										
  errors.go:65			0x75ccbe		488d15f5f00500		LEAQ 0x5f0f5(IP), DX										
  errors.go:65			0x75ccc5		488910			MOVQ DX, 0(AX)											
  members_string.go:4082	0x75ccc8		4889c3			MOVQ AX, BX											
  members_string.go:4082	0x75cccb		488d05beda3b00		LEAQ 0x3bdabe(IP), AX										
  members_string.go:4082	0x75ccd2		31c9			XORL CX, CX											
  members_string.go:4082	0x75ccd4		31ff			XORL DI, DI											
  members_string.go:4082	0x75ccd6		4889c6			MOVQ AX, SI											
  members_string.go:4082	0x75ccd9		4989d8			MOVQ BX, R8											
  members_string.go:4082	0x75ccdc		31c0			XORL AX, AX											
  members_string.go:4082	0x75ccde		31db			XORL BX, BX											
  members_string.go:4082	0x75cce0		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4082	0x75cce7		5d			POPQ BP												
  members_string.go:4082	0x75cce8		c3			RET												
  members_string.go:4084	0x75cce9		31c0			XORL AX, AX											
  members_string.go:4084	0x75cceb		31db			XORL BX, BX											
  members_string.go:4084	0x75cced		31c9			XORL CX, CX											
  members_string.go:4084	0x75ccef		31ff			XORL DI, DI											
  members_string.go:4084	0x75ccf1		89de			MOVL BX, SI											
  members_string.go:4084	0x75ccf3		4189c8			MOVL CX, R8											
  members_string.go:4084	0x75ccf6		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4084	0x75ccfd		5d			POPQ BP												
  members_string.go:4084	0x75ccfe		c3			RET												
  members_string.go:4060	0x75ccff		31c9			XORL CX, CX											
  members_string.go:4060	0x75cd01		31ff			XORL DI, DI											
  members_string.go:4060	0x75cd03		4889c6			MOVQ AX, SI											
  members_string.go:4060	0x75cd06		4989d8			MOVQ BX, R8											
  members_string.go:4060	0x75cd09		31c0			XORL AX, AX											
  members_string.go:4060	0x75cd0b		31db			XORL BX, BX											
  members_string.go:4060	0x75cd0d		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4060	0x75cd14		5d			POPQ BP												
  members_string.go:4060	0x75cd15		c3			RET												
  members_string.go:4056	0x75cd16		31c0			XORL AX, AX											
  members_string.go:4056	0x75cd18		31db			XORL BX, BX											
  members_string.go:4056	0x75cd1a		31c9			XORL CX, CX											
  members_string.go:4056	0x75cd1c		4989f0			MOVQ SI, R8											
  members_string.go:4056	0x75cd1f		4889fe			MOVQ DI, SI											
  members_string.go:4056	0x75cd22		31ff			XORL DI, DI											
  members_string.go:4056	0x75cd24		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4056	0x75cd2b		5d			POPQ BP												
  members_string.go:4056	0x75cd2c		c3			RET												
  errors.go:26			0x75cd2d		488d05e99a0600		LEAQ 0x69ae9(IP), AX										
  errors.go:26			0x75cd34		bb2e000000		MOVL $0x2e, BX											
  errors.go:26			0x75cd39		31c9			XORL CX, CX											
  errors.go:26			0x75cd3b		31ff			XORL DI, DI											
  errors.go:26			0x75cd3d		89fe			MOVL DI, SI											
  errors.go:26			0x75cd3f		90			NOPL												
  errors.go:26			0x75cd40		e81b11d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75cd45		4885c0			TESTQ AX, AX											
  errors.go:26			0x75cd48		7537			JNE 0x75cd81											
  errors.go:31			0x75cd4a		90			NOPL												
  errors.go:65			0x75cd4b		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75cd50		488d1d89fc3800		LEAQ 0x38fc89(IP), BX										
  errors.go:65			0x75cd57		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75cd5c		0f1f4000		NOPL 0(AX)											
  errors.go:65			0x75cd60		e8fb45ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75cd65		48c740082e000000	MOVQ $0x2e, 0x8(AX)										
  errors.go:65			0x75cd6d		488d15a99a0600		LEAQ 0x69aa9(IP), DX										
  errors.go:65			0x75cd74		488910			MOVQ DX, 0(AX)											
  members_string.go:4049	0x75cd77		4889c3			MOVQ AX, BX											
  members_string.go:4049	0x75cd7a		488d050fda3b00		LEAQ 0x3bda0f(IP), AX										
  members_string.go:4049	0x75cd81		31c9			XORL CX, CX											
  members_string.go:4049	0x75cd83		31ff			XORL DI, DI											
  members_string.go:4049	0x75cd85		4889c6			MOVQ AX, SI											
  members_string.go:4049	0x75cd88		4989d8			MOVQ BX, R8											
  members_string.go:4049	0x75cd8b		31c0			XORL AX, AX											
  members_string.go:4049	0x75cd8d		31db			XORL BX, BX											
  members_string.go:4049	0x75cd8f		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4049	0x75cd96		5d			POPQ BP												
  members_string.go:4049	0x75cd97		c3			RET												
  members_string.go:4086	0x75cd98		4c8b9424d8000000	MOVQ 0xd8(SP), R10										
  members_string.go:4086	0x75cda0		4939c2			CMPQ R10, AX											
  members_string.go:4089	0x75cda3		4c0f4fd0		CMOVG AX, R10											
  members_string.go:2100	0x75cda7		488b0592574000		MOVQ github.com/mgomes/vibescript/internal/runtime.compiledRegexps(SB), AX			
  members_string.go:4091	0x75cdae		90			NOPL												
  members_string.go:2100	0x75cdaf		488d1d926c0500		LEAQ 0x56c92(IP), BX										
  members_string.go:2100	0x75cdb6		b90c000000		MOVL $0xc, CX											
  members_string.go:2100	0x75cdbb		488bbc2418010000	MOVQ 0x118(SP), DI										
  members_string.go:2100	0x75cdc3		488bb424c8000000	MOVQ 0xc8(SP), SI										
  members_string.go:2100	0x75cdcb		4c8b842420010000	MOVQ 0x120(SP), R8										
  members_string.go:2100	0x75cdd3		4c8b8c24d0000000	MOVQ 0xd0(SP), R9										
  members_string.go:2100	0x75cddb		0f1f440000		NOPL 0(AX)(AX*1)										
  members_string.go:2100	0x75cde0		e85b64f7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexSubmatchFromRuneOffsetWithCache(SB)	
  members_string.go:4092	0x75cde5		4885ff			TESTQ DI, DI											
  members_string.go:4092	0x75cde8		0f85a5010000		JNE 0x75cf93											
  members_string.go:4095	0x75cdee		4885c0			TESTQ AX, AX											
  members_string.go:4095	0x75cdf1		0f8486010000		JE 0x75cf7d											
  members_string.go:2100	0x75cdf7		48898c24b8000000	MOVQ CX, 0xb8(SP)										
  members_string.go:2100	0x75cdff		48899c24b0000000	MOVQ BX, 0xb0(SP)										
  members_string.go:2100	0x75ce07		4889842410010000	MOVQ AX, 0x110(SP)										
  members_string.go:4100	0x75ce0f		488b842420010000	MOVQ 0x120(SP), AX										
  members_string.go:4100	0x75ce17		488b9c24d0000000	MOVQ 0xd0(SP), BX										
  members_string.go:4100	0x75ce1f		90			NOPL												
  members_string.go:4100	0x75ce20		e89b63f7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexSubexpNames(SB)				
  members_string.go:4100	0x75ce25		488b9424f8000000	MOVQ 0xf8(SP), DX										
  members_string.go:4100	0x75ce2d		48891424		MOVQ DX, 0(SP)											
  members_string.go:4100	0x75ce31		488b942400010000	MOVQ 0x100(SP), DX										
  members_string.go:4100	0x75ce39		4889542408		MOVQ DX, 0x8(SP)										
  members_string.go:4100	0x75ce3e		488b942430010000	MOVQ 0x130(SP), DX										
  members_string.go:4100	0x75ce46		4889542410		MOVQ DX, 0x10(SP)										
  members_string.go:4100	0x75ce4b		488b942408010000	MOVQ 0x108(SP), DX										
  members_string.go:4100	0x75ce53		4889542418		MOVQ DX, 0x18(SP)										
  members_string.go:4100	0x75ce58		488b9424c0010000	MOVQ 0x1c0(SP), DX										
  members_string.go:4100	0x75ce60		4889542420		MOVQ DX, 0x20(SP)										
  members_string.go:4100	0x75ce65		488b9424c8010000	MOVQ 0x1c8(SP), DX										
  members_string.go:4100	0x75ce6d		4889542428		MOVQ DX, 0x28(SP)										
  members_string.go:4100	0x75ce72		488b9424d0010000	MOVQ 0x1d0(SP), DX										
  members_string.go:4100	0x75ce7a		4889542430		MOVQ DX, 0x30(SP)										
  members_string.go:4100	0x75ce7f		488b9424d8010000	MOVQ 0x1d8(SP), DX										
  members_string.go:4100	0x75ce87		4889542438		MOVQ DX, 0x38(SP)										
  members_string.go:4100	0x75ce8c		488b942478010000	MOVQ 0x178(SP), DX										
  members_string.go:4100	0x75ce94		4889542440		MOVQ DX, 0x40(SP)										
  members_string.go:4100	0x75ce99		488b942480010000	MOVQ 0x180(SP), DX										
  members_string.go:4100	0x75cea1		4889542448		MOVQ DX, 0x48(SP)										
  members_string.go:4100	0x75cea6		488b942488010000	MOVQ 0x188(SP), DX										
  members_string.go:4100	0x75ceae		4889542450		MOVQ DX, 0x50(SP)										
  members_string.go:4100	0x75ceb3		488b942490010000	MOVQ 0x190(SP), DX										
  members_string.go:4100	0x75cebb		4889542458		MOVQ DX, 0x58(SP)										
  members_string.go:4100	0x75cec0		488bbc2410010000	MOVQ 0x110(SP), DI										
  members_string.go:4100	0x75cec8		488bb424b0000000	MOVQ 0xb0(SP), SI										
  members_string.go:4100	0x75ced0		4c8b8424b8000000	MOVQ 0xb8(SP), R8										
  members_string.go:4100	0x75ced8		4989c1			MOVQ AX, R9											
  members_string.go:4100	0x75cedb		4989da			MOVQ BX, R10											
  members_string.go:4100	0x75cede		4989cb			MOVQ CX, R11											
  members_string.go:4100	0x75cee1		488b842498010000	MOVQ 0x198(SP), AX										
  members_string.go:4100	0x75cee9		488b9c2418010000	MOVQ 0x118(SP), BX										
  members_string.go:4100	0x75cef1		488b8c24c8000000	MOVQ 0xc8(SP), CX										
  members_string.go:4100	0x75cef9		e86297f3ff		CALL github.com/mgomes/vibescript/internal/runtime.newMatchData(SB)				
  members_string.go:4100	0x75cefe		6690			NOPW												
  members_string.go:4101	0x75cf00		4885f6			TESTQ SI, SI											
  members_string.go:4101	0x75cf03		7567			JNE 0x75cf6c											
  members_string.go:4100	0x75cf05		48898424f0000000	MOVQ AX, 0xf0(SP)										
  members_string.go:4100	0x75cf0d		48899c24e8000000	MOVQ BX, 0xe8(SP)										
  members_string.go:4100	0x75cf15		48898c2428010000	MOVQ CX, 0x128(SP)										
  members_string.go:4100	0x75cf1d		4889bc24e0000000	MOVQ DI, 0xe0(SP)										
  aliases.go:1400		0x75cf25		90			NOPL												
  value_accessors.go:180	0x75cf26		488b942478010000	MOVQ 0x178(SP), DX										
  value_accessors.go:180	0x75cf2e		4883fa0f		CMPQ DX, $0xf											
  value_accessors.go:180	0x75cf32		7531			JNE 0x75cf65											
  value_accessors.go:183	0x75cf34		4c8b9c2480010000	MOVQ 0x180(SP), R11										
  value_accessors.go:183	0x75cf3c		0f1f4000		NOPL 0(AX)											
  value_accessors.go:183	0x75cf40		4d85db			TESTQ R11, R11											
  value_accessors.go:183	0x75cf43		7414			JE 0x75cf59											
  value_accessors.go:183	0x75cf45		4c8b2594463f00		MOVQ github.com/mgomes/vibescript/internal/runtime..typeAssert.357(SB), R12			
  value_accessors.go:183	0x75cf4c		4d8b2c24		MOVQ 0(R12), R13										
  value_accessors.go:183	0x75cf50		458b7b10		MOVL 0x10(R11), R15										
  value_accessors.go:183	0x75cf54		e9ac010000		JMP 0x75d105											
  members_string.go:4047	0x75cf59		4c89de			MOVQ R11, SI											
  members_string.go:4047	0x75cf5c		0f1f4000		NOPL 0(AX)											
  value_accessors.go:183	0x75cf60		e98f010000		JMP 0x75d0f4											
  value_accessors.go:183	0x75cf65		31f6			XORL SI, SI											
  value_accessors.go:183	0x75cf67		4531c0			XORL R8, R8											
  aliases.go:1367		0x75cf6a		eb3e			JMP 0x75cfaa											
  members_string.go:4102	0x75cf6c		31c0			XORL AX, AX											
  members_string.go:4102	0x75cf6e		31db			XORL BX, BX											
  members_string.go:4102	0x75cf70		31c9			XORL CX, CX											
  members_string.go:4102	0x75cf72		31ff			XORL DI, DI											
  members_string.go:4102	0x75cf74		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4102	0x75cf7b		5d			POPQ BP												
  members_string.go:4102	0x75cf7c		c3			RET												
  members_string.go:4098	0x75cf7d		31c0			XORL AX, AX											
  members_string.go:4098	0x75cf7f		31db			XORL BX, BX											
  members_string.go:4098	0x75cf81		31c9			XORL CX, CX											
  members_string.go:4098	0x75cf83		31ff			XORL DI, DI											
  members_string.go:4098	0x75cf85		89de			MOVL BX, SI											
  members_string.go:4098	0x75cf87		4189c8			MOVL CX, R8											
  members_string.go:4098	0x75cf8a		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4098	0x75cf91		5d			POPQ BP												
  members_string.go:4098	0x75cf92		c3			RET												
  members_string.go:4093	0x75cf93		31c0			XORL AX, AX											
  members_string.go:4093	0x75cf95		31db			XORL BX, BX											
  members_string.go:4093	0x75cf97		31c9			XORL CX, CX											
  members_string.go:4093	0x75cf99		4989f0			MOVQ SI, R8											
  members_string.go:4093	0x75cf9c		4889fe			MOVQ DI, SI											
  members_string.go:4093	0x75cf9f		31ff			XORL DI, DI											
  members_string.go:4093	0x75cfa1		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4093	0x75cfa8		5d			POPQ BP												
  members_string.go:4093	0x75cfa9		c3			RET												
  aliases.go:1367		0x75cfaa		4c8d1d3fe03b00		LEAQ 0x3be03f(IP), R11										
  aliases.go:1367		0x75cfb1		4c39de			CMPQ SI, R11											
  aliases.go:1367		0x75cfb4		740a			JE 0x75cfc0											
  aliases.go:1367		0x75cfb6		4531c0			XORL R8, R8											
  aliases.go:1367		0x75cfb9		0f1f8000000000		NOPL 0(AX)											
  members_string.go:4104	0x75cfc0		4d85c0			TESTQ R8, R8											
  members_string.go:4104	0x75cfc3		0f841d010000		JE 0x75d0e6											
  members_string.go:4108	0x75cfc9		4c8b9c24f8000000	MOVQ 0xf8(SP), R11										
  members_string.go:4108	0x75cfd1		4c891c24		MOVQ R11, 0(SP)											
  members_string.go:4108	0x75cfd5		4c8b9c2400010000	MOVQ 0x100(SP), R11										
  members_string.go:4108	0x75cfdd		4c895c2408		MOVQ R11, 0x8(SP)										
  members_string.go:4108	0x75cfe2		4c8b9c2430010000	MOVQ 0x130(SP), R11										
  members_string.go:4108	0x75cfea		4c895c2410		MOVQ R11, 0x10(SP)										
  members_string.go:4108	0x75cfef		4c8b9c2408010000	MOVQ 0x108(SP), R11										
  members_string.go:4108	0x75cff7		4c895c2418		MOVQ R11, 0x18(SP)										
  members_string.go:4108	0x75cffc		4c8b9c24c0010000	MOVQ 0x1c0(SP), R11										
  members_string.go:4108	0x75d004		4c895c2420		MOVQ R11, 0x20(SP)										
  members_string.go:4108	0x75d009		4c8b9c24c8010000	MOVQ 0x1c8(SP), R11										
  members_string.go:4108	0x75d011		4c895c2428		MOVQ R11, 0x28(SP)										
  members_string.go:4108	0x75d016		4c8b9c24d0010000	MOVQ 0x1d0(SP), R11										
  members_string.go:4108	0x75d01e		4c895c2430		MOVQ R11, 0x30(SP)										
  members_string.go:4108	0x75d023		488b842498010000	MOVQ 0x198(SP), AX										
  members_string.go:4108	0x75d02b		4889d3			MOVQ DX, BX											
  members_string.go:4108	0x75d02e		488b8c2480010000	MOVQ 0x180(SP), CX										
  members_string.go:4108	0x75d036		488bbc2488010000	MOVQ 0x188(SP), DI										
  members_string.go:4108	0x75d03e		488bb42490010000	MOVQ 0x190(SP), SI										
  members_string.go:4108	0x75d046		4c8d05fb690500		LEAQ 0x569fb(IP), R8										
  members_string.go:4108	0x75d04d		41b90c000000		MOVL $0xc, R9											
  members_string.go:4108	0x75d053		4c8b9424d8010000	MOVQ 0x1d8(SP), R10										
  members_string.go:4108	0x75d05b		0f1f440000		NOPL 0(AX)(AX*1)										
  members_string.go:4108	0x75d060		e87b57f1ff		CALL github.com/mgomes/vibescript/internal/runtime.newBlockCallRunner(SB)			
  members_string.go:4109	0x75d065		4885db			TESTQ BX, BX											
  members_string.go:4109	0x75d068		7417			JE 0x75d081											
  members_string.go:4110	0x75d06a		31c0			XORL AX, AX											
  members_string.go:4110	0x75d06c		31ff			XORL DI, DI											
  members_string.go:4110	0x75d06e		4889de			MOVQ BX, SI											
  members_string.go:4110	0x75d071		4989c8			MOVQ CX, R8											
  members_string.go:4110	0x75d074		31db			XORL BX, BX											
  members_string.go:4110	0x75d076		31c9			XORL CX, CX											
  members_string.go:4110	0x75d078		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4110	0x75d07f		5d			POPQ BP												
  members_string.go:4110	0x75d080		c3			RET												
  members_string.go:4112	0x75d081		488b9424f0000000	MOVQ 0xf0(SP), DX										
  members_string.go:4112	0x75d089		4889942438010000	MOVQ DX, 0x138(SP)										
  members_string.go:4112	0x75d091		488b9424e8000000	MOVQ 0xe8(SP), DX										
  members_string.go:4112	0x75d099		4889942440010000	MOVQ DX, 0x140(SP)										
  members_string.go:4112	0x75d0a1		488b9424e0000000	MOVQ 0xe0(SP), DX										
  members_string.go:4112	0x75d0a9		4889942450010000	MOVQ DX, 0x150(SP)										
  members_string.go:4112	0x75d0b1		488b942428010000	MOVQ 0x128(SP), DX										
  members_string.go:4112	0x75d0b9		4889942448010000	MOVQ DX, 0x148(SP)										
  eval.go:1785			0x75d0c1		488d9c2438010000	LEAQ 0x138(SP), BX										
  eval.go:1785			0x75d0c9		b901000000		MOVL $0x1, CX											
  eval.go:1785			0x75d0ce		89cf			MOVL CX, DI											
  eval.go:1785			0x75d0d0		31f6			XORL SI, SI											
  eval.go:1785			0x75d0d2		4531c0			XORL R8, R8											
  eval.go:1785			0x75d0d5		4589c1			MOVL R8, R9											
  eval.go:1785			0x75d0d8		e8435cf1ff		CALL github.com/mgomes/vibescript/internal/runtime.(*blockCallRunner).callWithChargedRoots(SB)	
  members_string.go:4112	0x75d0dd		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4112	0x75d0e4		5d			POPQ BP												
  members_string.go:4112	0x75d0e5		c3			RET												
  members_string.go:4114	0x75d0e6		31f6			XORL SI, SI											
  members_string.go:4114	0x75d0e8		4531c0			XORL R8, R8											
  members_string.go:4114	0x75d0eb		4881c468010000		ADDQ $0x168, SP											
  members_string.go:4114	0x75d0f2		5d			POPQ BP												
  members_string.go:4114	0x75d0f3		c3			RET												
  aliases.go:1367		0x75d0f4		4c89de			MOVQ R11, SI											
  aliases.go:1367		0x75d0f7		4c8b842488010000	MOVQ 0x188(SP), R8										
  aliases.go:1367		0x75d0ff		90			NOPL												
  aliases.go:1367		0x75d100		e9a5feffff		JMP 0x75cfaa											
  value_accessors.go:183	0x75d105		4c89fe			MOVQ R15, SI											
  value_accessors.go:183	0x75d108		4d21ef			ANDQ R13, R15											
  value_accessors.go:183	0x75d10b		49c1e704		SHLQ $0x4, R15											
  value_accessors.go:183	0x75d10f		4f8b442708		MOVQ 0x8(R15)(R12*1), R8									
  value_accessors.go:183	0x75d114		4d39c3			CMPQ R11, R8											
  value_accessors.go:183	0x75d117		7450			JE 0x75d169											
  value_accessors.go:183	0x75d119		4c8d7e01		LEAQ 0x1(SI), R15										
  value_accessors.go:183	0x75d11d		0f1f00			NOPL 0(AX)											
  value_accessors.go:183	0x75d120		4d85c0			TESTQ R8, R8											
  value_accessors.go:183	0x75d123		75e0			JNE 0x75d105											
  value_accessors.go:183	0x75d125		488d05b4443f00		LEAQ github.com/mgomes/vibescript/internal/runtime..typeAssert.357(SB), AX			
  value_accessors.go:183	0x75d12c		4c89db			MOVQ R11, BX											
  value_accessors.go:183	0x75d12f		e88c00ccff		CALL runtime.typeAssert(SB)									
  members_string.go:4114	0x75d134		488b8c2428010000	MOVQ 0x128(SP), CX										
  members_string.go:4108	0x75d13c		488b942478010000	MOVQ 0x178(SP), DX										
  members_string.go:4114	0x75d144		488b9c24e8000000	MOVQ 0xe8(SP), BX										
  members_string.go:4108	0x75d14c		488bb42480010000	MOVQ 0x180(SP), SI										
  members_string.go:4114	0x75d154		488bbc24e0000000	MOVQ 0xe0(SP), DI										
  value_accessors.go:183	0x75d15c		4989c3			MOVQ AX, R11											
  members_string.go:4114	0x75d15f		488b8424f0000000	MOVQ 0xf0(SP), AX										
  value_accessors.go:183	0x75d167		eb8b			JMP 0x75d0f4											
  value_accessors.go:183	0x75d169		4f8b642710		MOVQ 0x10(R15)(R12*1), R12									
  members_string.go:4108	0x75d16e		4c89de			MOVQ R11, SI											
  value_accessors.go:183	0x75d171		4d89e3			MOVQ R12, R11											
  value_accessors.go:183	0x75d174		e97bffffff		JMP 0x75d0f4											
  utf8.go:449			0x75d179		48ffc2			INCQ DX												
  utf8.go:449			0x75d17c		0f1f4000		NOPL 0(AX)											
  utf8.go:448			0x75d180		4c39de			CMPQ SI, R11											
  utf8.go:448			0x75d183		7e43			JLE 0x75d1c8											
  utf8.go:448			0x75d185		460fb6241f		MOVZX 0(DI)(R11*1), R12										
  utf8.go:448			0x75d18a		4183fc7f		CMPL R12, $0x7f											
  utf8.go:448			0x75d18e		7f05			JG 0x75d195											
  utf8.go:448			0x75d190		49ffc3			INCQ R11											
  utf8.go:448			0x75d193		ebe4			JMP 0x75d179											
  utf8.go:448			0x75d195		48899424c0000000	MOVQ DX, 0xc0(SP)										
  utf8.go:448			0x75d19d		4889f8			MOVQ DI, AX											
  utf8.go:448			0x75d1a0		4889f3			MOVQ SI, BX											
  utf8.go:448			0x75d1a3		4c89d9			MOVQ R11, CX											
  utf8.go:448			0x75d1a6		e81500d2ff		CALL runtime.decoderune(SB)									
  utf8.go:449			0x75d1ab		488b9424c0000000	MOVQ 0xc0(SP), DX										
  utf8.go:448			0x75d1b3		488bb424c8000000	MOVQ 0xc8(SP), SI										
  utf8.go:448			0x75d1bb		488bbc2418010000	MOVQ 0x118(SP), DI										
  utf8.go:449			0x75d1c3		4989db			MOVQ BX, R11											
  utf8.go:448			0x75d1c6		ebb1			JMP 0x75d179											
  members_string.go:4086	0x75d1c8		4889d0			MOVQ DX, AX											
  members_string.go:4086	0x75d1cb		e9c8fbffff		JMP 0x75cd98											
  members_string.go:4047	0x75d1d0		4889442428		MOVQ AX, 0x28(SP)										
  members_string.go:4047	0x75d1d5		48895c2430		MOVQ BX, 0x30(SP)										
  members_string.go:4047	0x75d1da		48894c2438		MOVQ CX, 0x38(SP)										
  members_string.go:4047	0x75d1df		48897c2440		MOVQ DI, 0x40(SP)										
  members_string.go:4047	0x75d1e4		4889742448		MOVQ SI, 0x48(SP)										
  members_string.go:4047	0x75d1e9		4c89442450		MOVQ R8, 0x50(SP)										
  members_string.go:4047	0x75d1ee		4c894c2458		MOVQ R9, 0x58(SP)										
  members_string.go:4047	0x75d1f3		4c89542460		MOVQ R10, 0x60(SP)										
  members_string.go:4047	0x75d1f8		4c895c2468		MOVQ R11, 0x68(SP)										
  members_string.go:4047	0x75d1fd		0f1f00			NOPL 0(AX)											
  members_string.go:4047	0x75d200		e8fbf3d2ff		CALL runtime.morestack_noctxt.abi0(SB)								
  members_string.go:4047	0x75d205		488b442428		MOVQ 0x28(SP), AX										
  members_string.go:4047	0x75d20a		488b5c2430		MOVQ 0x30(SP), BX										
  members_string.go:4047	0x75d20f		488b4c2438		MOVQ 0x38(SP), CX										
  members_string.go:4047	0x75d214		488b7c2440		MOVQ 0x40(SP), DI										
  members_string.go:4047	0x75d219		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:4047	0x75d21e		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4047	0x75d223		4c8b4c2458		MOVQ 0x58(SP), R9										
  members_string.go:4047	0x75d228		4c8b542460		MOVQ 0x60(SP), R10										
  members_string.go:4047	0x75d22d		4c8b5c2468		MOVQ 0x68(SP), R11										
  members_string.go:4047	0x75d232		e949f7ffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func23(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func24(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4117	0x75d240		4c8d6424e8		LEAQ -0x18(SP), R12										
  members_string.go:4117	0x75d245		4d3b6610		CMPQ R12, 0x10(R14)										
  members_string.go:4117	0x75d249		0f8660030000		JBE 0x75d5af											
  members_string.go:4117	0x75d24f		55			PUSHQ BP											
  members_string.go:4117	0x75d250		4889e5			MOVQ SP, BP											
  members_string.go:4117	0x75d253		4881ec90000000		SUBQ $0x90, SP											
  members_string.go:4117	0x75d25a		48898c24d0000000	MOVQ CX, 0xd0(SP)										
  members_string.go:4117	0x75d262		4889bc24d8000000	MOVQ DI, 0xd8(SP)										
  members_string.go:4117	0x75d26a		4c898424e8000000	MOVQ R8, 0xe8(SP)										
  members_string.go:4118	0x75d272		4d85db			TESTQ R11, R11											
  members_string.go:4118	0x75d275		7405			JE 0x75d27c											
  members_string.go:4118	0x75d277		498b13			MOVQ 0(R11), DX											
  members_string.go:4118	0x75d27a		eb04			JMP 0x75d280											
  members_string.go:4118	0x75d27c		31d2			XORL DX, DX											
  members_string.go:4118	0x75d27e		6690			NOPW												
  members_string.go:4118	0x75d280		4885d2			TESTQ DX, DX											
  members_string.go:4118	0x75d283		0f8fbb020000		JG 0x75d544											
  members_string.go:4121	0x75d289		4d85c9			TESTQ R9, R9											
  members_string.go:4121	0x75d28c		7406			JE 0x75d294											
  members_string.go:4121	0x75d28e		4983f902		CMPQ R9, $0x2											
  members_string.go:4121	0x75d292		7e66			JLE 0x75d2fa											
  errors.go:26			0x75d294		488d0529af0600		LEAQ 0x6af29(IP), AX										
  errors.go:26			0x75d29b		bb33000000		MOVL $0x33, BX											
  errors.go:26			0x75d2a0		31c9			XORL CX, CX											
  errors.go:26			0x75d2a2		31ff			XORL DI, DI											
  errors.go:26			0x75d2a4		89fe			MOVL DI, SI											
  errors.go:26			0x75d2a6		e8b50bd8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75d2ab		4885c0			TESTQ AX, AX											
  errors.go:26			0x75d2ae		7533			JNE 0x75d2e3											
  errors.go:31			0x75d2b0		90			NOPL												
  errors.go:65			0x75d2b1		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75d2b6		488d1d23f73800		LEAQ 0x38f723(IP), BX										
  errors.go:65			0x75d2bd		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75d2c2		e89940ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75d2c7		48c7400833000000	MOVQ $0x33, 0x8(AX)										
  errors.go:65			0x75d2cf		488d15eeae0600		LEAQ 0x6aeee(IP), DX										
  errors.go:65			0x75d2d6		488910			MOVQ DX, 0(AX)											
  members_string.go:4122	0x75d2d9		4889c3			MOVQ AX, BX											
  members_string.go:4122	0x75d2dc		488d05add43b00		LEAQ 0x3bd4ad(IP), AX										
  members_string.go:4122	0x75d2e3		31c9			XORL CX, CX											
  members_string.go:4122	0x75d2e5		31ff			XORL DI, DI											
  members_string.go:4122	0x75d2e7		4889c6			MOVQ AX, SI											
  members_string.go:4122	0x75d2ea		4989d8			MOVQ BX, R8											
  members_string.go:4122	0x75d2ed		31c0			XORL AX, AX											
  members_string.go:4122	0x75d2ef		31db			XORL BX, BX											
  members_string.go:4122	0x75d2f1		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4122	0x75d2f8		5d			POPQ BP												
  members_string.go:4122	0x75d2f9		c3			RET												
  members_string.go:4118	0x75d2fa		4889742470		MOVQ SI, 0x70(SP)										
  members_string.go:4118	0x75d2ff		4889bc2488000000	MOVQ DI, 0x88(SP)										
  members_string.go:4118	0x75d307		4c898c24f0000000	MOVQ R9, 0xf0(SP)										
  members_string.go:4118	0x75d30f		4c898424e8000000	MOVQ R8, 0xe8(SP)										
  members_string.go:4118	0x75d317		48895c2468		MOVQ BX, 0x68(SP)										
  members_string.go:4118	0x75d31c		48894c2460		MOVQ CX, 0x60(SP)										
  members_string.go:4124	0x75d321		498b7808		MOVQ 0x8(R8), DI										
  members_string.go:4124	0x75d325		498b7010		MOVQ 0x10(R8), SI										
  members_string.go:4124	0x75d329		498b5018		MOVQ 0x18(R8), DX										
  members_string.go:4124	0x75d32d		498b08			MOVQ 0(R8), CX											
  members_string.go:4124	0x75d330		488d05f56d0500		LEAQ 0x56df5(IP), AX										
  members_string.go:4124	0x75d337		bb0d000000		MOVL $0xd, BX											
  members_string.go:4124	0x75d33c		4989d0			MOVQ DX, R8											
  members_string.go:4124	0x75d33f		90			NOPL												
  members_string.go:4124	0x75d340		e83b40fbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4124	0x75d345		4885ff			TESTQ DI, DI											
  members_string.go:4124	0x75d348		0f85df010000		JNE 0x75d52d											
  members_string.go:4121	0x75d34e		488b9424f0000000	MOVQ 0xf0(SP), DX										
  members_string.go:4121	0x75d356		4883fa02		CMPQ DX, $0x2											
  members_string.go:4128	0x75d35a		7409			JE 0x75d365											
  members_string.go:4128	0x75d35c		31c0			XORL AX, AX											
  members_string.go:4128	0x75d35e		6690			NOPW												
  members_string.go:4128	0x75d360		e993000000		JMP 0x75d3f8											
  members_string.go:4129	0x75d365		488b9424e8000000	MOVQ 0xe8(SP), DX										
  members_string.go:4129	0x75d36d		488b4220		MOVQ 0x20(DX), AX										
  members_string.go:4129	0x75d371		488b5a28		MOVQ 0x28(DX), BX										
  members_string.go:4129	0x75d375		488b4a30		MOVQ 0x30(DX), CX										
  members_string.go:4129	0x75d379		488b7a38		MOVQ 0x38(DX), DI										
  members_string.go:4129	0x75d37d		0f1f00			NOPL 0(AX)											
  members_string.go:4129	0x75d380		e85b79fdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)				
  members_string.go:4130	0x75d385		4885db			TESTQ BX, BX											
  members_string.go:4130	0x75d388		7505			JNE 0x75d38f											
  members_string.go:4130	0x75d38a		4885c0			TESTQ AX, AX											
  members_string.go:4130	0x75d38d		7d69			JGE 0x75d3f8											
  errors.go:26			0x75d38f		488d051da70600		LEAQ 0x6a71d(IP), AX										
  errors.go:26			0x75d396		bb31000000		MOVL $0x31, BX											
  errors.go:26			0x75d39b		31c9			XORL CX, CX											
  errors.go:26			0x75d39d		31ff			XORL DI, DI											
  errors.go:26			0x75d39f		89fe			MOVL DI, SI											
  errors.go:26			0x75d3a1		e8ba0ad8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75d3a6		4885c0			TESTQ AX, AX											
  errors.go:26			0x75d3a9		7536			JNE 0x75d3e1											
  errors.go:31			0x75d3ab		90			NOPL												
  errors.go:65			0x75d3ac		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75d3b1		488d1d28f63800		LEAQ 0x38f628(IP), BX										
  errors.go:65			0x75d3b8		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75d3bd		0f1f00			NOPL 0(AX)											
  errors.go:65			0x75d3c0		e89b3fccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75d3c5		48c7400831000000	MOVQ $0x31, 0x8(AX)										
  errors.go:65			0x75d3cd		488d15dfa60600		LEAQ 0x6a6df(IP), DX										
  errors.go:65			0x75d3d4		488910			MOVQ DX, 0(AX)											
  members_string.go:4131	0x75d3d7		4889c3			MOVQ AX, BX											
  members_string.go:4131	0x75d3da		488d05afd33b00		LEAQ 0x3bd3af(IP), AX										
  members_string.go:4131	0x75d3e1		31c9			XORL CX, CX											
  members_string.go:4131	0x75d3e3		31ff			XORL DI, DI											
  members_string.go:4131	0x75d3e5		4889c6			MOVQ AX, SI											
  members_string.go:4131	0x75d3e8		4989d8			MOVQ BX, R8											
  members_string.go:4131	0x75d3eb		31c0			XORL AX, AX											
  members_string.go:4131	0x75d3ed		31db			XORL BX, BX											
  members_string.go:4131	0x75d3ef		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4131	0x75d3f6		5d			POPQ BP												
  members_string.go:4131	0x75d3f7		c3			RET												
  members_string.go:4135	0x75d3f8		4889442458		MOVQ AX, 0x58(SP)										
  members_string.go:4135	0x75d3fd		488b9424e8000000	MOVQ 0xe8(SP), DX										
  members_string.go:4135	0x75d405		488b0a			MOVQ 0(DX), CX											
  members_string.go:4135	0x75d408		488b7a08		MOVQ 0x8(DX), DI										
  members_string.go:4135	0x75d40c		488b7210		MOVQ 0x10(DX), SI										
  members_string.go:4135	0x75d410		4c8b4218		MOVQ 0x18(DX), R8										
  members_string.go:4135	0x75d414		488d05116d0500		LEAQ 0x56d11(IP), AX										
  members_string.go:4135	0x75d41b		bb0d000000		MOVL $0xd, BX											
  members_string.go:4135	0x75d420		e85b3ffbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)			
  members_string.go:4136	0x75d425		4885ff			TESTQ DI, DI											
  members_string.go:4136	0x75d428		0f85e8000000		JNE 0x75d516											
  members_string.go:4135	0x75d42e		884c2447		MOVB CL, 0x47(SP)										
  members_string.go:4135	0x75d432		4889842480000000	MOVQ AX, 0x80(SP)										
  members_string.go:4135	0x75d43a		48895c2450		MOVQ BX, 0x50(SP)										
  members_string.go:4139	0x75d43f		488b442468		MOVQ 0x68(SP), AX										
  members_string.go:4139	0x75d444		488b5c2460		MOVQ 0x60(SP), BX										
  members_string.go:4139	0x75d449		488b8c2488000000	MOVQ 0x88(SP), CX										
  members_string.go:4139	0x75d451		488b7c2470		MOVQ 0x70(SP), DI										
  members_string.go:4139	0x75d456		e865eee4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)					
  members_string.go:4139	0x75d45b		4889442478		MOVQ AX, 0x78(SP)										
  members_string.go:4139	0x75d460		48895c2448		MOVQ BX, 0x48(SP)										
  members_string.go:4140	0x75d465		4889c1			MOVQ AX, CX											
  members_string.go:4140	0x75d468		4889df			MOVQ BX, DI											
  members_string.go:4140	0x75d46b		488bb42480000000	MOVQ 0x80(SP), SI										
  members_string.go:4140	0x75d473		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4140	0x75d478		440fb64c2447		MOVZX 0x47(SP), R9										
  members_string.go:4140	0x75d47e		488d05a76c0500		LEAQ 0x56ca7(IP), AX										
  members_string.go:4140	0x75d485		bb0d000000		MOVL $0xd, BX											
  members_string.go:4140	0x75d48a		e89157f7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)			
  members_string.go:4140	0x75d48f		4885c0			TESTQ AX, AX											
  members_string.go:4140	0x75d492		756b			JNE 0x75d4ff											
  members_string.go:2034	0x75d494		488b05a5504000		MOVQ github.com/mgomes/vibescript/internal/runtime.compiledRegexps(SB), AX			
  members_string.go:4143	0x75d49b		90			NOPL												
  members_string.go:2034	0x75d49c		488d1d896c0500		LEAQ 0x56c89(IP), BX										
  members_string.go:2034	0x75d4a3		b90d000000		MOVL $0xd, CX											
  members_string.go:2034	0x75d4a8		488b7c2478		MOVQ 0x78(SP), DI										
  members_string.go:2034	0x75d4ad		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:2034	0x75d4b2		4c8b842480000000	MOVQ 0x80(SP), R8										
  members_string.go:2034	0x75d4ba		4c8b4c2450		MOVQ 0x50(SP), R9										
  members_string.go:2034	0x75d4bf		4c8b542458		MOVQ 0x58(SP), R10										
  members_string.go:2034	0x75d4c4		e8b758f7ff		CALL github.com/mgomes/vibescript/internal/runtime.regexMatchFromRuneOffsetWithCache(SB)	
  members_string.go:4144	0x75d4c9		4885db			TESTQ BX, BX											
  members_string.go:4144	0x75d4cc		7417			JE 0x75d4e5											
  members_string.go:4145	0x75d4ce		31c0			XORL AX, AX											
  members_string.go:4145	0x75d4d0		31ff			XORL DI, DI											
  members_string.go:4145	0x75d4d2		4889de			MOVQ BX, SI											
  members_string.go:4145	0x75d4d5		4989c8			MOVQ CX, R8											
  members_string.go:4145	0x75d4d8		31db			XORL BX, BX											
  members_string.go:4145	0x75d4da		31c9			XORL CX, CX											
  members_string.go:4145	0x75d4dc		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4145	0x75d4e3		5d			POPQ BP												
  members_string.go:4145	0x75d4e4		c3			RET												
  members_string.go:4147	0x75d4e5		0fb6f8			MOVZX AL, DI											
  members_string.go:4147	0x75d4e8		b801000000		MOVL $0x1, AX											
  members_string.go:4147	0x75d4ed		31db			XORL BX, BX											
  members_string.go:4147	0x75d4ef		31c9			XORL CX, CX											
  members_string.go:4147	0x75d4f1		89de			MOVL BX, SI											
  members_string.go:4147	0x75d4f3		4189c8			MOVL CX, R8											
  members_string.go:4147	0x75d4f6		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4147	0x75d4fd		5d			POPQ BP												
  members_string.go:4147	0x75d4fe		c3			RET												
  members_string.go:4141	0x75d4ff		31c9			XORL CX, CX											
  members_string.go:4141	0x75d501		31ff			XORL DI, DI											
  members_string.go:4141	0x75d503		4889c6			MOVQ AX, SI											
  members_string.go:4141	0x75d506		4989d8			MOVQ BX, R8											
  members_string.go:4141	0x75d509		31c0			XORL AX, AX											
  members_string.go:4141	0x75d50b		31db			XORL BX, BX											
  members_string.go:4141	0x75d50d		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4141	0x75d514		5d			POPQ BP												
  members_string.go:4141	0x75d515		c3			RET												
  members_string.go:4137	0x75d516		31c0			XORL AX, AX											
  members_string.go:4137	0x75d518		31db			XORL BX, BX											
  members_string.go:4137	0x75d51a		31c9			XORL CX, CX											
  members_string.go:4137	0x75d51c		4989f0			MOVQ SI, R8											
  members_string.go:4137	0x75d51f		4889fe			MOVQ DI, SI											
  members_string.go:4137	0x75d522		31ff			XORL DI, DI											
  members_string.go:4137	0x75d524		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4137	0x75d52b		5d			POPQ BP												
  members_string.go:4137	0x75d52c		c3			RET												
  members_string.go:4125	0x75d52d		31c0			XORL AX, AX											
  members_string.go:4125	0x75d52f		31db			XORL BX, BX											
  members_string.go:4125	0x75d531		31c9			XORL CX, CX											
  members_string.go:4125	0x75d533		4989f0			MOVQ SI, R8											
  members_string.go:4125	0x75d536		4889fe			MOVQ DI, SI											
  members_string.go:4125	0x75d539		31ff			XORL DI, DI											
  members_string.go:4125	0x75d53b		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4125	0x75d542		5d			POPQ BP												
  members_string.go:4125	0x75d543		c3			RET												
  errors.go:26			0x75d544		488d05ef990600		LEAQ 0x699ef(IP), AX										
  errors.go:26			0x75d54b		bb2f000000		MOVL $0x2f, BX											
  errors.go:26			0x75d550		31c9			XORL CX, CX											
  errors.go:26			0x75d552		31ff			XORL DI, DI											
  errors.go:26			0x75d554		89fe			MOVL DI, SI											
  errors.go:26			0x75d556		e80509d8ff		CALL fmt.errorf(SB)										
  errors.go:26			0x75d55b		0f1f440000		NOPL 0(AX)(AX*1)										
  errors.go:26			0x75d560		4885c0			TESTQ AX, AX											
  errors.go:26			0x75d563		7533			JNE 0x75d598											
  errors.go:31			0x75d565		90			NOPL												
  errors.go:65			0x75d566		b810000000		MOVL $0x10, AX											
  errors.go:65			0x75d56b		488d1d6ef43800		LEAQ 0x38f46e(IP), BX										
  errors.go:65			0x75d572		b901000000		MOVL $0x1, CX											
  errors.go:65			0x75d577		e8e43dccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)							
  errors.go:65			0x75d57c		48c740082f000000	MOVQ $0x2f, 0x8(AX)										
  errors.go:65			0x75d584		488d15af990600		LEAQ 0x699af(IP), DX										
  errors.go:65			0x75d58b		488910			MOVQ DX, 0(AX)											
  members_string.go:4119	0x75d58e		4889c3			MOVQ AX, BX											
  members_string.go:4119	0x75d591		488d05f8d13b00		LEAQ 0x3bd1f8(IP), AX										
  members_string.go:4119	0x75d598		31c9			XORL CX, CX											
  members_string.go:4119	0x75d59a		31ff			XORL DI, DI											
  members_string.go:4119	0x75d59c		4889c6			MOVQ AX, SI											
  members_string.go:4119	0x75d59f		4989d8			MOVQ BX, R8											
  members_string.go:4119	0x75d5a2		31c0			XORL AX, AX											
  members_string.go:4119	0x75d5a4		31db			XORL BX, BX											
  members_string.go:4119	0x75d5a6		4881c490000000		ADDQ $0x90, SP											
  members_string.go:4119	0x75d5ad		5d			POPQ BP												
  members_string.go:4119	0x75d5ae		c3			RET												
  members_string.go:4117	0x75d5af		4889442428		MOVQ AX, 0x28(SP)										
  members_string.go:4117	0x75d5b4		48895c2430		MOVQ BX, 0x30(SP)										
  members_string.go:4117	0x75d5b9		48894c2438		MOVQ CX, 0x38(SP)										
  members_string.go:4117	0x75d5be		48897c2440		MOVQ DI, 0x40(SP)										
  members_string.go:4117	0x75d5c3		4889742448		MOVQ SI, 0x48(SP)										
  members_string.go:4117	0x75d5c8		4c89442450		MOVQ R8, 0x50(SP)										
  members_string.go:4117	0x75d5cd		4c894c2458		MOVQ R9, 0x58(SP)										
  members_string.go:4117	0x75d5d2		4c89542460		MOVQ R10, 0x60(SP)										
  members_string.go:4117	0x75d5d7		4c895c2468		MOVQ R11, 0x68(SP)										
  members_string.go:4117	0x75d5dc		0f1f4000		NOPL 0(AX)											
  members_string.go:4117	0x75d5e0		e81bf0d2ff		CALL runtime.morestack_noctxt.abi0(SB)								
  members_string.go:4117	0x75d5e5		488b442428		MOVQ 0x28(SP), AX										
  members_string.go:4117	0x75d5ea		488b5c2430		MOVQ 0x30(SP), BX										
  members_string.go:4117	0x75d5ef		488b4c2438		MOVQ 0x38(SP), CX										
  members_string.go:4117	0x75d5f4		488b7c2440		MOVQ 0x40(SP), DI										
  members_string.go:4117	0x75d5f9		488b742448		MOVQ 0x48(SP), SI										
  members_string.go:4117	0x75d5fe		4c8b442450		MOVQ 0x50(SP), R8										
  members_string.go:4117	0x75d603		4c8b4c2458		MOVQ 0x58(SP), R9										
  members_string.go:4117	0x75d608		4c8b542460		MOVQ 0x60(SP), R10										
  members_string.go:4117	0x75d60d		4c8b5c2468		MOVQ 0x68(SP), R11										
  members_string.go:4117	0x75d612		e929fcffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func24(SB)			

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func25(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4150	0x75d620		4c8d642490		LEAQ -0x70(SP), R12								
  members_string.go:4150	0x75d625		4d3b6610		CMPQ R12, 0x10(R14)								
  members_string.go:4150	0x75d629		0f86a9030000		JBE 0x75d9d8									
  members_string.go:4150	0x75d62f		55			PUSHQ BP									
  members_string.go:4150	0x75d630		4889e5			MOVQ SP, BP									
  members_string.go:4150	0x75d633		4881ece8000000		SUBQ $0xe8, SP									
  members_string.go:4150	0x75d63a		48898c2428010000	MOVQ CX, 0x128(SP)								
  members_string.go:4150	0x75d642		4889bc2430010000	MOVQ DI, 0x130(SP)								
  members_string.go:4150	0x75d64a		4c89842440010000	MOVQ R8, 0x140(SP)								
  members_string.go:4151	0x75d652		4d85db			TESTQ R11, R11									
  members_string.go:4151	0x75d655		7405			JE 0x75d65c									
  members_string.go:4151	0x75d657		498b13			MOVQ 0(R11), DX									
  members_string.go:4151	0x75d65a		eb04			JMP 0x75d660									
  members_string.go:4151	0x75d65c		31d2			XORL DX, DX									
  members_string.go:4151	0x75d65e		6690			NOPW										
  members_string.go:4151	0x75d660		4885d2			TESTQ DX, DX									
  members_string.go:4151	0x75d663		0f8f09030000		JG 0x75d972									
  members_string.go:4154	0x75d669		4983f901		CMPQ R9, $0x1									
  members_string.go:4154	0x75d66d		7469			JE 0x75d6d8									
  errors.go:26			0x75d66f		488d05184d0600		LEAQ 0x64d18(IP), AX								
  errors.go:26			0x75d676		bb27000000		MOVL $0x27, BX									
  errors.go:26			0x75d67b		31c9			XORL CX, CX									
  errors.go:26			0x75d67d		31ff			XORL DI, DI									
  errors.go:26			0x75d67f		89fe			MOVL DI, SI									
  errors.go:26			0x75d681		e8da07d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75d686		4885c0			TESTQ AX, AX									
  errors.go:26			0x75d689		7536			JNE 0x75d6c1									
  errors.go:31			0x75d68b		90			NOPL										
  errors.go:65			0x75d68c		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75d691		488d1d48f33800		LEAQ 0x38f348(IP), BX								
  errors.go:65			0x75d698		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75d69d		0f1f00			NOPL 0(AX)									
  errors.go:65			0x75d6a0		e8bb3cccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75d6a5		48c7400827000000	MOVQ $0x27, 0x8(AX)								
  errors.go:65			0x75d6ad		488d15da4c0600		LEAQ 0x64cda(IP), DX								
  errors.go:65			0x75d6b4		488910			MOVQ DX, 0(AX)									
  members_string.go:4155	0x75d6b7		4889c3			MOVQ AX, BX									
  members_string.go:4155	0x75d6ba		488d05cfd03b00		LEAQ 0x3bd0cf(IP), AX								
  members_string.go:4155	0x75d6c1		31c9			XORL CX, CX									
  members_string.go:4155	0x75d6c3		31ff			XORL DI, DI									
  members_string.go:4155	0x75d6c5		4889c6			MOVQ AX, SI									
  members_string.go:4155	0x75d6c8		4989d8			MOVQ BX, R8									
  members_string.go:4155	0x75d6cb		31c0			XORL AX, AX									
  members_string.go:4155	0x75d6cd		31db			XORL BX, BX									
  members_string.go:4155	0x75d6cf		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4155	0x75d6d6		5d			POPQ BP										
  members_string.go:4155	0x75d6d7		c3			RET										
  members_string.go:4151	0x75d6d8		4889842418010000	MOVQ AX, 0x118(SP)								
  members_string.go:4151	0x75d6e0		4c899c2458010000	MOVQ R11, 0x158(SP)								
  members_string.go:4151	0x75d6e8		4c89842440010000	MOVQ R8, 0x140(SP)								
  members_string.go:4151	0x75d6f0		4889b424b8000000	MOVQ SI, 0xb8(SP)								
  members_string.go:4151	0x75d6f8		48899c24b0000000	MOVQ BX, 0xb0(SP)								
  members_string.go:4151	0x75d700		4889bc24e0000000	MOVQ DI, 0xe0(SP)								
  members_string.go:4151	0x75d708		48898c24a8000000	MOVQ CX, 0xa8(SP)								
  members_string.go:4151	0x75d710		4c898c2448010000	MOVQ R9, 0x148(SP)								
  members_string.go:4151	0x75d718		4c89942450010000	MOVQ R10, 0x150(SP)								
  members_string.go:4157	0x75d720		498b08			MOVQ 0(R8), CX									
  members_string.go:4157	0x75d723		498b7808		MOVQ 0x8(R8), DI								
  members_string.go:4157	0x75d727		498b7010		MOVQ 0x10(R8), SI								
  members_string.go:4157	0x75d72b		4d8b4018		MOVQ 0x18(R8), R8								
  members_string.go:4157	0x75d72f		488d05f45b0500		LEAQ 0x55bf4(IP), AX								
  members_string.go:4157	0x75d736		bb0b000000		MOVL $0xb, BX									
  members_string.go:4157	0x75d73b		0f1f440000		NOPL 0(AX)(AX*1)								
  members_string.go:4157	0x75d740		e83b3cfbff		CALL github.com/mgomes/vibescript/internal/runtime.stringPatternArgument(SB)	
  members_string.go:4158	0x75d745		4885ff			TESTQ DI, DI									
  members_string.go:4158	0x75d748		0f850d020000		JNE 0x75d95b									
  members_string.go:4157	0x75d74e		888c2497000000		MOVB CL, 0x97(SP)								
  members_string.go:4157	0x75d755		48898424c8000000	MOVQ AX, 0xc8(SP)								
  members_string.go:4157	0x75d75d		48899c24a0000000	MOVQ BX, 0xa0(SP)								
  members_string.go:4161	0x75d765		488b8424b0000000	MOVQ 0xb0(SP), AX								
  members_string.go:4161	0x75d76d		488b9c24a8000000	MOVQ 0xa8(SP), BX								
  members_string.go:4161	0x75d775		488b8c24e0000000	MOVQ 0xe0(SP), CX								
  members_string.go:4161	0x75d77d		488bbc24b8000000	MOVQ 0xb8(SP), DI								
  members_string.go:4161	0x75d785		e836ebe4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4161	0x75d78a		48898424c0000000	MOVQ AX, 0xc0(SP)								
  members_string.go:4161	0x75d792		48899c2498000000	MOVQ BX, 0x98(SP)								
  members_string.go:4162	0x75d79a		4889c1			MOVQ AX, CX									
  members_string.go:4162	0x75d79d		4889df			MOVQ BX, DI									
  members_string.go:4162	0x75d7a0		488bb424c8000000	MOVQ 0xc8(SP), SI								
  members_string.go:4162	0x75d7a8		4c8b8424a0000000	MOVQ 0xa0(SP), R8								
  members_string.go:4162	0x75d7b0		440fb68c2497000000	MOVZX 0x97(SP), R9								
  members_string.go:4162	0x75d7b9		488d056a5b0500		LEAQ 0x55b6a(IP), AX								
  members_string.go:4162	0x75d7c0		bb0b000000		MOVL $0xb, BX									
  members_string.go:4162	0x75d7c5		e85654f7ff		CALL github.com/mgomes/vibescript/internal/runtime.validateRegexTextPattern(SB)	
  members_string.go:4162	0x75d7ca		4885c0			TESTQ AX, AX									
  members_string.go:4162	0x75d7cd		0f8571010000		JNE 0x75d944									
  members_string.go:4165	0x75d7d3		488b8424c8000000	MOVQ 0xc8(SP), AX								
  members_string.go:4165	0x75d7db		488b9c24a0000000	MOVQ 0xa0(SP), BX								
  members_string.go:4165	0x75d7e3		e858cbfaff		CALL github.com/mgomes/vibescript/internal/runtime.compileCachedRegex(SB)	
  members_string.go:4166	0x75d7e8		4885db			TESTQ BX, BX									
  members_string.go:4166	0x75d7eb		0f848e000000		JE 0x75d87f									
  members_string.go:4167	0x75d7f1		440f11bc24d0000000	MOVUPS X15, 0xd0(SP)								
  members_string.go:4167	0x75d7fa		7404			JE 0x75d800									
  members_string.go:4167	0x75d7fc		488b5b08		MOVQ 0x8(BX), BX								
  members_string.go:4167	0x75d800		48899c24d0000000	MOVQ BX, 0xd0(SP)								
  members_string.go:4167	0x75d808		48898c24d8000000	MOVQ CX, 0xd8(SP)								
  errors.go:26			0x75d810		488d05eadc0500		LEAQ 0x5dcea(IP), AX								
  errors.go:26			0x75d817		bb1d000000		MOVL $0x1d, BX									
  errors.go:26			0x75d81c		488d8c24d0000000	LEAQ 0xd0(SP), CX								
  errors.go:26			0x75d824		bf01000000		MOVL $0x1, DI									
  errors.go:26			0x75d829		89fe			MOVL DI, SI									
  errors.go:26			0x75d82b		e83006d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75d830		4885c0			TESTQ AX, AX									
  errors.go:26			0x75d833		7533			JNE 0x75d868									
  errors.go:31			0x75d835		90			NOPL										
  errors.go:65			0x75d836		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75d83b		488d1d9ef13800		LEAQ 0x38f19e(IP), BX								
  errors.go:65			0x75d842		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75d847		e8143bccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75d84c		48c740081d000000	MOVQ $0x1d, 0x8(AX)								
  errors.go:65			0x75d854		488d15a6dc0500		LEAQ 0x5dca6(IP), DX								
  errors.go:65			0x75d85b		488910			MOVQ DX, 0(AX)									
  members_string.go:4167	0x75d85e		4889c3			MOVQ AX, BX									
  members_string.go:4167	0x75d861		488d0528cf3b00		LEAQ 0x3bcf28(IP), AX								
  members_string.go:4167	0x75d868		31c9			XORL CX, CX									
  members_string.go:4167	0x75d86a		31ff			XORL DI, DI									
  members_string.go:4167	0x75d86c		4889c6			MOVQ AX, SI									
  members_string.go:4167	0x75d86f		4989d8			MOVQ BX, R8									
  members_string.go:4167	0x75d872		31c0			XORL AX, AX									
  members_string.go:4167	0x75d874		31db			XORL BX, BX									
  members_string.go:4167	0x75d876		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4167	0x75d87d		5d			POPQ BP										
  members_string.go:4167	0x75d87e		c3			RET										
  members_string.go:4169	0x75d87f		488b9424b0000000	MOVQ 0xb0(SP), DX								
  members_string.go:4169	0x75d887		48891424		MOVQ DX, 0(SP)									
  members_string.go:4169	0x75d88b		488b9424a8000000	MOVQ 0xa8(SP), DX								
  members_string.go:4169	0x75d893		4889542408		MOVQ DX, 0x8(SP)								
  members_string.go:4169	0x75d898		488b9424e0000000	MOVQ 0xe0(SP), DX								
  members_string.go:4169	0x75d8a0		4889542410		MOVQ DX, 0x10(SP)								
  members_string.go:4169	0x75d8a5		488b9424b8000000	MOVQ 0xb8(SP), DX								
  members_string.go:4169	0x75d8ad		4889542418		MOVQ DX, 0x18(SP)								
  members_string.go:4169	0x75d8b2		488b942458010000	MOVQ 0x158(SP), DX								
  members_string.go:4169	0x75d8ba		4889542420		MOVQ DX, 0x20(SP)								
  members_string.go:4169	0x75d8bf		488b9424f8000000	MOVQ 0xf8(SP), DX								
  members_string.go:4169	0x75d8c7		4889542428		MOVQ DX, 0x28(SP)								
  members_string.go:4169	0x75d8cc		488b942400010000	MOVQ 0x100(SP), DX								
  members_string.go:4169	0x75d8d4		4889542430		MOVQ DX, 0x30(SP)								
  members_string.go:4169	0x75d8d9		488b942408010000	MOVQ 0x108(SP), DX								
  members_string.go:4169	0x75d8e1		4889542438		MOVQ DX, 0x38(SP)								
  members_string.go:4169	0x75d8e6		488b942410010000	MOVQ 0x110(SP), DX								
  members_string.go:4169	0x75d8ee		4889542440		MOVQ DX, 0x40(SP)								
  members_string.go:4169	0x75d8f3		4889c3			MOVQ AX, BX									
  members_string.go:4169	0x75d8f6		488b8c24c8000000	MOVQ 0xc8(SP), CX								
  members_string.go:4169	0x75d8fe		488bbc24a0000000	MOVQ 0xa0(SP), DI								
  members_string.go:4169	0x75d906		488bb424c0000000	MOVQ 0xc0(SP), SI								
  members_string.go:4169	0x75d90e		4c8b842498000000	MOVQ 0x98(SP), R8								
  members_string.go:4169	0x75d916		4c8b8c2440010000	MOVQ 0x140(SP), R9								
  members_string.go:4169	0x75d91e		4c8b942448010000	MOVQ 0x148(SP), R10								
  members_string.go:4169	0x75d926		4c8b9c2450010000	MOVQ 0x150(SP), R11								
  members_string.go:4169	0x75d92e		488b842418010000	MOVQ 0x118(SP), AX								
  members_string.go:4169	0x75d936		e8250cf8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringScan(SB)		
  members_string.go:4169	0x75d93b		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4169	0x75d942		5d			POPQ BP										
  members_string.go:4169	0x75d943		c3			RET										
  members_string.go:4163	0x75d944		31c9			XORL CX, CX									
  members_string.go:4163	0x75d946		31ff			XORL DI, DI									
  members_string.go:4163	0x75d948		4889c6			MOVQ AX, SI									
  members_string.go:4163	0x75d94b		4989d8			MOVQ BX, R8									
  members_string.go:4163	0x75d94e		31c0			XORL AX, AX									
  members_string.go:4163	0x75d950		31db			XORL BX, BX									
  members_string.go:4163	0x75d952		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4163	0x75d959		5d			POPQ BP										
  members_string.go:4163	0x75d95a		c3			RET										
  members_string.go:4159	0x75d95b		31c0			XORL AX, AX									
  members_string.go:4159	0x75d95d		31db			XORL BX, BX									
  members_string.go:4159	0x75d95f		31c9			XORL CX, CX									
  members_string.go:4159	0x75d961		4989f0			MOVQ SI, R8									
  members_string.go:4159	0x75d964		4889fe			MOVQ DI, SI									
  members_string.go:4159	0x75d967		31ff			XORL DI, DI									
  members_string.go:4159	0x75d969		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4159	0x75d970		5d			POPQ BP										
  members_string.go:4159	0x75d971		c3			RET										
  errors.go:26			0x75d972		488d05e6850600		LEAQ 0x685e6(IP), AX								
  errors.go:26			0x75d979		bb2d000000		MOVL $0x2d, BX									
  errors.go:26			0x75d97e		31c9			XORL CX, CX									
  errors.go:26			0x75d980		31ff			XORL DI, DI									
  errors.go:26			0x75d982		89fe			MOVL DI, SI									
  errors.go:26			0x75d984		e8d704d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75d989		4885c0			TESTQ AX, AX									
  errors.go:26			0x75d98c		7533			JNE 0x75d9c1									
  errors.go:31			0x75d98e		90			NOPL										
  errors.go:65			0x75d98f		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75d994		488d1d45f03800		LEAQ 0x38f045(IP), BX								
  errors.go:65			0x75d99b		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75d9a0		e8bb39ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75d9a5		48c740082d000000	MOVQ $0x2d, 0x8(AX)								
  errors.go:65			0x75d9ad		488d15ab850600		LEAQ 0x685ab(IP), DX								
  errors.go:65			0x75d9b4		488910			MOVQ DX, 0(AX)									
  members_string.go:4152	0x75d9b7		4889c3			MOVQ AX, BX									
  members_string.go:4152	0x75d9ba		488d05cfcd3b00		LEAQ 0x3bcdcf(IP), AX								
  members_string.go:4152	0x75d9c1		31c9			XORL CX, CX									
  members_string.go:4152	0x75d9c3		31ff			XORL DI, DI									
  members_string.go:4152	0x75d9c5		4889c6			MOVQ AX, SI									
  members_string.go:4152	0x75d9c8		4989d8			MOVQ BX, R8									
  members_string.go:4152	0x75d9cb		31c0			XORL AX, AX									
  members_string.go:4152	0x75d9cd		31db			XORL BX, BX									
  members_string.go:4152	0x75d9cf		4881c4e8000000		ADDQ $0xe8, SP									
  members_string.go:4152	0x75d9d6		5d			POPQ BP										
  members_string.go:4152	0x75d9d7		c3			RET										
  members_string.go:4150	0x75d9d8		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4150	0x75d9dd		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4150	0x75d9e2		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4150	0x75d9e7		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4150	0x75d9ec		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4150	0x75d9f1		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4150	0x75d9f6		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4150	0x75d9fb		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4150	0x75da00		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4150	0x75da05		e8f6ebd2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4150	0x75da0a		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4150	0x75da0f		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4150	0x75da14		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4150	0x75da19		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4150	0x75da1e		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4150	0x75da23		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4150	0x75da28		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4150	0x75da2d		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4150	0x75da32		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4150	0x75da37		e9e4fbffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func25(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func26(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4172	0x75da40		493b6610		CMPQ SP, 0x10(R14)								
  members_string.go:4172	0x75da44		0f867a010000		JBE 0x75dbc4									
  members_string.go:4172	0x75da4a		55			PUSHQ BP									
  members_string.go:4172	0x75da4b		4889e5			MOVQ SP, BP									
  members_string.go:4172	0x75da4e		4883ec70		SUBQ $0x70, SP									
  members_string.go:4172	0x75da52		48898c24b0000000	MOVQ CX, 0xb0(SP)								
  members_string.go:4172	0x75da5a		4889bc24b8000000	MOVQ DI, 0xb8(SP)								
  members_string.go:4172	0x75da62		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4173	0x75da6a		4d85c9			TESTQ R9, R9									
  members_string.go:4173	0x75da6d		7406			JE 0x75da75									
  members_string.go:4173	0x75da6f		4983f902		CMPQ R9, $0x2									
  members_string.go:4173	0x75da73		7e63			JLE 0x75dad8									
  errors.go:26			0x75da75		488d054da40600		LEAQ 0x6a44d(IP), AX								
  errors.go:26			0x75da7c		bb32000000		MOVL $0x32, BX									
  errors.go:26			0x75da81		31c9			XORL CX, CX									
  errors.go:26			0x75da83		31ff			XORL DI, DI									
  errors.go:26			0x75da85		89fe			MOVL DI, SI									
  errors.go:26			0x75da87		e8d403d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75da8c		4885c0			TESTQ AX, AX									
  errors.go:26			0x75da8f		7533			JNE 0x75dac4									
  errors.go:31			0x75da91		90			NOPL										
  errors.go:65			0x75da92		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75da97		488d1d42ef3800		LEAQ 0x38ef42(IP), BX								
  errors.go:65			0x75da9e		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75daa3		e8b838ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75daa8		48c7400832000000	MOVQ $0x32, 0x8(AX)								
  errors.go:65			0x75dab0		488d1512a40600		LEAQ 0x6a412(IP), DX								
  errors.go:65			0x75dab7		488910			MOVQ DX, 0(AX)									
  members_string.go:4174	0x75daba		4889c3			MOVQ AX, BX									
  members_string.go:4174	0x75dabd		488d05cccc3b00		LEAQ 0x3bcccc(IP), AX								
  members_string.go:4174	0x75dac4		31c9			XORL CX, CX									
  members_string.go:4174	0x75dac6		31ff			XORL DI, DI									
  members_string.go:4174	0x75dac8		4889c6			MOVQ AX, SI									
  members_string.go:4174	0x75dacb		4989d8			MOVQ BX, R8									
  members_string.go:4174	0x75dace		31c0			XORL AX, AX									
  members_string.go:4174	0x75dad0		31db			XORL BX, BX									
  members_string.go:4174	0x75dad2		4883c470		ADDQ $0x70, SP									
  members_string.go:4174	0x75dad6		5d			POPQ BP										
  members_string.go:4174	0x75dad7		c3			RET										
  members_string.go:4177	0x75dad8		7404			JE 0x75dade									
  members_string.go:4177	0x75dada		31d2			XORL DX, DX									
  members_string.go:4177	0x75dadc		eb65			JMP 0x75db43									
  members_string.go:4173	0x75dade		48898424a0000000	MOVQ AX, 0xa0(SP)								
  members_string.go:4173	0x75dae6		48895c2460		MOVQ BX, 0x60(SP)								
  members_string.go:4173	0x75daeb		4889742458		MOVQ SI, 0x58(SP)								
  members_string.go:4173	0x75daf0		48894c2450		MOVQ CX, 0x50(SP)								
  members_string.go:4173	0x75daf5		4c898424c8000000	MOVQ R8, 0xc8(SP)								
  members_string.go:4173	0x75dafd		48897c2468		MOVQ DI, 0x68(SP)								
  members_string.go:4178	0x75db02		498b4020		MOVQ 0x20(R8), AX								
  members_string.go:4178	0x75db06		498b5828		MOVQ 0x28(R8), BX								
  members_string.go:4178	0x75db0a		498b4830		MOVQ 0x30(R8), CX								
  members_string.go:4178	0x75db0e		498b7838		MOVQ 0x38(R8), DI								
  members_string.go:4178	0x75db12		e8c971fdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)		
  members_string.go:4179	0x75db17		4885db			TESTQ BX, BX									
  members_string.go:4179	0x75db1a		7545			JNE 0x75db61									
  members_string.go:4184	0x75db1c		488b4c2450		MOVQ 0x50(SP), CX								
  members_string.go:4184	0x75db21		488b5c2460		MOVQ 0x60(SP), BX								
  members_string.go:4184	0x75db26		488b742458		MOVQ 0x58(SP), SI								
  members_string.go:4184	0x75db2b		488b7c2468		MOVQ 0x68(SP), DI								
  members_string.go:4184	0x75db30		4c8b8424c8000000	MOVQ 0xc8(SP), R8								
  members_string.go:4184	0x75db38		4889c2			MOVQ AX, DX									
  members_string.go:4184	0x75db3b		488b8424a0000000	MOVQ 0xa0(SP), AX								
  members_string.go:4184	0x75db43		4d8b4808		MOVQ 0x8(R8), R9								
  members_string.go:4184	0x75db47		4d8b5010		MOVQ 0x10(R8), R10								
  members_string.go:4184	0x75db4b		4d8b5818		MOVQ 0x18(R8), R11								
  members_string.go:4184	0x75db4f		4d8b00			MOVQ 0(R8), R8									
  members_string.go:4184	0x75db52		48891424		MOVQ DX, 0(SP)									
  members_string.go:4184	0x75db56		e8e505f8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringIndexResult(SB)	
  members_string.go:4184	0x75db5b		4883c470		ADDQ $0x70, SP									
  members_string.go:4184	0x75db5f		5d			POPQ BP										
  members_string.go:4184	0x75db60		c3			RET										
  errors.go:26			0x75db61		488d0509160600		LEAQ 0x61609(IP), AX								
  errors.go:26			0x75db68		bb23000000		MOVL $0x23, BX									
  errors.go:26			0x75db6d		31c9			XORL CX, CX									
  errors.go:26			0x75db6f		31ff			XORL DI, DI									
  errors.go:26			0x75db71		89fe			MOVL DI, SI									
  errors.go:26			0x75db73		e8e802d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75db78		4885c0			TESTQ AX, AX									
  errors.go:26			0x75db7b		7533			JNE 0x75dbb0									
  errors.go:31			0x75db7d		90			NOPL										
  errors.go:65			0x75db7e		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75db83		488d1d56ee3800		LEAQ 0x38ee56(IP), BX								
  errors.go:65			0x75db8a		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75db8f		e8cc37ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75db94		48c7400823000000	MOVQ $0x23, 0x8(AX)								
  errors.go:65			0x75db9c		488d15ce150600		LEAQ 0x615ce(IP), DX								
  errors.go:65			0x75dba3		488910			MOVQ DX, 0(AX)									
  members_string.go:4180	0x75dba6		4889c3			MOVQ AX, BX									
  members_string.go:4180	0x75dba9		488d05e0cb3b00		LEAQ 0x3bcbe0(IP), AX								
  members_string.go:4180	0x75dbb0		31c9			XORL CX, CX									
  members_string.go:4180	0x75dbb2		31ff			XORL DI, DI									
  members_string.go:4180	0x75dbb4		4889c6			MOVQ AX, SI									
  members_string.go:4180	0x75dbb7		4989d8			MOVQ BX, R8									
  members_string.go:4180	0x75dbba		31c0			XORL AX, AX									
  members_string.go:4180	0x75dbbc		31db			XORL BX, BX									
  members_string.go:4180	0x75dbbe		4883c470		ADDQ $0x70, SP									
  members_string.go:4180	0x75dbc2		5d			POPQ BP										
  members_string.go:4180	0x75dbc3		c3			RET										
  members_string.go:4172	0x75dbc4		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4172	0x75dbc9		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4172	0x75dbce		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4172	0x75dbd3		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4172	0x75dbd8		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4172	0x75dbdd		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4172	0x75dbe2		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4172	0x75dbe7		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4172	0x75dbec		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4172	0x75dbf1		e80aead2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4172	0x75dbf6		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4172	0x75dbfb		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4172	0x75dc00		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4172	0x75dc05		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4172	0x75dc0a		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4172	0x75dc0f		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4172	0x75dc14		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4172	0x75dc19		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4172	0x75dc1e		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4172	0x75dc23		e918feffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func26(SB)	

TEXT github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func27(SB) /home/runner/work/vibescript/vibescript/ascii/internal/runtime/members_string.go
  members_string.go:4187	0x75dc40		4c8d6424e8		LEAQ -0x18(SP), R12								
  members_string.go:4187	0x75dc45		4d3b6610		CMPQ R12, 0x10(R14)								
  members_string.go:4187	0x75dc49		0f8688020000		JBE 0x75ded7									
  members_string.go:4187	0x75dc4f		55			PUSHQ BP									
  members_string.go:4187	0x75dc50		4889e5			MOVQ SP, BP									
  members_string.go:4187	0x75dc53		4881ec90000000		SUBQ $0x90, SP									
  members_string.go:4187	0x75dc5a		48898c24d0000000	MOVQ CX, 0xd0(SP)								
  members_string.go:4187	0x75dc62		4889bc24d8000000	MOVQ DI, 0xd8(SP)								
  members_string.go:4187	0x75dc6a		4c898424e8000000	MOVQ R8, 0xe8(SP)								
  members_string.go:4188	0x75dc72		4d85c9			TESTQ R9, R9									
  members_string.go:4188	0x75dc75		7406			JE 0x75dc7d									
  members_string.go:4188	0x75dc77		4983f902		CMPQ R9, $0x2									
  members_string.go:4188	0x75dc7b		7e66			JLE 0x75dce3									
  errors.go:26			0x75dc7d		488d0573a50600		LEAQ 0x6a573(IP), AX								
  errors.go:26			0x75dc84		bb33000000		MOVL $0x33, BX									
  errors.go:26			0x75dc89		31c9			XORL CX, CX									
  errors.go:26			0x75dc8b		31ff			XORL DI, DI									
  errors.go:26			0x75dc8d		89fe			MOVL DI, SI									
  errors.go:26			0x75dc8f		e8cc01d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75dc94		4885c0			TESTQ AX, AX									
  errors.go:26			0x75dc97		7533			JNE 0x75dccc									
  errors.go:31			0x75dc99		90			NOPL										
  errors.go:65			0x75dc9a		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75dc9f		488d1d3aed3800		LEAQ 0x38ed3a(IP), BX								
  errors.go:65			0x75dca6		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75dcab		e8b036ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75dcb0		48c7400833000000	MOVQ $0x33, 0x8(AX)								
  errors.go:65			0x75dcb8		488d1538a50600		LEAQ 0x6a538(IP), DX								
  errors.go:65			0x75dcbf		488910			MOVQ DX, 0(AX)									
  members_string.go:4189	0x75dcc2		4889c3			MOVQ AX, BX									
  members_string.go:4189	0x75dcc5		488d05c4ca3b00		LEAQ 0x3bcac4(IP), AX								
  members_string.go:4189	0x75dccc		31c9			XORL CX, CX									
  members_string.go:4189	0x75dcce		31ff			XORL DI, DI									
  members_string.go:4189	0x75dcd0		4889c6			MOVQ AX, SI									
  members_string.go:4189	0x75dcd3		4989d8			MOVQ BX, R8									
  members_string.go:4189	0x75dcd6		31c0			XORL AX, AX									
  members_string.go:4189	0x75dcd8		31db			XORL BX, BX									
  members_string.go:4189	0x75dcda		4881c490000000		ADDQ $0x90, SP									
  members_string.go:4189	0x75dce1		5d			POPQ BP										
  members_string.go:4189	0x75dce2		c3			RET										
  members_string.go:4188	0x75dce3		48898424c0000000	MOVQ AX, 0xc0(SP)								
  members_string.go:4188	0x75dceb		4889742478		MOVQ SI, 0x78(SP)								
  members_string.go:4188	0x75dcf0		48895c2470		MOVQ BX, 0x70(SP)								
  members_string.go:4188	0x75dcf5		48894c2468		MOVQ CX, 0x68(SP)								
  members_string.go:4188	0x75dcfa		4c898c24f0000000	MOVQ R9, 0xf0(SP)								
  members_string.go:4188	0x75dd02		4c898424e8000000	MOVQ R8, 0xe8(SP)								
  members_string.go:4188	0x75dd0a		4889bc2488000000	MOVQ DI, 0x88(SP)								
  members_string.go:4191	0x75dd12		4889d8			MOVQ BX, AX									
  members_string.go:4191	0x75dd15		4889cb			MOVQ CX, BX									
  members_string.go:4191	0x75dd18		4889f9			MOVQ DI, CX									
  members_string.go:4191	0x75dd1b		4889f7			MOVQ SI, DI									
  members_string.go:4191	0x75dd1e		6690			NOPW										
  members_string.go:4191	0x75dd20		e89be5e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4191	0x75dd25		4889842480000000	MOVQ AX, 0x80(SP)								
  members_string.go:4191	0x75dd2d		48895c2458		MOVQ BX, 0x58(SP)								
  ascii_scan_scalar_amd64.go:7	0x75dd32		e88942ebff		CALL github.com/mgomes/vibescript/internal/runtime.stringIsASCIIWords(SB)	
  ascii_scan_scalar_amd64.go:7	0x75dd37		84c0			TESTL AL, AL									
  members_string.go:1186	0x75dd39		7518			JNE 0x75dd53									
  members_string.go:1189	0x75dd3b		90			NOPL										
  utf8.go:448			0x75dd3c		31d2			XORL DX, DX									
  utf8.go:448			0x75dd3e		4531e4			XORL R12, R12									
  utf8.go:448			0x75dd41		488b5c2458		MOVQ 0x58(SP), BX								
  utf8.go:448			0x75dd46		488b842480000000	MOVQ 0x80(SP), AX								
  utf8.go:448			0x75dd4e		e937010000		JMP 0x75de8a									
  members_string.go:4188	0x75dd53		488b9424f0000000	MOVQ 0xf0(SP), DX								
  members_string.go:4188	0x75dd5b		4883fa02		CMPQ DX, $0x2									
  members_string.go:4191	0x75dd5f		488b442458		MOVQ 0x58(SP), AX								
  members_string.go:4192	0x75dd64		0f85bf000000		JNE 0x75de29									
  members_string.go:4193	0x75dd6a		488b9424e8000000	MOVQ 0xe8(SP), DX								
  members_string.go:4193	0x75dd72		488b5a28		MOVQ 0x28(DX), BX								
  members_string.go:4193	0x75dd76		488b4a30		MOVQ 0x30(DX), CX								
  members_string.go:4193	0x75dd7a		488b7a38		MOVQ 0x38(DX), DI								
  members_string.go:4193	0x75dd7e		488b4220		MOVQ 0x20(DX), AX								
  members_string.go:4193	0x75dd82		e8596ffdff		CALL github.com/mgomes/vibescript/internal/runtime.valueToInt(SB)		
  members_string.go:4194	0x75dd87		4885db			TESTQ BX, BX									
  members_string.go:4194	0x75dd8a		746c			JE 0x75ddf8									
  errors.go:26			0x75dd8c		488d0557210600		LEAQ 0x62157(IP), AX								
  errors.go:26			0x75dd93		bb24000000		MOVL $0x24, BX									
  errors.go:26			0x75dd98		31c9			XORL CX, CX									
  errors.go:26			0x75dd9a		31ff			XORL DI, DI									
  errors.go:26			0x75dd9c		89fe			MOVL DI, SI									
  errors.go:26			0x75dd9e		6690			NOPW										
  errors.go:26			0x75dda0		e8bb00d8ff		CALL fmt.errorf(SB)								
  errors.go:26			0x75dda5		4885c0			TESTQ AX, AX									
  errors.go:26			0x75dda8		7537			JNE 0x75dde1									
  errors.go:31			0x75ddaa		90			NOPL										
  errors.go:65			0x75ddab		b810000000		MOVL $0x10, AX									
  errors.go:65			0x75ddb0		488d1d29ec3800		LEAQ 0x38ec29(IP), BX								
  errors.go:65			0x75ddb7		b901000000		MOVL $0x1, CX									
  errors.go:65			0x75ddbc		0f1f4000		NOPL 0(AX)									
  errors.go:65			0x75ddc0		e89b35ccff		CALL runtime.mallocgcSmallScanNoHeaderSC2(SB)					
  errors.go:65			0x75ddc5		48c7400824000000	MOVQ $0x24, 0x8(AX)								
  errors.go:65			0x75ddcd		488d1516210600		LEAQ 0x62116(IP), DX								
  errors.go:65			0x75ddd4		488910			MOVQ DX, 0(AX)									
  members_string.go:4195	0x75ddd7		4889c3			MOVQ AX, BX									
  members_string.go:4195	0x75ddda		488d05afc93b00		LEAQ 0x3bc9af(IP), AX								
  members_string.go:4195	0x75dde1		31c9			XORL CX, CX									
  members_string.go:4195	0x75dde3		31ff			XORL DI, DI									
  members_string.go:4195	0x75dde5		4889c6			MOVQ AX, SI									
  members_string.go:4195	0x75dde8		4989d8			MOVQ BX, R8									
  members_string.go:4195	0x75ddeb		31c0			XORL AX, AX									
  members_string.go:4195	0x75dded		31db			XORL BX, BX									
  members_string.go:4195	0x75ddef		4881c490000000		ADDQ $0x90, SP									
  members_string.go:4195	0x75ddf6		5d			POPQ BP										
  members_string.go:4195	0x75ddf7		c3			RET										
  members_string.go:4193	0x75ddf8		4889442460		MOVQ AX, 0x60(SP)								
  members_string.go:4197	0x75ddfd		488b442470		MOVQ 0x70(SP), AX								
  members_string.go:4197	0x75de02		488b5c2468		MOVQ 0x68(SP), BX								
  members_string.go:4197	0x75de07		488b8c2488000000	MOVQ 0x88(SP), CX								
  members_string.go:4197	0x75de0f		488b7c2478		MOVQ 0x78(SP), DI								
  members_string.go:4197	0x75de14		e8a7e4e4ff		CALL github.com/mgomes/vibescript/vibes/value.Value.String(SB)			
  members_string.go:4197	0x75de19		488b4c2460		MOVQ 0x60(SP), CX								
  members_string.go:4197	0x75de1e		6690			NOPW										
  members_string.go:4197	0x75de20		e89b10f7ff		CALL github.com/mgomes/vibescript/internal/runtime.stringEffectiveOffset(SB)	
  members_string.go:4197	0x75de25		84db			TESTL BL, BL									
  members_string.go:4198	0x75de27		7448			JE 0x75de71									
  members_string.go:4203	0x75de29		488b9424e8000000	MOVQ 0xe8(SP), DX								
  members_string.go:4203	0x75de31		4c8b02			MOVQ 0(DX), R8									
  members_string.go:4203	0x75de34		4c8b4a08		MOVQ 0x8(DX), R9								
  members_string.go:4203	0x75de38		4c8b5210		MOVQ 0x10(DX), R10								
  members_string.go:4203	0x75de3c		4c8b5a18		MOVQ 0x18(DX), R11								
  members_string.go:4203	0x75de40		48890424		MOVQ AX, 0(SP)									
  members_string.go:4203	0x75de44		488b8424c0000000	MOVQ 0xc0(SP), AX								
  members_string.go:4203	0x75de4c		488b5c2470		MOVQ 0x70(SP), BX								
  members_string.go:4203	0x75de51		488b4c2468		MOVQ 0x68(SP), CX								
  members_string.go:4203	0x75de56		488bbc2488000000	MOVQ 0x88(SP), DI								
  members_string.go:4203	0x75de5e		488b742478		MOVQ 0x78(SP), SI								
  members_string.go:4203	0x75de63		e83805f8ff		CALL github.com/mgomes/vibescript/internal/runtime.stringRIndexResult(SB)	
  members_string.go:4203	0x75de68		4881c490000000		ADDQ $0x90, SP									
  members_string.go:4203	0x75de6f		5d			POPQ BP										
  members_string.go:4203	0x75de70		c3			RET										
  members_string.go:4199	0x75de71		31c0			XORL AX, AX									
  members_string.go:4199	0x75de73		31db			XORL BX, BX									
  members_string.go:4199	0x75de75		31c9			XORL CX, CX									
  members_string.go:4199	0x75de77		31ff			XORL DI, DI									
  members_string.go:4199	0x75de79		89de			MOVL BX, SI									
  members_string.go:4199	0x75de7b		4189c8			MOVL CX, R8									
  members_string.go:4199	0x75de7e		4881c490000000		ADDQ $0x90, SP									
  members_string.go:4199	0x75de85		5d			POPQ BP										
  members_string.go:4199	0x75de86		c3			RET										
  utf8.go:449			0x75de87		48ffc2			INCQ DX										
  utf8.go:448			0x75de8a		4c39e3			CMPQ BX, R12									
  utf8.go:448			0x75de8d		7e34			JLE 0x75dec3									
  utf8.go:448			0x75de8f		460fb62c20		MOVZX 0(AX)(R12*1), R13								
  utf8.go:448			0x75de94		4183fd7f		CMPL R13, $0x7f									
  utf8.go:448			0x75de98		7f05			JG 0x75de9f									
  utf8.go:448			0x75de9a		49ffc4			INCQ R12									
  utf8.go:448			0x75de9d		ebe8			JMP 0x75de87									
  utf8.go:448			0x75de9f		4889542450		MOVQ DX, 0x50(SP)								
  utf8.go:448			0x75dea4		4c89e1			MOVQ R12, CX									
  utf8.go:448			0x75dea7		e814f3d1ff		CALL runtime.decoderune(SB)							
  utf8.go:448			0x75deac		488b842480000000	MOVQ 0x80(SP), AX								
  utf8.go:449			0x75deb4		488b542450		MOVQ 0x50(SP), DX								
  utf8.go:449			0x75deb9		4989dc			MOVQ BX, R12									
  utf8.go:448			0x75debc		488b5c2458		MOVQ 0x58(SP), BX								
  utf8.go:448			0x75dec1		ebc4			JMP 0x75de87									
  members_string.go:4188	0x75dec3		4c8ba424f0000000	MOVQ 0xf0(SP), R12								
  members_string.go:4188	0x75decb		4983fc02		CMPQ R12, $0x2									
  members_string.go:4191	0x75decf		4889d0			MOVQ DX, AX									
  members_string.go:4191	0x75ded2		e98dfeffff		JMP 0x75dd64									
  members_string.go:4187	0x75ded7		4889442428		MOVQ AX, 0x28(SP)								
  members_string.go:4187	0x75dedc		48895c2430		MOVQ BX, 0x30(SP)								
  members_string.go:4187	0x75dee1		48894c2438		MOVQ CX, 0x38(SP)								
  members_string.go:4187	0x75dee6		48897c2440		MOVQ DI, 0x40(SP)								
  members_string.go:4187	0x75deeb		4889742448		MOVQ SI, 0x48(SP)								
  members_string.go:4187	0x75def0		4c89442450		MOVQ R8, 0x50(SP)								
  members_string.go:4187	0x75def5		4c894c2458		MOVQ R9, 0x58(SP)								
  members_string.go:4187	0x75defa		4c89542460		MOVQ R10, 0x60(SP)								
  members_string.go:4187	0x75deff		4c895c2468		MOVQ R11, 0x68(SP)								
  members_string.go:4187	0x75df04		e8f7e6d2ff		CALL runtime.morestack_noctxt.abi0(SB)						
  members_string.go:4187	0x75df09		488b442428		MOVQ 0x28(SP), AX								
  members_string.go:4187	0x75df0e		488b5c2430		MOVQ 0x30(SP), BX								
  members_string.go:4187	0x75df13		488b4c2438		MOVQ 0x38(SP), CX								
  members_string.go:4187	0x75df18		488b7c2440		MOVQ 0x40(SP), DI								
  members_string.go:4187	0x75df1d		488b742448		MOVQ 0x48(SP), SI								
  members_string.go:4187	0x75df22		4c8b442450		MOVQ 0x50(SP), R8								
  members_string.go:4187	0x75df27		4c8b4c2458		MOVQ 0x58(SP), R9								
  members_string.go:4187	0x75df2c		4c8b542460		MOVQ 0x60(SP), R10								
  members_string.go:4187	0x75df31		4c8b5c2468		MOVQ 0x68(SP), R11								
  members_string.go:4187	0x75df36		e905fdffff		JMP github.com/mgomes/vibescript/internal/runtime.stringMemberQuery.func27(SB)	

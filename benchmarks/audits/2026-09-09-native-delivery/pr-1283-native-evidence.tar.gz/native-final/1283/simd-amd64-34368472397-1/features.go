package main

import (
    "fmt"
    "simd/archsimd"
)

func main() {
    fmt.Println(archsimd.X86.AVX2())
}

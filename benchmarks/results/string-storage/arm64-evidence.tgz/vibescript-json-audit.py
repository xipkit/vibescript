"""Compare preserved engine observations and select intentional counter changes."""

from __future__ import annotations

from collections import Counter, defaultdict
import json
from pathlib import Path
import sys

sys.path.insert(0, "/tmp/vibescript-json-bytes/scripts")
import golden


def main() -> None:
    """Reject stable outcome differences while retaining every counter delta."""
    before_path, after_path, output_path = map(Path, sys.argv[1:])
    before = {
        (row["corpus"], row["id"]): golden.engine_record(row)
        for row in golden.read_jsonl(before_path)
    }
    varying = {
        (name, row["id"])
        for name, corpus in golden.CORPORA.items()
        if corpus.kind == "engine" and not corpus.inline
        for row in golden.read_jsonl(corpus.golden)
        if "varies" in row
    }
    changes, quotas, unstable, unexpected = [], [], [], []
    selected = defaultdict(list)
    totals = Counter()
    for row in golden.read_jsonl(after_path):
        key = row["corpus"], row["id"]
        previous, old_count = before.pop(key)
        current, new_count = golden.engine_record(row)
        totals[key[0]] += 1
        if key in varying:
            if golden.outcome_class(previous) != golden.outcome_class(current):
                unexpected.append({"case": key, "before": previous, "after": current})
            elif previous != current or old_count != new_count:
                unstable.append(key)
            continue
        if previous != current:
            entry = {"case": key, "before": previous, "after": current}
            quota = any(
                record.get("error", {}).get("kind") in golden.QUOTA_KINDS
                for record in (previous, current)
            )
            if key[0] == "replay" and quota:
                quotas.append(entry)
            else:
                unexpected.append(entry)
        if old_count != new_count:
            changes.append({"case": key, "before": old_count, "after": new_count})
            selected[key[0]].append(key[1])
    assert not before, f"Missing {len(before)} observations"
    report = {
        "cases": dict(totals),
        "counter_changes": changes,
        "quota_changes": quotas,
        "varying_cases": unstable,
        "unexpected_changes": unexpected,
    }
    output_path.write_text(json.dumps(report, indent=2) + "\n")
    output_path.with_suffix(".cases.json").write_text(json.dumps(selected, indent=2) + "\n")
    print(json.dumps({
        "cases": dict(totals),
        "counter_changes": len(changes),
        "quota_changes": len(quotas),
        "varying_cases": unstable,
        "unexpected_changes": unexpected[:20],
    }, indent=2))
    if unexpected:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

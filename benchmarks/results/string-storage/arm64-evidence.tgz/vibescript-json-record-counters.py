"""Keep golden observations and unrelated drift while accepting audited counter deltas."""

from __future__ import annotations

import gzip
import json
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, "/tmp/vibescript-json-bytes/scripts")
import golden


def original(path: Path) -> bytes:
    """Read the unchanged worktree baseline for one tracked golden file."""
    relative = path.relative_to(golden.ROOT)
    return subprocess.check_output(["git", "show", f"HEAD:{relative}"], cwd=golden.ROOT)


def main() -> None:
    """Validate the two-run recording, then preserve pre-existing counter offsets."""
    audit = json.loads(Path(sys.argv[1]).read_text())
    assert not audit["unexpected_changes"]
    by_corpus: dict[str, list[dict]] = {}
    for change in audit["counter_changes"]:
        by_corpus.setdefault(change["case"][0], []).append(change)
    replacements: dict[Path, list[list]] = {}
    stats: dict[str, dict] = {}
    for name, changes in by_corpus.items():
        corpus = golden.CORPORA[name]
        previous = {
            row[0]: row[1:]
            for line in gzip.decompress(original(corpus.counters)).splitlines()
            if (row := json.loads(line))
        }
        recorded = golden.load_counters(corpus)
        updated = dict(previous)
        offsets, variable, changed = 0, 0, 0
        for entry in changes:
            cid = entry["case"][1]
            before, after = entry["before"], entry["after"]
            observed = recorded.get(cid)
            if observed == [] or previous.get(cid) == []:
                variable += 1
                continue
            assert observed == after, (name, cid, after, observed)
            if after is None:
                updated.pop(cid, None)
            elif before is not None and cid in previous:
                offsets += previous[cid] != before
                updated[cid] = [old + new - base for old, new, base in zip(previous[cid], after, before)]
                assert all(value >= 0 for value in updated[cid]), (name, cid)
            else:
                updated[cid] = after
            changed += updated.get(cid) != previous.get(cid)
        selected = {entry["case"][1] for entry in changes}
        assert all(updated[cid] == values for cid, values in previous.items() if cid not in selected)
        replacements[corpus.counters] = [[cid, *updated[cid]] for cid in sorted(updated)]
        stats[name] = {"changed": changed, "preserved_offsets": offsets, "preserved_variable": variable}
    for path, rows in replacements.items():
        golden.write_jsonl(path, rows)
    for name in by_corpus:
        corpus = golden.CORPORA[name]
        if not corpus.inline:
            corpus.golden.write_bytes(original(corpus.golden))
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()

VIBE-205 a7daf27b physical OTIS evidence
Base 7ab5ea12a4b87a438789a2a347b4a0d399a05f4d
Head a7daf27b8386d2565fce32252a3390d811e64a11
Two independent axes; summaries and full phase curves are separate files.
Each timing file retains warmup and 15 measured rounds, 32 groups each; no rejected groups.
Peak accepted load: 3.35498046875. Output/accounting validation passed all six cases at all 256 placements.
Sample of exact SIMD head binary reaches put_run including the new short-span branch; sample checksum verified after rebuild.
Assembly: helper stack references are unchanged in count (14 each), including buffer initialization and prologue/epilogue; no stack mask reload in the helper loops. Both prefix and Unicode helpers have only entry/exit stack references in both modes and revisions.
Writer frame SIMD 0x120 both; portable 0x160 both, compared to 0x170 for rejected b9380440. Both revisions save x25 in the same stack slot; head has one extra x25 reload on a new path leading to write_text. Writer still uses stack for deferred steps and error state; do not interpret this as a blanket no-spill assertion.
Independent axes do not establish arbitrary joint layout robustness; no crossed control was run.
Instruction medians per call (96 estimates per side):
portable-run-counts.json
  lines_4k: 65447 -> 65476
  unicode_4k: 112321 -> 112233
  lone_escapes_4k: 282641 -> 136272
portable-string-counts.json
  lines_4k: 65385 -> 65572
  unicode_4k: 112285 -> 112334
  lone_escapes_4k: 282599 -> 136335
simd-run-counts.json
  lines_4k: 50008 -> 50243
  unicode_4k: 112248 -> 112275
  lone_escapes_4k: 254055 -> 135340
simd-string-counts.json
  lines_4k: 50095 -> 50178
  unicode_4k: 112310 -> 112296
  lone_escapes_4k: 254102 -> 135305

import collections,itertools,json,sys
from pathlib import Path
root=Path('/private/tmp/vibescript-json-simd')
sys.path.insert(0,str(root/'scripts'))
import golden

before=open('/tmp/json-rebase-before-observations.jsonl')
after=open('/tmp/json-rebase-after-observations.jsonl')
changes={}; observations=[];counts=collections.Counter();total=0
recorded={name:golden.load_counters(corpus) for name,corpus in golden.CORPORA.items() if corpus.kind=='engine'}
for left,right in itertools.zip_longest(before,after):
 assert left is not None and right is not None
 a,b=json.loads(left),json.loads(right)
 key=a['corpus'],a['id']
 assert key==(b['corpus'],b['id'])
 total+=1
 ar,ac=golden.engine_record(a);br,bc=golden.engine_record(b)
 if ar!=br:observations.append({'corpus':key[0],'id':key[1],'before':ar,'after':br})
 if ac is not None and bc is not None and ac!=bc:
  changes.setdefault(key[0],{})[key[1]]={'before':ac,'after':bc,'upstream_recorded':recorded[key[0]].get(key[1])}
  for i,name in enumerate(['steps','peak','retained']):
   if ac[i]!=bc[i]:counts[name]+=1
   if bc[i]>ac[i]:counts[name+'_increased']+=1
Path('/tmp/json-rebase-counter-audit.json').write_text(json.dumps({'cases':total,'counts':dict(counts),'changes':changes,'observation_differences':observations},indent=2)+'\n')
Path('/tmp/json-rebase-counter-cases.json').write_text(json.dumps({c:sorted(v) for c,v in changes.items()},indent=2)+'\n')
print('Counters:',dict(counts));print('Corpora:',{c:len(v) for c,v in changes.items()});print('Observation differences:',[(r['corpus'],r['id']) for r in observations])
assert counts['steps']==0

import pathlib,sys,os,subprocess
root=pathlib.Path('/tmp/json-rebase-bench')
os.environ['CARGO_NET_OFFLINE']='true'
os.environ['PATH']='/opt/homebrew/bin:'+str(pathlib.Path.home()/'.cargo/bin')+':'+os.environ['PATH']
os.chdir(root)
def check_idle():
 p=subprocess.run(['pgrep','-fl','[g]ate.sh'],capture_output=True,text=True)
 assert p.returncode==1,p.stdout
check_idle()
sys.path.insert(0,str(root/'scripts'))
import compare
original=compare.json_benchmark_cases
compare.json_benchmark_cases=lambda:[c for c in original() if any(c['name']==f'json_api_{kind}_1m/{mode}' for kind in ['parse','shape','array','project','stringify'] for mode in ['metered','unlimited'])]
sys.argv=['scripts/compare.py','--skip-build','--rounds','4','--suite','json','--baseline','/tmp/json-rebase-baseline-bins','--out','/tmp/json-rebase-arm64-repeat']
compare.main()
check_idle()

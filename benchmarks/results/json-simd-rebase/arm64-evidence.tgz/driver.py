import importlib, pathlib, shutil, subprocess, sys, os
root=pathlib.Path('/tmp/json-rebase-bench')
baseline=pathlib.Path('/tmp/json-rebase-baseline-bins');baseline.mkdir(exist_ok=False)
os.environ['CARGO_NET_OFFLINE']='true'
os.environ['PATH']='/opt/homebrew/bin:'+str(pathlib.Path.home()/'.cargo/bin')+':'+os.environ['PATH']
os.chdir(root)
def check_idle():
 p=subprocess.run(['pgrep','-fl','[g]ate.sh'],capture_output=True,text=True)
 assert p.returncode==1,p.stdout
check_idle()
with open('/tmp/json-rebase-baseline-build-darwin.log','w') as log:
 for name,features in [('rust-portable',[]),('rust-simd',['simd']),('rust-portable-alloc',['allocation-stats']),('rust-simd-alloc',['simd','allocation-stats'])]:
  command=['./scripts/cargo','build','--offline','--release','--locked','--example','compare','--no-default-features']
  if features:command+=['--features',','.join(features)]
  subprocess.run(command,check=True,stdout=log,stderr=log)
  shutil.copy2('target/release/examples/compare',baseline/name)
(baseline/'revision').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
subprocess.run(['git','checkout','--detach','e83d53f'],check=True)
check_idle()
sys.path.insert(0,str(root/'scripts'))
import compare
original=compare.json_benchmark_cases
compare.json_benchmark_cases=lambda:[c for c in original() if any(c['name']==f'json_api_{kind}_1m/{mode}' for kind in ['parse','shape','array','project','stringify'] for mode in ['metered','unlimited'])]
sys.argv=['scripts/compare.py','--rounds','4','--suite','json','--baseline',str(baseline),'--out','/tmp/json-rebase-arm64']
compare.main()
check_idle()
